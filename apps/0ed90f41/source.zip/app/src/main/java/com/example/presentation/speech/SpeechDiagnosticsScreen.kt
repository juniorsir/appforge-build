package com.example.presentation.speech

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.Transcript
import com.example.domain.repository.SpeechRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpeechDiagnosticsScreen(
    onNavigateBack: () -> Unit,
    viewModel: SpeechDiagnosticsViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val partialTranscript by viewModel.partialTranscript.collectAsState()
    val finalTranscript by viewModel.finalTranscript.collectAsState()
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val speechDurationMs by viewModel.speechDurationMs.collectAsState()
    val streamingLatencyMs by viewModel.streamingLatencyMs.collectAsState()
    val recognitionState by viewModel.recognitionState.collectAsState()
    val errorState by viewModel.errorState.collectAsState()
    val transcriptHistory by viewModel.transcriptHistory.collectAsState()
    val connectionState by viewModel.connectionState.collectAsState()
    val sessionId by viewModel.sessionId.collectAsState()

    val isSimulationMode by viewModel.isSimulationMode.collectAsState()
    val simulatePacketLoss by viewModel.simulatePacketLoss.collectAsState()
    val simulateNoise by viewModel.simulateNoise.collectAsState()
    val simulateMultiLanguage by viewModel.simulateMultiLanguage.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Speech Diagnostics",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleLarge
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Pipeline Connection & State Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Pipeline Status",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        HorizontalDivider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.1f))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Connection", style = MaterialTheme.typography.bodyMedium)
                            SuggestionChip(
                                onClick = {},
                                label = { Text(connectionState.name) },
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = if (connectionState == com.example.domain.model.SessionState.ConnectionState.CONNECTED)
                                        Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
                                    labelColor = if (connectionState == com.example.domain.model.SessionState.ConnectionState.CONNECTED)
                                        Color(0xFF2E7D32) else Color(0xFFC62828)
                                )
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Recognition State", style = MaterialTheme.typography.bodyMedium)
                            SuggestionChip(
                                onClick = {},
                                label = { Text(recognitionState.name) },
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = when (recognitionState) {
                                        SpeechRepository.RecognitionState.LISTENING -> Color(0xFFE3F2FD)
                                        SpeechRepository.RecognitionState.PROCESSING -> Color(0xFFFFF3E0)
                                        SpeechRepository.RecognitionState.ERROR -> Color(0xFFFFEBEE)
                                        else -> MaterialTheme.colorScheme.surface
                                    },
                                    labelColor = when (recognitionState) {
                                        SpeechRepository.RecognitionState.LISTENING -> Color(0xFF1565C0)
                                        SpeechRepository.RecognitionState.PROCESSING -> Color(0xFFE65100)
                                        SpeechRepository.RecognitionState.ERROR -> Color(0xFFC62828)
                                        else -> MaterialTheme.colorScheme.onSurface
                                    }
                                )
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Session ID", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                text = sessionId.take(8).plus("..."),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            // Real-Time Metrics Banner
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Speech Timer Card
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp)
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = "Speech Timer",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Duration",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                            Text(
                                text = "%.1fs".format(speechDurationMs / 1000.0),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Streaming Latency Card
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp)
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Speed,
                                contentDescription = "Latency",
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Latency",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                            Text(
                                text = "${streamingLatencyMs}ms",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Current Language Card
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp)
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = "Language",
                                tint = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Language",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                            Text(
                                text = currentLanguage.uppercase(),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Error Display banner if any
            errorState?.let { err ->
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Error,
                                contentDescription = "Error",
                                tint = MaterialTheme.colorScheme.onErrorContainer
                            )
                            Text(
                                text = err,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }
                }
            }

            // Active Live Transcript Display View
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Streaming Transcript Preview",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 100.dp, max = 200.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surface)
                                .border(
                                    1.dp,
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(12.dp)
                        ) {
                            if (partialTranscript.isBlank() && finalTranscript.isBlank()) {
                                Text(
                                    text = "Ready to stream speech...\nSelect 'Start STT' below and speak into the microphone.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                                    modifier = Modifier.align(Alignment.Center),
                                    textAlign = TextAlign.Center
                                )
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    if (finalTranscript.isNotBlank()) {
                                        Text(
                                            text = finalTranscript,
                                            style = MaterialTheme.typography.bodyLarge,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    if (partialTranscript.isNotBlank()) {
                                        Text(
                                            text = "$partialTranscript...",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Normal,
                                            modifier = Modifier.animateContentSize()
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Core Action Buttons
            item {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.startStt() },
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                                .testTag("start_stt_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (recognitionState == SpeechRepository.RecognitionState.LISTENING)
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
                                else MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Icon(Icons.Default.Mic, contentDescription = "Start")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Start STT")
                        }

                        Button(
                            onClick = { viewModel.stopStt() },
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                                .testTag("stop_stt_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (recognitionState == SpeechRepository.RecognitionState.LISTENING)
                                    Color(0xFFD32F2F) else MaterialTheme.colorScheme.secondary
                            )
                        ) {
                            Icon(Icons.Default.Stop, contentDescription = "Stop")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Stop STT")
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.clearTranscript() },
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("clear_transcript_button")
                        ) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = "Clear")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Clear")
                        }

                        OutlinedButton(
                            onClick = { viewModel.copyTranscript(context) },
                            modifier = Modifier
                                .weight(1.5f)
                                .height(44.dp)
                                .testTag("copy_transcript_button")
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Copy")
                        }

                        OutlinedButton(
                            onClick = { viewModel.exportTranscript(context) },
                            modifier = Modifier
                                .weight(1.5f)
                                .height(44.dp)
                                .testTag("export_transcript_button")
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Export")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Export")
                        }
                    }
                }
            }

            // High Fidelity Diagnostics Testing Controls
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.2f)
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Diagnostics Simulators",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        HorizontalDivider(color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.1f))

                        // Simulation toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Mock STT Backend", style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    "Simulates Whisper streams locally",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }
                            Switch(
                                checked = isSimulationMode,
                                onCheckedChange = { viewModel.isSimulationMode.value = it }
                            )
                        }

                        AnimatedVisibility(visible = isSimulationMode) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                // Packet loss simulation
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Simulate Packet Loss", style = MaterialTheme.typography.bodyMedium)
                                        Text(
                                            "Tests pipeline dropout recovery",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                        )
                                    }
                                    Switch(
                                        checked = simulatePacketLoss,
                                        onCheckedChange = { viewModel.simulatePacketLoss.value = it }
                                    )
                                }

                                // Noise simulation
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Simulate Ambient Noise", style = MaterialTheme.typography.bodyMedium)
                                        Text(
                                            "Inserts cough/static metadata tags",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                        )
                                    }
                                    Switch(
                                        checked = simulateNoise,
                                        onCheckedChange = { viewModel.simulateNoise.value = it }
                                    )
                                }

                                // Multi language simulation
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Simulate Multi-Language", style = MaterialTheme.typography.bodyMedium)
                                        Text(
                                            "Cycles through EN, ES, FR, JA",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                        )
                                    }
                                    Switch(
                                        checked = simulateMultiLanguage,
                                        onCheckedChange = { viewModel.simulateMultiLanguage.value = it }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Live Speech Transcript Log History
            item {
                Text(
                    text = "Transcript Session History",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            if (transcriptHistory.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "History is empty.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                        )
                    }
                }
            } else {
                items(transcriptHistory.reversed(), key = { it.id }) { transcript ->
                    TranscriptRowItem(transcript = transcript)
                }
            }
        }
    }
}

@Composable
fun TranscriptRowItem(transcript: Transcript) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SuggestionChip(
                        onClick = {},
                        label = { Text(transcript.language.uppercase()) },
                        colors = SuggestionChipDefaults.suggestionChipColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer,
                            labelColor = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    )
                    Text(
                        text = "Conf: %.2f".format(transcript.confidence),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }

                // Friendly, objective relative timestamp format
                val timeString = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
                    .format(java.util.Date(transcript.timestamp))
                Text(
                    text = timeString,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                )
            }
            Text(
                text = transcript.text,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
