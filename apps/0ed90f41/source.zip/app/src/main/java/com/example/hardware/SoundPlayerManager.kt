package com.example.hardware

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.net.Uri
import android.util.Log
import java.io.File

class SoundPlayerManager(private val context: Context) {

    private val TAG = "SoundPlayerManager"
    private var mediaPlayer: MediaPlayer? = null
    private var toneGenerator: ToneGenerator? = null

    fun playSystemSound(type: String = "notification", loop: Boolean = false): Boolean {
        stop()
        try {
            val ringtoneType = when (type.lowercase()) {
                "alarm" -> RingtoneManager.TYPE_ALARM
                "ringtone", "ring" -> RingtoneManager.TYPE_RINGTONE
                else -> RingtoneManager.TYPE_NOTIFICATION
            }

            val soundUri: Uri = RingtoneManager.getDefaultUri(ringtoneType)
                ?: RingtoneManager.getActualDefaultRingtoneUri(context, ringtoneType)
                ?: return false

            mediaPlayer = MediaPlayer().apply {
                setDataSource(context, soundUri)
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .setUsage(
                            if (type.equals("alarm", ignoreCase = true)) AudioAttributes.USAGE_ALARM
                            else if (type.equals("ringtone", ignoreCase = true)) AudioAttributes.USAGE_NOTIFICATION_RINGTONE
                            else AudioAttributes.USAGE_NOTIFICATION
                        )
                        .build()
                )
                isLooping = loop
                setOnCompletionListener {
                    if (!loop) stop()
                }
                prepare()
                start()
            }
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Error playing system sound: ${e.message}", e)
            return false
        }
    }

    fun playAudioFile(pathOrUri: String, loop: Boolean = false): Boolean {
        stop()
        try {
            mediaPlayer = MediaPlayer().apply {
                if (pathOrUri.startsWith("content://") || pathOrUri.startsWith("file://") || pathOrUri.startsWith("http://") || pathOrUri.startsWith("https://")) {
                    setDataSource(context, Uri.parse(pathOrUri))
                } else {
                    val file = File(pathOrUri)
                    if (!file.exists()) return false
                    setDataSource(file.absolutePath)
                }
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                isLooping = loop
                setOnCompletionListener {
                    if (!loop) stop()
                }
                prepare()
                start()
            }
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Error playing audio file '$pathOrUri': ${e.message}", e)
            return false
        }
    }

    fun playBeep(toneType: Int = ToneGenerator.TONE_PROP_BEEP, durationMs: Int = 150): Boolean {
        try {
            if (toneGenerator == null) {
                toneGenerator = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
            }
            toneGenerator?.startTone(toneType, durationMs)
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to play tone generator beep: ${e.message}")
            return false
        }
    }

    fun stop() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (e: Exception) {
            Log.w(TAG, "Failed to release MediaPlayer: ${e.message}")
        }
    }
}
