package com.example.aios.core

data class AgentIdentity(
    val id: String,
    val name: String,
    val description: String,
    val capabilities: List<String>,
    val permissions: List<String>,
    val requiredTools: List<String>,
    val priority: Int,
    val version: String
)
