package com.example.capabilities.contacts

import com.example.capabilities.CapabilityResult

data class ContactInfo(
    val name: String,
    val phoneNumber: String?
)

interface ContactRepository {
    suspend fun getContacts(): CapabilityResult<List<ContactInfo>>
    suspend fun searchContacts(query: String): CapabilityResult<List<ContactInfo>>
}
