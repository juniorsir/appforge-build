package com.example.aios.workflows

import com.example.aios.planning.TaskPlanner
import com.example.aios.planning.Goal
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

data class Workflow(
    val id: String,
    val name: String,
    val description: String,
    val stepGoals: List<String>
)

@Singleton
class WorkflowEngine @Inject constructor(
    private val taskPlanner: TaskPlanner
) {
    private val _workflows = MutableStateFlow<List<Workflow>>(emptyList())
    val workflows: StateFlow<List<Workflow>> = _workflows

    private val _activeWorkflowRuns = MutableStateFlow<Map<String, List<Goal>>>(emptyMap())
    val activeWorkflowRuns: StateFlow<Map<String, List<Goal>>> = _activeWorkflowRuns

    init {
        _workflows.value = listOf(
            Workflow(
                id = "morning_routine",
                name = "Morning Routine Coordinator",
                description = "Coactivates Calendar, Translation, and Notification agents.",
                stepGoals = listOf("Fetch calendar routine", "Translate agenda", "Notify upcoming conflicts")
            ),
            Workflow(
                id = "coding_session",
                name = "Software Coding Session",
                description = "Coordinates Planner, Coding, and Developer agents.",
                stepGoals = listOf("Design system blueprint", "Compile code files", "Verify compilation coverage")
            ),
            Workflow(
                id = "travel_planning",
                name = "Travel Itinerary Blueprint",
                description = "Coactivates Browser and Calendar agents.",
                stepGoals = listOf("Search flight catalogs", "Mark travel bookings on Calendar")
            ),
            Workflow(
                id = "research_session",
                name = "Digest Scientific Literature",
                description = "Coactivates Research and Memory agents.",
                stepGoals = listOf("Retrieve context cache", "Draft output briefing")
            )
        )
    }

    suspend fun executeWorkflow(workflowId: String) {
        val workflow = _workflows.value.find { it.id == workflowId } ?: return
        val runs = mutableListOf<Goal>()
        for (goalDesc in workflow.stepGoals) {
            val goal = taskPlanner.planAndExecute(goalDesc)
            runs.add(goal)
        }
        val current = _activeWorkflowRuns.value.toMutableMap()
        current[workflowId] = runs
        _activeWorkflowRuns.value = current
    }

    fun addCustomWorkflow(workflow: Workflow) {
        val list = _workflows.value.toMutableList()
        list.add(workflow)
        _workflows.value = list
    }
}
