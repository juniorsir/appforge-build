package com.example.capabilities.work

import android.content.Context
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.example.capabilities.CapabilityResult
import com.example.workers.TelemetrySyncWorker
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

data class BackgroundWorkSummary(
    val isWorkManagerAvailable: Boolean,
    val activeWorkersCount: Int
)

interface BackgroundWorkRepository {
    fun getWorkManagerStatus(): CapabilityResult<BackgroundWorkSummary>
    fun scheduleOneTimeSync(): CapabilityResult<String>
}

@Singleton
class BackgroundWorkRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : BackgroundWorkRepository {

    override fun getWorkManagerStatus(): CapabilityResult<BackgroundWorkSummary> {
        return try {
            val wm = WorkManager.getInstance(context)
            val infos = wm.getWorkInfosByTag("TelemetrySyncWorker").get()
            val activeCount = infos.count { it.state == WorkInfo.State.RUNNING || it.state == WorkInfo.State.ENQUEUED }
            CapabilityResult.Success(
                BackgroundWorkSummary(
                    isWorkManagerAvailable = true,
                    activeWorkersCount = activeCount
                )
            )
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to query WorkManager: ${e.message}", e)
        }
    }

    override fun scheduleOneTimeSync(): CapabilityResult<String> {
        return try {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val request = OneTimeWorkRequestBuilder<TelemetrySyncWorker>()
                .setConstraints(constraints)
                .addTag("TelemetrySyncWorker")
                .build()

            WorkManager.getInstance(context).enqueue(request)
            CapabilityResult.Success(request.id.toString())
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to enqueue background work: ${e.message}", e)
        }
    }
}
