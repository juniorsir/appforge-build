package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/**
 * AURA ASSISTANT — Centralized Liquid Glass Specifications
 */
@Immutable
enum class AuraGlassLevel(
    val bgAlpha: Float,
    val borderAlpha: Float,
    val highlightAlpha: Float
) {
    LEVEL_1(bgAlpha = 0.04f, borderAlpha = 0.10f, highlightAlpha = 0.05f),
    LEVEL_2(bgAlpha = 0.06f, borderAlpha = 0.12f, highlightAlpha = 0.07f),
    LEVEL_3(bgAlpha = 0.08f, borderAlpha = 0.16f, highlightAlpha = 0.09f),
    ELEVATED(bgAlpha = 0.11f, borderAlpha = 0.22f, highlightAlpha = 0.12f),
    ACTIVE(bgAlpha = 0.14f, borderAlpha = 0.35f, highlightAlpha = 0.15f);

    fun backgroundColor(): Color = AuraColors.White.copy(alpha = bgAlpha)
    fun borderColor(): Color = AuraColors.White.copy(alpha = borderAlpha)

    fun createHighlightBrush(): Brush = Brush.verticalGradient(
        0.0f to AuraColors.White.copy(alpha = highlightAlpha),
        0.5f to AuraColors.White.copy(alpha = highlightAlpha * 0.3f),
        1.0f to AuraColors.Transparent
    )
}
