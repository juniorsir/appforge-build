package com.example.data.repository

import com.example.data.local.BrainDao
import com.example.data.local.PromptTemplateEntity
import com.example.domain.model.PromptTemplate
import com.example.domain.repository.PromptRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onStart

class PromptRepositoryImpl(
    private val brainDao: BrainDao
) : PromptRepository {

    override fun getPromptTemplate(id: String): Flow<PromptTemplate> {
        return brainDao.getPromptTemplateFlow(id)
            .onStart {
                // Pre-populate if missing
                val existing = brainDao.getPromptTemplateSync(id)
                if (existing == null) {
                    brainDao.insertPromptTemplate(
                        PromptTemplateEntity(
                            id = id,
                            systemPrompt = "You are Aura, an empathetic real-time AI companion. Keep your responses concise, conversational, and direct.",
                            developerPrompt = "Formatting rule: Do not use Markdown styling. Speak in natural plain text. Use occasional verbal fillers like 'hmm' or 'well' to sound human.",
                            userPromptTemplate = "{user_message}"
                        )
                    )
                }
            }
            .map { entity ->
                entity?.toDomain() ?: PromptTemplate()
            }
    }

    override suspend fun getPromptTemplateSync(id: String): PromptTemplate {
        val entity = brainDao.getPromptTemplateSync(id)
        if (entity == null) {
            val defaultTemplate = PromptTemplateEntity(
                id = id,
                systemPrompt = "You are Aura, an empathetic real-time AI companion. Keep your responses concise, conversational, and direct.",
                developerPrompt = "Formatting rule: Do not use Markdown styling. Speak in natural plain text. Use occasional verbal fillers like 'hmm' or 'well' to sound human.",
                userPromptTemplate = "{user_message}"
            )
            brainDao.insertPromptTemplate(defaultTemplate)
            return defaultTemplate.toDomain()
        }
        return entity.toDomain()
    }

    override suspend fun savePromptTemplate(template: PromptTemplate) {
        brainDao.insertPromptTemplate(template.toEntity())
    }

    override fun buildUserPrompt(template: String, variables: Map<String, String>): String {
        var result = template
        variables.forEach { (key, value) ->
            result = result.replace("{$key}", value)
        }
        return result
    }

    private fun PromptTemplateEntity.toDomain() = PromptTemplate(
        id = id,
        systemPrompt = systemPrompt,
        developerPrompt = developerPrompt,
        userPromptTemplate = userPromptTemplate
    )

    private fun PromptTemplate.toEntity() = PromptTemplateEntity(
        id = id,
        systemPrompt = systemPrompt,
        developerPrompt = developerPrompt,
        userPromptTemplate = userPromptTemplate
    )
}
