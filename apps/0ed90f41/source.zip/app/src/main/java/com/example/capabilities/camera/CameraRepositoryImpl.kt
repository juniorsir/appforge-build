package com.example.capabilities.camera

import android.content.Context
import com.example.camera.BackgroundCameraCaptureEngine
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CameraRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    private val backgroundCameraCaptureEngine: BackgroundCameraCaptureEngine
) : CameraRepository {
    override suspend fun takePicture(): CapabilityResult<String> {
        return backgroundCameraCaptureEngine.takePicture()
    }

    override suspend fun recordVideo(): CapabilityResult<String> {
        return backgroundCameraCaptureEngine.recordVideo()
    }
}

