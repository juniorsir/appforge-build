package com.example.ui.components.header

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.components.glass.AuraGlassSurface
import com.example.ui.theme.AuraBorders
import com.example.ui.theme.AuraColors
import com.example.ui.theme.AuraGlassLevel
import com.example.ui.theme.AuraShapes

/**
 * AURA ASSISTANT — Monochrome Vector Logo Mark
 * Optically centered waveform glyph with 5 balanced vertical bars
 * inside a circular smoked glass surface.
 */
@Composable
fun AuraLogo(
    modifier: Modifier = Modifier,
    size: Dp = 34.dp,
    barColor: Color = AuraColors.White,
    isSolidWhite: Boolean = false
) {
    if (isSolidWhite) {
        Box(
            modifier = modifier
                .size(size)
                .semantics { contentDescription = "AURA Assistant Logo" },
            contentAlignment = Alignment.Center
        ) {
            AuraGlassSurface(
                modifier = Modifier.size(size),
                shape = CircleShape,
                level = AuraGlassLevel.ACTIVE,
                customBgAlpha = 1.0f,
                customBorderAlpha = 0.0f,
                showHighlight = false
            ) {
                WaveformMark(
                    modifier = Modifier.size(size),
                    barColor = AuraColors.Black
                )
            }
        }
    } else {
        Box(
            modifier = modifier
                .size(size)
                .semantics { contentDescription = "AURA Assistant Logo" },
            contentAlignment = Alignment.Center
        ) {
            AuraGlassSurface(
                modifier = Modifier.size(size),
                shape = CircleShape,
                level = AuraGlassLevel.LEVEL_2,
                borderWidth = AuraBorders.WidthSubtle,
                showHighlight = true
            ) {
                WaveformMark(
                    modifier = Modifier.size(size),
                    barColor = barColor
                )
            }
        }
    }
}

@Composable
private fun WaveformMark(
    modifier: Modifier = Modifier,
    barColor: Color = AuraColors.White
) {
    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height

        // Optical centering: waveform area occupies ~50% of the diameter
        val waveAreaWidth = width * 0.48f
        val waveAreaHeight = height * 0.48f

        val startX = (width - waveAreaWidth) / 2f
        val centerY = height / 2f

        // 5 balanced waveform bars: heights relative to waveAreaHeight
        val barRatios = floatArrayOf(0.40f, 0.75f, 1.00f, 0.75f, 0.40f)
        val numBars = barRatios.size
        val barWidth = waveAreaWidth / (numBars * 1.8f)
        val barSpacing = (waveAreaWidth - (numBars * barWidth)) / (numBars - 1)
        val cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)

        for (i in 0 until numBars) {
            val barH = waveAreaHeight * barRatios[i]
            val x = startX + i * (barWidth + barSpacing)
            val y = centerY - (barH / 2f)

            drawRoundRect(
                color = barColor,
                topLeft = Offset(x, y),
                size = Size(barWidth, barH),
                cornerRadius = cornerRadius
            )
        }
    }
}
