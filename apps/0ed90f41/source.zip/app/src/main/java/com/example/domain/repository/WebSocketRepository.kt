package com.example.domain.repository

import com.example.domain.model.NetworkMessage
import com.example.domain.model.SessionState
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

interface WebSocketRepository {
    /**
     * Observable stream of the active socket connection state.
     */
    val connectionState: StateFlow<SessionState.ConnectionState>

    /**
     * Stream of parsed, valid messages received from the local server.
     */
    val incomingMessages: SharedFlow<NetworkMessage>

    /**
     * Stream of raw unparsed JSON string messages received from the socket.
     */
    val incomingRawMessages: SharedFlow<String>

    /**
     * Live metrics of the low-latency socket pipeline.
     */
    val latencyMs: StateFlow<Long>
    val bytesSent: StateFlow<Long>
    val bytesReceived: StateFlow<Long>
    val queueSize: StateFlow<Int>
    val retryCount: StateFlow<Int>
    val connectionLogs: StateFlow<List<String>>
    val lastFailureReason: StateFlow<String?>
    val sessionId: StateFlow<String?>
    val lastConnectedAt: StateFlow<Long?>
    val activeUrlFlow: StateFlow<String>

    /**
     * Establishes a WebSocket connection to the local Termux server.
     */
    suspend fun connect(url: String)

    /**
     * Closes the active WebSocket connection.
     */
    suspend fun disconnect()

    /**
     * Sends a structured message. If disconnected, message is queued in-memory or persisted,
     * and automatically resent upon reconnection.
     */
    suspend fun sendMessage(message: NetworkMessage)

    /**
     * Sends a raw JSON string message directly over the active socket without serialization.
     */
    suspend fun sendRaw(text: String): Boolean

    /**
     * Clears local in-memory developer connection logs.
     */
    fun clearLogs()

    /**
     * Appends a developer log entry.
     */
    fun addLog(entry: String)
}
