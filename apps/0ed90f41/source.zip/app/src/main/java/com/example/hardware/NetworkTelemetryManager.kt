package com.example.hardware

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.telephony.TelephonyManager
import android.util.Log
import java.net.Inet4Address
import java.net.NetworkInterface

class NetworkTelemetryManager(private val context: Context) {

    private val TAG = "NetworkTelemetry"

    data class NetworkTelemetry(
        val activeTransport: String, // "WIFI", "CELLULAR", "ETHERNET", "VPN", "OFFLINE"
        val isConnected: Boolean,
        val isMetered: Boolean,
        val wifi: WifiTelemetry? = null,
        val cellular: CellularTelemetry? = null,
        val localIpv4Addresses: List<String> = emptyList()
    )

    data class WifiTelemetry(
        val ssid: String,
        val bssid: String,
        val rssiDbm: Int,
        val signalLevel: Int, // 0-4 bars
        val linkSpeedMbps: Int,
        val frequencyMhz: Int,
        val wifiStandard: String,
        val ipAddress: String?
    )

    data class CellularTelemetry(
        val carrierName: String,
        val networkType: String,
        val isRoaming: Boolean,
        val simState: String
    )

    fun getTelemetry(): NetworkTelemetry {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val activeNet = cm?.activeNetwork
        val caps = cm?.getNetworkCapabilities(activeNet)

        val isConnected = caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        val isMetered = caps != null && !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)

        val transport = when {
            caps == null -> "OFFLINE"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WIFI"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "CELLULAR"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ETHERNET"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
            else -> "OTHER"
        }

        var wifiTelemetry: WifiTelemetry? = null
        if (transport == "WIFI" || caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) {
            try {
                val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
                val info: WifiInfo? = wm?.connectionInfo
                if (info != null) {
                    val rawSsid = info.ssid.replace("\"", "")
                    val ssid = if (rawSsid == "<unknown ssid>") "Connected Wi-Fi" else rawSsid
                    val rssi = info.rssi
                    val level = WifiManager.calculateSignalLevel(rssi, 5)
                    val speed = info.linkSpeed
                    val freq = info.frequency
                    val std = if (freq > 4900) "5 GHz (802.11ac/ax)" else "2.4 GHz (802.11b/g/n)"
                    
                    val ipInt = info.ipAddress
                    val ipStr = if (ipInt != 0) {
                        String.format(
                            "%d.%d.%d.%d",
                            ipInt and 0xff,
                            ipInt shr 8 and 0xff,
                            ipInt shr 16 and 0xff,
                            ipInt shr 24 and 0xff
                        )
                    } else null

                    wifiTelemetry = WifiTelemetry(
                        ssid = ssid,
                        bssid = info.bssid ?: "00:00:00:00:00:00",
                        rssiDbm = rssi,
                        signalLevel = level,
                        linkSpeedMbps = speed,
                        frequencyMhz = freq,
                        wifiStandard = std,
                        ipAddress = ipStr
                    )
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed to read Wi-Fi details: ${e.message}")
            }
        }

        var cellTelemetry: CellularTelemetry? = null
        try {
            val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
            if (tm != null) {
                val carrier = tm.networkOperatorName.ifBlank { tm.simOperatorName }.ifBlank { "Mobile Operator" }
                val isRoaming = tm.isNetworkRoaming
                val simStateStr = when (tm.simState) {
                    TelephonyManager.SIM_STATE_READY -> "READY"
                    TelephonyManager.SIM_STATE_ABSENT -> "ABSENT"
                    TelephonyManager.SIM_STATE_PIN_REQUIRED -> "PIN_REQUIRED"
                    TelephonyManager.SIM_STATE_PUK_REQUIRED -> "PUK_REQUIRED"
                    else -> "UNKNOWN"
                }

                val netType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    try {
                        when (tm.dataNetworkType) {
                            TelephonyManager.NETWORK_TYPE_NR -> "5G (NR)"
                            TelephonyManager.NETWORK_TYPE_LTE -> "4G (LTE)"
                            TelephonyManager.NETWORK_TYPE_HSPAP,
                            TelephonyManager.NETWORK_TYPE_HSPA -> "3G (HSPA+)"
                            TelephonyManager.NETWORK_TYPE_UMTS -> "3G (UMTS)"
                            TelephonyManager.NETWORK_TYPE_EDGE -> "2G (EDGE)"
                            TelephonyManager.NETWORK_TYPE_GPRS -> "2G (GPRS)"
                            else -> "Cellular"
                        }
                    } catch (e: Exception) {
                        "Cellular"
                    }
                } else "Cellular"

                cellTelemetry = CellularTelemetry(
                    carrierName = carrier,
                    networkType = netType,
                    isRoaming = isRoaming,
                    simState = simStateStr
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to read Cellular details: ${e.message}")
        }

        val ipList = mutableListOf<String>()
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (iface.isLoopback || !iface.isUp) continue
                val addrs = iface.inetAddresses
                while (addrs.hasMoreElements()) {
                    val addr = addrs.nextElement()
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        ipList.add("${iface.name}: ${addr.hostAddress}")
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to get IPv4 interfaces: ${e.message}")
        }

        return NetworkTelemetry(
            activeTransport = transport,
            isConnected = isConnected,
            isMetered = isMetered,
            wifi = wifiTelemetry,
            cellular = cellTelemetry,
            localIpv4Addresses = ipList
        )
    }
}
