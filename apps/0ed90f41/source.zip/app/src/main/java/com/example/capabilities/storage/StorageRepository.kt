package com.example.capabilities.storage

import com.example.capabilities.CapabilityResult

interface StorageRepository {
    suspend fun readTextFile(uriString: String): CapabilityResult<String>
    suspend fun writeTextFile(fileName: String, content: String): CapabilityResult<String> // Returns new URI
    suspend fun deleteFile(uriString: String): CapabilityResult<Boolean>
}
