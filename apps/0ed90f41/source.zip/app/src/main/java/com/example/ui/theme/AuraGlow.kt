package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * AURA ASSISTANT — Centralized Glow Tokens
 * Subtle monochrome depth without aggressive bloom or neon effects.
 */
@Immutable
enum class AuraGlowLevel(
    val alpha: Float,
    val radius: Dp
) {
    NONE(alpha = 0.0f, radius = 0.dp),
    SOFT(alpha = 0.06f, radius = 12.dp),
    ACTIVE(alpha = 0.15f, radius = 20.dp);

    fun glowColor(): Color = AuraColors.White.copy(alpha = alpha)
}
