package com.example.data.repository

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import com.example.domain.repository.NetworkStateRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

class NetworkStateRepositoryImpl(
    private val context: Context,
    private val scope: CoroutineScope
) : NetworkStateRepository {

    private val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager

    private val _isNetworkAvailable = MutableStateFlow(false)
    override val isNetworkAvailable: StateFlow<Boolean> = _isNetworkAvailable.asStateFlow()

    private val _isLocalhostReachable = MutableStateFlow(false)
    override val isLocalhostReachable: StateFlow<Boolean> = _isLocalhostReachable.asStateFlow()

    init {
        if (connectivityManager != null) {
            val networkRequest = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()

            _isNetworkAvailable.value = isCurrentNetworkActive()

            try {
                connectivityManager.registerNetworkCallback(networkRequest, object : ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: Network) {
                        _isNetworkAvailable.value = true
                        scope.launch {
                            checkLocalhostReachabilitySync()
                        }
                    }

                    override fun onLost(network: Network) {
                        _isNetworkAvailable.value = false
                        _isLocalhostReachable.value = false
                    }
                })
            } catch (e: Exception) {
                // Fallback if permission issues or context limitations occur in background tests
                _isNetworkAvailable.value = true
            }
        } else {
            _isNetworkAvailable.value = true
        }

        // Periodically verify localhost reachability in a robust background loop
        scope.launch(Dispatchers.IO) {
            while (true) {
                checkLocalhostReachabilitySync()
                delay(10000) // check every 10 seconds
            }
        }
    }

    private fun isCurrentNetworkActive(): Boolean {
        val cm = connectivityManager ?: return false
        val activeNetwork = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(activeNetwork) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private suspend fun checkLocalhostReachabilitySync() {
        val reachable = checkLocalhostReachability("127.0.0.1", 8000)
        _isLocalhostReachable.value = reachable
    }

    override suspend fun checkLocalhostReachability(host: String, port: Int): Boolean = withContext(Dispatchers.IO) {
        try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), 1000)
                true
            }
        } catch (e: Exception) {
            false
        }
    }
}
