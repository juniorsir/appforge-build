package com.example.domain.repository

data class HealthCheckResult(
    val isSuccess: Boolean,
    val statusCode: Int? = null,
    val statusMessage: String? = null,
    val rawBody: String? = null,
    val error: String? = null
)

interface HttpRepository {
    /**
     * Checks if the Termux server HTTP endpoint is active.
     */
    suspend fun checkServerHealth(customUrl: String? = null): Boolean

    /**
     * Checks if the Termux server HTTP endpoint is active, returning granular diagnostic details.
     */
    suspend fun checkServerHealthDetailed(customUrl: String? = null): HealthCheckResult

    /**
     * Optional placeholder to send an authentication request.
     */
    suspend fun authenticateClient(token: String): Boolean

    /**
     * Optional HTTP request to send a text prompt and receive LLM response.
     */
    suspend fun sendTextPrompt(text: String): String
}
