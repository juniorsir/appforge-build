package com.example.capabilities.usb

import android.content.Context
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

data class UsbDeviceInfoModel(
    val deviceName: String,
    val vendorId: Int,
    val productId: Int,
    val deviceClass: Int,
    val interfaceCount: Int,
    val manufacturerName: String?,
    val productName: String?
)

data class UsbHostInfo(
    val hasUsbHostFeature: Boolean,
    val attachedDevicesCount: Int,
    val devices: List<UsbDeviceInfoModel>
)

interface UsbRepository {
    fun getUsbInfo(): CapabilityResult<UsbHostInfo>
}

@Singleton
class UsbRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : UsbRepository {

    override fun getUsbInfo(): CapabilityResult<UsbHostInfo> {
        return try {
            val usbManager = context.getSystemService(Context.USB_SERVICE) as? UsbManager
            val hasFeature = context.packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_USB_HOST)

            if (usbManager == null) {
                return CapabilityResult.Success(
                    UsbHostInfo(hasUsbHostFeature = hasFeature, attachedDevicesCount = 0, devices = emptyList())
                )
            }

            val deviceList: Map<String, UsbDevice> = usbManager.deviceList
            val devices = deviceList.values.map { dev ->
                UsbDeviceInfoModel(
                    deviceName = dev.deviceName,
                    vendorId = dev.vendorId,
                    productId = dev.productId,
                    deviceClass = dev.deviceClass,
                    interfaceCount = dev.interfaceCount,
                    manufacturerName = dev.manufacturerName,
                    productName = dev.productName
                )
            }

            CapabilityResult.Success(
                UsbHostInfo(
                    hasUsbHostFeature = hasFeature,
                    attachedDevicesCount = devices.size,
                    devices = devices
                )
            )
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to query USB: ${e.message}", e)
        }
    }
}
