package com.example.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

// --- Room Database Entities ---

@Entity(tableName = "companion_config")
data class CompanionConfigEntity(
    @PrimaryKey val id: String = "default",
    val modelName: String,
    val systemInstruction: String,
    val voiceName: String,
    val speechRate: Float,
    val isMicMuted: Boolean,
    val isCameraEnabled: Boolean,
    val lastUpdated: Long
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val sender: String, // "USER", "ASSISTANT", "SYSTEM"
    val text: String,
    val timestamp: Long
)

@Entity(tableName = "session_transcripts")
data class TranscriptEntity(
    @PrimaryKey val id: String,
    val sessionId: String,
    val text: String,
    val isFinal: Boolean,
    val timestamp: Long,
    val confidence: Double,
    val language: String
)

@Entity(tableName = "brain_conversations")
data class BrainConversationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val createdAt: Long,
    val isArchived: Boolean
)

@Entity(tableName = "brain_messages")
data class BrainMessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val sender: String, // "USER", "ASSISTANT", "SYSTEM"
    val text: String,
    val timestamp: Long,
    val tokenCountPlaceholder: Int,
    val responseTimeMs: Long
)

@Entity(tableName = "prompt_templates")
data class PromptTemplateEntity(
    @PrimaryKey val id: String = "default",
    val systemPrompt: String,
    val developerPrompt: String,
    val userPromptTemplate: String
)

// --- Data Access Objects (DAOs) ---

@Dao
interface CompanionDao {

    @Query("SELECT * FROM companion_config WHERE id = :id LIMIT 1")
    fun getCompanionConfigFlow(id: String = "default"): Flow<CompanionConfigEntity?>

    @Query("SELECT * FROM companion_config WHERE id = :id LIMIT 1")
    suspend fun getCompanionConfig(id: String = "default"): CompanionConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCompanionConfig(config: CompanionConfigEntity)

    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getChatMessagesFlow(): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChatMessage(message: ChatMessageEntity)

    @Query("DELETE FROM chat_messages")
    suspend fun clearChatMessages()

    // --- Speech-to-Text Transcripts DAO Methods ---
    @Query("SELECT * FROM session_transcripts WHERE sessionId = :sessionId ORDER BY timestamp ASC")
    fun getTranscriptsForSessionFlow(sessionId: String): Flow<List<TranscriptEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTranscript(transcript: TranscriptEntity)

    @Query("DELETE FROM session_transcripts WHERE sessionId = :sessionId")
    suspend fun deleteTranscriptsForSession(sessionId: String)
}

@Dao
interface BrainDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConversation(conversation: BrainConversationEntity)

    @Query("SELECT * FROM brain_conversations WHERE id = :id LIMIT 1")
    suspend fun getConversation(id: String): BrainConversationEntity?

    @Query("SELECT * FROM brain_conversations ORDER BY createdAt DESC")
    fun getConversationsFlow(): Flow<List<BrainConversationEntity>>

    @Query("DELETE FROM brain_conversations WHERE id = :id")
    suspend fun deleteConversation(id: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: BrainMessageEntity)

    @Query("SELECT * FROM brain_messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    fun getMessagesForConversationFlow(conversationId: String): Flow<List<BrainMessageEntity>>

    @Query("SELECT * FROM brain_messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    suspend fun getMessagesForConversation(conversationId: String): List<BrainMessageEntity>

    @Query("DELETE FROM brain_messages WHERE conversationId = :conversationId")
    suspend fun deleteMessagesForConversation(conversationId: String)

    @Query("SELECT * FROM brain_messages WHERE conversationId = :conversationId ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLatestMessageForConversation(conversationId: String): BrainMessageEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPromptTemplate(prompt: PromptTemplateEntity)

    @Query("SELECT * FROM prompt_templates WHERE id = :id LIMIT 1")
    fun getPromptTemplateFlow(id: String = "default"): Flow<PromptTemplateEntity?>

    @Query("SELECT * FROM prompt_templates WHERE id = :id LIMIT 1")
    suspend fun getPromptTemplateSync(id: String = "default"): PromptTemplateEntity?
}

// --- App Room Database Holder ---

@Database(
    entities = [
        CompanionConfigEntity::class,
        ChatMessageEntity::class,
        TranscriptEntity::class,
        BrainConversationEntity::class,
        BrainMessageEntity::class,
        PromptTemplateEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class CompanionDatabase : RoomDatabase() {
    abstract fun companionDao(): CompanionDao
    abstract fun brainDao(): BrainDao
}
