package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/**
 * AURA ASSISTANT — Centralized Color Tokens
 * Premium monochrome liquid glass palette.
 */
@Immutable
object AuraColors {
    // Pure Black Canvas & Near-Black Baselines
    val Background = Color(0xFF000000)
    val SurfaceDark = Color(0xFF050505)
    val SurfaceDarker = Color(0xFF080808)

    // Primary Text & Hierarchy
    val TextPrimary = Color(0xFFFFFFFF)
    val TextSecondary = Color(0xFFB8B8B8)
    val TextMuted = Color(0xFF777777)
    val TextVeryMuted = Color(0xFF555555)

    // Base Monochromes
    val White = Color(0xFFFFFFFF)
    val Black = Color(0xFF000000)
    val Transparent = Color(0x00000000)

    // Glass Translucent Fill Layers (Translucent white over dark background)
    val GlassLevel1 = White.copy(alpha = 0.04f)  // 4% - Subtle base cards / items
    val GlassLevel2 = White.copy(alpha = 0.06f)  // 6% - Standard section containers
    val GlassLevel3 = White.copy(alpha = 0.08f)  // 8% - Elevated interactive surfaces
    val GlassElevated = White.copy(alpha = 0.11f) // 11% - Prominent focus panels
    val GlassActive = White.copy(alpha = 0.14f)   // 14% - Selected / active state

    // Button Fills
    val ButtonPrimaryBg = White
    val ButtonPrimaryContent = Black
    val ButtonSecondaryBg = White.copy(alpha = 0.08f)
    val ButtonSecondaryContent = White
    val ButtonTertiaryContent = TextSecondary

    // Border Colors
    val BorderSubtle = White.copy(alpha = 0.12f)
    val BorderFocused = White.copy(alpha = 0.25f)
    val BorderActive = White.copy(alpha = 0.38f)

    // Glass Gradient Highlights (Subtle top sheen)
    val GlassHighlightBrush = Brush.verticalGradient(
        0.0f to White.copy(alpha = 0.07f),
        0.45f to White.copy(alpha = 0.02f),
        1.0f to Transparent
    )

    val GlassElevatedHighlightBrush = Brush.verticalGradient(
        0.0f to White.copy(alpha = 0.12f),
        0.4f to White.copy(alpha = 0.04f),
        1.0f to Transparent
    )

    // Semantic Status Colors (Monochrome-first with minimal functional accents)
    val StatusReady = White
    val StatusActive = White
    val StatusIdle = TextMuted
    val StatusError = Color(0xFFEF4444)
    val StatusWarning = Color(0xFFF59E0B)
}
