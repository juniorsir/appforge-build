package com.example.capabilities

import com.example.capabilities.core.CapabilityErrorCode

sealed class CapabilityResult<out T> {
    data class Success<out T>(val data: T) : CapabilityResult<T>()
    data class Error(
        val message: String,
        val cause: Exception? = null,
        val errorCode: CapabilityErrorCode = CapabilityErrorCode.EXECUTION_FAILED
    ) : CapabilityResult<Nothing>()
    data class PermissionDenied(
        val permission: String,
        val errorCode: CapabilityErrorCode = CapabilityErrorCode.PERMISSION_DENIED
    ) : CapabilityResult<Nothing>()
    data class HardwareUnavailable(
        val feature: String,
        val errorCode: CapabilityErrorCode = CapabilityErrorCode.HARDWARE_UNAVAILABLE
    ) : CapabilityResult<Nothing>()
    data class UnsupportedVersion(
        val requiredVersion: Int,
        val errorCode: CapabilityErrorCode = CapabilityErrorCode.ANDROID_VERSION_UNSUPPORTED
    ) : CapabilityResult<Nothing>()
    data class ServiceDisabled(
        val serviceName: String,
        val errorCode: CapabilityErrorCode = CapabilityErrorCode.SERVICE_DISABLED
    ) : CapabilityResult<Nothing>()

    fun isSuccess(): Boolean = this is Success
    fun getOrNull(): T? = (this as? Success)?.data
}
