package com.example.presentation.permissions

import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.capabilities.permissions.PermissionCategory
import com.example.capabilities.permissions.PermissionItem
import com.example.capabilities.permissions.PermissionManager
import com.example.capabilities.permissions.PermissionState
import com.example.capabilities.permissions.SpecialSettingType
import com.example.ui.theme.AuraColors
import com.example.ui.theme.AuraTypography

private val EmeraldAccent = Color(0xFF10B981)

/**
 * High-performance, full-spectrum 45+ Permission & Capability Access Hub.
 * Allows inspecting, batch requesting, and toggling all Android permissions using modern interactive switches.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PermissionsManagerDialog(
    onDismissRequest: () -> Unit,
    permissionManager: PermissionManager,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity

    // Refresh trigger state
    var refreshNonce by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<PermissionCategory?>(null) }
    var showOnlyMissing by remember { mutableStateOf(false) }

    // Multi-permission launcher for batch grant
    val batchPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val grantedCount = results.values.count { it }
        Toast.makeText(
            context,
            "Granted $grantedCount of ${results.size} requested permissions",
            Toast.LENGTH_SHORT
        ).show()
        refreshNonce++
    }

    // Single permission launcher
    val singlePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        refreshNonce++
    }

    val allPermissions = permissionManager.allDefinedPermissions

    // Map permissions with their evaluated state
    val evaluatedPermissions = remember(refreshNonce, allPermissions) {
        allPermissions.map { item ->
            val state = permissionManager.getPermissionItemState(item, activity)
            item to state
        }
    }

    val totalCount = evaluatedPermissions.size
    val grantedCount = evaluatedPermissions.count { it.second == PermissionState.GRANTED || it.second == PermissionState.NOT_REQUIRED }
    val missingRuntimeCount = evaluatedPermissions.count { it.first.isRuntime && it.second == PermissionState.DENIED }
    val progressFraction = if (totalCount > 0) grantedCount.toFloat() / totalCount else 0f

    val filteredList = evaluatedPermissions.filter { (item, state) ->
        val matchesCategory = selectedCategory == null || item.category == selectedCategory
        val matchesQuery = searchQuery.isEmpty() ||
                item.displayName.contains(searchQuery, ignoreCase = true) ||
                item.permission.contains(searchQuery, ignoreCase = true) ||
                item.description.contains(searchQuery, ignoreCase = true) ||
                item.category.displayName.contains(searchQuery, ignoreCase = true)
        val matchesMissing = !showOnlyMissing || (state == PermissionState.DENIED)

        matchesCategory && matchesQuery && matchesMissing
    }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.88f))
                .padding(horizontal = 12.dp, vertical = 18.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 680.dp)
                    .fillMaxHeight(0.92f)
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, AuraColors.BorderFocused, RoundedCornerShape(20.dp)),
                color = AuraColors.SurfaceDark
            ) {
                Column(
                    modifier = Modifier.fillMaxSize()
                ) {
                    // Top Header Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(AuraColors.SurfaceDarker)
                            .padding(horizontal = 18.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(EmeraldAccent.copy(alpha = 0.15f))
                                    .border(1.dp, EmeraldAccent.copy(alpha = 0.4f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = EmeraldAccent,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Column {
                                Text(
                                    text = "System Permissions Hub",
                                    style = AuraTypography.SectionTitle.copy(fontSize = 17.sp, fontWeight = FontWeight.SemiBold),
                                    color = AuraColors.TextPrimary
                                )
                                Text(
                                    text = "45+ Capabilities & OS Security Policies (Toggle to Grant)",
                                    style = AuraTypography.TechnicalLabel.copy(fontSize = 11.sp),
                                    color = AuraColors.TextMuted
                                )
                            }
                        }

                        IconButton(
                            onClick = onDismissRequest,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(AuraColors.GlassLevel3)
                                .testTag("close_permissions_dialog_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close Permissions Dialog",
                                tint = AuraColors.TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Status Summary & Fast Actions
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(AuraColors.GlassLevel1)
                            .padding(horizontal = 18.dp, vertical = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "ACCESS STATUS",
                                style = AuraTypography.TechnicalLabel.copy(fontSize = 11.sp),
                                color = AuraColors.TextMuted
                            )
                            Text(
                                text = "$grantedCount of $totalCount Configured",
                                style = AuraTypography.TechnicalMono.copy(fontSize = 12.sp, fontWeight = FontWeight.Bold),
                                color = if (missingRuntimeCount == 0) EmeraldAccent else AuraColors.StatusWarning
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        LinearProgressIndicator(
                            progress = { progressFraction },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = EmeraldAccent,
                            trackColor = AuraColors.BorderSubtle
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Fast Action Buttons Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    val toRequest = permissionManager.getRuntimePermissionsToRequest()
                                    if (toRequest.isNotEmpty()) {
                                        batchPermissionLauncher.launch(toRequest.toTypedArray())
                                    } else {
                                        Toast.makeText(context, "All standard runtime permissions are already granted!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier
                                    .weight(1.2f)
                                    .height(42.dp)
                                    .testTag("batch_grant_permissions_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = EmeraldAccent,
                                    contentColor = Color.Black
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LockOpen,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (missingRuntimeCount > 0) "Toggle All On ($missingRuntimeCount)" else "All Enabled",
                                    style = AuraTypography.ButtonLabel.copy(fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                )
                            }

                            OutlinedButton(
                                onClick = {
                                    try {
                                        context.startActivity(permissionManager.createAppSettingsIntent())
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Could not open settings: ${e.message}", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .testTag("open_app_settings_button"),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = AuraColors.TextPrimary
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = null,
                                    modifier = Modifier.size(15.dp),
                                    tint = AuraColors.TextSecondary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "OS Settings",
                                    style = AuraTypography.ButtonLabel.copy(fontSize = 12.sp)
                                )
                            }
                        }
                    }

                    // Search & Filter Controls
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = {
                                Text(
                                    text = "Search 45+ permissions, sensors, features...",
                                    style = AuraTypography.BodyMedium.copy(fontSize = 13.sp),
                                    color = AuraColors.TextMuted
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = null,
                                    tint = AuraColors.TextMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Clear search",
                                            tint = AuraColors.TextMuted,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("permissions_search_field"),
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = EmeraldAccent,
                                unfocusedBorderColor = AuraColors.BorderSubtle,
                                focusedContainerColor = AuraColors.SurfaceDarker,
                                unfocusedContainerColor = AuraColors.SurfaceDarker,
                                focusedTextColor = AuraColors.TextPrimary,
                                unfocusedTextColor = AuraColors.TextPrimary
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Filter Chips Row
                        LazyRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            contentPadding = PaddingValues(vertical = 2.dp)
                        ) {
                            item {
                                FilterChip(
                                    selected = selectedCategory == null && !showOnlyMissing,
                                    onClick = {
                                        selectedCategory = null
                                        showOnlyMissing = false
                                    },
                                    label = { Text("All (${allPermissions.size})", fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = EmeraldAccent.copy(alpha = 0.2f),
                                        selectedLabelColor = EmeraldAccent,
                                        containerColor = AuraColors.GlassLevel1,
                                        labelColor = AuraColors.TextSecondary
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true,
                                        selected = selectedCategory == null && !showOnlyMissing,
                                        borderColor = AuraColors.BorderSubtle,
                                        selectedBorderColor = EmeraldAccent
                                    )
                                )
                            }

                            item {
                                FilterChip(
                                    selected = showOnlyMissing,
                                    onClick = { showOnlyMissing = !showOnlyMissing },
                                    label = { Text("Missing (${missingRuntimeCount})", fontSize = 11.sp) },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.Warning,
                                            contentDescription = null,
                                            modifier = Modifier.size(13.dp),
                                            tint = if (showOnlyMissing) AuraColors.StatusWarning else AuraColors.TextMuted
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = AuraColors.StatusWarning.copy(alpha = 0.2f),
                                        selectedLabelColor = AuraColors.StatusWarning,
                                        containerColor = AuraColors.GlassLevel1,
                                        labelColor = AuraColors.TextSecondary
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true,
                                        selected = showOnlyMissing,
                                        borderColor = AuraColors.BorderSubtle,
                                        selectedBorderColor = AuraColors.StatusWarning
                                    )
                                )
                            }

                            items(PermissionCategory.values()) { category ->
                                val categoryCount = allPermissions.count { it.category == category }
                                FilterChip(
                                    selected = selectedCategory == category,
                                    onClick = {
                                        selectedCategory = if (selectedCategory == category) null else category
                                    },
                                    label = { Text("${category.displayName} ($categoryCount)", fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = EmeraldAccent.copy(alpha = 0.2f),
                                        selectedLabelColor = EmeraldAccent,
                                        containerColor = AuraColors.GlassLevel1,
                                        labelColor = AuraColors.TextSecondary
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true,
                                        selected = selectedCategory == category,
                                        borderColor = AuraColors.BorderSubtle,
                                        selectedBorderColor = EmeraldAccent
                                    )
                                )
                            }
                        }
                    }

                    // Permissions List
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(top = 4.dp, bottom = 16.dp)
                    ) {
                        if (filteredList.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 32.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "No matching permissions found.",
                                        style = AuraTypography.BodyMedium,
                                        color = AuraColors.TextMuted
                                    )
                                }
                            }
                        } else {
                            items(
                                items = filteredList,
                                key = { it.first.id }
                            ) { (item, state) ->
                                PermissionItemCard(
                                    item = item,
                                    state = state,
                                    onToggle = { enable ->
                                        if (item.isRuntime) {
                                            if (enable) {
                                                singlePermissionLauncher.launch(item.permission)
                                            } else {
                                                // When user turns switch off, navigate to App settings so they can revoke
                                                try {
                                                    context.startActivity(permissionManager.createAppSettingsIntent())
                                                } catch (e: Exception) {
                                                    Toast.makeText(context, "Manage permissions in Android Settings", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        } else if (item.specialSettingType != SpecialSettingType.NONE) {
                                            try {
                                                val intent = permissionManager.createSpecialIntent(item)
                                                context.startActivity(intent)
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "Could not launch setting: ${e.message}", Toast.LENGTH_SHORT).show()
                                            }
                                        } else {
                                            try {
                                                context.startActivity(permissionManager.createAppSettingsIntent())
                                            } catch (e: Exception) {
                                                // ignore
                                            }
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionItemCard(
    item: PermissionItem,
    state: PermissionState,
    onToggle: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val isGranted = state == PermissionState.GRANTED || state == PermissionState.NOT_REQUIRED
    val isInteractive = item.isRuntime || item.specialSettingType != SpecialSettingType.NONE

    val cardBorderColor by animateColorAsState(
        targetValue = if (isGranted) EmeraldAccent.copy(alpha = 0.4f) else AuraColors.BorderSubtle,
        label = "cardBorderColor"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("permission_card_${item.id}")
            .clickable(enabled = isInteractive) {
                onToggle(!isGranted)
            },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = AuraColors.GlassLevel1
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(cardBorderColor)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = item.displayName,
                            style = AuraTypography.SectionTitle.copy(fontSize = 14.sp, fontWeight = FontWeight.SemiBold),
                            color = AuraColors.TextPrimary
                        )

                        // Category chip
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(AuraColors.GlassLevel3)
                                .padding(horizontal = 5.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = item.category.displayName,
                                style = AuraTypography.TechnicalLabel.copy(fontSize = 9.sp),
                                color = AuraColors.TextMuted
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = item.permission.substringAfterLast("."),
                        style = AuraTypography.TechnicalMono.copy(fontSize = 11.sp),
                        color = AuraColors.TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                // Action Area: Material 3 Switch Toggle
                if (isInteractive) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (item.specialSettingType != SpecialSettingType.NONE) {
                            Icon(
                                imageVector = Icons.Default.OpenInNew,
                                contentDescription = "System Setting",
                                modifier = Modifier.size(14.dp),
                                tint = if (isGranted) EmeraldAccent else AuraColors.TextMuted
                            )
                        }

                        Switch(
                            checked = isGranted,
                            onCheckedChange = { onToggle(it) },
                            modifier = Modifier.testTag("permission_toggle_${item.id}"),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.Black,
                                checkedTrackColor = EmeraldAccent,
                                checkedBorderColor = EmeraldAccent,
                                uncheckedThumbColor = AuraColors.TextMuted,
                                uncheckedTrackColor = AuraColors.SurfaceDarker,
                                uncheckedBorderColor = AuraColors.BorderSubtle
                            ),
                            thumbContent = if (isGranted) {
                                {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        modifier = Modifier.size(12.dp),
                                        tint = Color.Black
                                    )
                                }
                            } else null
                        )
                    }
                } else {
                    // Static Manifest granted badge with clean mini toggle look
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(EmeraldAccent.copy(alpha = 0.12f))
                            .border(1.dp, EmeraldAccent.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Manifest Enabled",
                            tint = EmeraldAccent,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = "Enabled",
                            style = AuraTypography.TechnicalLabel.copy(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                            color = EmeraldAccent
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = item.description,
                style = AuraTypography.Caption.copy(fontSize = 12.sp, lineHeight = 16.sp),
                color = AuraColors.TextMuted
            )
        }
    }
}
