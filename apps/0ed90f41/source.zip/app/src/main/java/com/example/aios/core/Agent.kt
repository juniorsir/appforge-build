package com.example.aios.core

import com.example.aios.planning.Task
import com.example.aios.planning.TaskResult

interface Agent {
    val identity: AgentIdentity
    val healthStatus: HealthStatus
    var state: AgentState

    suspend fun initialize(): Boolean
    suspend fun executeTask(task: Task): TaskResult
    suspend fun shutdown(): Boolean
}
