package com.example.capabilities.share

import com.example.capabilities.CapabilityResult

interface ShareRepository {
    fun shareText(text: String): CapabilityResult<Unit>
}
