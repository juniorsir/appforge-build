package com.example.ui.components.header

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.glass.AuraGlassSurface
import com.example.ui.theme.AuraBorders
import com.example.ui.theme.AuraColors
import com.example.ui.theme.AuraGlassLevel
import com.example.ui.theme.AuraMotion
import com.example.ui.theme.AuraShapes
import com.example.ui.theme.AuraTypography
import com.example.ui.theme.rememberReducedMotion
import kotlin.math.sin
import kotlin.math.PI

/**
 * Engine status states representing the real-time AI assistant's lifecycle.
 */
enum class AuraEngineState(
    val label: String,
    val dotColor: Color,
    val textColor: Color,
    val isPulsing: Boolean,
    val pulseDurationMs: Int = 3000
) {
    STANDBY(
        label = "STANDBY",
        dotColor = AuraColors.White.copy(alpha = 0.45f),
        textColor = AuraColors.TextSecondary,
        isPulsing = false
    ),
    CONNECTING(
        label = "CONNECTING",
        dotColor = AuraColors.White.copy(alpha = 0.85f),
        textColor = AuraColors.TextPrimary,
        isPulsing = true,
        pulseDurationMs = 2500
    ),
    LISTENING(
        label = "LISTENING",
        dotColor = AuraColors.White,
        textColor = AuraColors.TextPrimary,
        isPulsing = true,
        pulseDurationMs = 2000
    ),
    PROCESSING(
        label = "PROCESSING",
        dotColor = AuraColors.White,
        textColor = AuraColors.TextPrimary,
        isPulsing = true,
        pulseDurationMs = 1500
    ),
    SPEAKING(
        label = "SPEAKING",
        dotColor = AuraColors.White,
        textColor = AuraColors.TextPrimary,
        isPulsing = true,
        pulseDurationMs = 3000
    ),
    PAUSED(
        label = "PAUSED",
        dotColor = AuraColors.TextMuted,
        textColor = AuraColors.TextMuted,
        isPulsing = false
    ),
    ERROR(
        label = "ERROR",
        dotColor = AuraColors.StatusError,
        textColor = AuraColors.TextSecondary,
        isPulsing = false
    )
}

/**
 * AURA ASSISTANT — Compact Glass Status Pill for Top Header
 */
@Composable
fun AuraHeaderStatus(
    engineState: AuraEngineState,
    modifier: Modifier = Modifier,
    height: Dp = 28.dp
) {
    val reducedMotion = rememberReducedMotion()

    AuraGlassSurface(
        modifier = modifier
            .height(height)
            .semantics(mergeDescendants = true) {
                contentDescription = "Engine status: ${engineState.label}"
            },
        shape = AuraShapes.Pill,
        level = AuraGlassLevel.LEVEL_1,
        borderWidth = AuraBorders.WidthSubtle,
        contentPadding = PaddingValues(horizontal = 9.dp, vertical = 3.dp)
    ) {
        Row(
            modifier = Modifier.align(Alignment.Center),
            horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Status Dot with smooth pulse
            AuraHeaderStatusDot(
                engineState = engineState,
                reducedMotion = reducedMotion,
                size = 5.dp
            )

            // Animated Status Text transition
            AnimatedContent(
                targetState = engineState,
                transitionSpec = {
                    fadeIn(animationSpec = AuraMotion.stateTransitionTween()) togetherWith
                            fadeOut(animationSpec = AuraMotion.stateTransitionTween())
                },
                label = "HeaderStatusTransition"
            ) { targetState ->
                Text(
                    text = targetState.label,
                    style = AuraTypography.TechnicalLabel.copy(fontSize = 10.sp, letterSpacing = 0.5.sp),
                    color = targetState.textColor
                )
            }
        }
    }
}

@Composable
private fun AuraHeaderStatusDot(
    engineState: AuraEngineState,
    reducedMotion: Boolean,
    modifier: Modifier = Modifier,
    size: Dp = 5.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "HeaderDotTransition")
    
    // alpha(t) = 0.65 + 0.20 sin(2πt/T)
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(engineState.pulseDurationMs, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "HeaderDotPhase"
    )

    val currentAlpha = if (engineState.isPulsing && !reducedMotion) {
        (0.65f + 0.20f * sin(2 * PI * phase)).toFloat()
    } else {
        engineState.dotColor.alpha
    }

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(engineState.dotColor.copy(alpha = currentAlpha))
    )
}
