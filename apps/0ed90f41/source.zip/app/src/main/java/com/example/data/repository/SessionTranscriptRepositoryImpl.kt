package com.example.data.repository

import com.example.data.local.CompanionDao
import com.example.data.local.TranscriptEntity
import com.example.domain.model.Transcript
import com.example.domain.repository.SessionTranscriptRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SessionTranscriptRepositoryImpl(
    private val companionDao: CompanionDao,
    private val coroutineScope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) : SessionTranscriptRepository {

    override fun getTranscriptsForSession(sessionId: String): StateFlow<List<Transcript>> {
        val stateFlow = MutableStateFlow<List<Transcript>>(emptyList())
        coroutineScope.launch {
            companionDao.getTranscriptsForSessionFlow(sessionId)
                .map { entities ->
                    entities.map { entity ->
                        Transcript(
                            id = entity.id,
                            sessionId = entity.sessionId,
                            text = entity.text,
                            isFinal = entity.isFinal,
                            timestamp = entity.timestamp,
                            confidence = entity.confidence,
                            language = entity.language
                        )
                    }
                }
                .collect { list ->
                    stateFlow.value = list
                }
        }
        return stateFlow.asStateFlow()
    }

    override suspend fun saveTranscript(transcript: Transcript) {
        val entity = TranscriptEntity(
            id = transcript.id,
            sessionId = transcript.sessionId,
            text = transcript.text,
            isFinal = transcript.isFinal,
            timestamp = transcript.timestamp,
            confidence = transcript.confidence,
            language = transcript.language
        )
        companionDao.insertTranscript(entity)
    }

    override suspend fun deleteTranscriptsForSession(sessionId: String) {
        companionDao.deleteTranscriptsForSession(sessionId)
    }
}
