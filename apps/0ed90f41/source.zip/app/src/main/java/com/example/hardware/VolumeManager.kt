package com.example.hardware

import android.content.Context
import android.media.AudioManager
import android.util.Log

class VolumeManager(private val context: Context) {

    private val TAG = "VolumeManager"
    private val audioManager by lazy {
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }

    data class VolumeInfo(
        val stream: String,
        val currentVolume: Int,
        val maxVolume: Int,
        val minVolume: Int,
        val percentage: Int
    )

    data class AudioStatus(
        val ringerMode: String,
        val isMusicActive: Boolean,
        val isSpeakerphoneOn: Boolean,
        val isBluetoothA2dpOn: Boolean,
        val streams: List<VolumeInfo>
    )

    fun getAudioStatus(): AudioStatus {
        val streams = listOf(
            getStreamInfo(AudioManager.STREAM_MUSIC, "MEDIA"),
            getStreamInfo(AudioManager.STREAM_RING, "RING"),
            getStreamInfo(AudioManager.STREAM_NOTIFICATION, "NOTIFICATION"),
            getStreamInfo(AudioManager.STREAM_ALARM, "ALARM"),
            getStreamInfo(AudioManager.STREAM_VOICE_CALL, "VOICE_CALL"),
            getStreamInfo(AudioManager.STREAM_SYSTEM, "SYSTEM")
        )

        val ringerModeStr = when (audioManager.ringerMode) {
            AudioManager.RINGER_MODE_SILENT -> "SILENT"
            AudioManager.RINGER_MODE_VIBRATE -> "VIBRATE"
            else -> "NORMAL"
        }

        return AudioStatus(
            ringerMode = ringerModeStr,
            isMusicActive = audioManager.isMusicActive,
            isSpeakerphoneOn = audioManager.isSpeakerphoneOn,
            isBluetoothA2dpOn = audioManager.isBluetoothA2dpOn,
            streams = streams
        )
    }

    private fun getStreamInfo(streamType: Int, name: String): VolumeInfo {
        val cur = audioManager.getStreamVolume(streamType)
        val max = audioManager.getStreamMaxVolume(streamType)
        val min = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
            audioManager.getStreamMinVolume(streamType)
        } else 0
        val pct = if (max > 0) ((cur.toFloat() / max) * 100).toInt() else 0
        return VolumeInfo(name, cur, max, min, pct)
    }

    fun setStreamVolume(streamName: String, volume: Int, showUi: Boolean = false): Boolean {
        val streamType = when (streamName.uppercase()) {
            "RING" -> AudioManager.STREAM_RING
            "NOTIFICATION", "NOTIF" -> AudioManager.STREAM_NOTIFICATION
            "ALARM" -> AudioManager.STREAM_ALARM
            "VOICE_CALL", "CALL" -> AudioManager.STREAM_VOICE_CALL
            "SYSTEM" -> AudioManager.STREAM_SYSTEM
            else -> AudioManager.STREAM_MUSIC
        }

        val flags = if (showUi) AudioManager.FLAG_SHOW_UI else 0
        val max = audioManager.getStreamMaxVolume(streamType)
        val clamped = volume.coerceIn(0, max)

        return try {
            audioManager.setStreamVolume(streamType, clamped, flags)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to set volume: ${e.message}", e)
            false
        }
    }

    fun setRingerMode(mode: String): Boolean {
        val rMode = when (mode.uppercase()) {
            "SILENT" -> AudioManager.RINGER_MODE_SILENT
            "VIBRATE" -> AudioManager.RINGER_MODE_VIBRATE
            else -> AudioManager.RINGER_MODE_NORMAL
        }
        return try {
            audioManager.ringerMode = rMode
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to set ringer mode: ${e.message}", e)
            false
        }
    }
}
