package com.example.tools.repository

import com.example.tools.core.ToolResult
import kotlinx.coroutines.flow.Flow

data class ExecutionLog(
    val executionId: String,
    val toolId: String,
    val timestamp: Long,
    val durationMs: Long,
    val status: String,
    val params: Map<String, Any>,
    val result: ToolResult
)

interface ExecutionHistoryRepository {
    fun getHistory(): Flow<List<ExecutionLog>>
    suspend fun logExecution(log: ExecutionLog)
    suspend fun getExecutionLog(executionId: String): ExecutionLog?
}
