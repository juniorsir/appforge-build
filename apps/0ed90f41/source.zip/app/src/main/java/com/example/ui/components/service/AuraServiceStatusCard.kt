package com.example.ui.components.service

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.glass.AuraGlassSurface
import com.example.ui.theme.AuraBorders
import com.example.ui.theme.AuraColors
import com.example.ui.theme.AuraDimensions
import com.example.ui.theme.AuraGlassLevel
import com.example.ui.theme.AuraMotion
import com.example.ui.theme.AuraShapes
import com.example.ui.theme.AuraSpacing
import com.example.ui.theme.AuraTypography

/**
 * Real UI state enum representing Foreground Service lifecycle.
 */
enum class AuraServiceState(
    val badgeLabel: String,
    val defaultDetail: String,
    val isPulsing: Boolean,
    val isRotating: Boolean,
    val actionText: String?,
    val actionDescription: String?
) {
    RUNNING(
        badgeLabel = "RUNNING",
        defaultDetail = "Active • Low-latency 16-bit PCM capture streaming",
        isPulsing = true,
        isRotating = false,
        actionText = "STOP",
        actionDescription = "Stop foreground service"
    ),
    STARTING(
        badgeLabel = "STARTING",
        defaultDetail = "Starting service & initializing audio bridge...",
        isPulsing = false,
        isRotating = true,
        actionText = "WAIT",
        actionDescription = "Service is starting"
    ),
    STOPPING(
        badgeLabel = "STOPPING",
        defaultDetail = "Stopping service & releasing resources...",
        isPulsing = false,
        isRotating = true,
        actionText = "WAIT",
        actionDescription = "Service is stopping"
    ),
    PAUSED(
        badgeLabel = "PAUSED",
        defaultDetail = "Paused • Audio capture suspended on device",
        isPulsing = false,
        isRotating = false,
        actionText = "RESUME",
        actionDescription = "Resume foreground service audio capture"
    ),
    STOPPED(
        badgeLabel = "STOPPED",
        defaultDetail = "Service inactive • Ready to start background capture",
        isPulsing = false,
        isRotating = false,
        actionText = "START",
        actionDescription = "Start foreground service"
    ),
    ERROR(
        badgeLabel = "ERROR",
        defaultDetail = "Service unavailable • Audio permission or device error",
        isPulsing = true,
        isRotating = false,
        actionText = "RETRY",
        actionDescription = "Retry starting foreground service"
    ),
    UNKNOWN(
        badgeLabel = "STANDBY",
        defaultDetail = "Engine standby • Ready for initialization",
        isPulsing = false,
        isRotating = false,
        actionText = "START",
        actionDescription = "Start foreground service"
    )
}

/**
 * AURA ASSISTANT — Phase 4: Foreground Service + System Status Card
 *
 * Monochromatic liquid-glass card communicating foreground service status,
 * supporting telemetry/state info, and single primary action.
 */
@Composable
fun AuraServiceStatusCard(
    state: AuraServiceState,
    modifier: Modifier = Modifier,
    statusDetail: String? = null,
    title: String = "Foreground Service",
    onActionClick: (() -> Unit)? = null,
    onSecondaryActionClick: (() -> Unit)? = null,
    reducedMotion: Boolean = false
) {
    val displayDetail = statusDetail ?: state.defaultDetail

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .widthIn(max = AuraSpacing.MaxContentWidth)
            .semantics(mergeDescendants = true) {
                contentDescription = "$title. Status: ${state.badgeLabel}. $displayDetail"
            }
    ) {
        val availableWidth = maxWidth
        val isNarrow = availableWidth < 360.dp

        AuraGlassSurface(
            modifier = Modifier.fillMaxWidth(),
            shape = AuraShapes.Large,
            level = when (state) {
                AuraServiceState.RUNNING -> AuraGlassLevel.LEVEL_2
                AuraServiceState.ERROR -> AuraGlassLevel.LEVEL_2
                else -> AuraGlassLevel.LEVEL_1
            },
            borderWidth = AuraBorders.WidthNormal,
            showHighlight = true
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Subtle radial indicator glow (White <= 3.5%)
                if (state == AuraServiceState.RUNNING || state == AuraServiceState.STARTING) {
                    Box(
                        modifier = Modifier
                            .size(120.dp)
                            .align(Alignment.CenterStart)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(
                                        AuraColors.White.copy(alpha = 0.035f),
                                        Color.Transparent
                                    ),
                                    radius = 120f
                                )
                            )
                    )
                }

                // Internal Layout
                if (isNarrow) {
                    // Vertical Stack Layout for Ultra-Compact Screens
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            AuraServiceIndicator(
                                state = state,
                                reducedMotion = reducedMotion
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                AuraServiceHeaderRow(title = title, state = state)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = displayDetail,
                                    style = AuraTypography.Caption.copy(
                                        fontSize = 11.5.sp,
                                        lineHeight = 16.sp
                                    ),
                                    color = AuraColors.TextSecondary,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        if (state.actionText != null && onActionClick != null) {
                            AuraServiceActionButton(
                                text = state.actionText,
                                contentDescription = state.actionDescription ?: state.actionText,
                                onClick = onActionClick,
                                enabled = state != AuraServiceState.STARTING && state != AuraServiceState.STOPPING,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                } else {
                    // Standard Adaptive Row Layout
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(
                                horizontal = if (availableWidth >= 600.dp) 24.dp else 18.dp,
                                vertical = if (availableWidth >= 600.dp) 18.dp else 14.dp
                            ),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            AuraServiceIndicator(
                                state = state,
                                size = if (availableWidth >= 600.dp) 32.dp else 28.dp,
                                reducedMotion = reducedMotion
                            )

                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                AuraServiceHeaderRow(title = title, state = state)
                                Text(
                                    text = displayDetail,
                                    style = AuraTypography.Caption.copy(
                                        fontSize = 12.sp,
                                        lineHeight = 17.sp
                                    ),
                                    color = AuraColors.TextSecondary,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        // Action Button on the Right
                        if (state.actionText != null && onActionClick != null) {
                            Spacer(modifier = Modifier.width(16.dp))
                            AuraServiceActionButton(
                                text = state.actionText,
                                contentDescription = state.actionDescription ?: state.actionText,
                                onClick = onActionClick,
                                enabled = state != AuraServiceState.STARTING && state != AuraServiceState.STOPPING
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Header Row displaying Title + Inline Technical Badge.
 */
@Composable
private fun AuraServiceHeaderRow(
    title: String,
    state: AuraServiceState,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = title,
            style = AuraTypography.SectionTitle.copy(
                fontSize = 14.5.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = (-0.1).sp
            ),
            color = AuraColors.TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false)
        )

        // Micro-pill badge
        Box(
            modifier = Modifier
                .clip(AuraShapes.Pill)
                .background(
                    when (state) {
                        AuraServiceState.RUNNING -> AuraColors.White.copy(alpha = 0.12f)
                        AuraServiceState.ERROR -> AuraColors.StatusError.copy(alpha = 0.15f)
                        AuraServiceState.PAUSED -> AuraColors.StatusWarning.copy(alpha = 0.15f)
                        else -> AuraColors.White.copy(alpha = 0.06f)
                    }
                )
                .padding(horizontal = 7.dp, vertical = 2.dp)
        ) {
            AnimatedContent(
                targetState = state.badgeLabel,
                transitionSpec = {
                    fadeIn(animationSpec = AuraMotion.stateTransitionTween()) togetherWith
                            fadeOut(animationSpec = AuraMotion.stateTransitionTween())
                },
                label = "BadgeLabelCrossfade"
            ) { label ->
                Text(
                    text = label,
                    style = AuraTypography.TechnicalLabel.copy(
                        fontSize = 9.sp,
                        letterSpacing = 0.6.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    maxLines = 1,
                    softWrap = false,
                    color = when (state) {
                        AuraServiceState.RUNNING -> AuraColors.TextPrimary
                        AuraServiceState.ERROR -> AuraColors.StatusError
                        AuraServiceState.PAUSED -> AuraColors.StatusWarning
                        else -> AuraColors.TextSecondary
                    }
                )
            }
        }
    }
}

/**
 * Monochrome Liquid-Glass Status Indicator (28–32dp).
 * Supports subtle breathing for RUNNING, sweep rotation for STARTING/STOPPING,
 * and clean static glyphs for STOPPED, PAUSED, and ERROR.
 */
@Composable
fun AuraServiceIndicator(
    state: AuraServiceState,
    modifier: Modifier = Modifier,
    size: Dp = 28.dp,
    reducedMotion: Boolean = false
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ServiceIndicatorMotion")

    // Subtle breathing animation for RUNNING: alpha = 0.65 + 0.20 * sin(2*PI*t / T)
    val breathingAlpha by infiniteTransition.animateFloat(
        initialValue = if (state.isPulsing && !reducedMotion) 0.55f else 1.0f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "BreathingAlpha"
    )

    // Smooth rotation for STARTING / STOPPING
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (state == AuraServiceState.STOPPING) 1800 else 1400,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "RotatingAngle"
    )

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(AuraColors.White.copy(alpha = 0.04f)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val centerOffset = Offset(this.size.width / 2f, this.size.height / 2f)
            val radius = this.size.minDimension / 2f

            when (state) {
                AuraServiceState.RUNNING -> {
                    // Outer subtle breathing halo
                    drawCircle(
                        color = AuraColors.White.copy(alpha = 0.10f * breathingAlpha),
                        radius = radius * 0.90f
                    )
                    // Mid border ring
                    drawCircle(
                        color = AuraColors.White.copy(alpha = 0.35f * breathingAlpha),
                        radius = radius * 0.70f,
                        style = Stroke(width = 1.2.dp.toPx())
                    )
                    // Inner bright solid core
                    drawCircle(
                        color = AuraColors.White.copy(alpha = 0.90f * breathingAlpha),
                        radius = radius * 0.32f
                    )
                }

                AuraServiceState.STARTING, AuraServiceState.STOPPING -> {
                    // Rotating arc indicator
                    val currentRotation = if (reducedMotion) 45f else rotation
                    drawArc(
                        color = AuraColors.White.copy(alpha = 0.70f),
                        startAngle = currentRotation,
                        sweepAngle = 260f,
                        useCenter = false,
                        topLeft = Offset(radius * 0.30f, radius * 0.30f),
                        size = androidx.compose.ui.geometry.Size(radius * 1.4f, radius * 1.4f),
                        style = Stroke(width = 1.8.dp.toPx(), cap = StrokeCap.Round)
                    )
                }

                AuraServiceState.PAUSED -> {
                    // Static ring with pause bars
                    drawCircle(
                        color = AuraColors.White.copy(alpha = 0.30f),
                        radius = radius * 0.75f,
                        style = Stroke(width = 1.2.dp.toPx())
                    )
                    // Two vertical pause bars
                    val barWidth = 1.8.dp.toPx()
                    val barHeight = radius * 0.60f
                    val barSpacing = 2.4.dp.toPx()

                    drawRect(
                        color = AuraColors.StatusWarning.copy(alpha = 0.85f),
                        topLeft = Offset(centerOffset.x - barSpacing - barWidth, centerOffset.y - barHeight / 2f),
                        size = androidx.compose.ui.geometry.Size(barWidth, barHeight)
                    )
                    drawRect(
                        color = AuraColors.StatusWarning.copy(alpha = 0.85f),
                        topLeft = Offset(centerOffset.x + barSpacing, centerOffset.y - barHeight / 2f),
                        size = androidx.compose.ui.geometry.Size(barWidth, barHeight)
                    )
                }

                AuraServiceState.STOPPED, AuraServiceState.UNKNOWN -> {
                    // Static clean hollow ring
                    drawCircle(
                        color = AuraColors.White.copy(alpha = 0.28f),
                        radius = radius * 0.65f,
                        style = Stroke(width = 1.4.dp.toPx())
                    )
                }

                AuraServiceState.ERROR -> {
                    // Static ring with center error dot
                    drawCircle(
                        color = AuraColors.StatusError.copy(alpha = 0.35f * breathingAlpha),
                        radius = radius * 0.75f,
                        style = Stroke(width = 1.2.dp.toPx())
                    )
                    drawCircle(
                        color = AuraColors.StatusError.copy(alpha = 0.85f * breathingAlpha),
                        radius = radius * 0.32f
                    )
                }
            }
        }
    }
}

/**
 * Compact Monochrome Glass Action Button.
 * Accessible 48dp touch target with tactile press animation and 40dp visual height.
 */
@Composable
fun AuraServiceActionButton(
    text: String,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed && enabled) AuraMotion.PressScalePressed else AuraMotion.PressScaleNormal,
        animationSpec = AuraMotion.PressSpring,
        label = "ServiceBtnScale"
    )

    AuraGlassSurface(
        modifier = modifier
            .defaultMinSize(minWidth = 84.dp, minHeight = AuraDimensions.MinTouchTarget)
            .height(40.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled,
                role = Role.Button,
                onClick = onClick
            )
            .semantics {
                role = Role.Button
                this.contentDescription = contentDescription
            },
        shape = AuraShapes.Medium,
        level = if (isPressed) AuraGlassLevel.ACTIVE else AuraGlassLevel.LEVEL_2,
        borderWidth = AuraBorders.WidthNormal,
        showHighlight = true
    ) {
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(horizontal = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text,
                style = AuraTypography.TechnicalLabel.copy(
                    fontSize = 12.5.sp,
                    letterSpacing = 0.8.sp,
                    fontWeight = FontWeight.Bold
                ),
                color = if (enabled) AuraColors.TextPrimary else AuraColors.TextMuted
            )
        }
    }
}
