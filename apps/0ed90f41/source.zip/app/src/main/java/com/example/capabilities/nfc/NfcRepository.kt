package com.example.capabilities.nfc

import android.content.Context
import android.nfc.NfcAdapter
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

data class NfcInfo(
    val hasNfcHardware: Boolean,
    val isEnabled: Boolean,
    val isSecureNfcSupported: Boolean
)

interface NfcRepository {
    fun getNfcInfo(): CapabilityResult<NfcInfo>
}

@Singleton
class NfcRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : NfcRepository {

    override fun getNfcInfo(): CapabilityResult<NfcInfo> {
        return try {
            val nfcAdapter = NfcAdapter.getDefaultAdapter(context)
            if (nfcAdapter == null) {
                return CapabilityResult.Success(
                    NfcInfo(
                        hasNfcHardware = false,
                        isEnabled = false,
                        isSecureNfcSupported = false
                    )
                )
            }

            val isSecure = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                nfcAdapter.isSecureNfcSupported
            } else false

            CapabilityResult.Success(
                NfcInfo(
                    hasNfcHardware = true,
                    isEnabled = nfcAdapter.isEnabled,
                    isSecureNfcSupported = isSecure
                )
            )
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to query NFC: ${e.message}", e)
        }
    }
}
