package com.example.ffmpeg

import android.content.Context
import android.util.Log
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFprobeKit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object FFmpegDiagnostics {
    private const val TAG = "FFmpegDiagnostics"

    suspend fun runSelfTest(context: Context): DiagnosticResult = withContext(Dispatchers.IO) {
        try {
            val ffmpegVersion = FFmpegKit.execute("-version")
            val ffmpegSuccess = ffmpegVersion.returnCode.isValueSuccess

            val ffprobeVersion = FFprobeKit.execute("-version")
            val ffprobeSuccess = ffprobeVersion.returnCode.isValueSuccess

            val isAvailable = ffmpegSuccess && ffprobeSuccess

            DiagnosticResult(
                isAvailable = isAvailable,
                ffmpegOutput = ffmpegVersion.allLogsAsString,
                ffprobeOutput = ffprobeVersion.allLogsAsString,
                error = if (!isAvailable) "FFmpeg execution returned non-success" else null
            )
        } catch (e: Exception) {
            Log.e(TAG, "FFmpeg diagnostic test failed: ${e.message}", e)
            DiagnosticResult(
                isAvailable = false,
                ffmpegOutput = "",
                ffprobeOutput = "",
                error = e.message ?: "Unknown error loading native libraries"
            )
        } catch (e: UnsatisfiedLinkError) {
            Log.e(TAG, "Native library load failed. ABI mismatch or missing libraries.", e)
            DiagnosticResult(
                isAvailable = false,
                ffmpegOutput = "",
                ffprobeOutput = "",
                error = "ABI mismatch or missing native libraries: ${e.message}"
            )
        }
    }

    data class DiagnosticResult(
        val isAvailable: Boolean,
        val ffmpegOutput: String,
        val ffprobeOutput: String,
        val error: String?
    )
}
