package com.example.tools.core

interface Tool {
    val id: String
    val name: String
    val description: String
    val category: ToolCategory
    val requiredPermissions: List<String>
    val riskLevel: RiskLevel
    val timeoutMs: Long
    val version: String
    val dependencies: List<String>

    suspend fun initialize(): Boolean
    suspend fun validateInput(params: Map<String, Any>): Boolean
    suspend fun execute(context: ToolContext, params: Map<String, Any>): ToolResult
    suspend fun cancel(executionId: String)
    suspend fun cleanup()
}
