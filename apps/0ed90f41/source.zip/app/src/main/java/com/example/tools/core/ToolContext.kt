package com.example.tools.core

data class ToolContext(
    val conversationId: String,
    val sessionId: String,
    val userId: String = "default_user",
    val timestamp: Long = System.currentTimeMillis(),
    val executionId: String,
    val previousResults: Map<String, ToolResult> = emptyMap()
)
