package com.example.ui.theme

import androidx.compose.foundation.BorderStroke
import androidx.compose.runtime.Immutable
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * AURA ASSISTANT — Centralized Border Tokens
 * Thin, precise liquid glass edge strokes.
 */
@Immutable
object AuraBorders {
    val WidthSubtle: Dp = 1.dp
    val WidthNormal: Dp = 1.dp
    val WidthFocused: Dp = 1.dp
    val WidthActive: Dp = 1.dp

    val Subtle: BorderStroke = BorderStroke(WidthSubtle, AuraColors.BorderSubtle)
    val Normal: BorderStroke = BorderStroke(WidthNormal, AuraColors.BorderSubtle)
    val Focused: BorderStroke = BorderStroke(WidthFocused, AuraColors.BorderFocused)
    val Active: BorderStroke = BorderStroke(WidthActive, AuraColors.BorderActive)

    fun custom(alpha: Float, width: Dp = WidthNormal): BorderStroke {
        return BorderStroke(width, AuraColors.White.copy(alpha = alpha.coerceIn(0f, 1f)))
    }
}
