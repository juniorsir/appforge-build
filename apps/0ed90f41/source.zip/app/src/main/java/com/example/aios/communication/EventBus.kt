package com.example.aios.communication

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import javax.inject.Inject
import javax.inject.Singleton

data class AiosEvent(
    val id: String = java.util.UUID.randomUUID().toString(),
    val topic: String,
    val payload: String,
    val priority: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)

data class AgentMessage(
    val messageId: String = java.util.UUID.randomUUID().toString(),
    val senderId: String,
    val receiverId: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Singleton
class EventBus @Inject constructor() {
    private val _events = MutableSharedFlow<AiosEvent>(replay = 50)
    val events: Flow<AiosEvent> = _events.asSharedFlow()

    private val _messages = MutableSharedFlow<AgentMessage>(replay = 50)
    val messages: Flow<AgentMessage> = _messages.asSharedFlow()

    suspend fun publish(event: AiosEvent) {
        _events.emit(event)
    }

    suspend fun sendMessage(message: AgentMessage) {
        _messages.emit(message)
    }
}
