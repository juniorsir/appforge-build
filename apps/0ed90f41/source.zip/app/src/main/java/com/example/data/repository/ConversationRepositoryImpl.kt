package com.example.data.repository

import com.example.data.local.BrainDao
import com.example.data.local.BrainConversationEntity
import com.example.data.local.BrainMessageEntity
import com.example.domain.model.BrainConversation
import com.example.domain.model.BrainMessage
import com.example.domain.model.LlmMessage
import com.example.domain.repository.ConversationRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class ConversationRepositoryImpl(
    private val brainDao: BrainDao,
    private val scope: CoroutineScope
) : ConversationRepository {

    private val _activeConversation = MutableStateFlow<BrainConversation?>(null)
    override val activeConversation: StateFlow<BrainConversation?> = _activeConversation.asStateFlow()

    override var maxHistoryLength: Int = 20

    init {
        // Initialize active conversation with the latest one, if any, otherwise create a default one
        scope.launch {
            brainDao.getConversationsFlow().firstOrNull()?.firstOrNull()?.let { latest ->
                _activeConversation.value = latest.toDomain()
            } ?: run {
                createNewConversation("Initial Session")
            }
        }
    }

    override suspend fun setActiveConversation(conversationId: String) {
        val entity = brainDao.getConversation(conversationId)
        if (entity != null) {
            _activeConversation.value = entity.toDomain()
        }
    }

    override suspend fun createNewConversation(title: String): BrainConversation {
        val newId = UUID.randomUUID().toString()
        val conversation = BrainConversation(id = newId, title = title)
        brainDao.insertConversation(conversation.toEntity())
        _activeConversation.value = conversation
        return conversation
    }

    override fun getAllConversations(): Flow<List<BrainConversation>> {
        return brainDao.getConversationsFlow().map { list ->
            list.map { it.toDomain() }
        }
    }

    override fun getMessagesFlow(conversationId: String): Flow<List<BrainMessage>> {
        return brainDao.getMessagesForConversationFlow(conversationId).map { list ->
            list.map { it.toDomain() }
        }
    }

    override suspend fun getMessages(conversationId: String): List<BrainMessage> {
        return brainDao.getMessagesForConversation(conversationId).map { it.toDomain() }
    }

    override suspend fun addMessage(message: BrainMessage) {
        brainDao.insertMessage(message.toEntity())
        trimHistoryIfNeeded(message.conversationId)
    }

    override suspend fun trimHistoryIfNeeded(conversationId: String) {
        val messages = brainDao.getMessagesForConversation(conversationId)
        if (messages.size > maxHistoryLength) {
            // Trim older history but summarize what was lost so LLM retains memory of what happened!
            val trimCount = messages.size - maxHistoryLength
            summarizeOlderMessages(conversationId, keepCount = maxHistoryLength)
        }
    }

    override suspend fun resetConversation(conversationId: String) {
        brainDao.deleteMessagesForConversation(conversationId)
    }

    override suspend fun summarizeOlderMessages(conversationId: String, keepCount: Int) {
        val messages = brainDao.getMessagesForConversation(conversationId)
        if (messages.size <= keepCount) return

        val trimSlice = messages.subList(0, messages.size - keepCount)
        val keepSlice = messages.subList(messages.size - keepCount, messages.size)

        // Generate a placeholder summary text to avoid expensive real API calls during core trimming
        val summaryText = buildString {
            append("[Context Memory Summary] Older messages summarized for token budget: ")
            trimSlice.forEach { msg ->
                append("${msg.sender}: ${msg.text.take(30)}...; ")
            }
        }

        // Delete all old messages
        brainDao.deleteMessagesForConversation(conversationId)

        // Re-insert summary message at the very beginning
        val summaryId = UUID.randomUUID().toString()
        val summaryMessage = BrainMessageEntity(
            id = summaryId,
            conversationId = conversationId,
            sender = LlmMessage.Role.SYSTEM.name,
            text = summaryText,
            timestamp = System.currentTimeMillis() - 1000, // ensure it's oldest
            tokenCountPlaceholder = summaryText.length / 4,
            responseTimeMs = 0
        )
        brainDao.insertMessage(summaryMessage)

        // Re-insert the kept messages
        keepSlice.forEach { msg ->
            brainDao.insertMessage(msg)
        }
    }

    private fun BrainConversationEntity.toDomain() = BrainConversation(
        id = id,
        title = title,
        createdAt = createdAt,
        isArchived = isArchived
    )

    private fun BrainConversation.toEntity() = BrainConversationEntity(
        id = id,
        title = title,
        createdAt = createdAt,
        isArchived = isArchived
    )

    private fun BrainMessageEntity.toDomain() = BrainMessage(
        id = id,
        conversationId = conversationId,
        role = LlmMessage.Role.valueOf(sender),
        content = text,
        timestamp = timestamp,
        tokenCountPlaceholder = tokenCountPlaceholder,
        responseTimeMs = responseTimeMs
    )

    private fun BrainMessage.toEntity() = BrainMessageEntity(
        id = id,
        conversationId = conversationId,
        sender = role.name,
        text = content,
        timestamp = timestamp,
        tokenCountPlaceholder = tokenCountPlaceholder,
        responseTimeMs = responseTimeMs
    )
}
