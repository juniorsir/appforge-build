package com.example.data.repository

import android.util.Log
import com.example.domain.model.AiResponseEvent
import com.example.domain.repository.AiResponseRepository
import kotlinx.coroutines.flow.*

class AiResponseRepositoryImpl : AiResponseRepository {

    private val _responseEvents = MutableSharedFlow<AiResponseEvent>(replay = 5)
    override val responseEvents: Flow<AiResponseEvent> = _responseEvents.asSharedFlow()

    private val _lastResponseLatencyMs = MutableStateFlow(0L)
    override val lastResponseLatencyMs: StateFlow<Long> = _lastResponseLatencyMs.asStateFlow()

    private val _lastTokenCount = MutableStateFlow(0)
    override val lastTokenCount: StateFlow<Int> = _lastTokenCount.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    override val lastError: StateFlow<String?> = _lastError.asStateFlow()

    override suspend fun logEvent(event: AiResponseEvent) {
        _responseEvents.emit(event)
        
        when (event) {
            is AiResponseEvent.Start -> {
                Log.d("AiBrain", "[START] Stream started. Session: ${event.sessionId}, Msg: ${event.messageId}")
                _lastError.value = null
            }
            is AiResponseEvent.Partial -> {
                Log.v("AiBrain", "[PARTIAL] Token: '${event.text}'")
            }
            is AiResponseEvent.Final -> {
                Log.d("AiBrain", "[FINAL] Complete response generated: '${event.text}'")
            }
            is AiResponseEvent.End -> {
                Log.d("AiBrain", "[END] Completed successfully. Latency: ${event.responseTimeMs}ms, Tokens: ${event.totalTokensPlaceholder}")
                _lastResponseLatencyMs.value = event.responseTimeMs
                _lastTokenCount.value = event.totalTokensPlaceholder
            }
            is AiResponseEvent.Cancelled -> {
                Log.w("AiBrain", "[CANCEL] Generation cancelled by user.")
            }
            is AiResponseEvent.Error -> {
                Log.e("AiBrain", "[ERROR] Generation failed: ${event.error}")
                _lastError.value = event.error
            }
        }
    }
}
