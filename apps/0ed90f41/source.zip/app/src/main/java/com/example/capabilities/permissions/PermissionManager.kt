package com.example.capabilities.permissions

import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

enum class PermissionState {
    GRANTED,
    DENIED,
    PERMANENTLY_DENIED,
    NOT_REQUIRED,
    HARDWARE_UNAVAILABLE
}

data class PermissionDetail(
    val permission: String,
    val name: String,
    val group: String,
    val state: PermissionState,
    val rationale: String
)

enum class PermissionCategory(val displayName: String) {
    AUDIO("Voice & Audio"),
    CAMERA("Camera & Vision"),
    LOCATION("Location & GPS"),
    CONTACTS_CALENDAR("Contacts & Calendar"),
    PHONE_SMS("Telephony & SMS"),
    BLUETOOTH_WIRELESS("Bluetooth & Wireless"),
    STORAGE_MEDIA("Media & File Storage"),
    SENSORS_BIOMETRICS("Sensors & Biometrics"),
    NOTIFICATIONS_SERVICE("Notifications & Services"),
    SYSTEM_SPECIAL("System & Special Access")
}

enum class SpecialSettingType {
    NONE,
    APP_DETAILS,
    ACCESSIBILITY,
    BATTERY_OPTIMIZATION,
    OVERLAY,
    WRITE_SETTINGS,
    EXACT_ALARM,
    NOTIFICATION,
    NOTIFICATION_POLICY,
    ALL_FILES_ACCESS,
    LOCATION,
    BLUETOOTH,
    WIFI
}

data class PermissionItem(
    val id: String,
    val permission: String,
    val displayName: String,
    val category: PermissionCategory,
    val description: String,
    val isRuntime: Boolean = true,
    val specialSettingType: SpecialSettingType = SpecialSettingType.NONE,
    val minSdk: Int = 1,
    val maxSdk: Int = Int.MAX_VALUE,
    val requiredFeature: String? = null
)

@Singleton
class PermissionManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val TAG = "PermissionManager"

    val allDefinedPermissions: List<PermissionItem> = listOf(
        // 1. Audio & Voice
        PermissionItem(
            id = "record_audio",
            permission = android.Manifest.permission.RECORD_AUDIO,
            displayName = "Microphone Capture",
            category = PermissionCategory.AUDIO,
            description = "Required for low-latency voice streaming, ASR, and speech capture.",
            isRuntime = true,
            requiredFeature = PackageManager.FEATURE_MICROPHONE
        ),
        PermissionItem(
            id = "modify_audio",
            permission = android.Manifest.permission.MODIFY_AUDIO_SETTINGS,
            displayName = "Modify Audio Settings",
            category = PermissionCategory.AUDIO,
            description = "Allows configuring hardware AEC, AGC, and routing modes.",
            isRuntime = false
        ),
        PermissionItem(
            id = "fg_service_mic",
            permission = "android.permission.FOREGROUND_SERVICE_MICROPHONE",
            displayName = "Foreground Service (Microphone)",
            category = PermissionCategory.AUDIO,
            description = "Allows continuous background voice listening while screen is locked.",
            isRuntime = false,
            minSdk = 34
        ),

        // 2. Camera & Vision
        PermissionItem(
            id = "camera",
            permission = android.Manifest.permission.CAMERA,
            displayName = "Camera Access",
            category = PermissionCategory.CAMERA,
            description = "Captures visual context, object recognition, and video streaming.",
            isRuntime = true,
            requiredFeature = PackageManager.FEATURE_CAMERA_ANY
        ),
        PermissionItem(
            id = "fg_service_cam",
            permission = "android.permission.FOREGROUND_SERVICE_CAMERA",
            displayName = "Foreground Service (Camera)",
            category = PermissionCategory.CAMERA,
            description = "Allows background visual processing when camera pipeline is active.",
            isRuntime = false,
            minSdk = 34
        ),

        // 3. Location & GPS
        PermissionItem(
            id = "fine_location",
            permission = android.Manifest.permission.ACCESS_FINE_LOCATION,
            displayName = "Precise Location (GPS)",
            category = PermissionCategory.LOCATION,
            description = "Provides high-accuracy GPS coordinates for spatial context.",
            isRuntime = true,
            requiredFeature = PackageManager.FEATURE_LOCATION
        ),
        PermissionItem(
            id = "coarse_location",
            permission = android.Manifest.permission.ACCESS_COARSE_LOCATION,
            displayName = "Approximate Location",
            category = PermissionCategory.LOCATION,
            description = "Provides network-based coarse location estimates.",
            isRuntime = true,
            requiredFeature = PackageManager.FEATURE_LOCATION
        ),
        PermissionItem(
            id = "background_location",
            permission = "android.permission.ACCESS_BACKGROUND_LOCATION",
            displayName = "Background Location",
            category = PermissionCategory.LOCATION,
            description = "Allows location updates when the app is in background.",
            isRuntime = true,
            minSdk = 29,
            requiredFeature = PackageManager.FEATURE_LOCATION
        ),
        PermissionItem(
            id = "fg_service_loc",
            permission = "android.permission.FOREGROUND_SERVICE_LOCATION",
            displayName = "Foreground Service (Location)",
            category = PermissionCategory.LOCATION,
            description = "Enables ongoing navigation and geofencing in foreground service.",
            isRuntime = false,
            minSdk = 34
        ),

        // 4. Contacts & Calendar
        PermissionItem(
            id = "read_contacts",
            permission = android.Manifest.permission.READ_CONTACTS,
            displayName = "Read Contacts",
            category = PermissionCategory.CONTACTS_CALENDAR,
            description = "Allows querying contacts list and details via ContactsContract.",
            isRuntime = true
        ),
        PermissionItem(
            id = "write_contacts",
            permission = android.Manifest.permission.WRITE_CONTACTS,
            displayName = "Write Contacts",
            category = PermissionCategory.CONTACTS_CALENDAR,
            description = "Allows creating and updating contacts via ContactsContract.",
            isRuntime = true
        ),
        PermissionItem(
            id = "read_calendar",
            permission = android.Manifest.permission.READ_CALENDAR,
            displayName = "Read Calendar",
            category = PermissionCategory.CONTACTS_CALENDAR,
            description = "Queries upcoming calendar events and meeting schedules.",
            isRuntime = true
        ),
        PermissionItem(
            id = "write_calendar",
            permission = android.Manifest.permission.WRITE_CALENDAR,
            displayName = "Write Calendar",
            category = PermissionCategory.CONTACTS_CALENDAR,
            description = "Schedules new calendar events and reminders.",
            isRuntime = true
        ),

        // 5. Telephony & SMS
        PermissionItem(
            id = "send_sms",
            permission = android.Manifest.permission.SEND_SMS,
            displayName = "Send SMS",
            category = PermissionCategory.PHONE_SMS,
            description = "Allows sending text messages on behalf of the user.",
            isRuntime = true,
            requiredFeature = PackageManager.FEATURE_TELEPHONY
        ),
        PermissionItem(
            id = "read_sms",
            permission = android.Manifest.permission.READ_SMS,
            displayName = "Read SMS",
            category = PermissionCategory.PHONE_SMS,
            description = "Reads incoming and historical SMS text messages.",
            isRuntime = true,
            requiredFeature = PackageManager.FEATURE_TELEPHONY
        ),
        PermissionItem(
            id = "receive_sms",
            permission = android.Manifest.permission.RECEIVE_SMS,
            displayName = "Receive SMS",
            category = PermissionCategory.PHONE_SMS,
            description = "Monitors real-time incoming SMS messages.",
            isRuntime = true,
            requiredFeature = PackageManager.FEATURE_TELEPHONY
        ),
        PermissionItem(
            id = "read_phone_state",
            permission = android.Manifest.permission.READ_PHONE_STATE,
            displayName = "Read Phone State",
            category = PermissionCategory.PHONE_SMS,
            description = "Inspects cellular network state and call status.",
            isRuntime = true,
            requiredFeature = PackageManager.FEATURE_TELEPHONY
        ),
        PermissionItem(
            id = "read_phone_numbers",
            permission = "android.permission.READ_PHONE_NUMBERS",
            displayName = "Read Phone Numbers",
            category = PermissionCategory.PHONE_SMS,
            description = "Reads device phone numbers from SIM.",
            isRuntime = true,
            minSdk = 26,
            requiredFeature = PackageManager.FEATURE_TELEPHONY
        ),
        PermissionItem(
            id = "call_phone",
            permission = android.Manifest.permission.CALL_PHONE,
            displayName = "Direct Phone Calls",
            category = PermissionCategory.PHONE_SMS,
            description = "Initiates phone calls directly through telephony stack.",
            isRuntime = true,
            requiredFeature = PackageManager.FEATURE_TELEPHONY
        ),
        PermissionItem(
            id = "answer_phone_calls",
            permission = "android.permission.ANSWER_PHONE_CALLS",
            displayName = "Answer Phone Calls",
            category = PermissionCategory.PHONE_SMS,
            description = "Answers incoming phone calls programmatically.",
            isRuntime = true,
            minSdk = 26,
            requiredFeature = PackageManager.FEATURE_TELEPHONY
        ),

        // 6. Bluetooth & Wireless
        PermissionItem(
            id = "bt_scan",
            permission = "android.permission.BLUETOOTH_SCAN",
            displayName = "Bluetooth Scan (BLE)",
            category = PermissionCategory.BLUETOOTH_WIRELESS,
            description = "Discovers nearby Bluetooth and BLE peripheral devices.",
            isRuntime = true,
            minSdk = 31,
            requiredFeature = PackageManager.FEATURE_BLUETOOTH
        ),
        PermissionItem(
            id = "bt_connect",
            permission = "android.permission.BLUETOOTH_CONNECT",
            displayName = "Bluetooth Connect",
            category = PermissionCategory.BLUETOOTH_WIRELESS,
            description = "Pairs and exchanges GATT data with Bluetooth devices.",
            isRuntime = true,
            minSdk = 31,
            requiredFeature = PackageManager.FEATURE_BLUETOOTH
        ),
        PermissionItem(
            id = "bt_advertise",
            permission = "android.permission.BLUETOOTH_ADVERTISE",
            displayName = "Bluetooth Advertise",
            category = PermissionCategory.BLUETOOTH_WIRELESS,
            description = "Advertises BLE services to nearby receivers.",
            isRuntime = true,
            minSdk = 31,
            requiredFeature = PackageManager.FEATURE_BLUETOOTH
        ),
        PermissionItem(
            id = "nearby_wifi",
            permission = "android.permission.NEARBY_WIFI_DEVICES",
            displayName = "Nearby Wi-Fi Devices",
            category = PermissionCategory.BLUETOOTH_WIRELESS,
            description = "Discovers and communicates with Wi-Fi Direct devices.",
            isRuntime = true,
            minSdk = 33,
            requiredFeature = PackageManager.FEATURE_WIFI
        ),
        PermissionItem(
            id = "bluetooth_legacy",
            permission = android.Manifest.permission.BLUETOOTH,
            displayName = "Bluetooth Basic",
            category = PermissionCategory.BLUETOOTH_WIRELESS,
            description = "Allows connecting to paired Bluetooth devices on older Android.",
            isRuntime = false,
            requiredFeature = PackageManager.FEATURE_BLUETOOTH
        ),
        PermissionItem(
            id = "bluetooth_admin",
            permission = "android.permission.BLUETOOTH_ADMIN",
            displayName = "Bluetooth Admin",
            category = PermissionCategory.BLUETOOTH_WIRELESS,
            description = "Controls Bluetooth discovery and device pairing parameters.",
            isRuntime = false,
            requiredFeature = PackageManager.FEATURE_BLUETOOTH
        ),
        PermissionItem(
            id = "change_wifi_state",
            permission = "android.permission.CHANGE_WIFI_STATE",
            displayName = "Change Wi-Fi State",
            category = PermissionCategory.BLUETOOTH_WIRELESS,
            description = "Allows toggling and configuring Wi-Fi connectivity.",
            isRuntime = false,
            requiredFeature = PackageManager.FEATURE_WIFI
        ),
        PermissionItem(
            id = "change_network_state",
            permission = "android.permission.CHANGE_NETWORK_STATE",
            displayName = "Change Network State",
            category = PermissionCategory.BLUETOOTH_WIRELESS,
            description = "Allows modifying network connectivity and preferred interfaces.",
            isRuntime = false
        ),
        PermissionItem(
            id = "nfc",
            permission = android.Manifest.permission.NFC,
            displayName = "NFC Communication",
            category = PermissionCategory.BLUETOOTH_WIRELESS,
            description = "Transfers NDEF tags and engages in contactless interactions.",
            isRuntime = false,
            requiredFeature = PackageManager.FEATURE_NFC
        ),

        // 7. Media & Storage
        PermissionItem(
            id = "media_images",
            permission = "android.permission.READ_MEDIA_IMAGES",
            displayName = "Read Media Images",
            category = PermissionCategory.STORAGE_MEDIA,
            description = "Accesses photos and gallery images on Android 13+.",
            isRuntime = true,
            minSdk = 33
        ),
        PermissionItem(
            id = "media_video",
            permission = "android.permission.READ_MEDIA_VIDEO",
            displayName = "Read Media Videos",
            category = PermissionCategory.STORAGE_MEDIA,
            description = "Accesses recorded and saved videos on Android 13+.",
            isRuntime = true,
            minSdk = 33
        ),
        PermissionItem(
            id = "media_audio",
            permission = "android.permission.READ_MEDIA_AUDIO",
            displayName = "Read Media Audio",
            category = PermissionCategory.STORAGE_MEDIA,
            description = "Accesses audio files and music tracks on Android 13+.",
            isRuntime = true,
            minSdk = 33
        ),
        PermissionItem(
            id = "legacy_read_storage",
            permission = "android.permission.READ_EXTERNAL_STORAGE",
            displayName = "Read External Storage",
            category = PermissionCategory.STORAGE_MEDIA,
            description = "Accesses shared files on Android 12 and below.",
            isRuntime = true,
            maxSdk = 32
        ),
        PermissionItem(
            id = "legacy_write_storage",
            permission = "android.permission.WRITE_EXTERNAL_STORAGE",
            displayName = "Write External Storage",
            category = PermissionCategory.STORAGE_MEDIA,
            description = "Writes files to shared storage on Android 9 and below.",
            isRuntime = true,
            maxSdk = 28
        ),
        PermissionItem(
            id = "manage_external_storage",
            permission = "android.permission.MANAGE_EXTERNAL_STORAGE",
            displayName = "All Files Access (Storage Manager)",
            category = PermissionCategory.STORAGE_MEDIA,
            description = "Full filesystem access across shared external storage for media files.",
            isRuntime = false,
            specialSettingType = SpecialSettingType.ALL_FILES_ACCESS,
            minSdk = 30
        ),

        // 8. Sensors & Biometrics
        PermissionItem(
            id = "body_sensors",
            permission = "android.permission.BODY_SENSORS",
            displayName = "Body & Health Sensors",
            category = PermissionCategory.SENSORS_BIOMETRICS,
            description = "Measures heart rate and wearable physiological signals.",
            isRuntime = true,
            requiredFeature = PackageManager.FEATURE_SENSOR_HEART_RATE
        ),
        PermissionItem(
            id = "body_sensors_bg",
            permission = "android.permission.BODY_SENSORS_BACKGROUND",
            displayName = "Background Body Sensors",
            category = PermissionCategory.SENSORS_BIOMETRICS,
            description = "Continuously gathers physiological data while app is backgrounded.",
            isRuntime = true,
            minSdk = 33,
            requiredFeature = PackageManager.FEATURE_SENSOR_HEART_RATE
        ),
        PermissionItem(
            id = "activity_recognition",
            permission = "android.permission.ACTIVITY_RECOGNITION",
            displayName = "Physical Activity Recognition",
            category = PermissionCategory.SENSORS_BIOMETRICS,
            description = "Detects walking, running, cycling, and step tracking.",
            isRuntime = true,
            minSdk = 29
        ),
        PermissionItem(
            id = "high_sampling_rate_sensors",
            permission = "android.permission.HIGH_SAMPLING_RATE_SENSORS",
            displayName = "High Sampling Rate Sensors",
            category = PermissionCategory.SENSORS_BIOMETRICS,
            description = "Allows querying motion sensors at >200Hz for high precision tracking.",
            isRuntime = false,
            minSdk = 31
        ),
        PermissionItem(
            id = "vibrate",
            permission = android.Manifest.permission.VIBRATE,
            displayName = "Haptic Vibration",
            category = PermissionCategory.SENSORS_BIOMETRICS,
            description = "Provides tactile haptic feedback during assistant interactions.",
            isRuntime = false
        ),
        PermissionItem(
            id = "biometric",
            permission = "android.permission.USE_BIOMETRIC",
            displayName = "Biometric Authentication",
            category = PermissionCategory.SENSORS_BIOMETRICS,
            description = "Authenticates user via Fingerprint, Face, or BiometricPrompt.",
            isRuntime = false,
            minSdk = 28
        ),
        PermissionItem(
            id = "fingerprint",
            permission = "android.permission.USE_FINGERPRINT",
            displayName = "Fingerprint Sensor",
            category = PermissionCategory.SENSORS_BIOMETRICS,
            description = "Authenticates using legacy fingerprint hardware scanner.",
            isRuntime = false,
            maxSdk = 27,
            requiredFeature = PackageManager.FEATURE_FINGERPRINT
        ),

        // 9. Notifications & Services
        PermissionItem(
            id = "post_notifications",
            permission = "android.permission.POST_NOTIFICATIONS",
            displayName = "Post Notifications",
            category = PermissionCategory.NOTIFICATIONS_SERVICE,
            description = "Sends active alerts, background updates, and audio status.",
            isRuntime = true,
            minSdk = 33
        ),
        PermissionItem(
            id = "foreground_service",
            permission = "android.permission.FOREGROUND_SERVICE",
            displayName = "Foreground Service",
            category = PermissionCategory.NOTIFICATIONS_SERVICE,
            description = "Runs resilient foreground background tasks.",
            isRuntime = false
        ),
        PermissionItem(
            id = "fg_service_media",
            permission = "android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK",
            displayName = "Foreground Service (Playback)",
            category = PermissionCategory.NOTIFICATIONS_SERVICE,
            description = "Maintains audio streaming playback when app is minimized.",
            isRuntime = false,
            minSdk = 34
        ),
        PermissionItem(
            id = "fg_service_connected_device",
            permission = "android.permission.FOREGROUND_SERVICE_CONNECTED_DEVICE",
            displayName = "Foreground Service (Connected Device)",
            category = PermissionCategory.NOTIFICATIONS_SERVICE,
            description = "Maintains connection with Bluetooth/USB external hardware peripherals.",
            isRuntime = false,
            minSdk = 34
        ),
        PermissionItem(
            id = "fg_service_data_sync",
            permission = "android.permission.FOREGROUND_SERVICE_DATA_SYNC",
            displayName = "Foreground Service (Data Sync)",
            category = PermissionCategory.NOTIFICATIONS_SERVICE,
            description = "Syncs background AI models, context data, and cache buffers.",
            isRuntime = false,
            minSdk = 34
        ),
        PermissionItem(
            id = "boot_completed",
            permission = "android.permission.RECEIVE_BOOT_COMPLETED",
            displayName = "Start on Boot",
            category = PermissionCategory.NOTIFICATIONS_SERVICE,
            description = "Resumes background alarms and monitoring after device reboot.",
            isRuntime = false
        ),
        PermissionItem(
            id = "wake_lock",
            permission = android.Manifest.permission.WAKE_LOCK,
            displayName = "Wake Lock",
            category = PermissionCategory.NOTIFICATIONS_SERVICE,
            description = "Prevents CPU sleep during real-time low-latency audio capture.",
            isRuntime = false
        ),
        PermissionItem(
            id = "schedule_alarm",
            permission = "android.permission.SCHEDULE_EXACT_ALARM",
            displayName = "Exact Alarms",
            category = PermissionCategory.NOTIFICATIONS_SERVICE,
            description = "Schedules precise timing alerts and reminder triggers.",
            isRuntime = false,
            specialSettingType = SpecialSettingType.EXACT_ALARM,
            minSdk = 31
        ),

        // 10. System & Special Access
        PermissionItem(
            id = "accessibility_service",
            permission = "android.permission.BIND_ACCESSIBILITY_SERVICE",
            displayName = "Accessibility Service",
            category = PermissionCategory.SYSTEM_SPECIAL,
            description = "Enables AI assistant UI automation and screen interaction.",
            isRuntime = false,
            specialSettingType = SpecialSettingType.ACCESSIBILITY
        ),
        PermissionItem(
            id = "battery_optimization",
            permission = "android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS",
            displayName = "Ignore Battery Optimization",
            category = PermissionCategory.SYSTEM_SPECIAL,
            description = "Prevents OS from throttling real-time audio and background tasks.",
            isRuntime = false,
            specialSettingType = SpecialSettingType.BATTERY_OPTIMIZATION
        ),
        PermissionItem(
            id = "system_overlay",
            permission = "android.permission.SYSTEM_ALERT_WINDOW",
            displayName = "Draw Over Other Apps (Overlay)",
            category = PermissionCategory.SYSTEM_SPECIAL,
            description = "Displays floating voice bubble and HUD over any application.",
            isRuntime = false,
            specialSettingType = SpecialSettingType.OVERLAY
        ),
        PermissionItem(
            id = "write_settings",
            permission = "android.permission.WRITE_SETTINGS",
            displayName = "Modify System Settings",
            category = PermissionCategory.SYSTEM_SPECIAL,
            description = "Adjusts system volume, brightness, and screen timeout.",
            isRuntime = false,
            specialSettingType = SpecialSettingType.WRITE_SETTINGS
        ),
        PermissionItem(
            id = "notification_policy",
            permission = "android.permission.ACCESS_NOTIFICATION_POLICY",
            displayName = "Do Not Disturb / Notification Policy",
            category = PermissionCategory.SYSTEM_SPECIAL,
            description = "Controls Do Not Disturb mode and audio notification streams.",
            isRuntime = false,
            specialSettingType = SpecialSettingType.NOTIFICATION_POLICY,
            minSdk = 23
        ),
        PermissionItem(
            id = "read_sync_settings",
            permission = "android.permission.READ_SYNC_SETTINGS",
            displayName = "Read Sync Settings",
            category = PermissionCategory.SYSTEM_SPECIAL,
            description = "Checks background synchronization status for account data.",
            isRuntime = false
        ),
        PermissionItem(
            id = "write_sync_settings",
            permission = "android.permission.WRITE_SYNC_SETTINGS",
            displayName = "Write Sync Settings",
            category = PermissionCategory.SYSTEM_SPECIAL,
            description = "Controls periodic background sync configurations.",
            isRuntime = false
        ),
        PermissionItem(
            id = "internet",
            permission = android.Manifest.permission.INTERNET,
            displayName = "Internet Access",
            category = PermissionCategory.SYSTEM_SPECIAL,
            description = "Connects to real-time Gemini AI streaming endpoints.",
            isRuntime = false
        ),
        PermissionItem(
            id = "network_state",
            permission = android.Manifest.permission.ACCESS_NETWORK_STATE,
            displayName = "Network State Monitor",
            category = PermissionCategory.SYSTEM_SPECIAL,
            description = "Monitors active internet connectivity and bandwidth.",
            isRuntime = false
        ),
        PermissionItem(
            id = "wifi_state",
            permission = android.Manifest.permission.ACCESS_WIFI_STATE,
            displayName = "Wi-Fi State Monitor",
            category = PermissionCategory.SYSTEM_SPECIAL,
            description = "Monitors Wi-Fi connection quality and signal strength.",
            isRuntime = false
        )
    )

    fun hasPermission(permission: String): Boolean {
        if (permission.isEmpty()) return true
        val granted = ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
        return granted
    }

    fun hasAllPermissions(permissions: List<String>): Boolean {
        return permissions.all { hasPermission(it) }
    }
    
    fun getMissingPermissions(permissions: List<String>): List<String> {
        return permissions.filter { !hasPermission(it) }.also {
            if (it.isNotEmpty()) {
                Log.w(TAG, "Missing permissions: $it")
            }
        }
    }

    fun getPermissionItemState(item: PermissionItem, activity: Activity? = null): PermissionState {
        // SDK Version check
        if (Build.VERSION.SDK_INT < item.minSdk || Build.VERSION.SDK_INT > item.maxSdk) {
            return PermissionState.NOT_REQUIRED
        }

        // Hardware feature check
        if (item.requiredFeature != null && !hasHardwareFeature(item.requiredFeature)) {
            return PermissionState.HARDWARE_UNAVAILABLE
        }

        // Special settings check
        when (item.specialSettingType) {
            SpecialSettingType.OVERLAY -> {
                return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (Settings.canDrawOverlays(context)) PermissionState.GRANTED else PermissionState.DENIED
                } else PermissionState.GRANTED
            }
            SpecialSettingType.WRITE_SETTINGS -> {
                return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (Settings.System.canWrite(context)) PermissionState.GRANTED else PermissionState.DENIED
                } else PermissionState.GRANTED
            }
            SpecialSettingType.BATTERY_OPTIMIZATION -> {
                val powerManager = context.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
                return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && powerManager != null) {
                    if (powerManager.isIgnoringBatteryOptimizations(context.packageName)) PermissionState.GRANTED else PermissionState.DENIED
                } else PermissionState.GRANTED
            }
            SpecialSettingType.ACCESSIBILITY -> {
                val enabledServices = Settings.Secure.getString(
                    context.contentResolver,
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
                ) ?: ""
                val isEnabled = enabledServices.contains(context.packageName)
                return if (isEnabled) PermissionState.GRANTED else PermissionState.DENIED
            }
            SpecialSettingType.NOTIFICATION_POLICY -> {
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && notificationManager != null) {
                    if (notificationManager.isNotificationPolicyAccessGranted) PermissionState.GRANTED else PermissionState.DENIED
                } else PermissionState.GRANTED
            }
            SpecialSettingType.ALL_FILES_ACCESS -> {
                return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    if (Environment.isExternalStorageManager()) PermissionState.GRANTED else PermissionState.DENIED
                } else PermissionState.GRANTED
            }
            SpecialSettingType.EXACT_ALARM -> {
                val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? android.app.AlarmManager
                return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarmManager != null) {
                    if (alarmManager.canScheduleExactAlarms()) PermissionState.GRANTED else PermissionState.DENIED
                } else PermissionState.GRANTED
            }
            else -> {}
        }

        if (hasPermission(item.permission)) return PermissionState.GRANTED

        if (item.isRuntime && activity != null) {
            val shouldShowRationale = ActivityCompat.shouldShowRequestPermissionRationale(activity, item.permission)
            return if (shouldShowRationale) PermissionState.DENIED else PermissionState.DENIED
        }

        return if (item.isRuntime) PermissionState.DENIED else PermissionState.GRANTED
    }

    fun getPermissionState(permission: String, activity: Activity? = null): PermissionState {
        if (hasPermission(permission)) return PermissionState.GRANTED
        if (activity != null) {
            val shouldShowRationale = ActivityCompat.shouldShowRequestPermissionRationale(activity, permission)
            return if (shouldShowRationale) PermissionState.DENIED else PermissionState.PERMANENTLY_DENIED
        }
        return PermissionState.DENIED
    }

    fun getRuntimePermissionsToRequest(): List<String> {
        return allDefinedPermissions
            .filter { item ->
                item.isRuntime &&
                Build.VERSION.SDK_INT >= item.minSdk &&
                Build.VERSION.SDK_INT <= item.maxSdk &&
                (item.requiredFeature == null || hasHardwareFeature(item.requiredFeature)) &&
                !hasPermission(item.permission) &&
                item.permission != "android.permission.ACCESS_BACKGROUND_LOCATION" &&
                item.permission != "android.permission.BODY_SENSORS_BACKGROUND"
            }
            .map { it.permission }
    }

    fun hasHardwareFeature(feature: String): Boolean {
        return context.packageManager.hasSystemFeature(feature)
    }

    fun createSpecialIntent(item: PermissionItem): Intent {
        return when (item.specialSettingType) {
            SpecialSettingType.ACCESSIBILITY -> createAccessibilitySettingsIntent()
            SpecialSettingType.BATTERY_OPTIMIZATION -> createBatteryOptimizationSettingsIntent()
            SpecialSettingType.OVERLAY -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                } else {
                    createAppSettingsIntent()
                }
            }
            SpecialSettingType.WRITE_SETTINGS -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                } else {
                    createAppSettingsIntent()
                }
            }
            SpecialSettingType.EXACT_ALARM -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                } else {
                    createAppSettingsIntent()
                }
            }
            SpecialSettingType.NOTIFICATION_POLICY -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                } else {
                    createAppSettingsIntent()
                }
            }
            SpecialSettingType.ALL_FILES_ACCESS -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    try {
                        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${context.packageName}")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                    } catch (e: Exception) {
                        Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                    }
                } else {
                    createAppSettingsIntent()
                }
            }
            SpecialSettingType.NOTIFICATION -> createNotificationSettingsIntent()
            SpecialSettingType.LOCATION -> createLocationSettingsIntent()
            SpecialSettingType.BLUETOOTH -> createBluetoothSettingsIntent()
            SpecialSettingType.WIFI -> createWifiSettingsIntent()
            else -> createAppSettingsIntent()
        }
    }

    fun createAppSettingsIntent(): Intent {
        return Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun createLocationSettingsIntent(): Intent {
        return Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun createBluetoothSettingsIntent(): Intent {
        return Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun createWifiSettingsIntent(): Intent {
        return Intent(Settings.ACTION_WIFI_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun createAccessibilitySettingsIntent(): Intent {
        return Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun createNotificationSettingsIntent(): Intent {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        } else {
            createAppSettingsIntent()
        }
    }

    fun createBatteryOptimizationSettingsIntent(): Intent {
        return Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }
}
