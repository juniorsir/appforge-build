package com.example.di

import android.content.Context
import androidx.room.Room
import com.example.data.local.CompanionDao
import com.example.data.local.CompanionDatabase
import com.example.data.remote.RealtimeWebSocketClient
import com.example.data.remote.RealtimeWebSocketClientStub
import com.example.data.repository.*
import com.example.domain.repository.*
import com.example.domain.usecase.*
import com.example.util.AndroidLogger
import com.example.util.AppLogger
import com.example.util.ConfigurationManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import javax.inject.Singleton

/**
 * Standard Hilt Modules prepared for production deployment.
 * Declares providers for database, networking stub layers, repositories, and usecases.
 */
@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): CompanionDatabase {
        return Room.databaseBuilder(
            context,
            CompanionDatabase::class.java,
            "companion_database"
        ).fallbackToDestructiveMigration().build()
    }

    @Provides
    @Singleton
    fun provideCompanionDao(database: CompanionDatabase): CompanionDao {
        return database.companionDao()
    }

    @Provides
    @Singleton
    fun provideBrainDao(database: CompanionDatabase): com.example.data.local.BrainDao {
        return database.brainDao()
    }
}

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides
    @Singleton
    fun provideAppLogger(): AppLogger {
        return AndroidLogger()
    }

    @Provides
    @Singleton
    fun provideConfigurationManager(@ApplicationContext context: Context): ConfigurationManager {
        return ConfigurationManager(context)
    }

    @Provides
    @Singleton
    fun provideApplicationScope(): CoroutineScope {
        return CoroutineScope(SupervisorJob() + Dispatchers.Main)
    }

    @Provides
    @Singleton
    fun provideOkHttpClient(): okhttp3.OkHttpClient {
        return okhttp3.OkHttpClient.Builder()
            .connectTimeout(5, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
            .writeTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
            .pingInterval(10, java.util.concurrent.TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    @Provides
    @Singleton
    fun provideWebSocketClient(logger: AppLogger, scope: CoroutineScope): RealtimeWebSocketClient {
        return RealtimeWebSocketClientStub(logger, scope)
    }
}

@Module
@InstallIn(SingletonComponent::class)
object RepositoryModule {

    @Provides
    @Singleton
    fun provideCompanionRepository(
        companionDao: CompanionDao,
        webSocketClient: RealtimeWebSocketClient,
        logger: AppLogger,
        scope: CoroutineScope
    ): CompanionRepository {
        return CompanionRepositoryImpl(companionDao, webSocketClient, logger, scope)
    }

    @Provides
    @Singleton
    fun provideSessionRepository(@ApplicationContext context: Context): SessionRepository {
        return SessionRepositoryImpl(context)
    }

    @Provides
    @Singleton
    fun provideWebSocketRepository(
        okHttpClient: okhttp3.OkHttpClient,
        logger: AppLogger,
        scope: CoroutineScope
    ): WebSocketRepository {
        return WebSocketRepositoryImpl(okHttpClient, logger, scope)
    }

    @Provides
    @Singleton
    fun provideTranscriptRepository(): TranscriptRepository {
        return TranscriptRepositoryImpl()
    }

    @Provides
    @Singleton
    fun provideSessionTranscriptRepository(
        companionDao: CompanionDao,
        scope: CoroutineScope
    ): SessionTranscriptRepository {
        return SessionTranscriptRepositoryImpl(companionDao, scope)
    }

    @Provides
    @Singleton
    fun provideSpeechRepository(
        webSocketRepository: WebSocketRepository,
        transcriptRepository: TranscriptRepository,
        sessionTranscriptRepository: SessionTranscriptRepository,
        sessionRepository: SessionRepository,
        scope: CoroutineScope
    ): SpeechRepository {
        return SpeechRepositoryImpl(
            webSocketRepository,
            transcriptRepository,
            sessionTranscriptRepository,
            sessionRepository,
            scope
        )
    }

    @Provides
    @Singleton
    fun provideLlmProvider(): LlmProvider {
        return MockLlmProvider()
    }

    @Provides
    @Singleton
    fun providePromptRepository(brainDao: com.example.data.local.BrainDao): PromptRepository {
        return PromptRepositoryImpl(brainDao)
    }

    @Provides
    @Singleton
    fun provideAiResponseRepository(): AiResponseRepository {
        return AiResponseRepositoryImpl()
    }

    @Provides
    @Singleton
    fun provideBrainConversationRepository(
        brainDao: com.example.data.local.BrainDao,
        scope: CoroutineScope
    ): ConversationRepository {
        return ConversationRepositoryImpl(brainDao, scope)
    }
}

@Module
@InstallIn(SingletonComponent::class)
object UseCaseModule {

    @Provides
    @Singleton
    fun provideGetCompanionConfigUseCase(repository: CompanionRepository) = GetCompanionConfigUseCase(repository)

    @Provides
    @Singleton
    fun provideSaveCompanionConfigUseCase(repository: CompanionRepository) = SaveCompanionConfigUseCase(repository)

    @Provides
    @Singleton
    fun provideGetSessionHistoryUseCase(repository: CompanionRepository) = GetSessionHistoryUseCase(repository)

    @Provides
    @Singleton
    fun provideSendMessageUseCase(repository: CompanionRepository) = SendMessageUseCase(repository)

    @Provides
    @Singleton
    fun provideGetSessionStateUseCase(repository: CompanionRepository) = GetSessionStateUseCase(repository)

    @Provides
    @Singleton
    fun provideToggleStreamConnectionUseCase(repository: CompanionRepository) = ToggleStreamConnectionUseCase(repository)
}
