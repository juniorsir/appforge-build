package com.example.capabilities.info

import android.os.Build
import android.util.DisplayMetrics
import android.content.Context
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

data class DeviceInfo(
    val manufacturer: String,
    val model: String,
    val androidVersion: String,
    val sdkVersion: Int,
    val screenWidthPixels: Int,
    val screenHeightPixels: Int,
    val density: Float,
    val cpuAbi: String,
    val locale: String,
    val timeZone: String
)

interface DeviceInfoRepository {
    fun getDeviceInfo(): CapabilityResult<DeviceInfo>
}

class DeviceInfoRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : DeviceInfoRepository {
    override fun getDeviceInfo(): CapabilityResult<DeviceInfo> {
        return try {
            val metrics: DisplayMetrics = context.resources.displayMetrics
            val info = DeviceInfo(
                manufacturer = Build.MANUFACTURER,
                model = Build.MODEL,
                androidVersion = Build.VERSION.RELEASE,
                sdkVersion = Build.VERSION.SDK_INT,
                screenWidthPixels = metrics.widthPixels,
                screenHeightPixels = metrics.heightPixels,
                density = metrics.density,
                cpuAbi = Build.SUPPORTED_ABIS.firstOrNull() ?: "Unknown",
                locale = context.resources.configuration.locales.get(0).toString(),
                timeZone = java.util.TimeZone.getDefault().id
            )
            CapabilityResult.Success(info)
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to get device info", e)
        }
    }
}
