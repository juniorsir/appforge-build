package com.example.tools.plugins

data class PluginManifest(
    val pluginId: String,
    val name: String,
    val description: String,
    val version: String,
    val requiredPermissions: List<String>,
    val capabilities: List<String>,
    val dependencies: List<String>
)

enum class PluginState {
    UNINITIALIZED, INITIALIZING, ACTIVE, STOPPED, ERROR
}

interface Plugin {
    val manifest: PluginManifest
    var state: PluginState
    
    suspend fun initialize(): Boolean
    suspend fun start(): Boolean
    suspend fun stop(): Boolean
    fun getTools(): List<com.example.tools.core.Tool>
}
