package com.example.tools.core

sealed class ToolResult {
    data class Success(val data: Any, val message: String? = null) : ToolResult()
    data class PartialSuccess(val data: Any, val message: String? = null, val warnings: List<String>) : ToolResult()
    data class Failure(val error: String, val exception: Exception? = null) : ToolResult()
    data class Cancelled(val reason: String) : ToolResult()
    data class ValidationFailed(val reason: String) : ToolResult()
    data class RequiresConfirmation(val executionId: String) : ToolResult()
}
