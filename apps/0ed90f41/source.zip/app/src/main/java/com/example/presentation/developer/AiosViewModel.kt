package com.example.presentation.developer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.BaseApplication
import com.example.aios.core.*
import com.example.aios.planning.*
import com.example.aios.communication.*
import com.example.aios.workflows.*
import com.example.aios.scheduler.*
import com.example.aios.observability.*
import com.example.aios.sdk.AiosSdk
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class AiosViewModel(
    private val agentManager: AgentManager,
    private val taskPlanner: TaskPlanner,
    private val eventBus: EventBus,
    private val workflowEngine: WorkflowEngine,
    private val scheduler: Scheduler,
    private val metricsTracker: MetricsTracker
) : ViewModel() {

    val agents: StateFlow<List<Agent>> = agentManager.agentsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeGoals: StateFlow<List<Goal>> = taskPlanner.activeGoals
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val workflows: StateFlow<List<Workflow>> = workflowEngine.workflows
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val schedules: StateFlow<List<ScheduledTask>> = scheduler.schedules
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs: StateFlow<List<AuditLogEntry>> = metricsTracker.auditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val eventLogs: StateFlow<List<AiosEvent>> = flow {
        val list = mutableListOf<AiosEvent>()
        eventBus.events.collect { event ->
            list.add(0, event)
            emit(list.toList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun triggerGoal(goalText: String) {
        viewModelScope.launch {
            eventBus.publish(AiosEvent(topic = "USER_GOAL", payload = goalText))
            taskPlanner.planAndExecute(goalText)
        }
    }

    fun triggerWorkflow(workflowId: String) {
        viewModelScope.launch {
            eventBus.publish(AiosEvent(topic = "WORKFLOW_TRIGGER", payload = workflowId))
            workflowEngine.executeWorkflow(workflowId)
        }
    }

    fun toggleSchedule(scheduleId: String) {
        viewModelScope.launch {
            eventBus.publish(AiosEvent(topic = "SCHEDULE_TOGGLE", payload = scheduleId))
            scheduler.toggleSchedule(scheduleId)
        }
    }

    fun addCustomSchedule(name: String, cron: String, workflowId: String) {
        viewModelScope.launch {
            val task = ScheduledTask(name = name, cronExpression = cron, workflowId = workflowId)
            eventBus.publish(AiosEvent(topic = "SCHEDULE_ADDED", payload = task.name))
            scheduler.addSchedule(task)
        }
    }

    fun addCustomWorkflow(name: String, description: String, stepGoals: List<String>) {
        viewModelScope.launch {
            val workflow = Workflow(
                id = java.util.UUID.randomUUID().toString(),
                name = name,
                description = description,
                stepGoals = stepGoals
            )
            eventBus.publish(AiosEvent(topic = "WORKFLOW_ADDED", payload = workflow.name))
            workflowEngine.addCustomWorkflow(workflow)
        }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as BaseApplication
                val container = app.container
                AiosViewModel(
                    agentManager = container.agentManager,
                    taskPlanner = container.taskPlanner,
                    eventBus = container.eventBus,
                    workflowEngine = container.workflowEngine,
                    scheduler = container.scheduler,
                    metricsTracker = container.metricsTracker
                )
            }
        }
    }
}
