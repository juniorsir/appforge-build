package com.example.aios.observability

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

data class AuditLogEntry(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val agentId: String,
    val action: String,
    val details: String,
    val isApproved: Boolean = true
)

@Singleton
class MetricsTracker @Inject constructor() {
    private val _executionCount = MutableStateFlow<Map<String, Int>>(emptyMap())
    val executionCount: StateFlow<Map<String, Int>> = _executionCount

    private val _successCount = MutableStateFlow<Map<String, Int>>(emptyMap())
    val successCount: StateFlow<Map<String, Int>> = _successCount

    private val _failureCount = MutableStateFlow<Map<String, Int>>(emptyMap())
    val failureCount: StateFlow<Map<String, Int>> = _failureCount

    private val _auditLogs = MutableStateFlow<List<AuditLogEntry>>(emptyList())
    val auditLogs: StateFlow<List<AuditLogEntry>> = _auditLogs

    fun trackExecutionStart(taskId: String, agentId: String) {
        val current = _executionCount.value.toMutableMap()
        current[agentId] = (current[agentId] ?: 0) + 1
        _executionCount.value = current
        logAudit(agentId, "EXECUTION_START", "Task ID: $taskId has commenced execution")
    }

    fun trackExecutionSuccess(taskId: String, agentId: String) {
        val current = _successCount.value.toMutableMap()
        current[agentId] = (current[agentId] ?: 0) + 1
        _successCount.value = current
        logAudit(agentId, "EXECUTION_SUCCESS", "Task ID: $taskId completed successfully")
    }

    fun trackExecutionFailure(taskId: String, agentId: String, error: String) {
        val current = _failureCount.value.toMutableMap()
        current[agentId] = (current[agentId] ?: 0) + 1
        _failureCount.value = current
        logAudit(agentId, "EXECUTION_FAILURE", "Task ID: $taskId failed. Reason: $error")
    }

    fun logAudit(agentId: String, action: String, details: String, isApproved: Boolean = true) {
        val list = _auditLogs.value.toMutableList()
        list.add(0, AuditLogEntry(agentId = agentId, action = action, details = details, isApproved = isApproved))
        _auditLogs.value = list
    }
}
