package com.example.capabilities.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

data class NetworkInfo(
    val isConnected: Boolean,
    val connectionType: String,
    val bandwidthDownKbps: Int
)

interface NetworkRepository {
    fun getNetworkInfo(): CapabilityResult<NetworkInfo>
}

class NetworkRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : NetworkRepository {
    override fun getNetworkInfo(): CapabilityResult<NetworkInfo> {
        return try {
            val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = connectivityManager.activeNetwork
            val capabilities = connectivityManager.getNetworkCapabilities(network)
            
            val isConnected = capabilities != null && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            var connectionType = "None"
            var bandwidthDown = 0
            
            if (capabilities != null) {
                if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    connectionType = "Wi-Fi"
                } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                    connectionType = "Cellular"
                } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
                    connectionType = "Ethernet"
                }
                bandwidthDown = capabilities.linkDownstreamBandwidthKbps
            }
            
            CapabilityResult.Success(
                NetworkInfo(
                    isConnected = isConnected,
                    connectionType = connectionType,
                    bandwidthDownKbps = bandwidthDown
                )
            )
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to get network info", e)
        }
    }
}
