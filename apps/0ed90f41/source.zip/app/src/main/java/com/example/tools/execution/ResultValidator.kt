package com.example.tools.execution

import com.example.tools.core.ToolResult
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ResultValidator @Inject constructor() {
    fun validate(result: ToolResult): ToolResult {
        // Validate result format, intercept unexpected errors
        return when (result) {
            is ToolResult.Success -> result
            is ToolResult.PartialSuccess -> result
            is ToolResult.Failure -> result
            is ToolResult.Cancelled -> result
            is ToolResult.ValidationFailed -> result
            is ToolResult.RequiresConfirmation -> result
        }
    }
}
