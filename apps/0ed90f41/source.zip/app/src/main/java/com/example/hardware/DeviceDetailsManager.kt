package com.example.hardware

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.os.SystemClock
import java.io.File

class DeviceDetailsManager(private val context: Context) {

    data class DeviceInfo(
        val manufacturer: String,
        val model: String,
        val brand: String,
        val device: String,
        val board: String,
        val hardware: String,
        val androidVersion: String,
        val sdkInt: Int,
        val securityPatch: String,
        val primaryAbi: String,
        val supportedAbis: List<String>,
        val cpuCores: Int,
        val ramTotalGb: Double,
        val ramAvailableGb: Double,
        val ramUsedPct: Int,
        val storageTotalGb: Double,
        val storageFreeGb: Double,
        val storageUsedPct: Int,
        val uptimeSeconds: Long,
        val batteryPct: Int,
        val isCharging: Boolean,
        val batteryTempC: Double,
        val isThermalThrottling: Boolean
    )

    fun getDeviceInfo(): DeviceInfo {
        val cores = Runtime.getRuntime().availableProcessors()
        
        // RAM
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(memInfo)
        val totalRamGb = memInfo.totalMem / (1024.0 * 1024.0 * 1024.0)
        val availRamGb = memInfo.availMem / (1024.0 * 1024.0 * 1024.0)
        val usedRamPct = if (totalRamGb > 0) (((totalRamGb - availRamGb) / totalRamGb) * 100).toInt() else 0

        // Storage
        val statFs = StatFs(Environment.getDataDirectory().path)
        val blockSize = statFs.blockSizeLong
        val totalBlocks = statFs.blockCountLong
        val availBlocks = statFs.availableBlocksLong
        val totalStorageGb = (totalBlocks * blockSize) / (1024.0 * 1024.0 * 1024.0)
        val freeStorageGb = (availBlocks * blockSize) / (1024.0 * 1024.0 * 1024.0)
        val usedStoragePct = if (totalStorageGb > 0) (((totalStorageGb - freeStorageGb) / totalStorageGb) * 100).toInt() else 0

        // Battery
        val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryStatus = context.registerReceiver(null, ifilter)
        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale) else 0
        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val rawTemp = batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val batteryTempC = rawTemp / 10.0

        // Thermal status
        var isThrottling = false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            val thermal = pm?.currentThermalStatus ?: PowerManager.THERMAL_STATUS_NONE
            isThrottling = thermal >= PowerManager.THERMAL_STATUS_MODERATE
        }

        val uptimeSec = SystemClock.elapsedRealtime() / 1000

        return DeviceInfo(
            manufacturer = Build.MANUFACTURER,
            model = Build.MODEL,
            brand = Build.BRAND,
            device = Build.DEVICE,
            board = Build.BOARD,
            hardware = Build.HARDWARE,
            androidVersion = Build.VERSION.RELEASE,
            sdkInt = Build.VERSION.SDK_INT,
            securityPatch = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Build.VERSION.SECURITY_PATCH else "N/A",
            primaryAbi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown",
            supportedAbis = Build.SUPPORTED_ABIS.toList(),
            cpuCores = cores,
            ramTotalGb = ((totalRamGb * 100).toInt() / 100.0),
            ramAvailableGb = ((availRamGb * 100).toInt() / 100.0),
            ramUsedPct = usedRamPct,
            storageTotalGb = ((totalStorageGb * 100).toInt() / 100.0),
            storageFreeGb = ((freeStorageGb * 100).toInt() / 100.0),
            storageUsedPct = usedStoragePct,
            uptimeSeconds = uptimeSec,
            batteryPct = batteryPct,
            isCharging = isCharging,
            batteryTempC = batteryTempC,
            isThermalThrottling = isThrottling
        )
    }
}
