package com.example.aios.planning

import java.util.UUID

enum class TaskStatus {
    PENDING, RUNNING, COMPLETED, FAILED, CANCELLED
}

data class Task(
    val id: String = UUID.randomUUID().toString(),
    val goalId: String,
    val title: String,
    val description: String,
    val assignedAgentId: String?,
    val dependencies: List<String> = emptyList(),
    var status: TaskStatus = TaskStatus.PENDING,
    var progress: Float = 0.0f,
    val params: Map<String, Any> = emptyMap(),
    val subtasks: List<Task> = emptyList(),
    var retryCount: Int = 0,
    val maxRetries: Int = 3,
    var error: String? = null
)

sealed class TaskResult {
    data class Success(val data: Any, val message: String) : TaskResult()
    data class Failure(val error: String, val exception: Exception? = null) : TaskResult()
}
