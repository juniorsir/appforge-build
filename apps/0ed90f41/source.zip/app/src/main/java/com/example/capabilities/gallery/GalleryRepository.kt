package com.example.capabilities.gallery

import com.example.capabilities.CapabilityResult

interface GalleryRepository {
    suspend fun pickImage(): CapabilityResult<String> // Returns local file URI string
    suspend fun pickMultipleImages(): CapabilityResult<List<String>>
    suspend fun pickVideo(): CapabilityResult<String>
}
