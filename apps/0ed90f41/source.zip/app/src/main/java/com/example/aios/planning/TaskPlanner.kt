package com.example.aios.planning

import com.example.aios.core.AgentManager
import com.example.aios.core.AgentState
import com.example.aios.core.HealthStatus
import com.example.aios.observability.MetricsTracker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

enum class GoalStatus {
    PENDING, RUNNING, COMPLETED, FAILED
}

data class Goal(
    val id: String,
    val description: String,
    var status: GoalStatus = GoalStatus.PENDING,
    val tasks: List<Task>
)

@Singleton
class TaskPlanner @Inject constructor(
    private val agentManager: AgentManager,
    private val metricsTracker: MetricsTracker
) {
    private val _activeGoals = MutableStateFlow<List<Goal>>(emptyList())
    val activeGoals: StateFlow<List<Goal>> = _activeGoals

    suspend fun planAndExecute(userGoal: String): Goal {
        val goalId = UUID.randomUUID().toString()
        val tasks = mutableListOf<Task>()
        
        if (userGoal.contains("code", ignoreCase = true) || userGoal.contains("coding", ignoreCase = true) || userGoal.contains("develop", ignoreCase = true)) {
            val task1 = Task(goalId = goalId, title = "Design System Architecture Blueprint", description = "Architect details of AIOS modules", assignedAgentId = "agent_planner")
            val task2 = Task(goalId = goalId, title = "Compile Code Classes", description = "Draft kotlin files & registries", assignedAgentId = "agent_coding", dependencies = listOf(task1.id))
            val task3 = Task(goalId = goalId, title = "Verify Compilation & Coverage", description = "Run verification checks", assignedAgentId = "agent_developer", dependencies = listOf(task2.id))
            tasks.addAll(listOf(task1, task2, task3))
        } else if (userGoal.contains("morning", ignoreCase = true) || userGoal.contains("routine", ignoreCase = true)) {
            val task1 = Task(goalId = goalId, title = "Check Calendar Event conflicts", description = "Fetch meetings log", assignedAgentId = "agent_calendar")
            val task2 = Task(goalId = goalId, title = "Transliterate Notes", description = "Linguistic conversion", assignedAgentId = "agent_translation")
            val task3 = Task(goalId = goalId, title = "Dispatch Notification Reminder", description = "Notify user of events", assignedAgentId = "agent_notification", dependencies = listOf(task1.id, task2.id))
            tasks.addAll(listOf(task1, task2, task3))
        } else if (userGoal.contains("travel", ignoreCase = true) || userGoal.contains("trip", ignoreCase = true)) {
            val task1 = Task(goalId = goalId, title = "Search flight catalogs", description = "Crawl travel sites", assignedAgentId = "agent_browser")
            val task2 = Task(goalId = goalId, title = "Mark travel bookings on Calendar", description = "Update schedule log", assignedAgentId = "agent_calendar", dependencies = listOf(task1.id))
            tasks.addAll(listOf(task1, task2))
        } else {
            val task1 = Task(goalId = goalId, title = "Retrieve context cache", description = "Episodic memory lookup", assignedAgentId = "agent_memory")
            val task2 = Task(goalId = goalId, title = "Draft output briefing", description = "Verbal translation", assignedAgentId = "agent_conversation", dependencies = listOf(task1.id))
            tasks.addAll(listOf(task1, task2))
        }

        val goal = Goal(id = goalId, description = userGoal, tasks = tasks)
        val currentGoals = _activeGoals.value.toMutableList()
        currentGoals.add(0, goal)
        _activeGoals.value = currentGoals

        // Launch execution
        executeGoal(goal)
        return goal
    }

    private suspend fun executeGoal(goal: Goal) {
        val completedTaskIds = mutableSetOf<String>()
        goal.status = GoalStatus.RUNNING

        while (completedTaskIds.size < goal.tasks.size) {
            val executableTasks = goal.tasks.filter { 
                it.status == TaskStatus.PENDING && it.dependencies.all { depId -> completedTaskIds.contains(depId) } 
            }
            if (executableTasks.isEmpty() && goal.tasks.any { it.status == TaskStatus.FAILED }) {
                goal.status = GoalStatus.FAILED
                _activeGoals.value = _activeGoals.value.map { if (it.id == goal.id) goal else it }
                return
            }
            if (executableTasks.isEmpty()) {
                break
            }

            for (task in executableTasks) {
                task.status = TaskStatus.RUNNING
                _activeGoals.value = _activeGoals.value.map { if (it.id == goal.id) goal else it }
                
                val agent = task.assignedAgentId?.let { agentManager.getAgentById(it) }
                if (agent != null && agent.healthStatus == HealthStatus.HEALTHY) {
                    agent.state = AgentState.BUSY
                    metricsTracker.trackExecutionStart(task.id, agent.identity.id)
                    
                    // Simulate execution increments
                    for (i in 1..5) {
                        kotlinx.coroutines.delay(100)
                        task.progress = i * 0.2f
                        _activeGoals.value = _activeGoals.value.map { if (it.id == goal.id) goal else it }
                    }
                    
                    val result = agent.executeTask(task)
                    agent.state = AgentState.IDLE
                    
                    if (result is TaskResult.Success) {
                        task.status = TaskStatus.COMPLETED
                        completedTaskIds.add(task.id)
                        metricsTracker.trackExecutionSuccess(task.id, agent.identity.id)
                    } else if (result is TaskResult.Failure) {
                        if (task.retryCount < task.maxRetries) {
                            task.retryCount++
                            task.status = TaskStatus.PENDING
                        } else {
                            task.status = TaskStatus.FAILED
                            task.error = result.error
                            metricsTracker.trackExecutionFailure(task.id, agent.identity.id, result.error)
                        }
                    }
                } else {
                    task.status = TaskStatus.FAILED
                    task.error = "Agent not found or unhealthy"
                    metricsTracker.trackExecutionFailure(task.id, task.assignedAgentId ?: "unknown", task.error ?: "")
                }
                _activeGoals.value = _activeGoals.value.map { if (it.id == goal.id) goal else it }
            }
        }

        goal.status = if (goal.tasks.all { it.status == TaskStatus.COMPLETED }) GoalStatus.COMPLETED else GoalStatus.FAILED
        _activeGoals.value = _activeGoals.value.map { if (it.id == goal.id) goal else it }
    }
}
