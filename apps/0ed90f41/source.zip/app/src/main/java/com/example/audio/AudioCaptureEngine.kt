package com.example.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.media.AudioFocusRequest
import androidx.annotation.RequiresApi
import com.example.domain.model.AudioCaptureState
import com.example.util.AppLogger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.sqrt

/**
 * Interface for streaming audio chunks in real-time.
 */
interface AudioChunkListener {
    fun onAudioChunk(chunk: ShortArray, rms: Double)
}

/**
 * Production-ready low-latency Audio Capture Engine using AudioRecord.
 * Automatically manages Audio Focus, calculates RMS, and emits stream telemetry.
 */
class AudioCaptureEngine(
    private val context: Context,
    private val logger: AppLogger,
    private val externalScope: CoroutineScope
) : AudioManager.OnAudioFocusChangeListener {

    private val tag = "AudioCaptureEngine"

    // Configuration
    private val sampleRate = 16000
    private val channelConfig = AudioFormat.CHANNEL_IN_MONO
    private val audioFormat = AudioFormat.ENCODING_PCM_16BIT
    private val chunkSamples = 480 // 30ms @ 16kHz (in 20ms - 40ms range)

    // Audio State flows
    private val _state = MutableStateFlow(AudioCaptureState(sampleRate = sampleRate))
    val state: StateFlow<AudioCaptureState> = _state.asStateFlow()

    // Internal components
    private var audioRecord: AudioRecord? = null
    private var audioManager: AudioManager? = null
    private var focusRequest: AudioFocusRequest? = null

    // Listeners
    private var chunkListener: AudioChunkListener? = null

    // Concurrency controls
    private var recordJob: Job? = null
    private val isRunning = AtomicBoolean(false)
    private val isPausedInternal = AtomicBoolean(false)

    init {
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        determineAndLogBufferSize()
    }

    /**
     * Set a listener to receive the raw short PCM chunks.
     */
    fun setChunkListener(listener: AudioChunkListener?) {
        this.chunkListener = listener
    }

    /**
     * Determines and logs the dynamic minimum buffer size.
     */
    private fun determineBufferSize(): Int {
        val minBufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
        if (minBufferSize == AudioRecord.ERROR || minBufferSize == AudioRecord.ERROR_BAD_VALUE || minBufferSize <= 0) {
            // Fallback: 4 periods of 30ms chunks * 2 bytes/sample
            val fallback = chunkSamples * 2 * 4
            logger.w(tag, "Failed to get min buffer size from AudioRecord. Using fallback: $fallback bytes.")
            return fallback
        }

        // Align buffer size to be a multiple of our chunk size (in bytes)
        val chunkBytes = chunkSamples * 2
        var bufferSize = minBufferSize
        val remainder = bufferSize % chunkBytes
        if (remainder != 0) {
            bufferSize += (chunkBytes - remainder)
        }

        // Add safety breathing room (double minimum or at least 4 chunk buffers) to avoid overflow
        bufferSize = maxOf(bufferSize, chunkBytes * 4)
        return bufferSize
    }

    private fun determineAndLogBufferSize() {
        val calculated = determineBufferSize()
        _state.update { it.copy(bufferSize = calculated) }
        logger.i(tag, "Dynamic buffer size initialized. Min chunk bytes: ${chunkSamples * 2}, AudioRecord Buffer: $calculated bytes")
    }

    /**
     * Start capturing audio.
     */
    @SuppressLint("MissingPermission")
    fun start() {
        if (isRunning.get()) {
            logger.w(tag, "Start requested, but engine is already running.")
            return
        }

        logger.i(tag, "Starting audio capture engine...")
        _state.update { it.copy(error = null) }

        // 1. Request Audio Focus
        if (!requestAudioFocus()) {
            val focusError = "Failed to obtain Audio Focus. Aborting recording."
            logger.e(tag, focusError)
            _state.update { it.copy(error = focusError) }
            return
        }

        // 2. Initialize AudioRecord
        val bufSize = determineBufferSize()
        try {
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                channelConfig,
                audioFormat,
                bufSize
            )

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                throw IllegalStateException("AudioRecord initialization failed.")
            }
        } catch (e: Exception) {
            val initError = "Initialization error: ${e.localizedMessage}"
            logger.e(tag, initError, e)
            _state.update { it.copy(error = initError) }
            releaseResources()
            return
        }

        // 3. Start Recording
        try {
            audioRecord?.startRecording()
            if (audioRecord?.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                throw IllegalStateException("AudioRecord failed to enter recording state.")
            }
        } catch (e: Exception) {
            val startError = "Start recording failed: ${e.localizedMessage}"
            logger.e(tag, startError, e)
            _state.update { it.copy(error = startError) }
            releaseResources()
            return
        }

        isRunning.set(true)
        isPausedInternal.set(false)

        _state.update {
            it.copy(
                isRecording = true,
                isPaused = false,
                rms = 0.0,
                timestamp = System.currentTimeMillis()
            )
        }

        logger.i(tag, "AudioRecord successfully started. Beginning capture loop...")

        // 4. Launch Recording thread
        recordJob = externalScope.launch(Dispatchers.IO) {
            captureLoop()
        }
    }

    /**
     * Main data fetching loop for recording.
     */
    private fun captureLoop() {
        val buffer = ShortArray(chunkSamples)
        logger.i(tag, "Running audio chunk reader loop. Chunk size: ${chunkSamples} samples")

        while (isRunning.get()) {
            if (isPausedInternal.get()) {
                try {
                    Thread.sleep(100) // Yield CPU while paused
                } catch (ignored: InterruptedException) {}
                continue
            }

            val record = audioRecord ?: break
            val readResult = record.read(buffer, 0, chunkSamples)

            when {
                readResult > 0 -> {
                    // Successful read
                    val rms = calculateRms(buffer, readResult)
                    
                    // Deliver chunk to listener
                    val activeChunk = if (readResult == chunkSamples) buffer else buffer.copyOfRange(0, readResult)
                    chunkListener?.onAudioChunk(activeChunk, rms)

                    // Update State flows
                    _state.update {
                        it.copy(
                            rms = rms,
                            timestamp = System.currentTimeMillis()
                        )
                    }
                }
                readResult == AudioRecord.ERROR_INVALID_OPERATION -> {
                    logger.e(tag, "AudioRecord read failed: ERROR_INVALID_OPERATION")
                    handleLoopError("Invalid operation in capture loop.")
                    break
                }
                readResult == AudioRecord.ERROR_BAD_VALUE -> {
                    logger.e(tag, "AudioRecord read failed: ERROR_BAD_VALUE")
                    handleLoopError("Bad value parameter inside loop.")
                    break
                }
                readResult == AudioRecord.ERROR_DEAD_OBJECT -> {
                    logger.e(tag, "AudioRecord read failed: ERROR_DEAD_OBJECT. Attempting recovery...")
                    attemptRecovery()
                    break
                }
                readResult == AudioRecord.ERROR -> {
                    logger.e(tag, "AudioRecord generic ERROR inside capture loop.")
                    handleLoopError("Generic AudioRecord error.")
                    break
                }
            }
        }
        logger.i(tag, "Capture loop finished.")
    }

    /**
     * Compute Root Mean Square (RMS) of PCM 16-bit stream.
     */
    private fun calculateRms(buffer: ShortArray, readSize: Int): Double {
        if (readSize <= 0) return 0.0
        var sum = 0.0
        for (i in 0 until readSize) {
            val sample = buffer[i].toDouble()
            sum += sample * sample
        }
        val mean = sum / readSize
        return sqrt(mean)
    }

    /**
     * Pause recording.
     */
    fun pause() {
        if (!isRunning.get() || isPausedInternal.get()) return
        logger.i(tag, "Pausing audio capture engine...")
        isPausedInternal.set(true)
        _state.update { it.copy(isPaused = true) }
    }

    /**
     * Resume recording.
     */
    fun resume() {
        if (!isRunning.get() || !isPausedInternal.get()) return
        logger.i(tag, "Resuming audio capture engine...")
        // Re-request audio focus
        if (!requestAudioFocus()) {
            val focusError = "Failed to regain Audio Focus during resume."
            logger.e(tag, focusError)
            _state.update { it.copy(error = focusError) }
            stop()
            return
        }
        isPausedInternal.set(false)
        _state.update { it.copy(isPaused = false, error = null) }
    }

    /**
     * Stop capturing audio and clean up focus/resources.
     */
    fun stop() {
        if (!isRunning.get()) {
            logger.w(tag, "Stop requested, but engine is not running.")
            return
        }
        logger.i(tag, "Stopping audio capture engine...")
        isRunning.set(false)
        isPausedInternal.set(false)

        recordJob?.cancel()
        recordJob = null

        abandonAudioFocus()
        releaseResources()

        _state.update {
            it.copy(
                isRecording = false,
                isPaused = false,
                rms = 0.0
            )
        }
        logger.i(tag, "Audio capture engine stopped cleanly.")
    }

    private fun handleLoopError(errorMessage: String) {
        _state.update { it.copy(error = errorMessage) }
        stop()
    }

    /**
     * AudioRecord recovery logic if a crash/dead object is encountered.
     */
    private fun attemptRecovery() {
        logger.i(tag, "Attempting AudioRecord recovery...")
        releaseResources()
        // Wait briefly before restarting
        try { Thread.sleep(500) } catch (e: Exception) {}
        
        isRunning.set(false)
        start()
    }

    /**
     * Frees and releases native resources safely.
     */
    private fun releaseResources() {
        try {
            audioRecord?.let {
                if (it.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    it.stop()
                }
                it.release()
            }
        } catch (e: Exception) {
            logger.e(tag, "Error releasing AudioRecord resource", e)
        } finally {
            audioRecord = null
        }
    }

    // Audio Focus Management

    private fun requestAudioFocus(): Boolean {
        val am = audioManager ?: return false
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            requestAudioFocusOreo(am)
        } else {
            @Suppress("DEPRECATION")
            val result = am.requestAudioFocus(
                this,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
            )
            result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun requestAudioFocusOreo(am: AudioManager): Boolean {
        val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
            .setOnAudioFocusChangeListener(this)
            .setAcceptsDelayedFocusGain(false)
            .build()
        focusRequest = request
        val result = am.requestAudioFocus(request)
        return result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun abandonAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            focusRequest?.let { am.abandonAudioFocusRequest(it) }
            focusRequest = null
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(this)
        }
    }

    override fun onAudioFocusChange(focusChange: Int) {
        logger.i(tag, "AudioFocus changed: $focusChange")
        when (focusChange) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                logger.w(tag, "Permanent AudioFocus loss. Stopping capture.")
                stop()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                logger.w(tag, "Transient AudioFocus loss. Pausing capture.")
                pause()
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                logger.i(tag, "AudioFocus regained. Resuming capture.")
                resume()
            }
        }
    }
}
