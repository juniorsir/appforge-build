package com.example.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import com.example.accessibility.models.AccessibilityEventModel
import com.example.accessibility.models.AccessibilityNodeModel
import com.example.accessibility.models.AccessibilityServiceStatus
import com.example.accessibility.models.GestureRequestModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object AccessibilityServiceRegistry {
    @Volatile
    var activeService: AccessibilityService? = null
        set(value) {
            field = value
            onServiceStateChangedListener?.invoke(value != null)
        }

    var onServiceStateChangedListener: ((Boolean) -> Unit)? = null
}

class AccessibilityRepositoryImpl : AccessibilityRepository {

    private val _serviceStatus = MutableStateFlow(AccessibilityServiceStatus())
    override val serviceStatus: StateFlow<AccessibilityServiceStatus> = _serviceStatus.asStateFlow()

    private val _recentEvents = MutableStateFlow<List<AccessibilityEventModel>>(emptyList())
    override val recentEvents: StateFlow<List<AccessibilityEventModel>> = _recentEvents.asStateFlow()

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    override val logs: StateFlow<List<String>> = _logs.asStateFlow()

    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    init {
        // Track connection and active status changes
        updateStatus()
        AccessibilityServiceRegistry.onServiceStateChangedListener = {
            updateStatus()
        }
    }

    private fun updateStatus() {
        val isEnabled = AccessibilityServiceRegistry.activeService != null
        _serviceStatus.value = AccessibilityServiceStatus(
            isEnabled = isEnabled,
            lastConnectedTime = if (isEnabled) System.currentTimeMillis() else _serviceStatus.value.lastConnectedTime,
            recentEventsCount = _recentEvents.value.size,
            recentGesturesCount = _serviceStatus.value.recentGesturesCount
        )
        addLog("Accessibility service status updated. isEnabled = $isEnabled")
    }

    override fun triggerGesture(gesture: GestureRequestModel, onComplete: (Boolean) -> Unit) {
        val service = AccessibilityServiceRegistry.activeService
        if (service == null) {
            addLog("GESTURE ERROR: Cannot perform gesture; Accessibility Service is disabled.")
            onComplete(false)
            return
        }

        val typeUpper = gesture.type.uppercase()
        if (typeUpper == "BACK" || typeUpper == "GLOBAL_BACK") {
            val success = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            addLog("GLOBAL ACTION BACK: success=$success")
            onComplete(success)
            return
        }
        if (typeUpper == "HOME" || typeUpper == "GLOBAL_HOME") {
            val success = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            addLog("GLOBAL ACTION HOME: success=$success")
            onComplete(success)
            return
        }
        if (typeUpper == "RECENTS" || typeUpper == "GLOBAL_RECENTS") {
            val success = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
            addLog("GLOBAL ACTION RECENTS: success=$success")
            onComplete(success)
            return
        }
        if (typeUpper == "NOTIFICATIONS" || typeUpper == "GLOBAL_NOTIFICATIONS") {
            val success = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            addLog("GLOBAL ACTION NOTIFICATIONS: success=$success")
            onComplete(success)
            return
        }

        try {
            val path = Path()
            path.moveTo(gesture.startX, gesture.startY)
            if (gesture.type == "SWIPE" || gesture.type == "DRAG") {
                path.lineTo(gesture.endX, gesture.endY)
            } else {
                // Click gesture (a simple small line or point)
                path.lineTo(gesture.startX + 1f, gesture.startY + 1f)
            }

            val stroke = GestureDescription.StrokeDescription(
                path,
                0L,
                if (gesture.durationMs <= 0) 100L else gesture.durationMs
            )

            val builder = GestureDescription.Builder()
            builder.addStroke(stroke)
            val desc = builder.build()

            addLog("DISPATCH GESTURE: type=${gesture.type}, start=(${gesture.startX}, ${gesture.startY}), duration=${gesture.durationMs}ms")
            
            service.dispatchGesture(desc, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    addLog("GESTURE SUCCESS: id=${gesture.id}")
                    _serviceStatus.value = _serviceStatus.value.copy(
                        recentGesturesCount = _serviceStatus.value.recentGesturesCount + 1
                    )
                    onComplete(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    addLog("GESTURE CANCELLED: id=${gesture.id}")
                    onComplete(false)
                }
            }, null)

        } catch (e: Exception) {
            addLog("GESTURE FAILURE: id=${gesture.id}, error=${e.message}")
            onComplete(false)
        }
    }

    override fun clickNodeByText(text: String, onComplete: (Boolean) -> Unit) {
        val matches = searchNodes(text = text, contentDescription = text, viewId = null)
        val target = matches.firstOrNull { it.isClickable } ?: matches.firstOrNull()
        if (target != null) {
            val bounds = target.bounds
            val regex = java.util.regex.Pattern.compile("\\d+")
            val matcher = regex.matcher(bounds)
            val nums = mutableListOf<Int>()
            while (matcher.find()) {
                nums.add(matcher.group().toInt())
            }
            if (nums.size == 4) {
                val cx = ((nums[0] + nums[2]) / 2).toFloat()
                val cy = ((nums[1] + nums[3]) / 2).toFloat()
                val req = GestureRequestModel(
                    id = "click_text_" + System.currentTimeMillis(),
                    type = "CLICK",
                    startX = cx,
                    startY = cy,
                    durationMs = 100
                )
                triggerGesture(req, onComplete)
                return
            }
        }
        onComplete(false)
    }

    override fun performScroll(forward: Boolean, onComplete: (Boolean) -> Unit) {
        val req = GestureRequestModel(
            id = "scroll_" + System.currentTimeMillis(),
            type = "SWIPE",
            startX = 500f,
            startY = if (forward) 1400f else 400f,
            endX = 500f,
            endY = if (forward) 300f else 1400f,
            durationMs = 250
        )
        triggerGesture(req, onComplete)
    }

    override fun getFullNodeTree(): List<AccessibilityNodeModel> {
        val service = AccessibilityServiceRegistry.activeService
        if (service == null) {
            addLog("INSPECT ERROR: Service not active.")
            return emptyList()
        }

        val rootNode = service.rootInActiveWindow
        if (rootNode == null) {
            addLog("INSPECT WARNING: rootInActiveWindow returned null.")
            return emptyList()
        }

        val nodes = mutableListOf<AccessibilityNodeModel>()
        convertNodeInfo(rootNode)?.let { nodes.add(it) }
        return nodes
    }

    override fun searchNodes(text: String?, contentDescription: String?, viewId: String?): List<AccessibilityNodeModel> {
        val allNodes = getFullNodeTree()
        val results = mutableListOf<AccessibilityNodeModel>()
        
        fun searchRecursive(node: AccessibilityNodeModel) {
            var match = false
            if (text != null && node.text?.contains(text, ignoreCase = true) == true) match = true
            if (contentDescription != null && node.contentDescription?.contains(contentDescription, ignoreCase = true) == true) match = true
            if (viewId != null && node.viewId?.contains(viewId, ignoreCase = true) == true) match = true
            
            if (match) {
                results.add(node)
            }
            
            for (child in node.children) {
                searchRecursive(child)
            }
        }

        for (node in allNodes) {
            searchRecursive(node)
        }

        addLog("SEARCH NODES: query(text=$text, desc=$contentDescription, id=$viewId) -> found ${results.size} matches")
        return results
    }

    override fun addLog(message: String) {
        val timestamp = timeFormat.format(Date())
        val formatted = "[$timestamp] $message"
        _logs.value = (listOf(formatted) + _logs.value).take(150)
    }

    override fun addEvent(event: AccessibilityEventModel) {
        _recentEvents.value = (listOf(event) + _recentEvents.value).take(100)
        _serviceStatus.value = _serviceStatus.value.copy(
            recentEventsCount = _recentEvents.value.size
        )
    }

    private fun convertNodeInfo(node: AccessibilityNodeInfo?): AccessibilityNodeModel? {
        if (node == null) return null
        val bounds = Rect()
        node.getBoundsInScreen(bounds)

        val childList = mutableListOf<AccessibilityNodeModel>()
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            if (child != null) {
                convertNodeInfo(child)?.let { childList.add(it) }
            }
        }

        return AccessibilityNodeModel(
            text = node.text?.toString(),
            contentDescription = node.contentDescription?.toString(),
            viewId = node.viewIdResourceName,
            className = node.className?.toString(),
            isClickable = node.isClickable,
            isScrollable = node.isScrollable,
            isEditable = node.isEditable,
            isFocused = node.isFocused,
            bounds = "[${bounds.left},${bounds.top}][${bounds.right},${bounds.bottom}]",
            children = childList
        )
    }
}
