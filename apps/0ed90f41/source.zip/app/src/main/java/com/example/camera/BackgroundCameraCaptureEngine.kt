package com.example.camera

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.Image
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Base64
import android.util.Log
import com.example.capabilities.CapabilityResult
import com.example.capabilities.camera.CameraRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Production Background Camera Capture Engine.
 * Takes high-resolution photos completely in the background via Camera2 API
 * without opening any Viewfinder Activity or UI preview.
 */
@Singleton
class BackgroundCameraCaptureEngine @Inject constructor(
    @ApplicationContext private val context: Context
) : CameraRepository {

    private val tag = "BgCameraEngine"

    override suspend fun takePicture(): CapabilityResult<String> {
        val result = capturePhotoInternal(lensFacing = CameraCharacteristics.LENS_FACING_BACK)
        return if (result != null) {
            CapabilityResult.Success(result.absolutePath)
        } else {
            CapabilityResult.Error("Failed to capture background photo via Camera2 API")
        }
    }

    override suspend fun recordVideo(): CapabilityResult<String> {
        return CapabilityResult.Error("Silent background video recording is not enabled")
    }

    /**
     * Captures a silent photo in the background without UI.
     * Returns the saved File object or null on error.
     */
    @SuppressLint("MissingPermission")
    suspend fun capturePhoto(lensFacing: Int = CameraCharacteristics.LENS_FACING_BACK): BackgroundCaptureResult? {
        val file = capturePhotoInternal(lensFacing) ?: return null
        val bytes = file.readBytes()
        val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        return BackgroundCaptureResult(
            filePath = file.absolutePath,
            fileSize = file.length(),
            base64Data = base64
        )
    }

    @SuppressLint("MissingPermission")
    private suspend fun capturePhotoInternal(lensFacing: Int): File? {
        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            ?: return null

        val handlerThread = HandlerThread("CameraBackgroundThread").apply { start() }
        val backgroundHandler = Handler(handlerThread.looper)

        val deferred = CompletableDeferred<File?>()

        try {
            var selectedCameraId: String? = null
            for (id in cameraManager.cameraIdList) {
                val characteristics = cameraManager.getCameraCharacteristics(id)
                val facing = characteristics.get(CameraCharacteristics.LENS_FACING)
                if (facing == lensFacing) {
                    selectedCameraId = id
                    break
                }
            }

            if (selectedCameraId == null && cameraManager.cameraIdList.isNotEmpty()) {
                selectedCameraId = cameraManager.cameraIdList[0]
            }

            if (selectedCameraId == null) {
                handlerThread.quitSafely()
                return null
            }

            val characteristics = cameraManager.getCameraCharacteristics(selectedCameraId)
            val map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val sizes = map?.getOutputSizes(ImageFormat.JPEG) ?: emptyArray()
            // Prefer fast standard capture resolutions (e.g. 1280x720 or first available <= 1920)
            val chosenSize = sizes.firstOrNull { it.width == 1280 && it.height == 720 }
                ?: sizes.firstOrNull { it.width <= 1280 }
                ?: sizes.firstOrNull()
                ?: android.util.Size(1280, 720)

            val imageReader = ImageReader.newInstance(chosenSize.width, chosenSize.height, ImageFormat.JPEG, 2)

            var cameraDeviceRef: CameraDevice? = null
            var captureSessionRef: CameraCaptureSession? = null

            imageReader.setOnImageAvailableListener({ reader ->
                var image: Image? = null
                try {
                    image = reader.acquireLatestImage()
                    if (image != null) {
                        val buffer = image.planes[0].buffer
                        val bytes = ByteArray(buffer.remaining())
                        buffer.get(bytes)

                        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                        val picturesDir = context.getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES)
                            ?: context.filesDir
                        val photoFile = File(picturesDir, "AURA_IMG_${timeStamp}.jpg")

                        FileOutputStream(photoFile).use { fos ->
                            fos.write(bytes)
                            fos.flush()
                        }
                        Log.i(tag, "Background photo captured and saved to: ${photoFile.absolutePath}")
                        deferred.complete(photoFile)
                    } else {
                        deferred.complete(null)
                    }
                } catch (e: Exception) {
                    Log.e(tag, "Error writing image buffer", e)
                    deferred.complete(null)
                } finally {
                    image?.close()
                    try {
                        captureSessionRef?.close()
                        cameraDeviceRef?.close()
                        imageReader.close()
                    } catch (e: Exception) {
                        // Safe close
                    }
                    handlerThread.quitSafely()
                }
            }, backgroundHandler)

            cameraManager.openCamera(selectedCameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    cameraDeviceRef = camera
                    try {
                        val surfaces = listOf(imageReader.surface)
                        camera.createCaptureSession(surfaces, object : CameraCaptureSession.StateCallback() {
                            override fun onConfigured(session: CameraCaptureSession) {
                                captureSessionRef = session
                                try {
                                    val captureBuilder = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                                        addTarget(imageReader.surface)
                                        set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
                                        set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                                        set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                                        set(CaptureRequest.JPEG_ORIENTATION, if (lensFacing == CameraCharacteristics.LENS_FACING_FRONT) 270 else 90)
                                        set(CaptureRequest.JPEG_QUALITY, 85.toByte())
                                    }
                                    session.capture(captureBuilder.build(), object : CameraCaptureSession.CaptureCallback() {
                                        override fun onCaptureFailed(
                                            session: CameraCaptureSession,
                                            request: CaptureRequest,
                                            failure: android.hardware.camera2.CaptureFailure
                                        ) {
                                            Log.e(tag, "Capture failed: reason=${failure.reason}")
                                            deferred.complete(null)
                                        }
                                    }, backgroundHandler)
                                } catch (e: Exception) {
                                    Log.e(tag, "Failed to send still capture request", e)
                                    deferred.complete(null)
                                }
                            }

                            override fun onConfigureFailed(session: CameraCaptureSession) {
                                Log.e(tag, "Failed to configure camera capture session")
                                camera.close()
                                deferred.complete(null)
                            }
                        }, backgroundHandler)
                    } catch (e: Exception) {
                        Log.e(tag, "Failed to create capture session", e)
                        camera.close()
                        deferred.complete(null)
                    }
                }

                override fun onDisconnected(camera: CameraDevice) {
                    camera.close()
                    deferred.complete(null)
                }

                override fun onError(camera: CameraDevice, error: Int) {
                    camera.close()
                    Log.e(tag, "CameraDevice error code: $error")
                    deferred.complete(null)
                }
            }, backgroundHandler)

            // Wait with a 4.5-second timeout
            val result = withTimeoutOrNull(4500L) {
                deferred.await()
            }
            return result
        } catch (e: Exception) {
            Log.e(tag, "Camera2 access exception", e)
            return null
        } finally {
            try {
                handlerThread.quitSafely()
            } catch (e: Exception) {
                // Ignore
            }
        }
    }
}

data class BackgroundCaptureResult(
    val filePath: String,
    val fileSize: Long,
    val base64Data: String
)
