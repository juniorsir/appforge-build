package com.example.capabilities.gallery

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

class GalleryRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : GalleryRepository {

    override suspend fun pickImage(): CapabilityResult<String> {
        return try {
            val projection = arrayOf(MediaStore.Images.Media._ID)
            val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"
            context.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID))
                    val contentUri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                    return CapabilityResult.Success(contentUri.toString())
                }
            }
            CapabilityResult.Error("No images found in device media store")
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to query media store: ${e.message}", e)
        }
    }

    override suspend fun pickMultipleImages(): CapabilityResult<List<String>> {
        return try {
            val projection = arrayOf(MediaStore.Images.Media._ID)
            val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"
            val uris = mutableListOf<String>()
            context.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                while (cursor.moveToNext() && uris.size < 20) {
                    val id = cursor.getLong(idCol)
                    uris.add(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id).toString())
                }
            }
            CapabilityResult.Success(uris)
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to query multiple images: ${e.message}", e)
        }
    }

    override suspend fun pickVideo(): CapabilityResult<String> {
        return try {
            val projection = arrayOf(MediaStore.Video.Media._ID)
            val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"
            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID))
                    val contentUri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                    return CapabilityResult.Success(contentUri.toString())
                }
            }
            CapabilityResult.Error("No videos found in device media store")
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to query media store video: ${e.message}", e)
        }
    }
}
