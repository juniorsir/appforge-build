package com.example.capabilities.gps

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.example.capabilities.CapabilityResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

data class LocationInfo(
    val latitude: Double,
    val longitude: Double,
    val altitude: Double,
    val speed: Float,
    val heading: Float,
    val accuracy: Float
)

interface LocationRepository {
    suspend fun getCurrentLocation(): CapabilityResult<LocationInfo>
}

class LocationRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : LocationRepository {
    private val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)

    @android.annotation.SuppressLint("MissingPermission")
    override suspend fun getCurrentLocation(): CapabilityResult<LocationInfo> {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return CapabilityResult.PermissionDenied(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        
        return try {
            val location = fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).await()
            if (location != null) {
                CapabilityResult.Success(
                    LocationInfo(
                        latitude = location.latitude,
                        longitude = location.longitude,
                        altitude = location.altitude,
                        speed = location.speed,
                        heading = if (location.hasBearing()) location.bearing else 0.0f,
                        accuracy = location.accuracy
                    )
                )
            } else {
                CapabilityResult.Error("Location not available")
            }
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to get location", e)
        }
    }
}
