package com.example.presentation.developer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.capabilities.core.CapabilityAvailability
import com.example.capabilities.core.CapabilityCategory
import com.example.capabilities.core.CapabilityDefinition
import com.example.capabilities.core.CapabilityRegistry
import com.example.capabilities.core.CapabilityRequest
import com.example.capabilities.core.CapabilityResponse
import com.example.capabilities.permissions.PermissionManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CapabilityViewModel @Inject constructor(
    private val capabilityRegistry: CapabilityRegistry,
    val permissionManager: PermissionManager
) : ViewModel() {

    val allCapabilities: StateFlow<List<CapabilityDefinition>> = capabilityRegistry.capabilities

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow<CapabilityCategory?>(null)
    val selectedCategory: StateFlow<CapabilityCategory?> = _selectedCategory.asStateFlow()

    private val _selectedAvailability = MutableStateFlow<CapabilityAvailability?>(null)
    val selectedAvailability: StateFlow<CapabilityAvailability?> = _selectedAvailability.asStateFlow()

    private val _lastExecutionResults = MutableStateFlow<Map<String, CapabilityResponse>>(emptyMap())
    val lastExecutionResults: StateFlow<Map<String, CapabilityResponse>> = _lastExecutionResults.asStateFlow()

    private val _isExecuting = MutableStateFlow<Map<String, Boolean>>(emptyMap())
    val isExecuting: StateFlow<Map<String, Boolean>> = _isExecuting.asStateFlow()

    val filteredCapabilities: StateFlow<List<CapabilityDefinition>> = combine(
        allCapabilities,
        searchQuery,
        selectedCategory,
        selectedAvailability
    ) { args: Array<Any?> ->
        @Suppress("UNCHECKED_CAST")
        val capabilities = args[0] as List<CapabilityDefinition>
        val query = args[1] as String
        val category = args[2] as? CapabilityCategory
        val availability = args[3] as? CapabilityAvailability

        capabilities.filter { cap ->
            val matchesQuery = query.isEmpty() ||
                    cap.name.contains(query, ignoreCase = true) ||
                    cap.description.contains(query, ignoreCase = true) ||
                    cap.id.contains(query, ignoreCase = true) ||
                    cap.category.name.contains(query, ignoreCase = true) ||
                    cap.category.displayName.contains(query, ignoreCase = true) ||
                    cap.requiredPermissions.any { it.contains(query, ignoreCase = true) }

            val matchesCategory = category == null || cap.category == category
            val matchesAvailability = availability == null || cap.availability == availability
            matchesQuery && matchesCategory && matchesAvailability
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: CapabilityCategory?) {
        _selectedCategory.value = category
    }

    fun selectAvailability(availability: CapabilityAvailability?) {
        _selectedAvailability.value = availability
    }

    fun refreshAll() {
        capabilityRegistry.refreshAvailability()
    }

    fun testCapability(capabilityId: String) {
        viewModelScope.launch {
            _isExecuting.value = _isExecuting.value + (capabilityId to true)
            try {
                val request = CapabilityRequest(
                    capabilityId = capabilityId,
                    action = "test",
                    requiresConfirmation = true
                )
                val response = capabilityRegistry.executeCapability(request)
                _lastExecutionResults.value = _lastExecutionResults.value + (capabilityId to response)
            } finally {
                _isExecuting.value = _isExecuting.value + (capabilityId to false)
            }
        }
    }
}
