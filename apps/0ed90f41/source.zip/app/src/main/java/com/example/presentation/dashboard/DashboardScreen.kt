package com.example.presentation.dashboard

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.max
import androidx.compose.ui.unit.min
import androidx.core.content.ContextCompat
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.capabilities.permissions.PermissionAlertEvent
import com.example.capabilities.permissions.PermissionManager
import com.example.domain.model.SessionState
import com.example.presentation.permissions.PermissionsManagerDialog
import com.example.ui.components.diagnostics.AuraAudioDiagnosticsCard
import com.example.ui.components.diagnostics.AuraAudioStatus
import com.example.ui.components.engine.AuraCoreEngineCard
import com.example.ui.components.engine.AuraCoreEngineState
import com.example.ui.components.engine.AuraPersistenceCard
import com.example.ui.components.engine.AuraPersistenceState
import com.example.ui.components.header.AuraEngineState
import com.example.ui.components.header.AuraHeader
import com.example.ui.components.hero.AuraHero
import com.example.ui.components.service.AuraServiceState
import com.example.ui.components.service.AuraServiceStatusCard
import com.example.ui.components.voice.AuraVoiceDock
import com.example.ui.components.voice.AuraVoiceState
import com.example.ui.theme.AuraColors
import com.example.ui.theme.rememberReducedMotion

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    onNavigateToSettings: () -> Unit,
    onNavigateToDeveloper: () -> Unit,
    onNavigateToSpeechDiagnostics: () -> Unit,
    onNavigateToConversationEngine: () -> Unit,
    viewModel: DashboardViewModel
) {
    val state by viewModel.uiState.collectAsState()
    val audioState by viewModel.audioState.collectAsState()
    val reducedMotion = rememberReducedMotion()
    
    val isConnected = state.sessionState.connectionState == SessionState.ConnectionState.CONNECTED
    val isConnecting = state.sessionState.connectionState == SessionState.ConnectionState.CONNECTING
    
    val context = LocalContext.current

    // Permission state handling
    var showPermissionsManagerDialog by remember { mutableStateOf(false) }
    var showPermissionRationaleDialog by remember { mutableStateOf(false) }
    var showPermissionDeniedDialog by remember { mutableStateOf(false) }
    var activePermissionAlert by remember { mutableStateOf<PermissionAlertEvent?>(null) }

    // Dynamic permission request launcher for background-triggered tasks (e.g. Camera)
    val dynamicPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        val alert = activePermissionAlert
        activePermissionAlert = null
        if (!isGranted && alert != null) {
            val activity = context as? androidx.activity.ComponentActivity
            val shouldShowRationale = activity?.shouldShowRequestPermissionRationale(alert.permission) ?: false
            if (!shouldShowRationale) {
                // Permanently denied -> show guidance to open OS settings
                showPermissionDeniedDialog = true
            }
        }
    }

    // Listen for background permission alerts (such as silent Termux camera capture requests)
    LaunchedEffect(viewModel.permissionAlerts) {
        viewModel.permissionAlerts.collect { alert ->
            activePermissionAlert = alert
        }
    }

    val permissionManager = remember(context) { PermissionManager(context.applicationContext) }

    val hasAudioPermission = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            viewModel.startAudioCapture(context)
        } else {
            val activity = context as? androidx.activity.ComponentActivity
            val shouldShowRationale = activity?.shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO) ?: false
            if (shouldShowRationale) {
                showPermissionRationaleDialog = true
            } else {
                showPermissionDeniedDialog = true
            }
        }
    }

    fun requestMicrophonePermission() {
        if (hasAudioPermission) {
            viewModel.startAudioCapture(context)
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    // Permission Dialogs
    if (showPermissionRationaleDialog) {
        AlertDialog(
            onDismissRequest = { showPermissionRationaleDialog = false },
            title = { Text("Microphone Access Required") },
            text = { Text("The real-time AI companion needs access to your microphone in order to capture and stream low-latency voice commands continuously.") },
            confirmButton = {
                Button(
                    onClick = {
                        showPermissionRationaleDialog = false
                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                ) {
                    Text("Grant Permission")
                }
            },
            dismissButton = {
                Button(onClick = { showPermissionRationaleDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showPermissionDeniedDialog) {
        AlertDialog(
            onDismissRequest = { showPermissionDeniedDialog = false },
            title = { Text("Permission Permanently Denied") },
            text = { Text("Microphone access was permanently denied. Please enable it inside Application settings to start the low-latency audio engine.") },
            confirmButton = {
                Button(
                    onClick = {
                        showPermissionDeniedDialog = false
                        try {
                            val intent = android.content.Intent(
                                android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                android.net.Uri.fromParts("package", context.packageName, null)
                            )
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            // Safe fallback
                        }
                    }
                ) {
                    Text("Go to Settings")
                }
            },
            dismissButton = {
                Button(onClick = { showPermissionDeniedDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showPermissionsManagerDialog) {
        PermissionsManagerDialog(
            onDismissRequest = { showPermissionsManagerDialog = false },
            permissionManager = permissionManager
        )
    }

    // Dynamic Permission Alert Popup for background requests (e.g. Camera from Termux script)
    activePermissionAlert?.let { alert ->
        AlertDialog(
            onDismissRequest = { activePermissionAlert = null },
            modifier = Modifier.testTag("permission_warning_alert_dialog"),
            title = {
                Text(
                    text = "Permission Required: ${alert.featureName}",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = AuraColors.StatusWarning
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = alert.reasonMessage,
                        style = MaterialTheme.typography.bodyMedium,
                        color = AuraColors.TextPrimary
                    )
                    Text(
                        text = "Permission: ${alert.permission.substringAfterLast(".")}",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        color = AuraColors.TextSecondary
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val perm = alert.permission
                        dynamicPermissionLauncher.launch(perm)
                    },
                    modifier = Modifier.testTag("grant_permission_popup_button")
                ) {
                    Text("Grant Permission")
                }
            },
            dismissButton = {
                Button(
                    onClick = { activePermissionAlert = null },
                    modifier = Modifier.testTag("dismiss_permission_popup_button")
                ) {
                    Text("Dismiss")
                }
            }
        )
    }

    val currentEngineState = when {
        state.sessionState.connectionState == SessionState.ConnectionState.ERROR || state.sessionState.error != null -> AuraEngineState.ERROR
        state.sessionState.connectionState == SessionState.ConnectionState.CONNECTING -> AuraEngineState.CONNECTING
        audioState.isPaused -> AuraEngineState.PAUSED
        audioState.isRecording && isConnected -> AuraEngineState.LISTENING
        isConnected -> AuraEngineState.SPEAKING
        else -> AuraEngineState.STANDBY
    }

    Scaffold(
        topBar = {
            AuraHeader(
                engineState = currentEngineState,
                onNavigateToSpeechDiagnostics = onNavigateToSpeechDiagnostics,
                onNavigateToConversationEngine = onNavigateToConversationEngine,
                onNavigateToDeveloper = onNavigateToDeveloper,
                onNavigateToSettings = onNavigateToSettings,
                onNavigateToPermissions = { showPermissionsManagerDialog = true }
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val wScreen = maxWidth
            val hScreen = maxHeight
            val isTablet = wScreen >= 600.dp
            
            // M = clamp(20dp, 0.06 * Wscreen, 40dp)
            val hMargin = max(20.dp, min((wScreen.value * 0.06f).dp, 40.dp))
            val wMax = 1050.dp
            
            // Smajor = clamp(16dp, 0.025 * Havailable, 28dp)
            val sMajor = max(16.dp, min((hScreen.value * 0.025f).dp, 28.dp))
            
            // 2-column if tablet
            val wColumn = (wScreen - (hMargin * 2) - sMajor) / 2
            val useTwoColumns = isTablet && wColumn >= 280.dp
            
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.TopCenter
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(
                        start = hMargin,
                        end = hMargin,
                        top = sMajor,
                        bottom = 190.dp + WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
                    ),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(sMajor)
                ) {
                    item {
                        Column(
                            modifier = Modifier.widthIn(max = wMax),
                            verticalArrangement = Arrangement.spacedBy(sMajor)
                        ) {
                            // 1. AURA Liquid Hero + Real-time Engine Visualizer (Phase 3)
                            AuraHero(
                        reducedMotion = reducedMotion,
                                engineState = currentEngineState,
                                rms = audioState.rms,
                                modifier = Modifier.fillMaxWidth()
                            )
                            
                            // 2. Foreground Service & System Status Card (Phase 4)
                            val currentServiceState = when {
                                !hasAudioPermission -> AuraServiceState.ERROR
                                audioState.isRecording && !audioState.isPaused -> AuraServiceState.RUNNING
                                audioState.isRecording && audioState.isPaused -> AuraServiceState.PAUSED
                                isConnecting -> AuraServiceState.STARTING
                                else -> AuraServiceState.STOPPED
                            }
                            
                            val currentServiceDetail = when {
                                !hasAudioPermission -> "Microphone permission missing: Tap Retry to grant access"
                                audioState.isRecording && !audioState.isPaused -> "Active: Low-latency 16-bit PCM capture thread streaming"
                                audioState.isRecording && audioState.isPaused -> "Paused: Audio capture suspended on device"
                                isConnected -> "Ready: WebSocket bridge connected to Termux daemon"
                                isConnecting -> "Connecting: Initializing WebSocket bridge & capture engines..."
                                else -> "Standby: WebSocket & capture engines idle"
                            }
                            
                            AuraServiceStatusCard(
                        reducedMotion = reducedMotion,
                                state = currentServiceState,
                                statusDetail = currentServiceDetail,
                                onActionClick = {
                                    when (currentServiceState) {
                                        AuraServiceState.ERROR -> {
                                            requestMicrophonePermission()
                                        }
                                        AuraServiceState.STOPPED, AuraServiceState.UNKNOWN -> {
                                            if (hasAudioPermission) {
                                                viewModel.startAudioCapture(context)
                                            } else {
                                                requestMicrophonePermission()
                                            }
                                        }
                                        AuraServiceState.RUNNING -> {
                                            viewModel.stopAudioCapture(context)
                                        }
                                        AuraServiceState.PAUSED -> {
                                            viewModel.toggleAudioPause(context)
                                        }
                                        AuraServiceState.STARTING, AuraServiceState.STOPPING -> {
                                            // In transition
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    
                    item {
                        // 3. Audio Diagnostics & Real-Time Signal Visualization (Phase 5)
                        val audioStatus = when {
                            !hasAudioPermission -> AuraAudioStatus.NO_PERMISSION
                            audioState.error != null -> AuraAudioStatus.ERROR
                            audioState.isRecording && !audioState.isPaused -> AuraAudioStatus.ACTIVE
                            audioState.isRecording && audioState.isPaused -> AuraAudioStatus.PAUSED
                            else -> AuraAudioStatus.IDLE
                        }
                        
                        val coreEngineState = when (state.sessionState.connectionState) {
                            SessionState.ConnectionState.CONNECTED -> AuraCoreEngineState.READY
                            SessionState.ConnectionState.CONNECTING,
                            SessionState.ConnectionState.AUTHENTICATING,
                            SessionState.ConnectionState.RECONNECTING -> AuraCoreEngineState.CONNECTING
                            SessionState.ConnectionState.ERROR -> AuraCoreEngineState.ERROR
                            SessionState.ConnectionState.DISCONNECTED -> AuraCoreEngineState.DISCONNECTED
                        }
                                    
                        val isEngineConnected = state.sessionState.connectionState == SessionState.ConnectionState.CONNECTED
                        val isEngineConnecting = state.sessionState.connectionState == SessionState.ConnectionState.CONNECTING
                        
                        val audioCard = @Composable {
                            AuraAudioDiagnosticsCard(
                        reducedMotion = reducedMotion,
                                status = audioStatus,
                                sampleRate = audioState.sampleRate,
                                bufferSize = audioState.bufferSize,
                                rms = audioState.rms,
                                errorMessage = audioState.error,
                                hasPermission = hasAudioPermission,
                                onStartClick = {
                                    if (hasAudioPermission) {
                                        viewModel.startAudioCapture(context)
                                    } else {
                                        requestMicrophonePermission()
                                    }
                                },
                                onPauseClick = { viewModel.toggleAudioPause(context) },
                                onStopClick = { viewModel.stopAudioCapture(context) },
                                onRestartClick = { viewModel.restartAudioCapture(context) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("audio_telemetry_card")
                            )
                        }
                        
                        val coreEngineCard = @Composable {
                            AuraCoreEngineCard(
                        reducedMotion = reducedMotion,
                                engineState = coreEngineState,
                                provider = "Google Gemini", 
                                modelName = state.config.modelName,
                                connectionText = state.sessionState.connectionState.name.lowercase().replaceFirstChar { it.uppercase() },
                                latencyOrDuration = if (coreEngineState == AuraCoreEngineState.READY) "${state.sessionState.activeDurationSeconds}s" else "—",
                                actionText = if (isEngineConnected) "DISCONNECT" else if (isEngineConnecting) "CANCEL" else "CONNECT",
                                onActionClick = { viewModel.toggleConnection() },
                                errorMessage = state.sessionState.error,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        
                        if (useTwoColumns) {
                            Row(
                                modifier = Modifier.widthIn(max = wMax).fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(sMajor)
                            ) {
                                Box(modifier = Modifier.weight(1f)) { audioCard() }
                                Box(modifier = Modifier.weight(1f)) { coreEngineCard() }
                            }
                        } else {
                            Column(
                                modifier = Modifier.widthIn(max = wMax).fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(sMajor)
                            ) {
                                audioCard()
                                coreEngineCard()
                            }
                        }
                    }
                    
                    item {
                        // Persistence
                        Column(
                            modifier = Modifier.widthIn(max = wMax).fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(sMajor)
                        ) {
                            AuraPersistenceCard(
                                reducedMotion = reducedMotion,
                                persistenceState = if (state.history.isNotEmpty()) AuraPersistenceState.SYNCED else AuraPersistenceState.IDLE,
                                storageEngine = "Room SQLite v1",
                                historyCount = state.history.size,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                // 4. Floating Fixed Bottom Dock (Primary Voice & Mic/Cam Controls)
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                0.0f to Color.Transparent,
                                0.25f to AuraColors.Background.copy(alpha = 0.92f),
                                1.0f to AuraColors.Background
                            )
                        )
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .padding(horizontal = hMargin, vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    val voiceState = when {
                        state.sessionState.connectionState == SessionState.ConnectionState.ERROR || audioState.error != null -> AuraVoiceState.ERROR
                        state.sessionState.connectionState == SessionState.ConnectionState.CONNECTING -> AuraVoiceState.CONNECTING
                        state.sessionState.connectionState != SessionState.ConnectionState.CONNECTED -> AuraVoiceState.IDLE
                        state.isMicMuted -> AuraVoiceState.MUTED
                        audioState.isRecording && !audioState.isPaused -> AuraVoiceState.LISTENING
                        else -> AuraVoiceState.IDLE
                    }

                    AuraVoiceDock(
                        reducedMotion = reducedMotion,
                        voiceState = voiceState,
                        isCameraEnabled = state.isCameraEnabled,
                        onMicClick = { viewModel.toggleMicrophone() },
                        onCameraClick = { viewModel.toggleCamera() },
                        onPrimaryVoiceClick = {
                            if (state.sessionState.connectionState != SessionState.ConnectionState.CONNECTED) {
                                viewModel.toggleConnection()
                            } else {
                                viewModel.toggleMicrophone()
                            }
                        },
                        modifier = Modifier.widthIn(max = wMax)
                    )
                }
            }
        }
    }
}
@Composable
fun borderBrush() = BorderStroke(
    width = 1.dp,
    color = AuraColors.BorderSubtle
)

