package com.example.capabilities.share

import android.content.Context
import android.content.Intent
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

class ShareRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : ShareRepository {
    override fun shareText(text: String): CapabilityResult<Unit> {
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Share via").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            return CapabilityResult.Success(Unit)
        } catch (e: Exception) {
            return CapabilityResult.Error("Failed to share text", e)
        }
    }
}
