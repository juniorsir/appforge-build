package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * AURA ASSISTANT — Centralized Dimensions & Component Height Tokens
 */
@Immutable
object AuraDimensions {
    // Icon Dimensions
    val IconNano: Dp = 14.dp
    val IconMicro: Dp = 16.dp
    val IconSmall: Dp = 18.dp
    val IconNormal: Dp = 20.dp
    val IconLarge: Dp = 24.dp
    val IconHero: Dp = 28.dp

    // Interactive Touch Targets (Minimum standard: 48dp x 48dp)
    val MinTouchTarget: Dp = 48.dp

    // Button Heights & Action Dimensions
    val HeaderActionSize: Dp = 36.dp
    val HeaderActionSizeCompact: Dp = 34.dp
    val HeaderIconSize: Dp = 16.dp
    val HeaderIconSizeCompact: Dp = 14.dp

    // Button Heights
    val ButtonHeightNormal: Dp = 48.dp
    val ButtonHeightLarge: Dp = 64.dp
    val IconButtonSize: Dp = 48.dp

    // Status Dots & Indicators
    val StatusDotSize: Dp = 6.dp
    val StatusDotPulseMax: Dp = 10.dp

    // Card & Panel Defaults
    val CardMinHeight: Dp = 68.dp
    val HeroCardHeight: Dp = 210.dp
    val VoiceDockHeight: Dp = 72.dp
}
