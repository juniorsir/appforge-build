package com.example.tools.repository

import com.example.tools.core.Tool
import kotlinx.coroutines.flow.Flow

interface ToolRegistryRepository {
    fun getTools(): Flow<List<Tool>>
    suspend fun registerTool(tool: Tool): Boolean
    suspend fun unregisterTool(toolId: String): Boolean
    suspend fun getToolById(toolId: String): Tool?
}
