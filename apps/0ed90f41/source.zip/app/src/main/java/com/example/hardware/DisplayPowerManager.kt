package com.example.hardware

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager

class DisplayPowerManager(private val context: Context) {

    private val TAG = "DisplayPowerManager"
    private var wakeLock: PowerManager.WakeLock? = null

    data class DisplayDetails(
        val widthPixels: Int,
        val heightPixels: Int,
        val densityDpi: Int,
        val densityScale: Float,
        val refreshRateHz: Float,
        val orientation: String,
        val isHdr: Boolean,
        val currentBrightness: Int,
        val isAutoBrightness: Boolean,
        val screenTimeoutMs: Int,
        val isInteractive: Boolean,
        val isPowerSaveMode: Boolean,
        val canWriteSystemSettings: Boolean
    )

    fun getDisplayDetails(): DisplayDetails {
        val metrics = context.resources.displayMetrics
        val config = context.resources.configuration
        val orientationStr = if (config.orientation == Configuration.ORIENTATION_LANDSCAPE) "LANDSCAPE" else "PORTRAIT"

        var refreshRate = 60.0f
        var isHdr = false

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val display = context.display
            if (display != null) {
                refreshRate = display.refreshRate
                isHdr = display.isHdr
            }
        } else {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            refreshRate = wm?.defaultDisplay?.refreshRate ?: 60.0f
        }

        val brightness = try {
            Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
        } catch (e: Exception) {
            128
        }

        val brightnessMode = try {
            Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        } catch (e: Exception) {
            Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
        }

        val screenTimeout = try {
            Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, 60000)
        } catch (e: Exception) {
            60000
        }

        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val isInteractive = pm?.isInteractive ?: true
        val isPowerSave = pm?.isPowerSaveMode ?: false

        val canWrite = Settings.System.canWrite(context)

        return DisplayDetails(
            widthPixels = metrics.widthPixels,
            heightPixels = metrics.heightPixels,
            densityDpi = metrics.densityDpi,
            densityScale = metrics.density,
            refreshRateHz = ((refreshRate * 10).toInt() / 10f),
            orientation = orientationStr,
            isHdr = isHdr,
            currentBrightness = brightness,
            isAutoBrightness = (brightnessMode == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC),
            screenTimeoutMs = screenTimeout,
            isInteractive = isInteractive,
            isPowerSaveMode = isPowerSave,
            canWriteSystemSettings = canWrite
        )
    }

    fun setBrightness(brightness: Int): Boolean {
        if (!Settings.System.canWrite(context)) {
            Log.w(TAG, "Cannot write system settings: WRITE_SETTINGS permission not granted")
            return false
        }
        return try {
            val safe = brightness.coerceIn(0, 255)
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS,
                safe
            )
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to set brightness: ${e.message}", e)
            false
        }
    }

    fun setAutoBrightness(enabled: Boolean): Boolean {
        if (!Settings.System.canWrite(context)) return false
        return try {
            val mode = if (enabled) Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC else Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                mode
            )
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to set auto brightness: ${e.message}", e)
            false
        }
    }

    fun acquireWakeLock(tag: String = "Aura:WakeLock", timeoutMs: Long = 10 * 60 * 1000L): Boolean {
        return try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            if (wakeLock == null) {
                wakeLock = pm?.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, tag)
            }
            wakeLock?.acquire(timeoutMs)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to acquire wake lock", e)
            false
        }
    }

    fun releaseWakeLock(): Boolean {
        return try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to release wake lock", e)
            false
        }
    }
}
