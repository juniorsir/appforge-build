package com.example.capabilities.input

import android.content.Context
import android.view.InputDevice
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

data class ConnectedInputDevice(
    val id: Int,
    val name: String,
    val isExternal: Boolean,
    val isKeyboard: Boolean,
    val isMouse: Boolean,
    val isGameController: Boolean,
    val isTouchscreen: Boolean
)

data class InputDevicesSummary(
    val totalDevices: Int,
    val hasKeyboard: Boolean,
    val hasMouse: Boolean,
    val hasGamepad: Boolean,
    val devices: List<ConnectedInputDevice>
)

interface InputRepository {
    fun getInputDevices(): CapabilityResult<InputDevicesSummary>
}

@Singleton
class InputRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : InputRepository {

    override fun getInputDevices(): CapabilityResult<InputDevicesSummary> {
        return try {
            val deviceIds = InputDevice.getDeviceIds()
            val list = mutableListOf<ConnectedInputDevice>()

            var hasKb = false
            var hasMouse = false
            var hasGamepad = false

            for (id in deviceIds) {
                val dev = InputDevice.getDevice(id) ?: continue
                val sources = dev.sources

                val isKb = (sources and InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD && dev.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC
                val isM = (sources and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE
                val isGamepadDev = (sources and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD || (sources and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
                val isTouch = (sources and InputDevice.SOURCE_TOUCHSCREEN) == InputDevice.SOURCE_TOUCHSCREEN

                if (isKb && dev.isExternal) hasKb = true
                if (isM) hasMouse = true
                if (isGamepadDev) hasGamepad = true

                list.add(
                    ConnectedInputDevice(
                        id = id,
                        name = dev.name,
                        isExternal = dev.isExternal,
                        isKeyboard = isKb,
                        isMouse = isM,
                        isGameController = isGamepadDev,
                        isTouchscreen = isTouch
                    )
                )
            }

            CapabilityResult.Success(
                InputDevicesSummary(
                    totalDevices = list.size,
                    hasKeyboard = hasKb,
                    hasMouse = hasMouse,
                    hasGamepad = hasGamepad,
                    devices = list
                )
            )
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to query input devices: ${e.message}", e)
        }
    }
}
