package com.example.presentation.brain

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConversationEngineScreen(
    onNavigateBack: () -> Unit,
    viewModel: ConversationEngineViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val activeConversation by viewModel.activeConversation.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val llmConfig by viewModel.llmConfig.collectAsState()
    val promptTemplate by viewModel.promptTemplate.collectAsState()
    val streamingResponse by viewModel.streamingResponse.collectAsState()
    val generationState by viewModel.generationState.collectAsState()
    val tokenCount by viewModel.tokenCountPlaceholder.collectAsState()
    val responseLatency by viewModel.lastResponseLatencyMs.collectAsState()
    val errorState by viewModel.errorState.collectAsState()
    val sessionId by viewModel.sessionId.collectAsState()

    var userMessageInput by remember { mutableStateOf("") }
    var showPromptConfig by remember { mutableStateOf(false) }
    var showLlmConfig by remember { mutableStateOf(false) }

    // Editable prompt holding variables
    var editableSystemPrompt by remember(promptTemplate) { mutableStateOf(promptTemplate.systemPrompt) }
    var editableDevPrompt by remember(promptTemplate) { mutableStateOf(promptTemplate.developerPrompt) }

    // Editable LLM config holding variables
    var editableApiKey by remember(llmConfig) { mutableStateOf(llmConfig.apiKey) }
    var editableBaseUrl by remember(llmConfig) { mutableStateOf(llmConfig.baseUrl) }
    var editableTemperature by remember(llmConfig) { mutableStateOf(llmConfig.temperature) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "AI Conversation Engine",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleLarge
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Telemetry Hub Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Inference & Memory State",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                // Active generation status badge
                                SuggestionChip(
                                    onClick = {},
                                    label = { Text(generationState.name) },
                                    colors = SuggestionChipDefaults.suggestionChipColors(
                                        containerColor = when (generationState) {
                                            GenerationState.GENERATING -> Color(0xFFFFF3E0)
                                            GenerationState.SUCCESS -> Color(0xFFE8F5E9)
                                            GenerationState.CANCELLED -> Color(0xFFECEFF1)
                                            GenerationState.ERROR -> Color(0xFFFFEBEE)
                                            else -> MaterialTheme.colorScheme.surface
                                        },
                                        labelColor = when (generationState) {
                                            GenerationState.GENERATING -> Color(0xFFE65100)
                                            GenerationState.SUCCESS -> Color(0xFF2E7D32)
                                            GenerationState.CANCELLED -> Color(0xFF546E7A)
                                            GenerationState.ERROR -> Color(0xFFC62828)
                                            else -> MaterialTheme.colorScheme.onSurface
                                        }
                                    )
                                )
                            }

                            HorizontalDivider(color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Latency Telemetry
                                Card(
                                    modifier = Modifier.weight(1f),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surface
                                    ),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                                ) {
                                    Column(
                                        modifier = Modifier.padding(8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Icon(Icons.Default.Speed, contentDescription = "Latency", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                        Text("Latency", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                                        Text("${responseLatency}ms", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                    }
                                }

                                // Token Estimate
                                Card(
                                    modifier = Modifier.weight(1f),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surface
                                    ),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                                ) {
                                    Column(
                                        modifier = Modifier.padding(8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Icon(Icons.Default.DataUsage, contentDescription = "Tokens", tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(20.dp))
                                        Text("Token Estimate", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                                        Text("${tokenCount}t", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            // IDs Metadata
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Session ID", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                    Text(sessionId.take(12).plus("..."), fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Conversation ID", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                    Text(activeConversation?.id?.take(12).plus("..."), fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // Error State Display
                errorState?.let { err ->
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.Error, contentDescription = "Error", tint = MaterialTheme.colorScheme.onErrorContainer)
                                Text(text = err, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onErrorContainer)
                            }
                        }
                    }
                }

                // Prompt Builder Configurations (Collapsible)
                item {
                    ElevatedCard(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.elevatedCardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.EditNote, contentDescription = "Prompt Config", tint = MaterialTheme.colorScheme.tertiary)
                                    Text("System & Developer Prompts", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                }
                                IconButton(onClick = { showPromptConfig = !showPromptConfig }) {
                                    Icon(
                                        imageVector = if (showPromptConfig) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                        contentDescription = "Toggle"
                                    )
                                }
                            }

                            AnimatedVisibility(visible = showPromptConfig) {
                                Column(
                                    modifier = Modifier.padding(top = 8.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    OutlinedTextField(
                                        value = editableSystemPrompt,
                                        onValueChange = { editableSystemPrompt = it },
                                        label = { Text("System Prompt") },
                                        modifier = Modifier.fillMaxWidth(),
                                        textStyle = MaterialTheme.typography.bodySmall
                                    )

                                    OutlinedTextField(
                                        value = editableDevPrompt,
                                        onValueChange = { editableDevPrompt = it },
                                        label = { Text("Developer Instructions") },
                                        modifier = Modifier.fillMaxWidth(),
                                        textStyle = MaterialTheme.typography.bodySmall
                                    )

                                    Button(
                                        onClick = {
                                            viewModel.updatePromptTemplate(editableSystemPrompt, editableDevPrompt)
                                            showPromptConfig = false
                                        },
                                        modifier = Modifier.align(Alignment.End)
                                    ) {
                                        Icon(Icons.Default.Save, contentDescription = "Save")
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Save Prompts")
                                    }
                                }
                            }
                        }
                    }
                }

                // LLM Vendor Providers Settings (Collapsible)
                item {
                    ElevatedCard(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.elevatedCardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.SettingsSuggest, contentDescription = "LLM Settings", tint = MaterialTheme.colorScheme.secondary)
                                    Text("LLM Vendor Abstraction", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                }
                                IconButton(onClick = { showLlmConfig = !showLlmConfig }) {
                                    Icon(
                                        imageVector = if (showLlmConfig) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                        contentDescription = "Toggle"
                                    )
                                }
                            }

                            AnimatedVisibility(visible = showLlmConfig) {
                                Column(
                                    modifier = Modifier.padding(top = 8.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    // Vendor Selector Row
                                    Text("Select Active Provider Model", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        LlmProviderType.values().forEach { provider ->
                                            val isSelected = llmConfig.providerType == provider
                                            InputChip(
                                                selected = isSelected,
                                                onClick = {
                                                    viewModel.updateConfig(llmConfig.copy(providerType = provider))
                                                },
                                                label = { Text(provider.name, fontSize = 10.sp) },
                                                colors = InputChipDefaults.inputChipColors(
                                                    selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                                                    selectedLabelColor = MaterialTheme.colorScheme.onSecondaryContainer
                                                )
                                            )
                                        }
                                    }

                                    OutlinedTextField(
                                        value = editableApiKey,
                                        onValueChange = {
                                            editableApiKey = it
                                            viewModel.updateConfig(llmConfig.copy(apiKey = it))
                                        },
                                        label = { Text("API Key (leave blank for local mock)") },
                                        modifier = Modifier.fillMaxWidth(),
                                        textStyle = MaterialTheme.typography.bodySmall
                                    )

                                    OutlinedTextField(
                                        value = editableBaseUrl,
                                        onValueChange = {
                                            editableBaseUrl = it
                                            viewModel.updateConfig(llmConfig.copy(baseUrl = it))
                                        },
                                        label = { Text("API Base URL (optional)") },
                                        modifier = Modifier.fillMaxWidth(),
                                        textStyle = MaterialTheme.typography.bodySmall
                                    )

                                    // Temperature Slider
                                    Column {
                                        Text("Temperature: %.1f".format(editableTemperature), style = MaterialTheme.typography.labelSmall)
                                        Slider(
                                            value = editableTemperature,
                                            onValueChange = {
                                                editableTemperature = it
                                                viewModel.updateConfig(llmConfig.copy(temperature = it))
                                            },
                                            valueRange = 0.0f..1.2f
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Conversation action buttons (Row 1)
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.createNewConversation("Chat Session " + (messages.size / 2 + 1)) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("new_conversation_button")
                        ) {
                            Icon(Icons.Default.AddComment, contentDescription = "New")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("New Chat", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = { viewModel.clearConversation() },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("clear_conversation_button")
                        ) {
                            Icon(Icons.Default.ClearAll, contentDescription = "Clear")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Clear", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = { viewModel.exportConversation(context) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("export_conversation_button")
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Export")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Export", fontSize = 11.sp)
                        }
                    }
                }

                // Conversation action buttons (Row 2 - Stop / Retry)
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (generationState == GenerationState.GENERATING) {
                            Button(
                                onClick = { viewModel.stopGeneration() },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("stop_generation_button")
                            ) {
                                Icon(Icons.Default.Cancel, contentDescription = "Stop")
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Stop Generation")
                            }
                        } else {
                            OutlinedButton(
                                onClick = { viewModel.retry() },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("retry_generation_button")
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = "Retry")
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Retry Generation")
                            }
                        }
                    }
                }

                // Message Thread Header
                item {
                    Text(
                        "Conversation History Thread",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                // Message Thread Flow List
                if (messages.isEmpty() && streamingResponse.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "No messages in active session. Send a message below to start streaming responses.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    }
                } else {
                    items(messages, key = { it.id }) { msg ->
                        BrainMessageBubble(message = msg)
                    }
                }

                // Streaming / Pulsing Live response bubble
                if (streamingResponse.isNotBlank() && generationState == GenerationState.GENERATING) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(end = 40.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                            )
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("AURA (Streaming...)", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    CircularProgressIndicator(modifier = Modifier.size(12.dp), strokeWidth = 2.dp)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = streamingResponse,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }
                        }
                    }
                }
            }

            // Input Send Row
            Surface(
                tonalElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                        .navigationBarsPadding(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = userMessageInput,
                        onValueChange = { userMessageInput = it },
                        placeholder = { Text("Type a message or instruction...") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_message_input"),
                        shape = RoundedCornerShape(24.dp),
                        maxLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.surface,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surface
                        )
                    )

                    FloatingActionButton(
                        onClick = {
                            if (userMessageInput.isNotBlank()) {
                                viewModel.startGeneration(userMessageInput)
                                userMessageInput = ""
                            }
                        },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("chat_send_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send Message"
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BrainMessageBubble(message: BrainMessage) {
    val isUser = message.role == LlmMessage.Role.USER
    val isSystem = message.role == LlmMessage.Role.SYSTEM

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(if (isSystem) 1f else 0.85f)
                .padding(vertical = 4.dp),
            colors = CardDefaults.cardColors(
                containerColor = when {
                    isUser -> MaterialTheme.colorScheme.primaryContainer
                    isSystem -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    else -> MaterialTheme.colorScheme.surface
                }
            ),
            border = if (!isUser && !isSystem) BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant) else null
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isSystem) "MEMORY/CONTEXT SYSTEM" else message.role.name,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = when {
                            isUser -> MaterialTheme.colorScheme.primary
                            isSystem -> MaterialTheme.colorScheme.secondary
                            else -> MaterialTheme.colorScheme.tertiary
                        }
                    )

                    val timeStr = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
                        .format(java.util.Date(message.timestamp))
                    Text(
                        text = timeStr,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = message.content,
                    style = if (isSystem) MaterialTheme.typography.bodySmall else MaterialTheme.typography.bodyMedium,
                    fontFamily = if (isSystem) FontFamily.Monospace else null
                )

                if (!isUser && !isSystem && message.responseTimeMs > 0) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Latency: ${message.responseTimeMs}ms | Token estimate: ${message.tokenCountPlaceholder}t",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }
            }
        }
    }
}
