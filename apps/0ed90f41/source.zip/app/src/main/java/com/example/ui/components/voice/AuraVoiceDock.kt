package com.example.ui.components.voice

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.glass.AuraGlassSurface
import com.example.ui.theme.AuraBorders
import com.example.ui.theme.AuraColors
import com.example.ui.theme.AuraDimensions
import com.example.ui.theme.AuraGlassLevel
import com.example.ui.theme.AuraMotion
import com.example.ui.theme.AuraShapes
import com.example.ui.theme.AuraTypography
import kotlin.math.max
import kotlin.math.min

/**
 * AURA ASSISTANT — Phase 7: Voice States
 * Maps directly to actual application connection and capture states.
 */
enum class AuraVoiceState(val label: String, val semantics: String) {
    IDLE("Ready to connect", "Voice interaction ready to connect"),
    CONNECTING("Connecting...", "Voice interaction connecting"),
    LISTENING("Listening...", "Listening. Tap to mute"),
    MUTED("Muted", "Microphone muted. Tap to unmute"),
    ERROR("Error", "Voice interaction error"),
    UNAVAILABLE("Unavailable", "Voice interaction unavailable")
}

/**
 * AURA ASSISTANT — Phase 7: Bottom Voice Dock
 *
 * Minimal, premium voice interaction dock.
 * Centers the dominant primary voice assistant interaction and positions the
 * compact secondary media controls [ MIC | VIDEO ] below it.
 */
@Composable
fun AuraVoiceDock(
    voiceState: AuraVoiceState,
    isCameraEnabled: Boolean,
    onMicClick: () -> Unit,
    onCameraClick: () -> Unit,
    modifier: Modifier = Modifier,
    reducedMotion: Boolean = false,
    onPrimaryVoiceClick: (() -> Unit)? = null
) {
    val micState = when (voiceState) {
        AuraVoiceState.UNAVAILABLE -> AuraMicState.UNAVAILABLE
        AuraVoiceState.MUTED -> AuraMicState.MUTED
        else -> AuraMicState.ENABLED
    }

    val videoState = if (isCameraEnabled) AuraVideoState.ENABLED else AuraVideoState.DISABLED

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. PRIMARY: Voice Assistant Interaction Control
        AuraPrimaryVoiceControl(
            state = voiceState,
            onClick = { onPrimaryVoiceClick?.invoke() ?: onMicClick() },
            reducedMotion = reducedMotion,
            modifier = Modifier.testTag("primary_voice_control")
        )

        // 2. SECONDARY: Bottom Media Controls Dock [ MIC | CAM ]
        AuraMediaControls(
            micState = micState,
            videoState = videoState,
            onMicClick = onMicClick,
            onVideoClick = onCameraClick,
            reducedMotion = reducedMotion,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("aura_media_controls")
        )
    }
}

/**
 * Primary Voice Assistant interaction control.
 * Visually dominant pill displaying the active voice state, breathing pulse, and status label.
 */
@Composable
private fun AuraPrimaryVoiceControl(
    state: AuraVoiceState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    reducedMotion: Boolean = false
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    // Breathing pulse for LISTENING and CONNECTING states
    val isListening = state == AuraVoiceState.LISTENING
    val isConnecting = state == AuraVoiceState.CONNECTING
    val isMuted = state == AuraVoiceState.MUTED
    val isError = state == AuraVoiceState.ERROR

    val infiniteTransition = rememberInfiniteTransition(label = "VoicePulseTransition")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "VoicePulseAlpha"
    )

    // Touch feedback scale
    val pressScale by animateFloatAsState(
        targetValue = if (isPressed && !reducedMotion) 0.98f else 1.0f,
        animationSpec = tween(durationMillis = if (isPressed) 120 else 160),
        label = "PrimaryVoicePressScale"
    )

    val surfaceLevel = when {
        isPressed -> AuraGlassLevel.ACTIVE
        isListening -> AuraGlassLevel.LEVEL_3
        else -> AuraGlassLevel.LEVEL_2
    }

    val dotColor = when {
        isError -> AuraColors.StatusError
        isMuted -> AuraColors.TextMuted
        isListening -> AuraColors.TextPrimary
        isConnecting -> AuraColors.TextSecondary
        else -> AuraColors.White.copy(alpha = 0.7f)
    }

    val effectiveDotAlpha = if ((isListening || isConnecting) && !reducedMotion) pulseAlpha else 1.0f

    Box(
        modifier = modifier
            .scale(pressScale)
            .clip(RoundedCornerShape(20.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                role = Role.Button,
                onClick = onClick,
                enabled = state != AuraVoiceState.UNAVAILABLE
            )
            .semantics {
                role = Role.Button
                contentDescription = state.semantics
            },
        contentAlignment = Alignment.Center
    ) {
        AuraGlassSurface(
            modifier = Modifier
                .height(40.dp)
                .clip(RoundedCornerShape(20.dp)),
            shape = RoundedCornerShape(20.dp),
            level = surfaceLevel,
            borderWidth = AuraBorders.WidthNormal,
            customBorderAlpha = if (isListening) 0.18f else 0.08f,
            showHighlight = true
        ) {
            Row(
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Live Status Indicator Dot
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(dotColor.copy(alpha = effectiveDotAlpha))
                )

                // Voice State Label
                Text(
                    text = state.label.uppercase(),
                    style = AuraTypography.Caption.copy(
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 0.8.sp
                    ),
                    color = when {
                        isError -> AuraColors.StatusError
                        isListening -> AuraColors.TextPrimary
                        isMuted -> AuraColors.TextMuted
                        else -> AuraColors.TextSecondary
                    },
                    maxLines = 1,
                    modifier = Modifier.testTag("voice_dock_label")
                )

                // Subtle icon indicator
                Icon(
                    imageVector = if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = null,
                    tint = dotColor.copy(alpha = 0.7f),
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}
