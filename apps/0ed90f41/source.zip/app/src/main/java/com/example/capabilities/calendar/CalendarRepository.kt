package com.example.capabilities.calendar

import com.example.capabilities.CapabilityResult

data class CalendarEvent(
    val title: String,
    val description: String,
    val startTime: Long,
    val endTime: Long
)

interface CalendarRepository {
    suspend fun getEvents(startTime: Long, endTime: Long): CapabilityResult<List<CalendarEvent>>
    suspend fun createEvent(event: CalendarEvent): CapabilityResult<Long> // Returns event ID
}
