package com.example.media

data class MediaConversionRequest(
    val inputUri: String,
    val outputUri: String,
    val videoCodec: String? = null,
    val audioCodec: String? = null,
    val width: Int? = null,
    val height: Int? = null,
    val videoBitrate: String? = null,
    val audioBitrate: String? = null,
    val format: String? = null
)

sealed class MediaConversionResult {
    data class Success(val outputUri: String) : MediaConversionResult()
    data class Failure(val error: String, val logs: String) : MediaConversionResult()
    object Cancelled : MediaConversionResult()
}
