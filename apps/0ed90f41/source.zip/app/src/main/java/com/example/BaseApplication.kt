package com.example

import android.app.Application
import com.example.di.AppContainer
import com.example.workers.TelemetrySyncWorker
// import dagger.hilt.android.HiltAndroidApp

/**
 * Base Application entry point.
 * Initializes dependency injection scopes and periodic WorkManager synchronization workers.
 */
// @HiltAndroidApp
class BaseApplication : Application() {

    // Access container for manual dependency injection
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        
        // Initialize dependency locator container
        container = AppContainer(this)
        
        // Enqueue background telemetry sync jobs using WorkManager
        try {
            TelemetrySyncWorker.enqueuePeriodicSync(this)
        } catch (e: Exception) {
            android.util.Log.w("BaseApplication", "Failed to enqueue periodic telemetry sync worker", e)
        }
    }
}
