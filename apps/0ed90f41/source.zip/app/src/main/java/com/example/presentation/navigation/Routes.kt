package com.example.presentation.navigation

import kotlinx.serialization.Serializable

@Serializable
object DashboardRoute

@Serializable
object SettingsRoute

@Serializable
object DeveloperRoute

@Serializable
object CapabilityDashboardRoute

@Serializable
object ToolsFrameworkRoute

@Serializable
object SpeechDiagnosticsRoute

@Serializable
object ConversationEngineRoute

@Serializable
object AccessibilityDashboardRoute

