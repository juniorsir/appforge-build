package com.example.tools.registry

import com.example.tools.core.Tool
import com.example.tools.repository.ToolRegistryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ToolRegistryImpl @Inject constructor() : ToolRegistryRepository {
    private val _tools = MutableStateFlow<Map<String, Tool>>(emptyMap())
    
    override fun getTools(): Flow<List<Tool>> {
        return _tools.map { it.values.toList() }
    }

    override suspend fun registerTool(tool: Tool): Boolean {
        val current = _tools.value.toMutableMap()
        current[tool.id] = tool
        _tools.value = current
        return true
    }

    override suspend fun unregisterTool(toolId: String): Boolean {
        val current = _tools.value.toMutableMap()
        val removed = current.remove(toolId)
        if (removed != null) {
            _tools.value = current
            return true
        }
        return false
    }

    override suspend fun getToolById(toolId: String): Tool? {
        return _tools.value[toolId]
    }
}
