package com.example.presentation.developer

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.capabilities.core.CapabilityAvailability
import com.example.capabilities.core.CapabilityCategory
import com.example.capabilities.core.CapabilityDefinition
import com.example.capabilities.core.CapabilityResponse
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CapabilityDashboardScreen(
    onNavigateBack: () -> Unit = {},
    viewModel: CapabilityViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val allCapabilities by viewModel.allCapabilities.collectAsStateWithLifecycle()
    val filteredCapabilities by viewModel.filteredCapabilities.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val selectedAvailability by viewModel.selectedAvailability.collectAsStateWithLifecycle()
    val executionResults by viewModel.lastExecutionResults.collectAsStateWithLifecycle()
    val isExecuting by viewModel.isExecuting.collectAsStateWithLifecycle()

    val totalCount = allCapabilities.size
    val availableCount = allCapabilities.count { it.availability == CapabilityAvailability.AVAILABLE }
    val permReqCount = allCapabilities.count { it.availability == CapabilityAvailability.PERMISSION_REQUIRED }
    val hwMissingCount = allCapabilities.count { it.availability == CapabilityAvailability.HARDWARE_MISSING }
    val unsupportedCount = allCapabilities.count { 
        it.availability == CapabilityAvailability.ANDROID_VERSION_UNSUPPORTED ||
        it.availability == CapabilityAvailability.SERVICE_DISABLED ||
        it.availability == CapabilityAvailability.UNAVAILABLE_TO_NORMAL_APP
    }

    Scaffold(
        modifier = Modifier.testTag("capability_dashboard_scaffold"),
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(listOf(NeonCyan, ElectricViolet))
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Layers,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column {
                            Text(
                                "Android Capability Layer",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                "$availableCount of $totalCount Capabilities Ready & Active",
                                style = MaterialTheme.typography.bodySmall,
                                color = NeonEmerald,
                                fontSize = 11.sp
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("capability_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Default.ArrowBack,
                            contentDescription = "Navigate Back",
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.refreshAll() },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(ObsidianSurfaceVariant)
                            .testTag("refresh_capabilities_button")
                    ) {
                        Icon(
                            Icons.Default.Refresh,
                            contentDescription = "Refresh Capabilities",
                            tint = NeonCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                        onClick = {
                            try {
                                context.startActivity(viewModel.permissionManager.createAppSettingsIntent())
                            } catch (e: Exception) {
                                Toast.makeText(context, "Cannot open settings: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(ObsidianSurfaceVariant)
                            .testTag("open_settings_button")
                    ) {
                        Icon(
                            Icons.Default.Settings,
                            contentDescription = "App Settings",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ObsidianBg
                )
            )
        },
        containerColor = ObsidianBg
    ) { padding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            val isTabletOrWide = maxWidth >= 600.dp

            if (isTabletOrWide) {
                // Adaptive Grid Layout for Tablets and Wide Screens
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 360.dp),
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("capability_list_column")
                ) {
                    // Span Header Controls across all columns
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        CapabilityHeaderSection(
                            totalCount = totalCount,
                            availableCount = availableCount,
                            permReqCount = permReqCount,
                            hwMissingCount = hwMissingCount,
                            unsupportedCount = unsupportedCount,
                            searchQuery = searchQuery,
                            onSearchChange = { viewModel.updateSearchQuery(it) },
                            allCapabilities = allCapabilities,
                            selectedCategory = selectedCategory,
                            onSelectCategory = { viewModel.selectCategory(it) },
                            selectedAvailability = selectedAvailability,
                            onSelectAvailability = { viewModel.selectAvailability(it) }
                        )
                    }

                    if (filteredCapabilities.isEmpty()) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            EmptyFilterPlaceholder(searchQuery = searchQuery)
                        }
                    } else {
                        items(filteredCapabilities, key = { it.id }) { capability ->
                            CapabilityItemCard(
                                capability = capability,
                                lastResult = executionResults[capability.id],
                                isBusy = isExecuting[capability.id] == true,
                                onTestClick = { viewModel.testCapability(capability.id) },
                                onOpenSettings = {
                                    try {
                                        context.startActivity(viewModel.permissionManager.createAppSettingsIntent())
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Cannot open settings: ${e.message}", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onCopyResult = { label, text ->
                                    copyToClipboard(context, label, text)
                                }
                            )
                        }
                    }
                }
            } else {
                // Compact Single-Column Layout for Phones
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("capability_list_column"),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        CapabilityHeaderSection(
                            totalCount = totalCount,
                            availableCount = availableCount,
                            permReqCount = permReqCount,
                            hwMissingCount = hwMissingCount,
                            unsupportedCount = unsupportedCount,
                            searchQuery = searchQuery,
                            onSearchChange = { viewModel.updateSearchQuery(it) },
                            allCapabilities = allCapabilities,
                            selectedCategory = selectedCategory,
                            onSelectCategory = { viewModel.selectCategory(it) },
                            selectedAvailability = selectedAvailability,
                            onSelectAvailability = { viewModel.selectAvailability(it) }
                        )
                    }

                    if (filteredCapabilities.isEmpty()) {
                        item {
                            EmptyFilterPlaceholder(searchQuery = searchQuery)
                        }
                    } else {
                        items(filteredCapabilities, key = { it.id }) { capability ->
                            CapabilityItemCard(
                                capability = capability,
                                lastResult = executionResults[capability.id],
                                isBusy = isExecuting[capability.id] == true,
                                onTestClick = { viewModel.testCapability(capability.id) },
                                onOpenSettings = {
                                    try {
                                        context.startActivity(viewModel.permissionManager.createAppSettingsIntent())
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Cannot open settings: ${e.message}", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onCopyResult = { label, text ->
                                    copyToClipboard(context, label, text)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CapabilityHeaderSection(
    totalCount: Int,
    availableCount: Int,
    permReqCount: Int,
    hwMissingCount: Int,
    unsupportedCount: Int,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    allCapabilities: List<CapabilityDefinition>,
    selectedCategory: CapabilityCategory?,
    onSelectCategory: (CapabilityCategory?) -> Unit,
    selectedAvailability: CapabilityAvailability?,
    onSelectAvailability: (CapabilityAvailability?) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Metric Stats Cards Matrix
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatBadge(
                label = "Total",
                count = totalCount.toString(),
                color = NeonCyan,
                isSelected = selectedAvailability == null && selectedCategory == null,
                onClick = {
                    onSelectAvailability(null)
                    onSelectCategory(null)
                },
                modifier = Modifier.weight(1f)
            )
            StatBadge(
                label = "Available",
                count = availableCount.toString(),
                color = NeonEmerald,
                isSelected = selectedAvailability == CapabilityAvailability.AVAILABLE,
                onClick = {
                    if (selectedAvailability == CapabilityAvailability.AVAILABLE) onSelectAvailability(null)
                    else onSelectAvailability(CapabilityAvailability.AVAILABLE)
                },
                modifier = Modifier.weight(1f)
            )
            StatBadge(
                label = "Needs Perm",
                count = permReqCount.toString(),
                color = NeonAmber,
                isSelected = selectedAvailability == CapabilityAvailability.PERMISSION_REQUIRED,
                onClick = {
                    if (selectedAvailability == CapabilityAvailability.PERMISSION_REQUIRED) onSelectAvailability(null)
                    else onSelectAvailability(CapabilityAvailability.PERMISSION_REQUIRED)
                },
                modifier = Modifier.weight(1f)
            )
            StatBadge(
                label = "Unavailable",
                count = (hwMissingCount + unsupportedCount).toString(),
                color = NeonRose,
                isSelected = selectedAvailability == CapabilityAvailability.HARDWARE_MISSING,
                onClick = {
                    if (selectedAvailability == CapabilityAvailability.HARDWARE_MISSING) onSelectAvailability(null)
                    else onSelectAvailability(CapabilityAvailability.HARDWARE_MISSING)
                },
                modifier = Modifier.weight(1f)
            )
        }

        // 2. Search Input Field
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("capability_search_field"),
            placeholder = {
                Text(
                    "Search 31+ capabilities, sensors, permissions, IDs...",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            },
            leadingIcon = {
                Icon(
                    Icons.Default.Search,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(20.dp)
                )
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchChange("") }) {
                        Icon(
                            Icons.Default.Clear,
                            contentDescription = "Clear search",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = ObsidianSurface,
                unfocusedContainerColor = ObsidianSurface,
                focusedBorderColor = NeonCyan,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                unfocusedTextColor = MaterialTheme.colorScheme.onSurface
            )
        )

        // 3. Category Filter Chips Carousel
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = selectedCategory == null,
                onClick = { onSelectCategory(null) },
                label = { Text("All Categories (${allCapabilities.size})", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                leadingIcon = {
                    Icon(
                        Icons.Default.AllInclusive,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                },
                modifier = Modifier.testTag("filter_all"),
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = NeonCyan.copy(alpha = 0.2f),
                    selectedLabelColor = NeonCyan,
                    selectedLeadingIconColor = NeonCyan,
                    containerColor = ObsidianSurfaceVariant,
                    labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = selectedCategory == null,
                    borderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                    selectedBorderColor = NeonCyan.copy(alpha = 0.6f)
                ),
                shape = RoundedCornerShape(10.dp)
            )

            CapabilityCategory.values().forEach { category ->
                val count = allCapabilities.count { it.category == category }
                if (count > 0) {
                    val isSelected = selectedCategory == category
                    val categoryIcon = getCategoryIcon(category)
                    val categoryColor = getCategoryColor(category)

                    FilterChip(
                        selected = isSelected,
                        onClick = { onSelectCategory(if (isSelected) null else category) },
                        label = { Text("${category.displayName} ($count)", fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                        leadingIcon = {
                            Icon(
                                categoryIcon,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                        },
                        modifier = Modifier.testTag("filter_${category.name.lowercase()}"),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = categoryColor.copy(alpha = 0.2f),
                            selectedLabelColor = categoryColor,
                            selectedLeadingIconColor = categoryColor,
                            containerColor = ObsidianSurfaceVariant,
                            labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                            selectedBorderColor = categoryColor.copy(alpha = 0.6f)
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun StatBadge(
    label: String,
    count: String,
    color: Color,
    isSelected: Boolean = false,
    onClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        color = if (isSelected) color.copy(alpha = 0.22f) else ObsidianSurface,
        border = BorderStroke(
            if (isSelected) 1.5.dp else 1.dp,
            if (isSelected) color else MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
        )
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = count,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = color,
                fontSize = 18.sp
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = if (isSelected) color else MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
fun CapabilityItemCard(
    capability: CapabilityDefinition,
    lastResult: CapabilityResponse?,
    isBusy: Boolean,
    onTestClick: () -> Unit,
    onOpenSettings: () -> Unit,
    onCopyResult: (String, String) -> Unit
) {
    var isExpanded by remember { mutableStateOf(false) }

    val availabilityColor = when (capability.availability) {
        CapabilityAvailability.AVAILABLE -> NeonEmerald
        CapabilityAvailability.PERMISSION_REQUIRED -> NeonAmber
        CapabilityAvailability.HARDWARE_MISSING -> Color(0xFF94A3B8)
        CapabilityAvailability.ANDROID_VERSION_UNSUPPORTED -> NeonRose
        CapabilityAvailability.SERVICE_DISABLED -> NeonRose
        CapabilityAvailability.UNAVAILABLE_TO_NORMAL_APP -> ElectricPurple
        CapabilityAvailability.DISABLED -> Color(0xFF64748B)
    }

    val categoryColor = getCategoryColor(capability.category)
    val categoryIcon = getCategoryIcon(capability.category)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize()
            .testTag("capability_card_${capability.id}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = ObsidianSurface
        ),
        border = BorderStroke(
            1.dp,
            if (isExpanded) categoryColor.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header Row: Category Badge + Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Category Chip with Icon
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = categoryColor.copy(alpha = 0.15f),
                    border = BorderStroke(0.5.dp, categoryColor.copy(alpha = 0.35f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            imageVector = categoryIcon,
                            contentDescription = null,
                            tint = categoryColor,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = capability.category.displayName,
                            style = MaterialTheme.typography.labelSmall,
                            color = categoryColor,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.sp
                        )
                    }
                }

                // Availability Status Indicator Pill
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = availabilityColor.copy(alpha = 0.15f),
                    border = BorderStroke(0.5.dp, availabilityColor.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        val pulseTransition = rememberInfiniteTransition(label = "Status dot pulse")
                        val dotAlpha by pulseTransition.animateFloat(
                            initialValue = 0.5f,
                            targetValue = 1.0f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(900, easing = LinearEasing),
                                repeatMode = RepeatMode.Reverse
                            ),
                            label = "dotAlpha"
                        )

                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(availabilityColor.copy(alpha = if (capability.availability == CapabilityAvailability.AVAILABLE) dotAlpha else 1f))
                        )
                        Text(
                            text = capability.availability.label,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = availabilityColor,
                            fontSize = 10.5.sp
                        )
                    }
                }
            }

            // Title & Monospace ID
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = capability.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 15.sp
                )
                Text(
                    text = capability.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }

            // Required Permissions Chips
            if (capability.requiredPermissions.isNotEmpty()) {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = NeonAmber,
                        modifier = Modifier.size(12.dp)
                    )
                    capability.requiredPermissions.forEach { perm ->
                        val shortName = perm.substringAfterLast(".")
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = ObsidianSurfaceVariant,
                            border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                        ) {
                            Text(
                                text = shortName,
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            // Action Controls Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Test Action Button
                    Button(
                        onClick = onTestClick,
                        enabled = !isBusy,
                        modifier = Modifier
                            .heightIn(min = 40.dp)
                            .testTag("test_btn_${capability.id}"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonCyan,
                            contentColor = ObsidianBg,
                            disabledContainerColor = ObsidianSurfaceVariant.copy(alpha = 0.5f),
                            disabledContentColor = Color.Gray
                        ),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)
                    ) {
                        if (isBusy) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(14.dp),
                                strokeWidth = 2.dp,
                                color = ObsidianBg
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Testing...", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Test", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Grant Permission Button when missing
                    if (capability.availability == CapabilityAvailability.PERMISSION_REQUIRED) {
                        OutlinedButton(
                            onClick = onOpenSettings,
                            modifier = Modifier.heightIn(min = 40.dp),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = NeonAmber
                            ),
                            border = BorderStroke(1.dp, NeonAmber.copy(alpha = 0.6f)),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Grant", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Expand / Collapse Details Button
                TextButton(
                    onClick = { isExpanded = !isExpanded },
                    modifier = Modifier.heightIn(min = 40.dp),
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = NeonCyan
                    )
                ) {
                    Text(
                        if (isExpanded) "Hide Details" else "Details",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Icon(
                        if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            // Expandable Execution Result & Technical Specification Panel
            AnimatedVisibility(visible = isExpanded || lastResult != null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(ObsidianBg)
                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Last Execution Result Box
                    if (lastResult != null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = if (lastResult.success) Icons.Default.CheckCircle else Icons.Default.Cancel,
                                    contentDescription = null,
                                    tint = if (lastResult.success) NeonEmerald else NeonRose,
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = if (lastResult.success) "SUCCESS" else "FAILED",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = if (lastResult.success) NeonEmerald else NeonRose
                                )
                                Text(
                                    text = "(${lastResult.durationMs}ms)",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            IconButton(
                                onClick = {
                                    val copyText = lastResult.data?.toString() ?: lastResult.errorMessage ?: "Result"
                                    onCopyResult("Execution Result", copyText)
                                },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "Copy result",
                                    tint = NeonCyan,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }

                        // Payload Output
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(ObsidianSurfaceVariant)
                                .padding(8.dp)
                        ) {
                            Text(
                                text = if (lastResult.success) {
                                    lastResult.data?.toString() ?: "Empty payload response"
                                } else {
                                    "Error: ${lastResult.errorMessage ?: lastResult.errorCode?.name ?: "Unknown failure"}"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = if (lastResult.success) MaterialTheme.colorScheme.onSurface else CrimsonText,
                                lineHeight = 15.sp
                            )
                        }
                    }

                    // Metadata Technical Attributes
                    if (isExpanded) {
                        if (lastResult != null) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                        }
                        TechMetadataRow(label = "Capability ID", value = capability.id, isMonospace = true)
                        TechMetadataRow(label = "Minimum SDK", value = "Android API ${capability.minSdkVersion}+")
                        if (capability.hardwareFeature != null) {
                            TechMetadataRow(label = "Hardware Feature", value = capability.hardwareFeature, isMonospace = true)
                        }
                        TechMetadataRow(label = "Confirmation Policy", value = capability.confirmationLevel.name)
                        TechMetadataRow(label = "Implementation State", value = capability.implementationStatus)
                    }
                }
            }
        }
    }
}

@Composable
fun TechMetadataRow(label: String, value: String, isMonospace: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = FontWeight.Medium
        )
        Text(
            text = value,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.SemiBold,
            fontFamily = if (isMonospace) FontFamily.Monospace else FontFamily.Default
        )
    }
}

@Composable
fun EmptyFilterPlaceholder(searchQuery: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 48.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.SearchOff,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.size(42.dp)
            )
            Text(
                text = if (searchQuery.isNotEmpty()) "No capabilities matched \"$searchQuery\"" else "No capabilities in selected category",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

fun getCategoryIcon(category: CapabilityCategory): ImageVector {
    return when (category) {
        CapabilityCategory.AUDIO -> Icons.Default.GraphicEq
        CapabilityCategory.CAMERA -> Icons.Default.Videocam
        CapabilityCategory.MEDIA -> Icons.Default.PermMedia
        CapabilityCategory.FILE_SYSTEM -> Icons.Default.Folder
        CapabilityCategory.LOCATION -> Icons.Default.LocationOn
        CapabilityCategory.SENSORS -> Icons.Default.Sensors
        CapabilityCategory.BLUETOOTH -> Icons.Default.Bluetooth
        CapabilityCategory.NETWORK -> Icons.Default.Wifi
        CapabilityCategory.NOTIFICATIONS -> Icons.Default.Notifications
        CapabilityCategory.CONTACTS -> Icons.Default.Contacts
        CapabilityCategory.CALENDAR -> Icons.Default.Event
        CapabilityCategory.TELEPHONY -> Icons.Default.Phone
        CapabilityCategory.SMS -> Icons.Default.Sms
        CapabilityCategory.CLIPBOARD -> Icons.Default.ContentPaste
        CapabilityCategory.APPLICATION -> Icons.Default.Apps
        CapabilityCategory.DEVICE_INFO -> Icons.Default.Info
        CapabilityCategory.BATTERY -> Icons.Default.BatteryChargingFull
        CapabilityCategory.DISPLAY -> Icons.Default.Tv
        CapabilityCategory.HAPTICS -> Icons.Default.Vibration
        CapabilityCategory.BIOMETRICS -> Icons.Default.Fingerprint
        CapabilityCategory.NFC -> Icons.Default.Nfc
        CapabilityCategory.USB -> Icons.Default.Usb
        CapabilityCategory.INPUT_DEVICES -> Icons.Default.Keyboard
        CapabilityCategory.ACCESSIBILITY -> Icons.Default.Accessibility
        CapabilityCategory.SCREEN_CAPTURE -> Icons.Default.ScreenShare
        CapabilityCategory.WEB_BROWSER -> Icons.Default.Language
        CapabilityCategory.INTENTS -> Icons.Default.Send
        CapabilityCategory.SYSTEM_SETTINGS -> Icons.Default.Settings
        CapabilityCategory.BACKGROUND_WORK -> Icons.Default.Schedule
        CapabilityCategory.SYSTEM_EVENTS -> Icons.Default.NotificationsActive
    }
}

fun getCategoryColor(category: CapabilityCategory): Color {
    return when (category) {
        CapabilityCategory.AUDIO -> NeonCyan
        CapabilityCategory.CAMERA -> NeonRose
        CapabilityCategory.MEDIA -> NeonEmerald
        CapabilityCategory.FILE_SYSTEM -> NeonAmber
        CapabilityCategory.LOCATION -> ElectricViolet
        CapabilityCategory.SENSORS -> NeonCyan
        CapabilityCategory.BLUETOOTH -> ElectricPurple
        CapabilityCategory.NETWORK -> NeonCyan
        CapabilityCategory.NOTIFICATIONS -> NeonAmber
        CapabilityCategory.CONTACTS -> NeonEmerald
        CapabilityCategory.CALENDAR -> NeonCyan
        CapabilityCategory.TELEPHONY -> NeonRose
        CapabilityCategory.SMS -> NeonAmber
        CapabilityCategory.CLIPBOARD -> ElectricViolet
        CapabilityCategory.APPLICATION -> ElectricPurple
        CapabilityCategory.DEVICE_INFO -> NeonCyan
        CapabilityCategory.BATTERY -> NeonEmerald
        CapabilityCategory.DISPLAY -> ElectricViolet
        CapabilityCategory.HAPTICS -> NeonAmber
        CapabilityCategory.BIOMETRICS -> NeonCyan
        CapabilityCategory.NFC -> NeonCyan
        CapabilityCategory.USB -> NeonEmerald
        CapabilityCategory.INPUT_DEVICES -> ElectricViolet
        CapabilityCategory.ACCESSIBILITY -> NeonAmber
        CapabilityCategory.SCREEN_CAPTURE -> NeonRose
        CapabilityCategory.WEB_BROWSER -> NeonCyan
        CapabilityCategory.INTENTS -> ElectricViolet
        CapabilityCategory.SYSTEM_SETTINGS -> Color(0xFF94A3B8)
        CapabilityCategory.BACKGROUND_WORK -> NeonCyan
        CapabilityCategory.SYSTEM_EVENTS -> NeonAmber
    }
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText(label, text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, "$label copied to clipboard", Toast.LENGTH_SHORT).show()
}
