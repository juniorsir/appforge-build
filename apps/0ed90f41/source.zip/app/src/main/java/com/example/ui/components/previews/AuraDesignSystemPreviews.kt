package com.example.ui.components.previews

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.ui.components.buttons.AuraIconButton
import com.example.ui.components.buttons.AuraPrimaryButton
import com.example.ui.components.buttons.AuraSecondaryButton
import com.example.ui.components.buttons.AuraTertiaryButton
import com.example.ui.components.glass.AuraGlassCard
import com.example.ui.components.glass.AuraGlassSurface
import com.example.ui.components.status.AuraStatusBadge
import com.example.ui.components.status.AuraStatusDot
import com.example.ui.components.status.AuraStatusType
import com.example.ui.theme.AuraColors
import com.example.ui.theme.AuraDimensions
import com.example.ui.theme.AuraGlassLevel
import com.example.ui.theme.AuraShapes
import com.example.ui.theme.AuraSpacing
import com.example.ui.theme.AuraTypography
import com.example.ui.theme.MyApplicationTheme

/**
 * AURA ASSISTANT — Design System Showcase Preview
 * Demonstrates the unified monochrome liquid glass visual foundation.
 */
@Composable
fun AuraDesignSystemShowcase(
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AuraColors.Background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(AuraSpacing.LG)
                .widthIn(max = AuraSpacing.MaxContentWidth)
                .align(Alignment.TopCenter),
            verticalArrangement = Arrangement.spacedBy(AuraSpacing.LG)
        ) {
            // 1. App Title & Typography Showcase
            Column(verticalArrangement = Arrangement.spacedBy(AuraSpacing.XS)) {
                Text(
                    text = "AURA DESIGN SYSTEM",
                    style = AuraTypography.TechnicalLabel,
                    color = AuraColors.TextMuted
                )
                Text(
                    text = "Smoked Liquid Glass Foundation",
                    style = AuraTypography.AppTitle
                )
                Text(
                    text = "Phase 1: Tokenized black canvas, glass levels, typography, borders, and tactile primitives.",
                    style = AuraTypography.BodyMedium
                )
            }

            HorizontalDivider(color = AuraColors.BorderSubtle)

            // 2. Status Indicators & Badges
            Text("STATUS INDICATORS", style = AuraTypography.TechnicalLabel)
            Row(
                horizontalArrangement = Arrangement.spacedBy(AuraSpacing.SM),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AuraStatusBadge(label = "Ready", type = AuraStatusType.READY)
                AuraStatusBadge(label = "Active", type = AuraStatusType.ACTIVE)
                AuraStatusBadge(label = "Idle", type = AuraStatusType.IDLE)
                AuraStatusBadge(label = "Error", type = AuraStatusType.ERROR)
            }

            // 3. Glass Levels Hierarchy
            Text("LIQUID GLASS HIERARCHY", style = AuraTypography.TechnicalLabel)

            // Level 1: 4% fill
            AuraGlassSurface(
                modifier = Modifier.fillMaxWidth(),
                level = AuraGlassLevel.LEVEL_1,
                contentPadding = androidx.compose.foundation.layout.PaddingValues(AuraSpacing.MD)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Glass Level 1", style = AuraTypography.SectionTitle)
                        Text("Subtle baseline card (4% fill, 10% border)", style = AuraTypography.Caption)
                    }
                    AuraStatusDot(type = AuraStatusType.READY)
                }
            }

            // Level 2: 6% fill
            AuraGlassSurface(
                modifier = Modifier.fillMaxWidth(),
                level = AuraGlassLevel.LEVEL_2,
                contentPadding = androidx.compose.foundation.layout.PaddingValues(AuraSpacing.MD)
            ) {
                Column {
                    Text("Glass Level 2 (Standard)", style = AuraTypography.SectionTitle)
                    Text("Standard container surface (6% fill, 12% border)", style = AuraTypography.Caption)
                }
            }

            // Level 3: 8% fill
            AuraGlassSurface(
                modifier = Modifier.fillMaxWidth(),
                level = AuraGlassLevel.LEVEL_3,
                contentPadding = androidx.compose.foundation.layout.PaddingValues(AuraSpacing.MD)
            ) {
                Column {
                    Text("Glass Level 3 (Interactive)", style = AuraTypography.SectionTitle)
                    Text("Interactive panel surface (8% fill, 16% border)", style = AuraTypography.Caption)
                }
            }

            // Elevated: 11% fill
            AuraGlassSurface(
                modifier = Modifier.fillMaxWidth(),
                level = AuraGlassLevel.ELEVATED,
                contentPadding = androidx.compose.foundation.layout.PaddingValues(AuraSpacing.MD)
            ) {
                Column {
                    Text("Elevated Glass", style = AuraTypography.SectionTitle)
                    Text("Prominent card focus (11% fill, 22% border)", style = AuraTypography.Caption)
                }
            }

            // Active / Selected: 14% fill
            AuraGlassSurface(
                modifier = Modifier.fillMaxWidth(),
                level = AuraGlassLevel.ACTIVE,
                contentPadding = androidx.compose.foundation.layout.PaddingValues(AuraSpacing.MD)
            ) {
                Column {
                    Text("Active Glass State", style = AuraTypography.SectionTitle)
                    Text("Selected state (14% fill, 35% border)", style = AuraTypography.Caption)
                }
            }

            // 4. Interactive Glass Card with Spring Press
            Text("TACTILE GLASS CARD (CLICKABLE)", style = AuraTypography.TechnicalLabel)
            AuraGlassCard(
                onClick = {},
                modifier = Modifier.fillMaxWidth(),
                level = AuraGlassLevel.LEVEL_2
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Interactive Glass Card", style = AuraTypography.SectionTitle)
                        Text("Tap to test soft spring compression & active glow", style = AuraTypography.Caption)
                    }
                    AuraIconButton(
                        icon = Icons.Default.PlayArrow,
                        contentDescription = "Play Action",
                        onClick = {}
                    )
                }
            }

            // 5. Button Foundation
            Text("BUTTON FOUNDATION", style = AuraTypography.TechnicalLabel)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(AuraSpacing.MD),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AuraPrimaryButton(
                    onClick = {},
                    modifier = Modifier.weight(1f),
                    contentDescriptionText = "Start voice stream"
                ) {
                    Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.padding(end = 4.dp))
                    Text("Start Stream", style = AuraTypography.ButtonLabel, color = AuraColors.Black)
                }

                AuraSecondaryButton(
                    onClick = {},
                    modifier = Modifier.weight(1f),
                    contentDescriptionText = "Pause audio capture"
                ) {
                    Text("Pause", style = AuraTypography.ButtonLabel, color = AuraColors.White)
                }
            }

            // Icon Buttons & Tertiary Row
            Row(
                horizontalArrangement = Arrangement.spacedBy(AuraSpacing.SM),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AuraIconButton(
                    icon = Icons.Default.Settings,
                    contentDescription = "Open settings",
                    onClick = {}
                )
                AuraIconButton(
                    icon = Icons.Default.Refresh,
                    contentDescription = "Reset audio engine",
                    onClick = {}
                )
                AuraTertiaryButton(
                    onClick = {},
                    contentDescriptionText = "Diagnostics"
                ) {
                    Text("Diagnostics", style = AuraTypography.TechnicalLabel)
                }
            }

            // 6. Typography Scale
            Text("TYPOGRAPHY HIERARCHY", style = AuraTypography.TechnicalLabel)
            AuraGlassSurface(
                modifier = Modifier.fillMaxWidth(),
                level = AuraGlassLevel.LEVEL_1,
                contentPadding = androidx.compose.foundation.layout.PaddingValues(AuraSpacing.MD)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(AuraSpacing.XS)) {
                    Text("App Title: 24sp SemiBold", style = AuraTypography.AppTitle)
                    Text("Primary Metric: 48,000 Hz", style = AuraTypography.PrimaryValue)
                    Text("Section Title: 16sp SemiBold", style = AuraTypography.SectionTitle)
                    Text("Body Large: 15sp Regular text hierarchy.", style = AuraTypography.BodyLarge)
                    Text("Body Medium: 14sp Regular system information.", style = AuraTypography.BodyMedium)
                    Text("Technical Mono: PCM_16BIT / 16000Hz", style = AuraTypography.TechnicalMono)
                    Text("Caption: 12sp Regular secondary metadata.", style = AuraTypography.Caption)
                }
            }

            Spacer(modifier = Modifier.height(AuraSpacing.LG))
        }
    }
}

// Representative Width Previews
@Preview(name = "Phone Compact (360dp)", widthDp = 360, heightDp = 800)
@Composable
fun PreviewAuraDesignSystemCompact() {
    MyApplicationTheme {
        AuraDesignSystemShowcase()
    }
}

@Preview(name = "Phone Standard (411dp)", widthDp = 411, heightDp = 891)
@Composable
fun PreviewAuraDesignSystemNormal() {
    MyApplicationTheme {
        AuraDesignSystemShowcase()
    }
}

@Preview(name = "Tablet Expanded (700dp)", widthDp = 700, heightDp = 900)
@Composable
fun PreviewAuraDesignSystemExpanded() {
    MyApplicationTheme {
        AuraDesignSystemShowcase()
    }
}
