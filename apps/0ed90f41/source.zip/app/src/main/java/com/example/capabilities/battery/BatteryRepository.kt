package com.example.capabilities.battery

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.PowerManager
import com.example.capabilities.CapabilityResult
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

data class BatteryInfo(
    val percentage: Float,
    val isCharging: Boolean,
    val temperature: Float,
    val health: String,
    val powerSavingMode: Boolean
)

interface BatteryRepository {
    fun getBatteryInfo(): CapabilityResult<BatteryInfo>
}

class BatteryRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : BatteryRepository {
    override fun getBatteryInfo(): CapabilityResult<BatteryInfo> {
        return try {
            val batteryStatus: Intent? = IntentFilter(Intent.ACTION_BATTERY_CHANGED).let { ifilter ->
                context.registerReceiver(null, ifilter)
            }
            val status: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val isCharging: Boolean = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
            
            val level: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val percentage = level * 100 / scale.toFloat()
            
            val temp: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
            val temperature = temp / 10.0f
            
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            val powerSavingMode = powerManager.isPowerSaveMode
            
            CapabilityResult.Success(
                BatteryInfo(
                    percentage = percentage,
                    isCharging = isCharging,
                    temperature = temperature,
                    health = "Good", // Placeholder as real health requires specific OEM APIs sometimes
                    powerSavingMode = powerSavingMode
                )
            )
        } catch (e: Exception) {
            CapabilityResult.Error("Failed to get battery info", e)
        }
    }
}
