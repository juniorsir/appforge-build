package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.CompanionDatabase
import com.example.data.repository.AiResponseRepositoryImpl
import com.example.data.repository.ConversationRepositoryImpl
import com.example.data.repository.MockLlmProvider
import com.example.data.repository.PromptRepositoryImpl
import com.example.domain.model.*
import com.example.domain.repository.SessionRepository
import com.example.presentation.brain.ConversationEngineViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.take
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ConversationEngineTest {

    private lateinit var context: Context
    private lateinit var database: CompanionDatabase
    private lateinit var repositoryScope: CoroutineScope
    private lateinit var promptRepository: PromptRepositoryImpl
    private lateinit var aiResponseRepository: AiResponseRepositoryImpl
    private lateinit var conversationRepository: ConversationRepositoryImpl
    private lateinit var llmProvider: MockLlmProvider

    @Before
    fun setUp() {
        val dispatcher = UnconfinedTestDispatcher()
        Dispatchers.setMain(dispatcher)
        context = ApplicationProvider.getApplicationContext()
        // repositoryScope will be assigned in tests if needed, or we can use a basic one.
        // For Room, we use a basic unconfined one for repo initialization.
        repositoryScope = CoroutineScope(SupervisorJob() + dispatcher)
        
        // In-memory SQLite Database configuration
        database = Room.inMemoryDatabaseBuilder(
            context,
            CompanionDatabase::class.java
        ).allowMainThreadQueries().build()

        promptRepository = PromptRepositoryImpl(database.brainDao())
        aiResponseRepository = AiResponseRepositoryImpl()
        
        // Expose matching test scope
        conversationRepository = ConversationRepositoryImpl(database.brainDao(), repositoryScope)
        llmProvider = MockLlmProvider()
    }

    @After
    fun tearDown() {
        repositoryScope.cancel()
        database.close()
        Dispatchers.resetMain()
    }

    @Test
    fun testPromptRepositoryTemplateReplacement() {
        val template = "Context: {system_prompt}. Message: {user_message}."
        val variables = mapOf(
            "system_prompt" to "You are Aura",
            "user_message" to "Hello World"
        )
        val built = promptRepository.buildUserPrompt(template, variables)
        assertEquals("Context: You are Aura. Message: Hello World.", built)
    }

    @Test
    fun testMockLlmProviderStreamsCorrectEvents() = runTest {
        val config = LlmConfig(providerType = LlmProviderType.LOCAL)
        val sessionId = UUID.randomUUID().toString()
        val conversationId = UUID.randomUUID().toString()
        val messageId = UUID.randomUUID().toString()

        val events = llmProvider.streamResponse(
            config = config,
            systemPrompt = "System instruction",
            developerPrompt = "Formatting guidelines",
            messages = emptyList(),
            userMessage = "Hello",
            sessionId = sessionId,
            conversationId = conversationId,
            messageId = messageId
        ).toList()

        // Should start, emit partials, finalize, and end
        assertTrue(events.first() is AiResponseEvent.Start)
        assertTrue(events.last() is AiResponseEvent.End)

        val endEvent = events.last() as AiResponseEvent.End
        assertEquals(sessionId, endEvent.sessionId)
        assertEquals(conversationId, endEvent.conversationId)
        assertEquals(messageId, endEvent.messageId)
        assertTrue(endEvent.responseTimeMs >= 0)
    }

    @Test
    fun testMockLlmProviderHandlesMissingApiKeyForRemoteProviders() = runTest {
        val config = LlmConfig(providerType = LlmProviderType.GEMINI, apiKey = "") // empty key
        val sessionId = UUID.randomUUID().toString()
        val conversationId = UUID.randomUUID().toString()
        val messageId = UUID.randomUUID().toString()

        val events = llmProvider.streamResponse(
            config = config,
            systemPrompt = "System instruction",
            developerPrompt = "Formatting guidelines",
            messages = emptyList(),
            userMessage = "Hello",
            sessionId = sessionId,
            conversationId = conversationId,
            messageId = messageId
        ).toList()

        // Should emit Start, then directly fail with Error due to missing key
        assertTrue(events.size >= 2)
        assertTrue(events[0] is AiResponseEvent.Start)
        assertTrue(events[1] is AiResponseEvent.Error)
        
        val errorEvent = events[1] as AiResponseEvent.Error
        assertTrue(errorEvent.error.contains("Missing API key"))
    }

    @Test
    fun testConversationRepositoryTrimmingAndSummarization() = runTest {
        val conversation = conversationRepository.createNewConversation("Testing Thread")
        
        // Set maximum history size to 3 for testing
        conversationRepository.maxHistoryLength = 3

        // Insert 4 messages
        for (i in 1..4) {
            val msg = BrainMessage(
                id = "msg-$i",
                conversationId = conversation.id,
                role = if (i % 2 == 0) LlmMessage.Role.USER else LlmMessage.Role.ASSISTANT,
                content = "Test message content $i",
                timestamp = System.currentTimeMillis() + (i * 10)
            )
            conversationRepository.addMessage(msg)
        }

        // Get the current messages inside the conversation
        val currentMessages = conversationRepository.getMessages(conversation.id)
        
        // Because the limit is 3, inserting 4 messages should have triggered trimming and summarization.
        // The first message is replaced by a single memory summary message, and the kept messages (length 3) should remain.
        // Total messages should be: 1 summary message + 3 kept messages = 4 messages.
        assertEquals(4, currentMessages.size)
        assertEquals(LlmMessage.Role.SYSTEM, currentMessages[0].role)
        assertTrue(currentMessages[0].content.contains("[Context Memory Summary]"))
        assertEquals("msg-2", currentMessages[1].id)
        assertEquals("msg-3", currentMessages[2].id)
        assertEquals("msg-4", currentMessages[3].id)
    }

    @Test
    fun testViewModelOrchestrasFullStreamingLifecycle() = runTest {
        Dispatchers.setMain(UnconfinedTestDispatcher(testScheduler))
        // Create active conversation explicitly
        val conversation = conversationRepository.createNewConversation("Test Live Session")

        // Create matching mock session repo
        val mockSessionRepo = object : SessionRepository {
            override val currentSession: StateFlow<SessionData> = kotlinx.coroutines.flow.MutableStateFlow(
                SessionData("mock-session", "mock-conv", "mock-device")
            ).asStateFlow()

            override suspend fun createNewSession(): SessionData {
                return SessionData("mock-session", "mock-conv", "mock-device")
            }

            override fun getDeviceId(): String = "mock-device"
            override fun getUserIdPlaceholder(): String = "local-user-999"
        }

        val viewModel = ConversationEngineViewModel(
            conversationRepository = conversationRepository,
            promptRepository = promptRepository,
            llmProvider = llmProvider,
            aiResponseRepository = aiResponseRepository,
            sessionRepository = mockSessionRepo
        )

        // Collect flows to trigger stateIn with SharingStarted.WhileSubscribed
        val collectJob1 = launch(UnconfinedTestDispatcher(testScheduler)) {
            viewModel.activeConversation.collect {}
        }
        val collectJob2 = launch(UnconfinedTestDispatcher(testScheduler)) {
            viewModel.messages.collect {}
        }

        // Give UI thread a breath to settle active conversation creation
        testScheduler.advanceUntilIdle()
        val currentConv = viewModel.activeConversation.value
        assertNotNull(currentConv)

        // Set config to LOCAL to avoid API key check error in MockLlmProvider
        viewModel.updateConfig(com.example.domain.model.LlmConfig(providerType = com.example.domain.model.LlmProviderType.LOCAL, apiKey = "mock-key"))

        // Initiate stream
        viewModel.startGeneration("Hello")
        
        // Wait for flow to complete. Room uses a background thread, so we must wait
        // for the state to change rather than just advancing the virtual clock.
        val state = viewModel.generationState.first { it == GenerationState.SUCCESS || it == GenerationState.ERROR || it == GenerationState.CANCELLED }
        
        assertEquals(GenerationState.SUCCESS, state)
        assertTrue(viewModel.streamingResponse.value.contains("powered by the LOCAL Integration Module") || viewModel.streamingResponse.value.contains("Aura"))

        // Assert user and assistant messages have been added to the database
        val history = conversationRepository.getMessages(conversation.id)
        assertEquals(2, history.size)
        assertEquals(LlmMessage.Role.USER, history[0].role)
        assertEquals(LlmMessage.Role.ASSISTANT, history[1].role)
        
        collectJob1.cancel()
        collectJob2.cancel()
    }
}
