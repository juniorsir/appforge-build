package com.example.aios

import com.example.aios.core.*
import com.example.aios.planning.*
import com.example.aios.communication.*
import com.example.aios.workflows.*
import com.example.aios.scheduler.*
import com.example.aios.observability.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class AiosTest {

    private lateinit var agentManager: AgentManager
    private lateinit var metricsTracker: MetricsTracker
    private lateinit var taskPlanner: TaskPlanner
    private lateinit var eventBus: EventBus
    private lateinit var workflowEngine: WorkflowEngine
    private lateinit var scheduler: Scheduler

    @Before
    fun setup() {
        agentManager = AgentManager()
        metricsTracker = MetricsTracker()
        taskPlanner = TaskPlanner(agentManager, metricsTracker)
        eventBus = EventBus()
        workflowEngine = WorkflowEngine(taskPlanner)
        scheduler = Scheduler(workflowEngine)
    }

    @Test
    fun testAgentAutomaticRegistration() = runTest {
        val agents = agentManager.agentsFlow.first()
        assertEquals("Should register exactly 15 specialized agents", 15, agents.size)

        val codingAgent = agentManager.getAgentById("agent_coding")
        assertNotNull("Coding Agent must be registered", codingAgent)
        assertEquals("Coding Agent", codingAgent?.identity?.name)

        val plannerAgent = agentManager.getAgentById("agent_planner")
        assertNotNull("Planner Agent must be registered", plannerAgent)

        val devAgent = agentManager.getAgentById("agent_developer")
        assertNotNull("Developer Agent must be registered", devAgent)
    }

    @Test
    fun testAgentDiscoveryByCapability() = runTest {
        val nlpAgents = agentManager.discoverAgentsByCapability("NATURAL_LANGUAGE_PROCESSING")
        assertTrue("Should discover Conversation Agent for NLP", nlpAgents.any { it.identity.id == "agent_conversation" })

        val cameraAgents = agentManager.discoverAgentsByCapability("IMAGE_CLASSIFICATION")
        assertTrue("Should discover Vision Agent for visual capabilities", cameraAgents.any { it.identity.id == "agent_vision" })
    }

    @Test
    fun testGoalPlanningAndDecomposition() = runTest {
        val goal = taskPlanner.planAndExecute("develop dynamic databases")
        
        assertEquals(GoalStatus.COMPLETED, goal.status)
        assertEquals("Should decompose code goal into exactly 3 subtasks", 3, goal.tasks.size)

        val designTask = goal.tasks[0]
        val writeTask = goal.tasks[1]
        val verifyTask = goal.tasks[2]

        assertEquals("Design System Architecture Blueprint", designTask.title)
        assertEquals("agent_planner", designTask.assignedAgentId)
        assertEquals(TaskStatus.COMPLETED, designTask.status)

        assertEquals("Compile Code Classes", writeTask.title)
        assertEquals("agent_coding", writeTask.assignedAgentId)
        assertTrue("writeTask must depend on designTask", writeTask.dependencies.contains(designTask.id))
        assertEquals(TaskStatus.COMPLETED, writeTask.status)

        assertEquals("Verify Compilation & Coverage", verifyTask.title)
        assertEquals("agent_developer", verifyTask.assignedAgentId)
        assertTrue("verifyTask must depend on writeTask", verifyTask.dependencies.contains(writeTask.id))
        assertEquals(TaskStatus.COMPLETED, verifyTask.status)
    }

    @Test
    fun testWorkflowEnginePreloads() = runTest {
        val list = workflowEngine.workflows.value
        assertEquals("Should preload 4 predefined workflows", 4, list.size)

        val morningWf = list.find { it.id == "morning_routine" }
        assertNotNull("Morning Routine workflow must exist", morningWf)
        assertEquals(3, morningWf?.stepGoals?.size)
    }

    @Test
    fun testEventBusBroadcast() = runTest {
        var eventReceived: AiosEvent? = null
        val job = launch {
            eventBus.events.collect { eventReceived = it }
        }

        val event = AiosEvent(topic = "TEST_ALARM", payload = "System Temperature: Normal")
        eventBus.publish(event)

        kotlinx.coroutines.delay(50)
        assertNotNull("Event bus must deliver published events", eventReceived)
        assertEquals("TEST_ALARM", eventReceived?.topic)
        assertEquals("System Temperature: Normal", eventReceived?.payload)
        job.cancel()
    }

    @Test
    fun testObservabilityMetricsAndAudit() = runTest {
        taskPlanner.planAndExecute("morning alarm")
        
        val auditLogs = metricsTracker.auditLogs.value
        assertTrue("Should log execution actions in audit trails", auditLogs.isNotEmpty())
        
        val startLog = auditLogs.find { it.action == "EXECUTION_START" }
        assertNotNull("Audit trail should capture execution start logs", startLog)
    }
}
