package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.SessionRepositoryImpl
import com.example.data.repository.SpeechRepositoryImpl
import com.example.data.repository.TranscriptRepositoryImpl
import com.example.domain.model.NetworkMessage
import com.example.domain.model.SessionState
import com.example.domain.model.Transcript
import com.example.domain.repository.SessionTranscriptRepository
import com.example.domain.repository.SpeechRepository
import com.example.domain.repository.WebSocketRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Before
import org.junit.After
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SttStreamingTest {

    private lateinit var context: Context
    private lateinit var mockWebSocketRepository: MockWebSocketRepository
    private lateinit var transcriptRepository: TranscriptRepositoryImpl
    private lateinit var mockSessionTranscriptRepository: MockSessionTranscriptRepository
    private lateinit var sessionRepository: SessionRepositoryImpl
    private lateinit var speechRepository: SpeechRepositoryImpl

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        mockWebSocketRepository = MockWebSocketRepository()
        transcriptRepository = TranscriptRepositoryImpl()
        mockSessionTranscriptRepository = MockSessionTranscriptRepository()
        sessionRepository = SessionRepositoryImpl(context)
        
        speechRepository = SpeechRepositoryImpl(
            webSocketRepository = mockWebSocketRepository,
            transcriptRepository = transcriptRepository,
            sessionTranscriptRepository = mockSessionTranscriptRepository,
            sessionRepository = sessionRepository
        )
    }

    @After
    fun tearDown() {
        kotlinx.coroutines.runBlocking {
            speechRepository.stopStt()
        }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun testStartSttTransitionsStateToListening() = runTest {
        assertEquals(SpeechRepository.RecognitionState.IDLE, speechRepository.recognitionState.value)
        speechRepository.startStt()
        assertEquals(SpeechRepository.RecognitionState.LISTENING, speechRepository.recognitionState.value)
        assertTrue(speechRepository.speechDurationMs.value >= 0)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun testSimulationProducesTranscripts() = runTest {
        speechRepository.isSimulationMode.value = true
        speechRepository.simulateMultiLanguage.value = false
        speechRepository.simulateNoise.value = false
        speechRepository.simulatePacketLoss.value = false

        speechRepository.startStt()
        
        // Let simulation run for some iterations
        val startHistoryCount = transcriptRepository.transcriptHistory.value.size
        
        // Wait or trigger fake delay, we can assert initial state
        assertNotNull(speechRepository.partialTranscript.value)
        
        speechRepository.stopStt()
        assertEquals(SpeechRepository.RecognitionState.IDLE, speechRepository.recognitionState.value)
    }

    @Test
    fun testConversationPreparationAndFormatting() = runTest {
        // Add fake transcripts to history
        val sessionId = sessionRepository.currentSession.value.sessionId
        val trans1 = Transcript(sessionId = sessionId, text = "Hello Aura  ", isFinal = true)
        val trans2 = Transcript(sessionId = sessionId, text = "  can you hear me?", isFinal = true)
        
        transcriptRepository.addTranscript(trans1)
        transcriptRepository.addTranscript(trans2)

        val request = speechRepository.prepareConversationRequest()
        assertNotNull(request)
        assertEquals(sessionId, request?.sessionId)
        val expectedRaw = "Hello Aura     can you hear me?"
        assertEquals(expectedRaw, request?.rawText)
        assertEquals(expectedRaw, request?.cleanedText)
        assertEquals("User: $expectedRaw", request?.formattedText)
    }

    @Test
    fun testNoiseSimulationConfidenceLowering() = runTest {
        speechRepository.isSimulationMode.value = true
        speechRepository.simulateNoise.value = true
        
        val sessionId = "session-noise-1"
        val transcript = Transcript(
            sessionId = sessionId,
            text = "Hello [cough] Aura",
            isFinal = true,
            confidence = 0.78
        )
        
        transcriptRepository.addTranscript(transcript)
        assertEquals(1, transcriptRepository.transcriptHistory.value.size)
        assertEquals(0.78, transcriptRepository.transcriptHistory.value.first().confidence, 0.01)
    }

    // --- MOCK STUBS FOR ISOLATED PIPELINE UNIT TESTING ---

    class MockWebSocketRepository : WebSocketRepository {
        private val _connectionState = MutableStateFlow(SessionState.ConnectionState.CONNECTED)
        override val connectionState: StateFlow<SessionState.ConnectionState> = _connectionState.asStateFlow()

        private val _incomingMessages = MutableSharedFlow<NetworkMessage>()
        override val incomingMessages: SharedFlow<NetworkMessage> = _incomingMessages.asSharedFlow()

        private val _incomingRawMessages = MutableSharedFlow<String>()
        override val incomingRawMessages: SharedFlow<String> = _incomingRawMessages.asSharedFlow()

        override val latencyMs = MutableStateFlow(12L)
        override val bytesSent = MutableStateFlow(1024L)
        override val bytesReceived = MutableStateFlow(2048L)
        override val queueSize = MutableStateFlow(0)
        override val retryCount = MutableStateFlow(0)
        override val connectionLogs = MutableStateFlow(listOf("Connected to Mock"))
        override val lastFailureReason = MutableStateFlow<String?>(null)
        override val sessionId = MutableStateFlow<String?>("mock-session-id")
        override val lastConnectedAt = MutableStateFlow<Long?>(1000L)
        override val activeUrlFlow = MutableStateFlow("ws://127.0.0.1:8000/ws")

        var lastSentMessage: NetworkMessage? = null

        override suspend fun connect(url: String) {
            _connectionState.value = SessionState.ConnectionState.CONNECTED
        }

        override suspend fun disconnect() {
            _connectionState.value = SessionState.ConnectionState.DISCONNECTED
        }

        override suspend fun sendMessage(message: NetworkMessage) {
            lastSentMessage = message
        }

        override suspend fun sendRaw(text: String): Boolean {
            return true
        }

        override fun clearLogs() {}
        override fun addLog(entry: String) {}
    }

    class MockSessionTranscriptRepository : SessionTranscriptRepository {
        private val storage = mutableMapOf<String, MutableList<Transcript>>()

        override fun getTranscriptsForSession(sessionId: String): StateFlow<List<Transcript>> {
            val list = storage.getOrPut(sessionId) { mutableListOf() }
            return MutableStateFlow(list.toList()).asStateFlow()
        }

        override suspend fun saveTranscript(transcript: Transcript) {
            storage.getOrPut(transcript.sessionId) { mutableListOf() }.add(transcript)
        }

        override suspend fun deleteTranscriptsForSession(sessionId: String) {
            storage.remove(sessionId)
        }
    }
}
