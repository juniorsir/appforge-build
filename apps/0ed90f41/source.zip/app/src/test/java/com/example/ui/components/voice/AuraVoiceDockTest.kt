package com.example.ui.components.voice

import androidx.compose.ui.test.assertContentDescriptionEquals
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import com.example.ui.theme.MyApplicationTheme
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AuraVoiceDockTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun `media controls render compact secondary controls and handle click interactions`() {
        var micClicked = false
        var videoClicked = false

        composeTestRule.setContent {
            MyApplicationTheme {
                AuraMediaControls(
                    micState = AuraMicState.ENABLED,
                    videoState = AuraVideoState.DISABLED,
                    onMicClick = { micClicked = true },
                    onVideoClick = { videoClicked = true }
                )
            }
        }

        // Verify group exists
        composeTestRule.onNodeWithTag("aura_media_controls").assertExists()

        // Verify secondary controls exist
        composeTestRule.onNodeWithTag("mic_control").assertExists()
        composeTestRule.onNodeWithTag("video_control").assertExists()

        // Verify semantics
        composeTestRule.onNodeWithTag("mic_control").assertContentDescriptionEquals("Microphone on. Tap to mute")
        composeTestRule.onNodeWithTag("video_control").assertContentDescriptionEquals("Camera off. Tap to turn on")

        // Verify labels
        composeTestRule.onNodeWithText("MIC", useUnmergedTree = true).assertExists()
        composeTestRule.onNodeWithText("CAM", useUnmergedTree = true).assertExists()
        composeTestRule.onNodeWithText("ON", useUnmergedTree = true).assertExists()
        composeTestRule.onNodeWithText("OFF", useUnmergedTree = true).assertExists()

        // Test clicks
        composeTestRule.onNodeWithTag("mic_control").performClick()
        assertTrue(micClicked)

        composeTestRule.onNodeWithTag("video_control").performClick()
        assertTrue(videoClicked)
    }

    @Test
    fun `voice dock displays dominant primary control and compact secondary controls`() {
        var primaryClicked = false
        var micClicked = false
        var cameraClicked = false

        composeTestRule.setContent {
            MyApplicationTheme {
                AuraVoiceDock(
                    voiceState = AuraVoiceState.LISTENING,
                    isCameraEnabled = true,
                    onMicClick = { micClicked = true },
                    onCameraClick = { cameraClicked = true },
                    onPrimaryVoiceClick = { primaryClicked = true }
                )
            }
        }

        // Primary voice control dominates
        composeTestRule.onNodeWithTag("primary_voice_control").assertExists()
        composeTestRule.onNodeWithTag("voice_dock_label", useUnmergedTree = true).assertExists()
        composeTestRule.onNodeWithText("LISTENING...", useUnmergedTree = true).assertExists()

        // Secondary media controls are grouped together
        composeTestRule.onNodeWithTag("aura_media_controls").assertExists()
        composeTestRule.onNodeWithTag("mic_control").assertExists()
        composeTestRule.onNodeWithTag("video_control").assertExists()

        // Perform primary action
        composeTestRule.onNodeWithTag("primary_voice_control").performClick()
        assertTrue(primaryClicked)

        // Perform secondary action
        composeTestRule.onNodeWithTag("mic_control").performClick()
        assertTrue(micClicked)

        composeTestRule.onNodeWithTag("video_control").performClick()
        assertTrue(cameraClicked)
    }
}
