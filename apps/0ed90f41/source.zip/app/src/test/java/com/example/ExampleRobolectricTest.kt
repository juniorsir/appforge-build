package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.audio.AudioCaptureEngine
import com.example.domain.model.AudioCaptureState
import com.example.presentation.dashboard.DashboardViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("AI Companion", appName)
  }

  @Test
  fun `verify audio capture state initialization has safe defaults`() {
    val state = AudioCaptureState()
    assertFalse(state.isRecording)
    assertFalse(state.isPaused)
    assertEquals(16000, state.sampleRate)
    assertEquals(0, state.bufferSize)
    assertEquals(0.0, state.rms, 0.0)
    assertNull(state.error)
  }

  @OptIn(ExperimentalCoroutinesApi::class)
  @Test
  fun `verify state transition updates in audio capture state`() {
    val state = AudioCaptureState(
      isRecording = true,
      isPaused = true,
      sampleRate = 16000,
      bufferSize = 1024,
      rms = 230.5,
      error = "Focus lost"
    )
    assertTrue(state.isRecording)
    assertTrue(state.isPaused)
    assertEquals(1024, state.bufferSize)
    assertEquals(230.5, state.rms, 0.0)
    assertEquals("Focus lost", state.error)
  }
}
