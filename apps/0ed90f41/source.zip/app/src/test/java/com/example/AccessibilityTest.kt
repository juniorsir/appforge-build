package com.example

import com.example.accessibility.AccessibilityRepository
import com.example.accessibility.models.AccessibilityEventModel
import com.example.accessibility.models.AccessibilityNodeModel
import com.example.accessibility.models.AccessibilityServiceStatus
import com.example.accessibility.models.GestureRequestModel
import com.example.presentation.accessibility.AccessibilityViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AccessibilityTest {

    private lateinit var mockRepository: MockAccessibilityRepository
    private lateinit var viewModel: AccessibilityViewModel

    @Before
    fun setup() {
        mockRepository = MockAccessibilityRepository()
        viewModel = AccessibilityViewModel(mockRepository)
    }

    @Test
    fun `verify initial state of accessibility viewmodel`() {
        assertFalse(viewModel.serviceStatus.value.isEnabled)
        assertEquals(0, viewModel.recentEvents.value.size)
        assertEquals(0, viewModel.logs.value.size)
        assertEquals("", viewModel.searchQueryText.value)
    }

    @Test
    fun `verify updating search query propagates to state`() {
        viewModel.updateSearchQuery("test_button")
        assertEquals("test_button", viewModel.searchQueryText.value)
    }

    @Test
    fun `verify local click trigger dispatches to repository`() = runTest {
        viewModel.triggerLocalClick(250f, 600f)
        assertEquals(1, mockRepository.triggeredGestures.size)
        val gesture = mockRepository.triggeredGestures.first()
        assertEquals("CLICK", gesture.type)
        assertEquals(250f, gesture.startX)
        assertEquals(600f, gesture.startY)
    }

    @Test
    fun `verify local swipe trigger dispatches to repository`() = runTest {
        viewModel.triggerLocalSwipe(100f, 800f, 100f, 200f)
        assertEquals(1, mockRepository.triggeredGestures.size)
        val gesture = mockRepository.triggeredGestures.first()
        assertEquals("SWIPE", gesture.type)
        assertEquals(100f, gesture.startX)
        assertEquals(800f, gesture.startY)
        assertEquals(100f, gesture.endX)
        assertEquals(200f, gesture.endY)
    }

    @Test
    fun `verify manual inspect screen loads elements into node tree`() = runTest {
        viewModel.inspectActiveScreen()
        assertEquals(1, viewModel.nodeTree.value.size)
        val rootNode = viewModel.nodeTree.value.first()
        assertEquals("com.android.launcher", rootNode.viewId)
        assertEquals("HomeScreen", rootNode.text)
    }

    // A robust, mock implementation of the repository for clean unit test isolation
    class MockAccessibilityRepository : AccessibilityRepository {
        private val _serviceStatus = MutableStateFlow(AccessibilityServiceStatus())
        override val serviceStatus: StateFlow<AccessibilityServiceStatus> = _serviceStatus.asStateFlow()

        private val _recentEvents = MutableStateFlow<List<AccessibilityEventModel>>(emptyList())
        override val recentEvents: StateFlow<List<AccessibilityEventModel>> = _recentEvents.asStateFlow()

        private val _logs = MutableStateFlow<List<String>>(emptyList())
        override val logs: StateFlow<List<String>> = _logs.asStateFlow()

        val triggeredGestures = mutableListOf<GestureRequestModel>()

        override fun triggerGesture(gesture: GestureRequestModel, onComplete: (Boolean) -> Unit) {
            triggeredGestures.add(gesture)
            onComplete(true)
        }

        override fun getFullNodeTree(): List<AccessibilityNodeModel> {
            return listOf(
                AccessibilityNodeModel(
                    text = "HomeScreen",
                    contentDescription = "Launcher Home Screen",
                    viewId = "com.android.launcher",
                    className = "android.widget.FrameLayout",
                    isClickable = false,
                    isScrollable = false,
                    isEditable = false,
                    isFocused = true,
                    bounds = "[0,0][1440,2560]"
                )
            )
        }

        override fun searchNodes(text: String?, contentDescription: String?, viewId: String?): List<AccessibilityNodeModel> {
            return getFullNodeTree()
        }

        override fun clickNodeByText(text: String, onComplete: (Boolean) -> Unit) {
            onComplete(true)
        }

        override fun performScroll(forward: Boolean, onComplete: (Boolean) -> Unit) {
            onComplete(true)
        }

        override fun addLog(message: String) {
            _logs.value = listOf(message) + _logs.value
        }

        override fun addEvent(event: AccessibilityEventModel) {
            _recentEvents.value = listOf(event) + _recentEvents.value
        }
    }
}
