package com.example.ui.components.diagnostics

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import com.example.ui.theme.MyApplicationTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AuraAudioDiagnosticsTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun `audio status mappings verify active state display and metrics`() {
        var startClicked = false
        var pauseClicked = false
        var stopClicked = false
        var restartClicked = false

        composeTestRule.setContent {
            MyApplicationTheme {
                AuraAudioDiagnosticsCard(
                    status = AuraAudioStatus.ACTIVE,
                    sampleRate = 16000,
                    bufferSize = 640,
                    rms = 5000.0,
                    errorMessage = null,
                    hasPermission = true,
                    onStartClick = { startClicked = true },
                    onPauseClick = { pauseClicked = true },
                    onStopClick = { stopClicked = true },
                    onRestartClick = { restartClicked = true }
                )
            }
        }

        // Check header title and tag
        composeTestRule.onNodeWithText("AUDIO DIAGNOSTICS").assertExists()
        composeTestRule.onNodeWithTag("audio_telemetry_card").assertExists()

        // Check telemetry pills
        composeTestRule.onNodeWithText("16.0 kHz").assertExists()
        composeTestRule.onNodeWithText("640 B").assertExists()
        composeTestRule.onNodeWithText("1-CH PCM").assertExists()

        // Test action clicks
        composeTestRule.onNodeWithTag("audio_pause_button").performClick()
        assertTrue(pauseClicked)

        composeTestRule.onNodeWithTag("audio_stop_button").performClick()
        assertTrue(stopClicked)

        composeTestRule.onNodeWithTag("audio_restart_button").performClick()
        assertTrue(restartClicked)
    }

    @Test
    fun `audio diagnostics displays error banner when error provided`() {
        composeTestRule.setContent {
            MyApplicationTheme {
                AuraAudioDiagnosticsCard(
                    status = AuraAudioStatus.ERROR,
                    sampleRate = 16000,
                    bufferSize = 0,
                    rms = 0.0,
                    errorMessage = "AudioRecord initialization failed",
                    hasPermission = true,
                    onStartClick = {},
                    onPauseClick = {},
                    onStopClick = {},
                    onRestartClick = {}
                )
            }
        }

        composeTestRule.onNodeWithText("ERROR: AudioRecord initialization failed").assertExists()
    }

    @Test
    fun `audio status enum properties verify accurate technical tags`() {
        assertEquals("ACTIVE", AuraAudioStatus.ACTIVE.tag)
        assertEquals("IDLE", AuraAudioStatus.IDLE.tag)
        assertEquals("PAUSED", AuraAudioStatus.PAUSED.tag)
        assertEquals("NO PERMISSION", AuraAudioStatus.NO_PERMISSION.tag)
        assertEquals("UNAVAILABLE", AuraAudioStatus.UNAVAILABLE.tag)
        assertEquals("ERROR", AuraAudioStatus.ERROR.tag)
    }
}
