package com.example.capabilities

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.capabilities.core.*
import com.example.capabilities.permissions.PermissionManager
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class CapabilityRegistryTest {

    private lateinit var context: Context
    private lateinit var permissionManager: PermissionManager
    private lateinit var gateway: CapabilityGateway

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        permissionManager = PermissionManager(context)
        gateway = CapabilityGateway(context, permissionManager)
    }

    @Test
    fun testCapabilityErrorCodeValues() {
        assertEquals(13, CapabilityErrorCode.values().size)
        assertTrue(CapabilityErrorCode.values().contains(CapabilityErrorCode.PERMISSION_REQUIRED))
        assertTrue(CapabilityErrorCode.values().contains(CapabilityErrorCode.HARDWARE_UNAVAILABLE))
        assertTrue(CapabilityErrorCode.values().contains(CapabilityErrorCode.UNAVAILABLE_TO_NORMAL_APP))
    }

    @Test
    fun testCapabilityCategoryCoverage() {
        val categories = CapabilityCategory.values()
        assertTrue(categories.size >= 25)
        assertTrue(categories.contains(CapabilityCategory.AUDIO))
        assertTrue(categories.contains(CapabilityCategory.CAMERA))
        assertTrue(categories.contains(CapabilityCategory.LOCATION))
        assertTrue(categories.contains(CapabilityCategory.SENSORS))
        assertTrue(categories.contains(CapabilityCategory.BLUETOOTH))
        assertTrue(categories.contains(CapabilityCategory.NETWORK))
        assertTrue(categories.contains(CapabilityCategory.BATTERY))
        assertTrue(categories.contains(CapabilityCategory.DISPLAY))
        assertTrue(categories.contains(CapabilityCategory.HAPTICS))
        assertTrue(categories.contains(CapabilityCategory.BIOMETRICS))
        assertTrue(categories.contains(CapabilityCategory.USB))
        assertTrue(categories.contains(CapabilityCategory.INPUT_DEVICES))
        assertTrue(categories.contains(CapabilityCategory.APPLICATION))
        assertTrue(categories.contains(CapabilityCategory.INTENTS))
        assertTrue(categories.contains(CapabilityCategory.SYSTEM_SETTINGS))
    }

    @Test
    fun testGatewayExecutionSuccess() = runTest {
        val def = CapabilityDefinition(
            id = "test_cap",
            name = "Test Capability",
            description = "Test Description",
            category = CapabilityCategory.DEVICE_INFO,
            minSdkVersion = 21
        )
        val request = CapabilityRequest(capabilityId = "test_cap")
        val response = gateway.execute(def, request) {
            "Sample output data"
        }

        assertTrue(response.success)
        assertEquals("Sample output data", response.data)
        assertNull(response.errorCode)
        assertTrue(response.durationMs >= 0)
    }

    @Test
    fun testGatewayExecutionMinSdkFailure() = runTest {
        val def = CapabilityDefinition(
            id = "future_cap",
            name = "Future Capability",
            description = "Requires Android SDK 99",
            category = CapabilityCategory.DEVICE_INFO,
            minSdkVersion = 99
        )
        val request = CapabilityRequest(capabilityId = "future_cap")
        val response = gateway.execute(def, request) {
            "Should not execute"
        }

        assertFalse(response.success)
        assertEquals(CapabilityErrorCode.ANDROID_VERSION_UNSUPPORTED, response.errorCode)
    }

    @Test
    fun testGatewayExecutionMissingPermission() = runTest {
        val def = CapabilityDefinition(
            id = "perm_cap",
            name = "Protected Capability",
            description = "Requires non-granted permission",
            category = CapabilityCategory.CONTACTS,
            requiredPermissions = listOf("android.permission.BIND_NFC_SERVICE")
        )
        val request = CapabilityRequest(capabilityId = "perm_cap")
        val response = gateway.execute(def, request) {
            "Should not execute"
        }

        assertFalse(response.success)
        assertEquals(CapabilityErrorCode.PERMISSION_REQUIRED, response.errorCode)
    }

    @Test
    fun testPermissionManagerAppSettingsIntent() {
        val intent = permissionManager.createAppSettingsIntent()
        assertNotNull(intent)
        assertEquals(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, intent.action)
    }

    @Test
    fun testPermissionManagerAllDefinedPermissions() {
        val permissions = permissionManager.allDefinedPermissions
        assertTrue("Should define 40+ permissions, found ${permissions.size}", permissions.size >= 40)
        
        // Verify key capability categories are covered
        val categories = permissions.map { it.category }.distinct()
        assertTrue(categories.size >= 8)

        // Verify runtime permissions helper
        val runtimeToRequest = permissionManager.getRuntimePermissionsToRequest()
        assertNotNull(runtimeToRequest)
    }
}
