package com.example

import com.example.domain.model.AudioStreamMessage
import com.example.domain.model.AuthMessage
import com.example.domain.model.ErrorMessage
import com.example.domain.model.HelloMessage
import com.example.domain.model.NetworkMessage
import com.example.domain.model.PingMessage
import com.example.domain.model.PongMessage
import com.example.domain.model.sanitizeInput
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CommunicationFrameworkTest {

    private val json = Json {
        classDiscriminator = "type"
        ignoreUnknownKeys = true
    }

    @Test
    fun testHelloMessageSerialization() {
        val hello: NetworkMessage = HelloMessage(
            timestamp = 1718000000000L,
            sessionId = "session-test-id",
            deviceId = "device-xyz-123"
        )
        assertTrue(hello.validate())

        val jsonString = json.encodeToString(NetworkMessage.serializer(), hello)
        assertTrue(jsonString.contains("\"type\":\"HELLO\""))
        assertTrue(jsonString.contains("\"sessionId\":\"session-test-id\""))
        assertTrue(jsonString.contains("\"deviceId\":\"device-xyz-123\""))

        val decoded = json.decodeFromString(NetworkMessage.serializer(), jsonString)
        assertTrue(decoded is HelloMessage)
        val decodedHello = decoded as HelloMessage
        assertEquals("device-xyz-123", decodedHello.deviceId)
        assertEquals("session-test-id", decodedHello.sessionId)
    }

    @Test
    fun testAudioStreamMessageSerialization() {
        val audioMsg: NetworkMessage = AudioStreamMessage(
            timestamp = 1718000001000L,
            sessionId = "session-test-id",
            sequenceNumber = 42,
            dataBase64 = "U09VTkRfREFUQQ=="
        )
        assertTrue(audioMsg.validate())

        val jsonString = json.encodeToString(NetworkMessage.serializer(), audioMsg)
        assertTrue(jsonString.contains("\"type\":\"AUDIO_STREAM\""))
        assertTrue(jsonString.contains("\"sequenceNumber\":42"))

        val decoded = json.decodeFromString(NetworkMessage.serializer(), jsonString) as AudioStreamMessage
        assertEquals(42L, decoded.sequenceNumber)
        assertEquals("U09VTkRfREFUQQ==", decoded.dataBase64)
    }

    @Test
    fun testValidationRules() {
        // Invalid Hello message (blank device ID)
        val invalidHello = HelloMessage(
            timestamp = 1718000000000L,
            sessionId = "session-test-id",
            deviceId = "   "
        )
        assertFalse(invalidHello.validate())

        // Invalid Auth message (blank token)
        val invalidAuth = AuthMessage(
            timestamp = 1718000000000L,
            sessionId = "session-test-id",
            token = "",
            userId = "user-1"
        )
        assertFalse(invalidAuth.validate())

        // Invalid Ping message (negative timestamp)
        val invalidPing = PingMessage(
            timestamp = -10L,
            sessionId = "sess",
            pingId = "ping-123"
        )
        assertFalse(invalidPing.validate())
    }

    @Test
    fun testSanitizeInput() {
        val dirtyText = "Hello\u0000World\u001F!\n"
        val cleanText = sanitizeInput(dirtyText)
        assertEquals("HelloWorld!", cleanText)
    }
}
