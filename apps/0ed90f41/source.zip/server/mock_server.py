#!/usr/bin/env python3
"""
Termux AIOS Unified WebSocket & HTTP Server
Designed for local loopback (127.0.0.1:8000) on Android device.

Features:
- STEP 1 Diagnostic: Logs PID, bind address, port, interfaces
- STEP 2 HTTP Support: Intercepts plain HTTP GET requests and returns 200 OK JSON
- STEP 4 WebSocket: Accepts ws://127.0.0.1:8000/ws and ws://127.0.0.1:8000/
- STEP 6 Path Handling: Supports both /ws and / paths cleanly
- STEP 8 Protocol: Sends HELLO on connect, responds to PING with PONG, relays gestures/inspect

Requirements:
    pip install websockets
"""

import asyncio
from http import HTTPStatus
import json
import os
import sys
import time

try:
    import websockets
except ImportError as e:
    print(f"[ERROR] Could not import websockets: {e}")
    print("Run: pip install websockets")
    sys.exit(1)

HOST = "127.0.0.1"
PORT = 8000
CONNECTED_CLIENTS = set()

def get_ms():
    return int(time.time() * 1000)

async def handle_incoming_message(websocket, raw_data, session_state):
    try:
        data = json.loads(raw_data)
    except Exception as e:
        print(f"[{time.strftime('%X')}] [WARN] Invalid JSON packet: {e}")
        return

    msg_type = data.get("type", "UNKNOWN")
    session_id = data.get("sessionId", "termux-session")
    print(f"[{time.strftime('%X')}] [INCOMING] Type: {msg_type} (Session: {session_id})")

    # 1. Heartbeat PING -> PONG
    if msg_type == "PING":
        pong = {
            "type": "PONG",
            "timestamp": get_ms(),
            "sessionId": session_id,
            "pingId": data.get("pingId", "1"),
            "requestTimestamp": data.get("timestamp", get_ms())
        }
        await websocket.send(json.dumps(pong))
        return

    # 2. HELLO response if client sent HELLO
    if msg_type == "HELLO":
        print(f"[{time.strftime('%X')}] [HELLO] Received HELLO from client device: {data.get('deviceId', 'unknown')}")
        return

    # 3. Audio streaming frames
    if msg_type == "AUDIO_STREAM":
        session_state["audio_packets"] = session_state.get("audio_packets", 0) + 1
        if session_state["audio_packets"] % 50 == 1:
            print(f"\r[{time.strftime('%X')}] [AUDIO] Streaming active | Packets: {session_state['audio_packets']}", end="", flush=True)
        return

    if msg_type == "AUDIO_END":
        packets = session_state.get("audio_packets", 0)
        print(f"\n[{time.strftime('%X')}] [AUDIO] Stream ended. Total frames: {packets}")
        session_state["audio_packets"] = 0
        return

    # 4. Universal Relay: Forward all commands (APP_LIST, APP_LAUNCH, GESTURE, INSPECT, etc.)
    # and all results (APP_LIST_RESULT, APP_LAUNCH_RESULT, INSPECT_RESULT, etc.) to all other connected clients
    other_clients = [c for c in CONNECTED_CLIENTS if c != websocket]
    if other_clients:
        print(f"[{time.strftime('%X')}] [RELAY] >>> Relay {msg_type} to {len(other_clients)} client(s) <<<")
        for client in other_clients:
            try:
                await client.send(raw_data)
            except Exception as e:
                print(f"[{time.strftime('%X')}] [WARN] Relay {msg_type} failed: {e}")
    else:
        print(f"[{time.strftime('%X')}] [INFO] {msg_type} received, but no other clients connected.")
    return

async def ws_handler(websocket, *args):
    """Handles active WebSocket connections."""
    CONNECTED_CLIENTS.add(websocket)
    client_info = getattr(websocket, 'remote_address', '127.0.0.1')
    req_path = getattr(websocket, 'path', '/ws')
    print(f"\n[{time.strftime('%X')}] [CONNECTED] Client connected from {client_info} on path '{req_path}' (Total active: {len(CONNECTED_CLIENTS)})")

    session_state = {"audio_packets": 0}

    # Immediately send server greeting HELLO
    hello_greeting = {
        "type": "HELLO",
        "timestamp": get_ms(),
        "sessionId": "termux-session-" + str(int(time.time())),
        "clientName": "TermuxAIOS",
        "deviceId": "termux-localhost",
        "protocolVersion": "1.0"
    }
    await websocket.send(json.dumps(hello_greeting))
    print(f"[{time.strftime('%X')}] [SENT] Initial HELLO packet sent to client.")

    try:
        async for message in websocket:
            await handle_incoming_message(websocket, message, session_state)
    except websockets.exceptions.ConnectionClosed as e:
        print(f"\n[{time.strftime('%X')}] [DISCONNECTED] Connection closed: code={e.code}, reason={e.reason}")
    except Exception as e:
        print(f"\n[{time.strftime('%X')}] [SOCKET ERROR] {type(e).__name__}: {e}")
    finally:
        CONNECTED_CLIENTS.discard(websocket)
        print(f"[{time.strftime('%X')}] [DISCONNECTED] Client removed. Active remaining: {len(CONNECTED_CLIENTS)}")

def handle_http_or_ws_request(*args, **kwargs):
    """
    Hook called before WebSocket handshake.
    Supports both:
      - websockets >= 13 (asyncio API): process_request(connection, request)
      - websockets < 13 (legacy API):   process_request(path, request_headers)
    """
    try:
        if len(args) >= 2:
            arg1, arg2 = args[0], args[1]
            # Modern websockets (arg1 = ServerConnection, arg2 = Request)
            if hasattr(arg2, "headers") and hasattr(arg2, "path"):
                connection = arg1
                request = arg2
                path = request.path
                headers = request.headers
                upgrade = headers.get("Upgrade", "").lower()
                
                if "websocket" not in upgrade:
                    # HTTP request (e.g. Health Check from Android app or curl)
                    print(f"[{time.strftime('%X')}] [HTTP HEALTH CHECK] Path: '{path}' -> Responding HTTP 200 OK")
                    body = json.dumps({
                        "status": "ok",
                        "server": "termux-aios",
                        "bind": f"{HOST}:{PORT}",
                        "ws_endpoint": f"ws://{HOST}:{PORT}/ws",
                        "active_clients": len(CONNECTED_CLIENTS),
                        "timestamp": get_ms()
                    }) + "\n"
                    if hasattr(connection, "respond"):
                        return connection.respond(HTTPStatus.OK, body)
                    return None
                else:
                    print(f"[{time.strftime('%X')}] [WS HANDSHAKE] Upgrade request on path '{path}'")
                    return None
            else:
                # Legacy websockets (arg1 = path, arg2 = request_headers)
                path = str(arg1)
                headers = arg2
                upgrade = ""
                if hasattr(headers, "get"):
                    upgrade = headers.get("Upgrade", "").lower()
                elif hasattr(headers, "raw_items"):
                    for k, v in headers.raw_items():
                        if k.lower() == "upgrade":
                            upgrade = v.lower()

                if "websocket" not in upgrade:
                    print(f"[{time.strftime('%X')}] [HTTP HEALTH CHECK] Path: '{path}' -> Responding HTTP 200 OK")
                    response_body = json.dumps({
                        "status": "ok",
                        "server": "termux-aios",
                        "bind": f"{HOST}:{PORT}",
                        "ws_endpoint": f"ws://{HOST}:{PORT}/ws",
                        "active_clients": len(CONNECTED_CLIENTS),
                        "timestamp": get_ms()
                    }, indent=2).encode("utf-8")

                    resp_headers = [
                        ("Content-Type", "application/json"),
                        ("Content-Length", str(len(response_body))),
                        ("Access-Control-Allow-Origin", "*"),
                        ("Connection", "close")
                    ]
                    return HTTPStatus.OK, resp_headers, response_body
                else:
                    print(f"[{time.strftime('%X')}] [WS HANDSHAKE] Upgrade request on path '{path}'")
                    return None
    except Exception as e:
        print(f"[{time.strftime('%X')}] [WARN] Error in process_request: {e}")
        return None
    return None

async def main():
    pid = os.getpid()
    ws_version = getattr(websockets, "__version__", "unknown")
    print("==================================================")
    print("  TERMUX AIOS LOCALHOST SERVER")
    print(f"  PID:             {pid}")
    print(f"  Websockets Ver:  {ws_version}")
    print(f"  Bind Address:    {HOST}")
    print(f"  Port:            {PORT}")
    print(f"  HTTP Health:     http://{HOST}:{PORT}/")
    print(f"  WebSocket URL:   ws://{HOST}:{PORT}/ws")
    print(f"  Supported Paths: /ws, /")
    print("==================================================")
    print("[STATUS] Starting server loop...")

    try:
        # Check websockets library version compatibility for process_request
        server = await websockets.serve(
            ws_handler,
            HOST,
            PORT,
            process_request=handle_http_or_ws_request
        )
        print(f"[READY] Server successfully listening on {HOST}:{PORT}")
        print("[READY] Android app on same device can now connect directly.")
        await server.wait_closed()
    except OSError as e:
        print(f"\n[FATAL] Could not bind to {HOST}:{PORT}: {e}")
        if e.errno == 98 or "address already in use" in str(e).lower():
            print("Hint: Another process is already running on port 8000.")
            print("Run in Termux: fuser -k 8000/tcp  OR  kill -9 <PID>")
        sys.exit(1)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n[SHUTDOWN] Server stopped by user.")
