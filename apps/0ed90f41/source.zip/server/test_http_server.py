#!/usr/bin/env python3
"""
Step 2 — Minimal HTTP Loopback Test Server
No external dependencies required (uses Python standard library).

Usage in Termux:
    python test_http_server.py
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import time

HOST = "127.0.0.1"
PORT = 8000

class HealthCheckHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        print(f"[{time.strftime('%X')}] Received HTTP GET request for path: '{self.path}' from {self.client_address[0]}:{self.client_address[1]}")
        
        response_data = {
            "status": "ok",
            "service": "termux-http-loopback",
            "bind": f"{HOST}:{PORT}",
            "requested_path": self.path,
            "timestamp": int(time.time() * 1000)
        }
        
        body = json.dumps(response_data, indent=2).encode('utf-8')
        
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Connection', 'close')
        self.end_headers()
        self.wfile.write(body)
        print(f"[{time.strftime('%X')}] Responded HTTP 200 OK ({len(body)} bytes)")

    def log_message(self, format, *args):
        # Override default noisy stderr logging
        pass

def run():
    print("==================================================")
    print("  STEP 2 — HTTP LOOPBACK TEST SERVER")
    print(f"  Binding to: http://{HOST}:{PORT}")
    print("==================================================")
    server = HTTPServer((HOST, PORT), HealthCheckHandler)
    print(f"[READY] Listening on http://{HOST}:{PORT}/")
    print("Ready for Android App HTTP Health Check test.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[STOPPED] HTTP Server stopped.")

if __name__ == "__main__":
    run()
