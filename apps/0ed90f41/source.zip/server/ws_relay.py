#!/usr/bin/env python3
"""
Termux & proot/Ubuntu WebSocket Relay Server (ws_relay.py)
Binds to 127.0.0.1:8000 and transparently relays messages between ACAgent (proot) and the Aura Android app.

Supported Message Types:
  - HELLO, PING / PONG
  - AI_STREAM, AI_STREAM_RESULT
  - ACCESSIBILITY_GESTURE, ACCESSIBILITY_INSPECT, ACCESSIBILITY_INSPECT_RESULT
  - APP_LIST, APP_LAUNCH, APP_LIST_RESULT, APP_LAUNCH_RESULT
  - AUDIO_STREAM, AUDIO_END

Requirements:
  pip install websockets
"""

import sys
import os
import asyncio

# Import implementation from mock_server
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mock_server import (
    HOST,
    PORT,
    ws_handler,
    handle_http_or_ws_request,
    websockets
)

async def run_relay():
    print("==================================================")
    print("  ACAgent & Termux WebSocket Relay Server Active")
    print(f"  Listening on ws://{HOST}:{PORT}")
    print("==================================================")
    
    try:
        # Compatible with modern websockets (13+, 14+) and legacy versions
        async with websockets.serve(
            ws_handler,
            HOST,
            PORT,
            process_request=handle_http_or_ws_request
        ):
            print(f"[READY] WebSocket relay listening on ws://{HOST}:{PORT}")
            print("[READY] Relay active — forwarding messages between Android & Termux.")
            await asyncio.Future()  # run forever
    except OSError as e:
        print(f"\n[FATAL] Could not bind to {HOST}:{PORT}: {e}")
        if e.errno == 98 or "address already in use" in str(e).lower():
            print("Hint: Port 8000 is already in use. Terminate other process via:")
            print("  fuser -k 8000/tcp   OR   kill -9 <PID>")
        sys.exit(1)

def main():
    try:
        asyncio.run(run_relay())
    except KeyboardInterrupt:
        print("\n[STOPPED] Relay server stopped by user.")

if __name__ == "__main__":
    main()
