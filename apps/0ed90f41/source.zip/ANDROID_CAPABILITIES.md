# ANDROID CAPABILITIES ARCHITECTURE & REGISTRY SPECIFICATION

This document details the complete Android Capability Layer implemented in the application for Phase 14.

---

## 1. ARCHITECTURAL OVERVIEW

The Android Capability Subsystem provides a unified, secure, and typed gateway for interacting with Android platform hardware, system services, and device sensors.

```text
       ┌────────────────────────┐
       │   Termux AI Backend    │
       │ (JSON Capability Req)  │
       └───────────┬────────────┘
                   │
                   ▼
       ┌────────────────────────┐
       │ TermuxCapabilityBridge │
       └───────────┬────────────┘
                   │
                   ▼
       ┌────────────────────────┐
       │   CapabilityGateway    │ ───► PermissionManager (Runtime / Scoped)
       │  (Security & Direct Ops)  │ ───► Version & Hardware Validator
       └───────────┬────────────┘ ───► User Confirmation Check
                   │
                   ▼
       ┌────────────────────────┐
       │   CapabilityRegistry   │
       └───────────┬────────────┘
                   │
      ┌────────────┼──────────────────────────┬────────────────────────┐
      │            │                          │                        │
      ▼            ▼                          ▼                        ▼
Audio/Sound    Camera & Vision            Sensors & Motion        Storage & Media
(AudioRecord)  (CameraX / Analysis)       (SensorManager)         (SAF / Scoped Storage)
```

---

## 2. CAPABILITY MATRIX

| Capability ID | Name | Category | Implemented | Required Permissions | Android Requirement | Hardware Requirement | Security & Limitations | Test Status |
| :--- | :--- | :--- | :---: | :--- | :--- | :--- | :--- | :---: |
| `audio_record` | Microphone & Audio Capture | AUDIO | ✓ | `RECORD_AUDIO` | Android 8.0+ (API 26+) | `android.hardware.microphone` | 16kHz PCM streaming; AEC/NS/AGC auto-detected | Verified |
| `audio_output` | Speaker & Audio Output | AUDIO | ✓ | None | Android 8.0+ (API 26+) | Speaker / Earpiece | Routing between Speaker, Headset, Bluetooth SCO | Verified |
| `camera_camerax` | Camera & Image Analysis | CAMERA | ✓ | `CAMERA` | Android 8.0+ (API 26+) | `android.hardware.camera.any` | Lens selection, Torch toggle, ImageAnalysis stream | Verified |
| `media_gallery` | Media & Scoped Gallery | MEDIA | ✓ | Zero-perm PhotoPicker | Android 11+ (API 30+) | Internal / External Storage | Scoped storage MediaStore query, thumbnails | Verified |
| `file_storage` | File System & Documents | FILE_SYSTEM | ✓ | Direct Storage & SAF | Android 8.0+ (API 26+) | Storage | Direct filesystem (/sdcard) & All-Files access | Verified |
| `location_gps` | Location & GPS Services | LOCATION | ✓ | `ACCESS_FINE_LOCATION` | Android 8.0+ (API 26+) | `android.hardware.location` | Single-shot & continuous updates with accuracy | Verified |
| `sensors_motion` | Motion & Environmental Sensors | SENSORS | ✓ | None | Android 8.0+ (API 26+) | `android.hardware.sensor.accelerometer` | Auto-stops when inactive to conserve battery | Verified |
| `bluetooth_ble` | Bluetooth & BLE Manager | BLUETOOTH | ✓ | `BLUETOOTH_SCAN`, `CONNECT` | Android 12+ (API 31+) | `android.hardware.bluetooth` | Safe GATT abstraction and bonded devices listing | Verified |
| `network_status` | Network & Connectivity | NETWORK | ✓ | `ACCESS_NETWORK_STATE` | Android 8.0+ (API 26+) | Wi-Fi / Cellular Modem | NetworkCapabilities, bandwidth estimates, local IP | Verified |
| `notification_manager`| Notification System | NOTIFICATIONS | ✓ | `POST_NOTIFICATIONS` (API 33+) | Android 8.0+ (API 26+) | None | Notification channels, progress bars, actions | Verified |
| `contacts_provider` | Contacts Provider | CONTACTS | ✓ | `READ_CONTACTS` | Android 8.0+ (API 26+) | None | Name, phone numbers, and email address query | Verified |
| `calendar_provider` | Calendar & Events Provider | CALENDAR | ✓ | `READ_CALENDAR`, `WRITE_CALENDAR` | Android 8.0+ (API 26+) | None | CalendarContract event insertion and querying | Verified |
| `telephony_manager` | Telephony & SIM Status | TELEPHONY | ✓ | None | Android 8.0+ (API 26+) | `android.hardware.telephony` | SIM state, carrier name, dialer intent | Verified |
| `sms_manager` | SMS & Messaging Dispatcher | SMS | ✓ | `SEND_SMS` (if default) | Android 8.0+ (API 26+) | `android.hardware.telephony` | Intent composer fallback for non-default SMS app | Verified |
| `clipboard_manager` | Clipboard Manager | CLIPBOARD | ✓ | None | Android 8.0+ (API 26+) | None | Text read/write with MIME type validation | Verified |
| `application_manager`| Installed Apps Manager | APPLICATION | ✓ | None (with `<queries>`) | Android 11+ (API 30+) | None | Launcher intent resolution, version, target SDK | Verified |
| `device_info` | Device Hardware & OS Info | DEVICE_INFO | ✓ | None | Android 8.0+ (API 26+) | None | Build info, CPU ABIs, RAM metrics, storage | Verified |
| `battery_power` | Battery & Power Management | BATTERY | ✓ | None | Android 8.0+ (API 26+) | Battery | Level, charging technology, temperature, power saver | Verified |
| `display_manager` | Screen & Display Metrics | DISPLAY | ✓ | None | Android 8.0+ (API 26+) | Display | Resolution, density DPI, refresh rate, HDR | Verified |
| `haptics_vibration` | Haptics & Vibration Engine | HAPTICS | ✓ | `VIBRATE` | Android 8.0+ (API 26+) | Vibrator | Predefined haptic ticks, clicks, amplitude scaling | Verified |
| `biometrics_security`| Biometrics & Device Security | BIOMETRICS | ✓ | None | Android 8.0+ (API 26+) | Biometric Sensor | BiometricPrompt strong/weak/credential availability | Verified |
| `nfc_manager` | NFC & NDEF Controller | NFC | ✓ | `NFC` | Android 8.0+ (API 26+) | `android.hardware.nfc` | Tag discovery, NDEF push, adapter state | Verified |
| `usb_host` | USB Host & Peripherals | USB | ✓ | None | Android 8.0+ (API 26+) | `android.hardware.usb.host` | Attached USB devices, vendor/product IDs | Verified |
| `input_devices` | Input Devices & Gamepads | INPUT_DEVICES | ✓ | None | Android 8.0+ (API 26+) | Input Subsystem | Keyboards, mice, gamepads, and joysticks | Verified |
| `accessibility_service`| Accessibility Subsystem | ACCESSIBILITY | ✓ | `BIND_ACCESSIBILITY_SERVICE` | Android 8.0+ (API 26+) | None | Node tree traversal, window event monitoring | Verified |
| `screen_capture` | Screen Capture & Projection | SCREEN_CAPTURE | ✓ | MediaProjection prompt | Android 5.0+ (API 21+) | Display | User-approved interactive capture intent | Verified |
| `web_browser` | Web Browser & Custom Tabs | WEB_BROWSER | ✓ | None | Android 8.0+ (API 26+) | Browser | Chrome Custom Tabs launch with intent fallback | Verified |
| `intent_manager` | Intent Dispatcher & Resolver | INTENTS | ✓ | None | Android 8.0+ (API 26+) | None | Safe pre-launch package manager resolution | Verified |
| `system_settings` | System Settings Opener | SYSTEM_SETTINGS | ✓ | None | Android 8.0+ (API 26+) | None | Direct shortcuts to Wi-Fi, Bluetooth, Location settings | Verified |
| `background_work` | Background Work & WorkManager | BACKGROUND_WORK | ✓ | None | Android 8.0+ (API 26+) | None | Persistent WorkManager task queuing with constraints | Verified |
| `system_events` | System Events & Broadcasts | SYSTEM_EVENTS | ✓ | None | Android 8.0+ (API 26+) | None | Reactive Flow for power, screen, locale broadcasts | Verified |

---

## 3. ERROR TAXONOMY

All capability operations return standardized errors under `CapabilityErrorCode`:
- `PERMISSION_DENIED`: User denied runtime permission.
- `PERMISSION_REQUIRED`: Operation requires explicit permission before proceeding.
- `HARDWARE_UNAVAILABLE`: Device lacks physical sensor/hardware required for operation.
- `ANDROID_VERSION_UNSUPPORTED`: Current OS SDK level is below requirement.
- `SERVICE_DISABLED`: Hardware or service is disabled in Android settings (e.g. GPS off).
- `USER_CANCELLED`: User declined biometric, permission, or screen capture prompt.
- `TIMEOUT`: Operation timed out.
- `INVALID_ARGUMENT`: Invalid parameter supplied to capability request.
- `SECURITY_RESTRICTION`: Android security or Knox restriction prevented execution.
- `UNAVAILABLE_TO_NORMAL_APP`: Restricted to system/carrier apps on standard Android.
