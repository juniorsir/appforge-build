import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'services.dart';
import 'screens.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => NetworkState()),
      ],
      child: const OfflineSyncApp(),
    ),
  );
}

class OfflineSyncApp extends StatelessWidget {
  const OfflineSyncApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LocalSync',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0F172A),
      ),
      home: HomeScreen(),
    );
  }
}
