import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'package:web_socket_channel/io.dart';

class NetworkState extends ChangeNotifier {
  // Shared State
  String? localIp;
  bool isHost = false;
  bool isConnected = false;
  List<String> messages = [];

  // Host State
  HttpServer? _server;
  String hostCode = "";
  List<WebSocket> clients = [];
  Timer? _udpBroadcastTimer;
  RawDatagramSocket? _udpSocket;

  // Client State
  IOWebSocketChannel? _clientChannel;
  Map<String, String> discoveredHosts = {}; // code -> ip:port

  NetworkState() {
    _initNetwork();
  }

  Future<void> _initNetwork() async {
    localIp = await NetworkInfo().getWifiIP();
    notifyListeners();
    _startUdpListener(); // Always listen for nearby hosts
  }

  // ================= HOST MODE =================
  Future<void> startHost() async {
    if (localIp == null) return;
    hostCode = (Random().nextInt(900000) + 100000).toString(); // 6-digit code
    isHost = true;
    
    // 1. Start HTTP Server and upgrade to WebSocket
    _server = await HttpServer.bind(InternetAddress.anyIPv4, 8080);
    _server!.listen((HttpRequest request) {
      if (WebSocketTransformer.isUpgradeRequest(request)) {
        WebSocketTransformer.upgrade(request).then((WebSocket ws) {
          clients.add(ws);
          notifyListeners();
          ws.listen(
            (data) => _handleIncomingData(data, ws),
            onDone: () { clients.remove(ws); notifyListeners(); },
          );
        });
      }
    });

    // 2. Start UDP Broadcast for LAN Discovery
    _udpSocket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
    _udpSocket!.broadcastEnabled = true;
    _udpBroadcastTimer = Timer.periodic(const Duration(seconds: 2), (timer) {
      final payload = jsonEncode({"code": hostCode, "ip": localIp, "port": 8080});
      _udpSocket!.send(utf8.encode(payload), InternetAddress("255.255.255.255"), 8888);
    });

    notifyListeners();
  }

  void stopHost() {
    _server?.close();
    _udpBroadcastTimer?.cancel();
    _udpSocket?.close();
    for (var c in clients) { c.close(); }
    clients.clear();
    isHost = false;
    notifyListeners();
  }

  // ================= CLIENT MODE =================
  Future<void> _startUdpListener() async {
    final socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 8888);
    socket.listen((RawSocketEvent event) {
      if (event == RawSocketEvent.read) {
        final datagram = socket.receive();
        if (datagram != null) {
          final data = jsonDecode(utf8.decode(datagram.data));
          discoveredHosts[data['code']] = "${data['ip']}:${data['port']}";
          notifyListeners();
        }
      }
    });
  }

  Future<bool> joinWithCode(String code) async {
    final target = discoveredHosts[code];
    if (target != null) {
      return await connectToUri("ws://$target");
    }
    return false; // Code not found on LAN
  }

  Future<bool> connectToUri(String uri) async {
    try {
      _clientChannel = IOWebSocketChannel.connect(Uri.parse(uri));
      _clientChannel!.stream.listen(
        (data) => _handleIncomingData(data, null),
        onDone: () => disconnect(),
      );
      isConnected = true;
      notifyListeners();
      return true;
    } catch (e) {
      return false;
    }
  }

  void disconnect() {
    _clientChannel?.sink.close();
    isConnected = false;
    notifyListeners();
  }

  // ================= SHARED DATA EXCHANGE =================
  void _handleIncomingData(dynamic data, WebSocket? sender) {
    messages.add("Received: $data");
    // If host, relay to other clients (Chat room behavior)
    if (isHost && sender != null) {
      for (var c in clients) {
        if (c != sender) c.add(data);
      }
    }
    notifyListeners();
  }

  void sendMessage(String text) {
    messages.add("Me: $text");
    if (isHost) {
      for (var c in clients) { c.add(text); }
    } else {
      _clientChannel?.sink.add(text);
    }
    notifyListeners();
  }
}
