import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'services.dart';

// --- Shared Theme & Styling ---
const Color bgColor = Color(0xFF0F172A);
const Color primaryColor = Color(0xFF6366F1);
const Color cardColor = Color(0xFF1E293B);

class AppTheme {
  static BoxDecoration glassBox = BoxDecoration(
    color: cardColor.withOpacity(0.8),
    borderRadius: BorderRadius.circular(24),
    boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 10, spreadRadius: 2)],
    border: Border.all(color: Colors.white.withOpacity(0.1)),
  );
}

// --- 1. Home Screen ---
class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final net = context.watch<NetworkState>();

    if (net.isConnected || net.isHost) return ConnectionScreen();

    return Scaffold(
      backgroundColor: bgColor,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(colors: [Color(0xFF0F172A), Color(0xFF312E81)], begin: Alignment.topLeft, end: Alignment.bottomRight),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.wifi_tethering, size: 80, color: Colors.white),
              const SizedBox(height: 20),
              const Text("LocalSync", style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold)),
              const SizedBox(height: 50),
              _buildButton("Start Host", Icons.cell_tower, () => net.startHost()),
              const SizedBox(height: 20),
              _buildButton("Join Server", Icons.login, () => Navigator.push(context, MaterialPageRoute(builder: (_) => JoinScreen()))),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildButton(String text, IconData icon, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: 250,
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: AppTheme.glassBox.copyWith(color: primaryColor),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white),
            const SizedBox(width: 10),
            Text(text, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}

// --- 2. Join Screen (Code / QR) ---
class JoinScreen extends StatelessWidget {
  final TextEditingController _codeCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final net = context.read<NetworkState>();
    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(backgroundColor: Colors.transparent, elevation: 0),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            Container(
              decoration: AppTheme.glassBox,
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  const Text("Enter 6-Digit Code", style: TextStyle(color: Colors.white, fontSize: 20)),
                  const SizedBox(height: 20),
                  TextField(
                    controller: _codeCtrl,
                    style: const TextStyle(color: Colors.white, fontSize: 24, letterSpacing: 8),
                    textAlign: TextAlign.center,
                    keyboardType: TextInputType.number,
                    maxLength: 6,
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.black26,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                    ),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: primaryColor, minimumSize: const Size(double.infinity, 50)),
                    onPressed: () async {
                      bool success = await net.joinWithCode(_codeCtrl.text);
                      if (success) Navigator.pop(context);
                      else ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Host not found on LAN!")));
                    },
                    child: const Text("Join Network"),
                  )
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Text("OR", style: TextStyle(color: Colors.white54)),
            const SizedBox(height: 20),
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(24),
                child: MobileScanner(
                  onDetect: (capture) {
                    final List<Barcode> barcodes = capture.barcodes;
                    if (barcodes.isNotEmpty && barcodes.first.rawValue != null) {
                      net.connectToUri(barcodes.first.rawValue!);
                      Navigator.pop(context);
                    }
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// --- 3. Connection/Dashboard Screen ---
class ConnectionScreen extends StatelessWidget {
  final TextEditingController _msgCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final net = context.watch<NetworkState>();

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: cardColor,
        title: Text(net.isHost ? "Hosting Server" : "Connected to Host"),
        actions: [
          IconButton(
            icon: const Icon(Icons.power_settings_new, color: Colors.redAccent),
            onPressed: () {
              net.isHost ? net.stopHost() : net.disconnect();
            },
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            if (net.isHost) ...[
              Container(
                padding: const EdgeInsets.all(20),
                decoration: AppTheme.glassBox,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text("Connection Code", style: TextStyle(color: Colors.white54)),
                        Text(net.hostCode, style: const TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.bold, letterSpacing: 4)),
                        Text("Clients Connected: ${net.clients.length}", style: const TextStyle(color: Colors.greenAccent)),
                      ],
                    ),
                    Container(
                      color: Colors.white,
                      padding: const EdgeInsets.all(8),
                      child: QrImageView(
                        data: "ws://${net.localIp}:8080",
                        version: QrVersions.auto,
                        size: 80.0,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
            ],
            
            // Chat / Data Exchange UI
            Expanded(
              child: Container(
                decoration: AppTheme.glassBox,
                child: ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: net.messages.length,
                  itemBuilder: (ctx, i) => Padding(
                    padding: const EdgeInsets.only(bottom: 8.0),
                    child: Text(net.messages[i], style: const TextStyle(color: Colors.white70)),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _msgCtrl,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: "Send data...",
                      hintStyle: const TextStyle(color: Colors.white54),
                      filled: true,
                      fillColor: cardColor,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                CircleAvatar(
                  backgroundColor: primaryColor,
                  radius: 24,
                  child: IconButton(
                    icon: const Icon(Icons.send, color: Colors.white),
                    onPressed: () {
                      if (_msgCtrl.text.isNotEmpty) {
                        net.sendMessage(_msgCtrl.text);
                        _msgCtrl.clear();
                      }
                    },
                  ),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
