package com.example.presentation.dashboard

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeDown
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BrightnessMedium
import android.widget.Toast
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.DoNotDisturbOn
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.ViewCarousel
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.capabilities.permissions.PermissionAlertEvent
import com.example.capabilities.permissions.PermissionManager
import com.example.domain.model.SessionState
import com.example.presentation.permissions.PermissionsManagerDialog
import com.example.services.RealtimeConnectionService

private val ConsoleBg = Color(0xFF0A0E14)
private val CardBg = Color(0xFF111722)
private val CardElevatedBg = Color(0xFF182030)
private val BorderSubtleColor = Color(0xFF1F2A3C)
private val EmeraldAccent = Color(0xFF10B981)
private val CyanAccent = Color(0xFF38BDF8)
private val AmberAccent = Color(0xFFF59E0B)
private val CoralError = Color(0xFFF43F5E)
private val TextPrimaryColor = Color(0xFFF8FAFC)
private val TextSecondaryColor = Color(0xFF94A3B8)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    onNavigateToSettings: () -> Unit = {},
    onNavigateToDeveloper: () -> Unit = {},
    onNavigateToSpeechDiagnostics: () -> Unit = {},
    onNavigateToConversationEngine: () -> Unit = {},
    viewModel: DashboardViewModel
) {
    val wsState by viewModel.wsConnectionState.collectAsState()
    val activeUrl by viewModel.activeUrl.collectAsState()
    val logs by viewModel.connectionLogs.collectAsState()
    val lastFailure by viewModel.lastFailureReason.collectAsState()
    val isTorchOn by viewModel.isTorchOn.collectAsState()
    val isDndActive by viewModel.isDndActive.collectAsState()
    val isAutoRotateOn by viewModel.isAutoRotateOn.collectAsState()
    val ringerMode by viewModel.ringerMode.collectAsState()
    val brightnessLevel by viewModel.brightnessLevel.collectAsState()
    val isLocationEnabled by viewModel.isLocationEnabled.collectAsState()
    val isLiveLocationTracking by viewModel.isLiveLocationTracking.collectAsState()
    val locationSnapshot by viewModel.locationSnapshot.collectAsState()
    val clipboardPreview by viewModel.clipboardPreview.collectAsState()
    val accessibilityStatus by viewModel.accessibilityStatus.collectAsState()
    val lastCommandOutput by viewModel.lastCommandOutput.collectAsState()

    val context = LocalContext.current
    val permissionManager = remember(context) { PermissionManager(context.applicationContext) }

    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                viewModel.refreshStates()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val livePulseTransition = rememberInfiniteTransition(label = "gps_live_pulse")
    val livePulseAlpha by livePulseTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 750),
            repeatMode = RepeatMode.Reverse
        ),
        label = "gps_pulse_alpha"
    )

    var urlInput by remember(activeUrl) { mutableStateOf(activeUrl) }
    var shellInput by remember { mutableStateOf("") }
    var selectedLogFilter by remember { mutableStateOf("ALL") }

    var showTerminalSheet by remember { mutableStateOf(false) }
    var showControlCenterSheet by remember { mutableStateOf(false) }
    var showAdvancedControlsSheet by remember { mutableStateOf(false) }
    var advancedControlsTab by remember { mutableIntStateOf(0) }
    var showPermissionsDialog by remember { mutableStateOf(false) }
    var showCameraDialog by remember { mutableStateOf(false) }
    var showMicDialog by remember { mutableStateOf(false) }
    var showNotifDialog by remember { mutableStateOf(false) }
    var showStorageDialog by remember { mutableStateOf(false) }
    var showClipboardDialog by remember { mutableStateOf(false) }
    var clipboardEditBuffer by remember { mutableStateOf("") }
    var activePermissionAlert by remember { mutableStateOf<PermissionAlertEvent?>(null) }

    val dynamicPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        activePermissionAlert = null
    }

    LaunchedEffect(viewModel.permissionAlerts) {
        viewModel.permissionAlerts.collect { alert ->
            activePermissionAlert = alert
        }
    }

    if (showPermissionsDialog) {
        PermissionsManagerDialog(
            onDismissRequest = { showPermissionsDialog = false },
            permissionManager = permissionManager,
            onOpenCameraStation = {
                showPermissionsDialog = false
                showCameraDialog = true
            },
            onOpenMicStation = {
                showPermissionsDialog = false
                showMicDialog = true
            },
            onOpenNotifStation = {
                showPermissionsDialog = false
                showNotifDialog = true
            },
            onOpenStorageStation = {
                showPermissionsDialog = false
                showStorageDialog = true
            }
        )
    }

    if (showClipboardDialog) {
        AlertDialog(
            onDismissRequest = { showClipboardDialog = false },
            containerColor = CardBg,
            title = {
                Text(
                    text = "Clipboard",
                    color = TextPrimaryColor,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                )
            },
            text = {
                OutlinedTextField(
                    value = clipboardEditBuffer,
                    onValueChange = { clipboardEditBuffer = it },
                    placeholder = { Text("Enter text to sync...", color = TextSecondaryColor) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("clipboard_edit_input"),
                    minLines = 3,
                    maxLines = 6,
                    textStyle = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = FontFamily.Monospace,
                        color = TextPrimaryColor
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateClipboard(clipboardEditBuffer)
                        showClipboardDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent),
                    modifier = Modifier.testTag("clipboard_save_button")
                ) {
                    Text("Save", color = Color.Black, fontWeight = FontWeight.SemiBold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClipboardDialog = false }) {
                    Text("Cancel", color = TextSecondaryColor)
                }
            }
        )
    }

    var showLocationDialog by remember { mutableStateOf(false) }

    if (showLocationDialog) {
        AlertDialog(
            onDismissRequest = { showLocationDialog = false },
            containerColor = CardBg,
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (isLiveLocationTracking) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(EmeraldAccent.copy(alpha = livePulseAlpha))
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = if (isLocationEnabled) EmeraldAccent else AmberAccent
                        )
                    }
                    Text(
                        text = when {
                            isLiveLocationTracking -> "Live GPS Realtime Stream"
                            isLocationEnabled -> "GPS Location"
                            else -> "GPS Location (Disabled)"
                        },
                        color = TextPrimaryColor,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Live streaming badge
                    if (isLiveLocationTracking) {
                        Surface(
                            color = EmeraldAccent.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, EmeraldAccent.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(EmeraldAccent.copy(alpha = livePulseAlpha))
                                    )
                                    Text(
                                        text = "LIVE STREAM (1s)",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = EmeraldAccent
                                    )
                                }
                                Text(
                                    text = "Update #${locationSnapshot.updateCount}",
                                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                                    color = TextSecondaryColor
                                )
                            }
                        }
                    }

                    if (locationSnapshot.hasCoordinates) {
                        val coordPair = String.format(java.util.Locale.US, "%.6f, %.6f", locationSnapshot.latitude, locationSnapshot.longitude)
                        Surface(
                            color = ConsoleBg,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, if (isLiveLocationTracking) EmeraldAccent.copy(alpha = 0.6f) else BorderSubtleColor),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "COORDINATES",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondaryColor
                                    )
                                    Text(
                                        text = locationSnapshot.provider.uppercase(),
                                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                                        color = CyanAccent
                                    )
                                }
                                Text(
                                    text = coordPair,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = EmeraldAccent
                                )

                                HorizontalDivider(color = BorderSubtleColor, thickness = 0.5.dp)

                                // Live Telemetry: Speed, Heading, Alt/Acc
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("SPEED", style = MaterialTheme.typography.labelSmall, color = TextSecondaryColor, fontSize = 10.sp)
                                        Text(
                                            text = String.format(java.util.Locale.US, "%.1f km/h", locationSnapshot.speedKmh),
                                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace),
                                            color = CyanAccent
                                        )
                                    }
                                    Column {
                                        Text("HEADING", style = MaterialTheme.typography.labelSmall, color = TextSecondaryColor, fontSize = 10.sp)
                                        Text(
                                            text = "${locationSnapshot.bearingCompass} (${locationSnapshot.bearingDegrees.toInt()}°)",
                                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace),
                                            color = AmberAccent
                                        )
                                    }
                                    Column {
                                        Text("ACCURACY", style = MaterialTheme.typography.labelSmall, color = TextSecondaryColor, fontSize = 10.sp)
                                        Text(
                                            text = String.format(java.util.Locale.US, "±%.1fm", locationSnapshot.accuracyMeters),
                                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace),
                                            color = TextPrimaryColor
                                        )
                                    }
                                    Column {
                                        Text("ALTITUDE", style = MaterialTheme.typography.labelSmall, color = TextSecondaryColor, fontSize = 10.sp)
                                        Text(
                                            text = String.format(java.util.Locale.US, "%.1fm", locationSnapshot.altitudeMeters),
                                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace),
                                            color = TextSecondaryColor
                                        )
                                    }
                                }

                                if (locationSnapshot.mapsUrl.isNotEmpty()) {
                                    Text(
                                        text = locationSnapshot.mapsUrl,
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 10.sp
                                        ),
                                        color = CyanAccent,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }

                        // Stream Toggle Action Button (Start / Stop Realtime)
                        Button(
                            onClick = { viewModel.toggleLiveLocationTracking() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isLiveLocationTracking) CoralError else EmeraldAccent
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(42.dp)
                                .testTag("toggle_live_location_button")
                        ) {
                            Icon(
                                imageVector = if (isLiveLocationTracking) Icons.Default.LinkOff else Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = if (isLiveLocationTracking) "Stop Realtime Stream" else "Start Realtime Stream (1s)",
                                color = Color.Black,
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    viewModel.updateClipboard("$coordPair\n${locationSnapshot.mapsUrl}")
                                },
                                border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.6f)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Copy Coords", color = CyanAccent, style = MaterialTheme.typography.labelSmall)
                            }
                            OutlinedButton(
                                onClick = {
                                    viewModel.openUrlOnDevice(locationSnapshot.mapsUrl)
                                },
                                border = BorderStroke(1.dp, EmeraldAccent.copy(alpha = 0.6f)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Open Maps", color = EmeraldAccent, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    } else {
                        Text(
                            text = locationSnapshot.statusMessage,
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                            color = AmberAccent
                        )
                        Button(
                            onClick = { viewModel.toggleLiveLocationTracking() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isLiveLocationTracking) CoralError else EmeraldAccent
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (isLiveLocationTracking) "Stop Realtime Stream" else "Start Realtime Stream (1s)",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Text(
                        text = "Termux: python send_cmd.py location --live",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        ),
                        color = TextSecondaryColor
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.refreshLocationDetails() },
                    colors = ButtonDefaults.buttonColors(containerColor = if (isLiveLocationTracking) CyanAccent else EmeraldAccent)
                ) {
                    Text("Instant Fix", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { viewModel.openLocationSettings() }) {
                        Text("Settings", color = CyanAccent)
                    }
                    TextButton(onClick = { showLocationDialog = false }) {
                        Text("Close", color = TextSecondaryColor)
                    }
                }
            }
        )
    }

    if (showCameraDialog) {
        val camDetails = remember { viewModel.getCameraStationDetails() }
        val isGranted = camDetails.optBoolean("isGranted", false)
        val cameraCount = camDetails.optInt("cameraCount", 0)
        val frontCameras = camDetails.optInt("frontCameras", 0)
        val backCameras = camDetails.optInt("backCameras", 0)
        val hasFlash = camDetails.optBoolean("hasFlash", false)

        AlertDialog(
            onDismissRequest = { showCameraDialog = false },
            containerColor = CardBg,
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CameraAlt,
                        contentDescription = null,
                        tint = CyanAccent
                    )
                    Text(
                        text = "Camera & Vision Station",
                        color = TextPrimaryColor,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Surface(
                        color = ConsoleBg,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (isGranted) CyanAccent.copy(alpha = 0.5f) else AmberAccent.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("PERMISSION STATUS", style = MaterialTheme.typography.labelSmall, color = TextSecondaryColor)
                                Text(
                                    text = if (isGranted) "● GRANTED" else "⚠️ MISSING",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (isGranted) EmeraldAccent else AmberAccent
                                )
                            }
                            HorizontalDivider(color = BorderSubtleColor, thickness = 0.5.dp)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("CAMERAS", style = MaterialTheme.typography.labelSmall, color = TextSecondaryColor, fontSize = 10.sp)
                                    Text("$cameraCount Total", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace), color = CyanAccent)
                                }
                                Column {
                                    Text("LENSES", style = MaterialTheme.typography.labelSmall, color = TextSecondaryColor, fontSize = 10.sp)
                                    Text("Back: $backCameras | Front: $frontCameras", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace), color = TextPrimaryColor)
                                }
                                Column {
                                    Text("FLASH", style = MaterialTheme.typography.labelSmall, color = TextSecondaryColor, fontSize = 10.sp)
                                    Text(if (hasFlash) "Available" else "No Unit", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace), color = AmberAccent)
                                }
                            }
                        }
                    }

                    Button(
                        onClick = {
                            viewModel.testCameraCapture()
                            Toast.makeText(context, "Dispatched camera capture test", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanAccent),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Take Test Photo / Open Camera", color = Color.Black, fontWeight = FontWeight.Bold)
                    }

                    if (!isGranted) {
                        Button(
                            onClick = {
                                viewModel.requestPermissionDirect(
                                    android.Manifest.permission.CAMERA,
                                    "Camera Hardware",
                                    "Camera access is required for vision inspection and photo capture."
                                )
                                showCameraDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Request Camera Permission", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }

                    Text(
                        text = "Termux: python send_cmd.py camera test",
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 11.sp),
                        color = TextSecondaryColor
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { viewModel.openPermissionSetting("camera") }) {
                    Text("Settings", color = CyanAccent)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCameraDialog = false }) {
                    Text("Close", color = TextSecondaryColor)
                }
            }
        )
    }

    if (showMicDialog) {
        val micDetails = remember { viewModel.getMicrophoneStationDetails() }
        val isGranted = micDetails.optBoolean("isGranted", false)
        val hasHw = micDetails.optBoolean("hasMicrophoneHardware", true)
        val sampleRate = micDetails.optString("sampleRateHz", "44100")
        val isMuted = micDetails.optBoolean("isMicrophoneMuted", false)
        val rtStatus by viewModel.realtimeAudioStatus.collectAsState()
        var testRecordingResult by remember { mutableStateOf<String?>(null) }
        var isPlayingLastClip by remember { mutableStateOf(false) }
        val coroutineScope = rememberCoroutineScope()

        AlertDialog(
            onDismissRequest = { if (!rtStatus.isRecording) showMicDialog = false },
            containerColor = CardBg,
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = null,
                        tint = if (rtStatus.isRecording) CoralError else AmberAccent
                    )
                    Text(
                        text = if (rtStatus.isRecording) "🎙️ Real-Time Recording..." else "Microphone & Voice Station",
                        color = TextPrimaryColor,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Hardware info card
                    Surface(
                        color = ConsoleBg,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (rtStatus.isRecording) CoralError.copy(alpha = 0.6f) else if (isGranted) AmberAccent.copy(alpha = 0.5f) else CoralError.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("STATUS", style = MaterialTheme.typography.labelSmall, color = TextSecondaryColor)
                                Text(
                                    text = if (rtStatus.isRecording) "● LIVE STREAMING" else if (isGranted) "● GRANTED" else "⚠️ MISSING",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (rtStatus.isRecording) CoralError else if (isGranted) EmeraldAccent else AmberAccent
                                )
                            }
                            HorizontalDivider(color = BorderSubtleColor, thickness = 0.5.dp)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("HARDWARE", style = MaterialTheme.typography.labelSmall, color = TextSecondaryColor, fontSize = 10.sp)
                                    Text(if (hasHw) "Present" else "Virtual", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace), color = CyanAccent)
                                }
                                Column {
                                    Text("SAMPLE RATE", style = MaterialTheme.typography.labelSmall, color = TextSecondaryColor, fontSize = 10.sp)
                                    Text("${sampleRate}Hz", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace), color = TextPrimaryColor)
                                }
                                Column {
                                    Text("MIC MUTE", style = MaterialTheme.typography.labelSmall, color = TextSecondaryColor, fontSize = 10.sp)
                                    Text(if (isMuted) "MUTED" else "Unmuted", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace), color = if (isMuted) CoralError else EmeraldAccent)
                                }
                            }
                        }
                    }

                    // REAL-TIME AUDIO WAVEFORM & VU METER PANEL
                    if (rtStatus.isRecording) {
                        Surface(
                            color = CoralError.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, CoralError.copy(alpha = 0.6f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(CoralError))
                                        Text("LIVE AUDIO STREAM", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = CoralError)
                                    }
                                    Text(
                                        text = "${rtStatus.sizeKb} KB",
                                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold),
                                        color = TextPrimaryColor
                                    )
                                }

                                // Live digital timer display
                                Text(
                                    text = rtStatus.formattedDuration,
                                    style = MaterialTheme.typography.headlineMedium.copy(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold),
                                    color = Color.White
                                )

                                // Live animated waveform bars
                                val rmsNormalized = (rtStatus.rms / 4000.0).coerceIn(0.1, 1.0).toFloat()
                                Row(
                                    modifier = Modifier.fillMaxWidth().height(42.dp),
                                    horizontalArrangement = Arrangement.SpaceEvenly,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    for (i in 0 until 18) {
                                        val waveFactor = (0.3f + 0.7f * Math.abs(Math.sin((i * 0.4) + (System.currentTimeMillis() / 150.0))).toFloat())
                                        val barHeight = (42.dp * rmsNormalized * waveFactor).coerceIn(6.dp, 40.dp)
                                        Box(
                                            modifier = Modifier
                                                .width(4.dp)
                                                .height(barHeight)
                                                .clip(RoundedCornerShape(2.dp))
                                                .background(if (i % 2 == 0) CoralError else AmberAccent)
                                        )
                                    }
                                }

                                // Live dB Meter
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("VOLUME LEVEL", style = MaterialTheme.typography.labelSmall, color = TextSecondaryColor, fontSize = 9.sp)
                                    Text("${rtStatus.decibels} dB", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace), color = AmberAccent)
                                }
                                val dbNormalized = ((rtStatus.decibels + 60.0) / 60.0).coerceIn(0.0, 1.0).toFloat()
                                LinearProgressIndicator(
                                    progress = { dbNormalized },
                                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                                    color = if (dbNormalized > 0.85f) CoralError else AmberAccent,
                                    trackColor = BorderSubtleColor
                                )
                            }
                        }
                    }

                    // Status / feedback message
                    if (testRecordingResult != null) {
                        Surface(
                            color = EmeraldAccent.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, EmeraldAccent.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = testRecordingResult ?: "",
                                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 11.sp),
                                color = EmeraldAccent,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    // PRIMARY REAL-TIME RECORDING TOGGLE BUTTON
                    Button(
                        onClick = {
                            if (!isGranted) {
                                viewModel.requestPermissionDirect(
                                    android.Manifest.permission.RECORD_AUDIO,
                                    "Microphone & Audio",
                                    "Audio capture permission is required for real-time live recording."
                                )
                                testRecordingResult = "⚠️ RECORD_AUDIO permission required. Please grant permission."
                                return@Button
                            }
                            if (rtStatus.isRecording) {
                                // Stop live recording
                                val res = viewModel.stopRealtimeRecording()
                                if (res.optBoolean("success", false)) {
                                    val p = res.optString("filePath", res.optString("path", "recording.wav"))
                                    testRecordingResult = "✅ Live audio saved (${res.optDouble("durationSec")}s): ${p.substringAfterLast("/")}"
                                } else {
                                    testRecordingResult = "⚠️ Failed: ${res.optString("error", "Error stopping recording")}"
                                }
                            } else {
                                // Start live recording
                                val res = viewModel.startRealtimeRecording()
                                if (res.optBoolean("success", false)) {
                                    testRecordingResult = "🎙️ Real-time recording active! Speak into microphone..."
                                } else {
                                    testRecordingResult = "⚠️ Start failed: ${res.optString("error", "Recording error")}"
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (rtStatus.isRecording) CoralError else EmeraldAccent
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) {
                        Icon(
                            imageVector = if (rtStatus.isRecording) Icons.Default.Stop else Icons.Default.Mic,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = if (rtStatus.isRecording) "■ Stop Real-Time Recording" else "● Start Real-Time Recording",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Playback button if last recording exists
                    if (!rtStatus.isRecording && rtStatus.filePath != null) {
                        OutlinedButton(
                            onClick = {
                                isPlayingLastClip = true
                                val res = viewModel.playRecordedAudio(rtStatus.filePath ?: "")
                                coroutineScope.launch {
                                    kotlinx.coroutines.delay(res.optLong("durationMs", 2000L).coerceAtLeast(1000L))
                                    isPlayingLastClip = false
                                }
                                if (res.optBoolean("success", false)) {
                                    testRecordingResult = "▶ Playing recorded audio (${res.optInt("durationMs")}ms)"
                                } else {
                                    testRecordingResult = "⚠️ Playback error: ${res.optString("error")}"
                                }
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = CyanAccent),
                            border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (isPlayingLastClip) "Playing Audio..." else "Play Recorded Clip (${rtStatus.formattedDuration})", fontWeight = FontWeight.SemiBold)
                        }
                    }

                    if (!isGranted) {
                        Button(
                            onClick = {
                                viewModel.requestPermissionDirect(
                                    android.Manifest.permission.RECORD_AUDIO,
                                    "Microphone & Audio",
                                    "Audio capture permission is required for voice streaming and recordings."
                                )
                                showMicDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Request Mic Permission", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }

                    Text(
                        text = "Termux: python send_cmd.py mic --live",
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 11.sp),
                        color = TextSecondaryColor
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { viewModel.openPermissionSetting("mic") }) {
                    Text("Settings", color = CyanAccent)
                }
            },
            dismissButton = {
                TextButton(onClick = { showMicDialog = false }) {
                    Text("Close", color = TextSecondaryColor)
                }
            }
        )
    }

    if (showNotifDialog) {
        val notifDetails = remember { viewModel.getNotificationStationDetails() }
        val isGranted = notifDetails.optBoolean("isGranted", false)
        val areEnabled = notifDetails.optBoolean("areNotificationsEnabled", false)
        val canBypassDnd = notifDetails.optBoolean("canBypassDnd", false)
        val channelsCount = notifDetails.optInt("channelCount", 0)

        AlertDialog(
            onDismissRequest = { showNotifDialog = false },
            containerColor = CardBg,
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Notifications, contentDescription = null, tint = Color(0xFFA855F7))
                    Text(
                        text = "Notification Center Station",
                        color = TextPrimaryColor,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Surface(
                        color = ConsoleBg,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (isGranted) Color(0xFFA855F7).copy(alpha = 0.5f) else AmberAccent.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("NOTIFICATION STATUS", style = MaterialTheme.typography.labelSmall, color = TextSecondaryColor)
                                Text(
                                    text = if (isGranted) "● ACTIVE" else "⚠️ ACTION NEEDED",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (isGranted) EmeraldAccent else AmberAccent
                                )
                            }
                            HorizontalDivider(color = BorderSubtleColor, thickness = 0.5.dp)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("POSTING", style = MaterialTheme.typography.labelSmall, color = TextSecondaryColor, fontSize = 10.sp)
                                    Text(if (areEnabled) "Enabled" else "Blocked", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace), color = if (areEnabled) EmeraldAccent else CoralError)
                                }
                                Column {
                                    Text("CHANNELS", style = MaterialTheme.typography.labelSmall, color = TextSecondaryColor, fontSize = 10.sp)
                                    Text("$channelsCount Channels", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace), color = CyanAccent)
                                }
                                Column {
                                    Text("DND ACCESS", style = MaterialTheme.typography.labelSmall, color = TextSecondaryColor, fontSize = 10.sp)
                                    Text(if (canBypassDnd) "Granted" else "Restricted", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace), color = if (canBypassDnd) EmeraldAccent else AmberAccent)
                                }
                            }
                        }
                    }

                    Button(
                        onClick = {
                            viewModel.sendHardwareTestNotification("AeroShare Hardware Test", "Interactive test notification received!")
                            Toast.makeText(context, "Dispatched test notification", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFA855F7)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Notifications, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Send Test Notification", color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    if (!isGranted) {
                        Button(
                            onClick = {
                                if (android.os.Build.VERSION.SDK_INT >= 33) {
                                    viewModel.requestPermissionDirect(
                                        "android.permission.POST_NOTIFICATIONS",
                                        "Notifications",
                                        "Notification permission is needed to deliver critical alerts."
                                    )
                                } else {
                                    viewModel.openPermissionSetting("notif")
                                }
                                showNotifDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Grant Notification Permission", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }

                    Text(
                        text = "Termux: python send_cmd.py notif test",
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 11.sp),
                        color = TextSecondaryColor
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { viewModel.openPermissionSetting("notif") }) {
                    Text("Settings", color = CyanAccent)
                }
            },
            dismissButton = {
                TextButton(onClick = { showNotifDialog = false }) {
                    Text("Close", color = TextSecondaryColor)
                }
            }
        )
    }

    if (showStorageDialog) {
        val storageDetails = remember { viewModel.getStorageStationDetails() }
        val isGranted = storageDetails.optBoolean("isGranted", false)
        val totalSpaceGb = storageDetails.optString("totalSpaceGb", "0.0")
        val freeSpaceGb = storageDetails.optString("freeSpaceGb", "0.0")
        val usedSpaceGb = storageDetails.optString("usedSpaceGb", "0.0")
        val usedPercent = storageDetails.optInt("usedPercent", 0)
        val picturesCount = storageDetails.optInt("picturesCount", 0)
        val downloadsCount = storageDetails.optInt("downloadsCount", 0)

        AlertDialog(
            onDismissRequest = { showStorageDialog = false },
            containerColor = CardBg,
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Folder, contentDescription = null, tint = EmeraldAccent)
                    Text(
                        text = "Storage & File Media Station",
                        color = TextPrimaryColor,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Surface(
                        color = ConsoleBg,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (isGranted) EmeraldAccent.copy(alpha = 0.5f) else AmberAccent.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("STORAGE ACCESS", style = MaterialTheme.typography.labelSmall, color = TextSecondaryColor)
                                Text(
                                    text = if (isGranted) "● GRANTED" else "⚠️ RESTRICTED",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (isGranted) EmeraldAccent else AmberAccent
                                )
                            }
                            HorizontalDivider(color = BorderSubtleColor, thickness = 0.5.dp)

                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("DISK USAGE", style = MaterialTheme.typography.labelSmall, color = TextSecondaryColor, fontSize = 10.sp)
                                    Text("$usedSpaceGb GB / $totalSpaceGb GB ($usedPercent%)", style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace), color = CyanAccent)
                                }
                                LinearProgressIndicator(
                                    progress = { (usedPercent / 100f).coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                                    color = if (usedPercent > 85) CoralError else EmeraldAccent,
                                    trackColor = CardElevatedBg
                                )
                                Text("Free Space: $freeSpaceGb GB", style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp), color = TextSecondaryColor)
                            }

                            HorizontalDivider(color = BorderSubtleColor, thickness = 0.5.dp)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("DCIM PHOTOS", style = MaterialTheme.typography.labelSmall, color = TextSecondaryColor, fontSize = 10.sp)
                                    Text("$picturesCount Files", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace), color = CyanAccent)
                                }
                                Column {
                                    Text("DOWNLOADS", style = MaterialTheme.typography.labelSmall, color = TextSecondaryColor, fontSize = 10.sp)
                                    Text("$downloadsCount Files", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace), color = AmberAccent)
                                }
                            }
                        }
                    }

                    if (!isGranted) {
                        Button(
                            onClick = {
                                viewModel.openPermissionSetting("storage")
                                showStorageDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Grant All Files / Storage Access", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }

                    Text(
                        text = "Termux: python send_cmd.py storage stat",
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 11.sp),
                        color = TextSecondaryColor
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { viewModel.openPermissionSetting("storage") }) {
                    Text("Settings", color = CyanAccent)
                }
            },
            dismissButton = {
                TextButton(onClick = { showStorageDialog = false }) {
                    Text("Close", color = TextSecondaryColor)
                }
            }
        )
    }

    activePermissionAlert?.let { alert ->
        AlertDialog(
            onDismissRequest = { activePermissionAlert = null },
            containerColor = CardBg,
            modifier = Modifier.testTag("permission_warning_alert_dialog"),
            title = {
                Text(
                    text = alert.featureName,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = AmberAccent
                )
            },
            text = {
                Text(text = alert.reasonMessage, style = MaterialTheme.typography.bodyMedium, color = TextPrimaryColor)
            },
            confirmButton = {
                Button(
                    onClick = { dynamicPermissionLauncher.launch(alert.permission) },
                    modifier = Modifier.testTag("grant_permission_popup_button")
                ) {
                    Text("Grant")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { activePermissionAlert = null },
                    modifier = Modifier.testTag("dismiss_permission_popup_button")
                ) {
                    Text("Dismiss")
                }
            }
        )
    }

    if (showControlCenterSheet) {
        UnifiedControlCenterSheet(
            viewModel = viewModel,
            permissionManager = permissionManager,
            onOpenPermissionsModal = {
                showControlCenterSheet = false
                showPermissionsDialog = true
            },
            onDismiss = { showControlCenterSheet = false }
        )
    }

    if (showAdvancedControlsSheet) {
        AdvancedControlsBottomSheet(
            initialTab = advancedControlsTab,
            viewModel = viewModel,
            onDismiss = { showAdvancedControlsSheet = false }
        )
    }

    val isWsConnected = wsState == SessionState.ConnectionState.CONNECTED
    val isWsConnecting = wsState == SessionState.ConnectionState.CONNECTING ||
            wsState == SessionState.ConnectionState.RECONNECTING

    val filteredLogs = remember(logs, selectedLogFilter) {
        if (selectedLogFilter == "ALL") {
            logs
        } else {
            logs.filter { entry ->
                when (selectedLogFilter) {
                    "HTTP" -> entry.contains("HTTP ", ignoreCase = true)
                    "WS" -> entry.contains("WS", ignoreCase = true) || entry.contains("WebSocket", ignoreCase = true) || entry.contains("AI_STREAM", ignoreCase = true)
                    "SHELL" -> entry.contains("SHELL", ignoreCase = true)
                    "SYSTEM" -> entry.contains("SYSTEM", ignoreCase = true) || entry.contains("CLIPBOARD", ignoreCase = true) || entry.contains("UI_", ignoreCase = true) || entry.contains("INSPECT", ignoreCase = true) || entry.contains("SCREENSHOT", ignoreCase = true)
                    else -> true
                }
            }
        }
    }

    if (showTerminalSheet) {
        TerminalAndLogsBottomSheet(
            logs = filteredLogs,
            selectedFilter = selectedLogFilter,
            onFilterSelect = { selectedLogFilter = it },
            shellInput = shellInput,
            onShellInputChange = { shellInput = it },
            lastCommandOutput = lastCommandOutput,
            onDismissCommandOutput = { viewModel.clearCommandOutput() },
            onExecuteCommand = {
                if (shellInput.isNotBlank()) {
                    viewModel.executeConsoleCommand(shellInput)
                    shellInput = ""
                }
            },
            onClearLogs = { viewModel.clearLogs() },
            onDismiss = { showTerminalSheet = false }
        )
    }

    Scaffold(
        containerColor = ConsoleBg,
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(ConsoleBg)
                .padding(innerPadding)
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .widthIn(max = 640.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 1. Compact Single-Line Top Bar
            CompactTopBar(
                wsState = wsState,
                onOpenTerminal = { showTerminalSheet = true },
                onOpenPermissions = { showPermissionsDialog = true },
                onOpenSettings = { showControlCenterSheet = true }
            )

            // 2. Clean Connection Card (Dedicated Tunnel/Local row, URL field, Connect/Stop)
            CleanConnectionCard(
                urlInput = urlInput,
                onUrlChange = { urlInput = it },
                isConnected = isWsConnected,
                isConnecting = isWsConnecting,
                lastFailure = lastFailure,
                onConnect = { viewModel.connectToServer(context, urlInput) },
                onDisconnect = { viewModel.disconnectServer(context) }
            )

            // 3. Icon-First 4x3 Controls Grid + Brightness Slider + Media/Volume/Global Bar
            CleanControlsGrid(
                isTorchOn = isTorchOn,
                isDndActive = isDndActive,
                isAutoRotateOn = isAutoRotateOn,
                ringerMode = ringerMode,
                brightnessLevel = brightnessLevel,
                isLocationEnabled = isLocationEnabled,
                isLiveLocationTracking = isLiveLocationTracking,
                isAccessibilityEnabled = accessibilityStatus.isEnabled,
                hasClipboard = clipboardPreview.isNotBlank(),
                onToggleTorch = { viewModel.toggleTorch() },
                onToggleDnd = { viewModel.toggleDnd() },
                onAccessibilityAction = {
                    if (accessibilityStatus.isEnabled) {
                        viewModel.inspectUiHierarchy()
                        showTerminalSheet = true
                    } else {
                        try {
                            context.startActivity(
                                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                            )
                        } catch (_: Exception) {}
                    }
                },
                onOpenWifi = { viewModel.openWifiPanel() },
                onOpenBluetooth = { viewModel.openBluetoothPanel() },
                onOpenClipboard = {
                    viewModel.refreshClipboard()
                    clipboardEditBuffer = clipboardPreview
                    showClipboardDialog = true
                },
                onCaptureScreenshot = { viewModel.captureScreenshot() },
                onOpenCamera = { showCameraDialog = true },
                onOpenMic = { showMicDialog = true },
                onOpenNotif = { showNotifDialog = true },
                onOpenStorage = { showStorageDialog = true },
                onToggleAutoRotate = { viewModel.toggleAutoRotate() },
                onCycleRinger = { viewModel.cycleRingerAndVibrate() },
                onOpenHotspot = { viewModel.openHotspotPanel() },
                onOpenLocation = {
                    viewModel.refreshLocationDetails()
                    showLocationDialog = true
                },
                onLockScreen = { viewModel.lockDeviceScreen() },
                onBrightnessChange = { viewModel.setBrightnessLevel(it) },
                onVolumeAction = { viewModel.adjustVolume(it) },
                onMediaAction = { viewModel.triggerMediaControl(it) },
                onGlobalAction = { viewModel.triggerGlobalUiAction(it) },
                onOpenAdvancedTab = { tabIdx ->
                    advancedControlsTab = tabIdx
                    showAdvancedControlsSheet = true
                }
            )

            // 4. Compact Bottom Drawer Trigger Bar for Terminal & Logs
            TerminalDrawerTriggerBar(
                latestLog = logs.firstOrNull(),
                logCount = logs.size,
                onClick = { showTerminalSheet = true }
            )
        }
    }
}

@Composable
private fun CompactTopBar(
    wsState: SessionState.ConnectionState,
    onOpenTerminal: () -> Unit,
    onOpenPermissions: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val (statusText, statusColor) = when (wsState) {
        SessionState.ConnectionState.CONNECTED -> "Connected" to EmeraldAccent
        SessionState.ConnectionState.CONNECTING,
        SessionState.ConnectionState.RECONNECTING,
        SessionState.ConnectionState.AUTHENTICATING -> "Connecting" to AmberAccent
        SessionState.ConnectionState.ERROR -> "Retrying" to CoralError
        SessionState.ConnectionState.DISCONNECTED -> "HTTP :8080 Ready" to CyanAccent
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "AeroShare",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.3.sp
                ),
                color = TextPrimaryColor
            )

            Surface(
                color = CardBg,
                shape = RoundedCornerShape(50),
                border = BorderStroke(1.dp, statusColor.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(statusColor)
                    )
                    Text(
                        text = statusText,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.sp
                        ),
                        color = TextPrimaryColor
                    )
                }
            }
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            HeaderIconBtn(
                icon = Icons.Default.Terminal,
                contentDescription = "Terminal & Logs",
                tint = EmeraldAccent,
                testTag = "terminal_header_button",
                onClick = onOpenTerminal
            )
            HeaderIconBtn(
                icon = Icons.Default.Security,
                contentDescription = "Permissions",
                tint = CyanAccent,
                testTag = "permissions_header_button",
                onClick = onOpenPermissions
            )
            HeaderIconBtn(
                icon = Icons.Default.Settings,
                contentDescription = "Control Center",
                tint = TextSecondaryColor,
                testTag = "control_center_button",
                onClick = onOpenSettings
            )
        }
    }
}

@Composable
private fun HeaderIconBtn(
    icon: ImageVector,
    contentDescription: String,
    tint: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        color = CardBg,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, BorderSubtleColor),
        modifier = Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = tint,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun CleanConnectionCard(
    urlInput: String,
    onUrlChange: (String) -> Unit,
    isConnected: Boolean,
    isConnecting: Boolean,
    lastFailure: String?,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit
) {
    val isLocalSelected = urlInput.contains("127.0.0.1") || urlInput.contains("localhost")

    Surface(
        color = CardBg,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, if (isConnected) EmeraldAccent.copy(alpha = 0.45f) else BorderSubtleColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Dedicated 2-pill segmented endpoint switcher (never wraps vertically)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                EndpointSegmentPill(
                    label = "Tunnel",
                    selected = !isLocalSelected,
                    onClick = { onUrlChange(RealtimeConnectionService.DEFAULT_SERVER_URL) },
                    modifier = Modifier.weight(1f)
                )
                EndpointSegmentPill(
                    label = "Local",
                    selected = isLocalSelected,
                    onClick = { onUrlChange("ws://127.0.0.1:8000/ws") },
                    modifier = Modifier.weight(1f)
                )
            }

            OutlinedTextField(
                value = urlInput,
                onValueChange = onUrlChange,
                singleLine = true,
                placeholder = {
                    Text(
                        text = "wss://tunnel.trycloudflare.com/ws",
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                        color = TextSecondaryColor.copy(alpha = 0.5f)
                    )
                },
                textStyle = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = FontFamily.Monospace,
                    color = TextPrimaryColor
                ),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = if (isConnected) EmeraldAccent else CyanAccent,
                    unfocusedBorderColor = if (isConnected) EmeraldAccent.copy(alpha = 0.35f) else BorderSubtleColor,
                    focusedContainerColor = ConsoleBg,
                    unfocusedContainerColor = ConsoleBg
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("server_url_input")
            )

            if (!lastFailure.isNullOrBlank() && !isConnected) {
                Text(
                    text = lastFailure,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = AmberAccent.copy(alpha = 0.9f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onConnect,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isConnected) EmeraldAccent else CyanAccent
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("connect_bridge_button")
                ) {
                    Icon(
                        imageVector = if (isConnected) Icons.Default.CheckCircle else Icons.Default.Link,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = when {
                            isConnected -> "Connected"
                            isConnecting -> "Connecting..."
                            else -> "Connect"
                        },
                        color = Color.Black,
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }

                if (isConnected) {
                    OutlinedButton(
                        onClick = onConnect,
                        border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("refresh_bridge_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh Connection",
                            tint = CyanAccent,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                OutlinedButton(
                    onClick = onDisconnect,
                    border = BorderStroke(1.dp, BorderSubtleColor),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("disconnect_bridge_button")
                ) {
                    Text(
                        text = "Stop",
                        color = TextSecondaryColor,
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                }
            }
        }
    }
}

@Composable
private fun EndpointSegmentPill(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = if (selected) CyanAccent.copy(alpha = 0.16f) else ConsoleBg,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, if (selected) CyanAccent.copy(alpha = 0.6f) else BorderSubtleColor),
        modifier = modifier
            .height(36.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                color = if (selected) CyanAccent else TextSecondaryColor,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun CleanControlsGrid(
    isTorchOn: Boolean,
    isDndActive: Boolean,
    isAutoRotateOn: Boolean,
    ringerMode: String,
    brightnessLevel: Int,
    isLocationEnabled: Boolean,
    isLiveLocationTracking: Boolean = false,
    isAccessibilityEnabled: Boolean,
    hasClipboard: Boolean,
    onToggleTorch: () -> Unit,
    onToggleDnd: () -> Unit,
    onAccessibilityAction: () -> Unit,
    onOpenWifi: () -> Unit,
    onOpenBluetooth: () -> Unit,
    onOpenClipboard: () -> Unit,
    onCaptureScreenshot: () -> Unit,
    onOpenCamera: () -> Unit = {},
    onOpenMic: () -> Unit = {},
    onOpenNotif: () -> Unit = {},
    onOpenStorage: () -> Unit = {},
    onToggleAutoRotate: () -> Unit,
    onCycleRinger: () -> Unit,
    onOpenHotspot: () -> Unit,
    onOpenLocation: () -> Unit,
    onLockScreen: () -> Unit,
    onBrightnessChange: (Int) -> Unit,
    onVolumeAction: (String) -> Unit,
    onMediaAction: (String) -> Unit,
    onGlobalAction: (String) -> Unit,
    onOpenAdvancedTab: (Int) -> Unit
) {
    var sliderVal by remember(brightnessLevel) { mutableStateOf(brightnessLevel.toFloat()) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Row 1: Torch, DND, Inspect
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            IconTileButton(
                label = "Torch",
                icon = Icons.Default.FlashlightOn,
                isActive = isTorchOn,
                activeColor = AmberAccent,
                testTag = "toggle_torch_tile",
                onClick = onToggleTorch,
                modifier = Modifier.weight(1f)
            )
            IconTileButton(
                label = "DND",
                icon = Icons.Default.DoNotDisturbOn,
                isActive = isDndActive,
                activeColor = CoralError,
                testTag = "toggle_dnd_tile",
                onClick = onToggleDnd,
                modifier = Modifier.weight(1f)
            )
            IconTileButton(
                label = "Inspect",
                icon = Icons.Default.TouchApp,
                isActive = isAccessibilityEnabled,
                activeColor = EmeraldAccent,
                testTag = "toggle_accessibility_tile",
                onClick = onAccessibilityAction,
                modifier = Modifier.weight(1f)
            )
        }

        // Row 2: Wi-Fi, Bluetooth, Clip
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            IconTileButton(
                label = "Wi-Fi",
                icon = Icons.Default.Wifi,
                isActive = true,
                activeColor = CyanAccent,
                testTag = "toggle_wifi_tile",
                onClick = onOpenWifi,
                modifier = Modifier.weight(1f)
            )
            IconTileButton(
                label = "Bluetooth",
                icon = Icons.Default.Bluetooth,
                isActive = false,
                activeColor = CyanAccent,
                testTag = "toggle_bluetooth_tile",
                onClick = onOpenBluetooth,
                modifier = Modifier.weight(1f)
            )
            IconTileButton(
                label = "Clip",
                icon = Icons.Default.ContentPaste,
                isActive = hasClipboard,
                activeColor = EmeraldAccent,
                testTag = "toggle_clipboard_tile",
                onClick = onOpenClipboard,
                modifier = Modifier.weight(1f)
            )
        }

        // Row 3: Shot (Screenshot), Rotate (Auto-Rotate), Vibrate (Ringer Cycle + Haptic)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            IconTileButton(
                label = "Shot",
                icon = Icons.Default.CameraAlt,
                isActive = isAccessibilityEnabled,
                activeColor = CyanAccent,
                testTag = "capture_screenshot_tile",
                onClick = onCaptureScreenshot,
                modifier = Modifier.weight(1f)
            )
            IconTileButton(
                label = "Rotate",
                icon = Icons.Default.ScreenRotation,
                isActive = isAutoRotateOn,
                activeColor = EmeraldAccent,
                testTag = "toggle_rotate_tile",
                onClick = onToggleAutoRotate,
                modifier = Modifier.weight(1f)
            )
            IconTileButton(
                label = if (ringerMode == "NORMAL") "Vibrate" else ringerMode.lowercase().replaceFirstChar { it.uppercase() },
                icon = Icons.Default.Vibration,
                isActive = ringerMode != "NORMAL",
                activeColor = AmberAccent,
                testTag = "cycle_ringer_tile",
                onClick = onCycleRinger,
                modifier = Modifier.weight(1f)
            )
        }

        // Row 4: Hotspot, Location, Lock
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            IconTileButton(
                label = "Hotspot",
                icon = Icons.Default.WifiTethering,
                isActive = false,
                activeColor = CyanAccent,
                testTag = "open_hotspot_tile",
                onClick = onOpenHotspot,
                modifier = Modifier.weight(1f)
            )
            IconTileButton(
                label = if (isLiveLocationTracking) "GPS (Live)" else "Location",
                icon = Icons.Default.LocationOn,
                isActive = isLiveLocationTracking || isLocationEnabled,
                activeColor = if (isLiveLocationTracking) EmeraldAccent else CyanAccent,
                testTag = "open_location_tile",
                onClick = onOpenLocation,
                modifier = Modifier.weight(1f)
            )
            IconTileButton(
                label = "Lock",
                icon = Icons.Default.Lock,
                isActive = false,
                activeColor = CoralError,
                testTag = "lock_screen_tile",
                onClick = onLockScreen,
                modifier = Modifier.weight(1f)
            )
        }

        // Hardware Stations Bar (Camera, Mic, Notifications, Storage)
        Surface(
            color = CardBg,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, BorderSubtleColor),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "HARDWARE STATIONS (TEST & TELEMETRY)",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                    color = TextSecondaryColor
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StationPillButton(
                        label = "Camera",
                        icon = Icons.Default.CameraAlt,
                        tint = CyanAccent,
                        onClick = onOpenCamera,
                        modifier = Modifier.weight(1f)
                    )
                    StationPillButton(
                        label = "Mic",
                        icon = Icons.Default.Mic,
                        tint = AmberAccent,
                        onClick = onOpenMic,
                        modifier = Modifier.weight(1f)
                    )
                    StationPillButton(
                        label = "Notif",
                        icon = Icons.Default.Notifications,
                        tint = Color(0xFFA855F7),
                        onClick = onOpenNotif,
                        modifier = Modifier.weight(1f)
                    )
                    StationPillButton(
                        label = "Storage",
                        icon = Icons.Default.Folder,
                        tint = EmeraldAccent,
                        onClick = onOpenStorage,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Row 5: Compact Brightness Slider Bar
        Surface(
            color = CardBg,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, BorderSubtleColor),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.BrightnessMedium,
                    contentDescription = "Brightness",
                    tint = AmberAccent,
                    modifier = Modifier.size(18.dp)
                )
                Slider(
                    value = sliderVal,
                    onValueChange = { sliderVal = it },
                    onValueChangeFinished = { onBrightnessChange(sliderVal.toInt()) },
                    valueRange = 10f..255f,
                    colors = SliderDefaults.colors(
                        thumbColor = AmberAccent,
                        activeTrackColor = AmberAccent,
                        inactiveTrackColor = BorderSubtleColor
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(32.dp)
                        .testTag("brightness_slider")
                )
                Text(
                    text = "${((sliderVal / 255f) * 100).toInt()}%",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold
                    ),
                    color = TextSecondaryColor
                )
            }
        }

        // Row 6: Full-width evenly-spaced icon-only Media, Volume & Global Navigation Bar
        Surface(
            color = CardBg,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, BorderSubtleColor),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    MediaIconBtn(
                        icon = Icons.AutoMirrored.Filled.VolumeDown,
                        contentDescription = "Volume Down",
                        onClick = { onVolumeAction("down") }
                    )
                    MediaIconBtn(
                        icon = Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = "Volume Up",
                        onClick = { onVolumeAction("up") }
                    )
                    MediaIconBtn(
                        icon = Icons.AutoMirrored.Filled.VolumeOff,
                        contentDescription = "Mute",
                        onClick = { onVolumeAction("mute") }
                    )
                    MediaIconBtn(
                        icon = Icons.Default.SkipPrevious,
                        contentDescription = "Previous Track",
                        onClick = { onMediaAction("PREVIOUS") }
                    )
                    MediaIconBtn(
                        icon = Icons.Default.PlayArrow,
                        contentDescription = "Play or Pause",
                        onClick = { onMediaAction("PLAY_PAUSE") }
                    )
                    MediaIconBtn(
                        icon = Icons.Default.SkipNext,
                        contentDescription = "Next Track",
                        onClick = { onMediaAction("NEXT") }
                    )
                }

                HorizontalDivider(color = BorderSubtleColor.copy(alpha = 0.6f))

                // Global System Navigation Actions (Back, Home, Recents, Notification Shade)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    MediaIconBtn(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "System Back",
                        onClick = { onGlobalAction("BACK") }
                    )
                    MediaIconBtn(
                        icon = Icons.Default.Home,
                        contentDescription = "System Home",
                        onClick = { onGlobalAction("HOME") }
                    )
                    MediaIconBtn(
                        icon = Icons.Default.ViewCarousel,
                        contentDescription = "Recents Overview",
                        onClick = { onGlobalAction("RECENTS") }
                    )
                    MediaIconBtn(
                        icon = Icons.Default.Notifications,
                        contentDescription = "Notification Shade",
                        onClick = { onGlobalAction("NOTIFICATIONS") }
                    )
                }
            }
        }

        // Row 7: Quick Launch Tiles for Audio/TTS, Gesture Pad & Apps + Expandable Advanced Controls Drawer
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            IconTileButton(
                label = "Speak",
                icon = Icons.AutoMirrored.Filled.VolumeUp,
                isActive = false,
                activeColor = CyanAccent,
                testTag = "open_tts_tile",
                onClick = { onOpenAdvancedTab(0) },
                modifier = Modifier.weight(1f)
            )
            IconTileButton(
                label = "Pad",
                icon = Icons.Default.TouchApp,
                isActive = isAccessibilityEnabled,
                activeColor = EmeraldAccent,
                testTag = "open_gesture_pad_tile",
                onClick = { onOpenAdvancedTab(1) },
                modifier = Modifier.weight(1f)
            )
            IconTileButton(
                label = "Apps",
                icon = Icons.Default.Apps,
                isActive = false,
                activeColor = AmberAccent,
                testTag = "open_apps_tile",
                onClick = { onOpenAdvancedTab(2) },
                modifier = Modifier.weight(1f)
            )
        }

        // Row 8: Expandable Advanced Controls Drawer Bar (Media, Files, SMS, Dialer, Telemetry)
        Surface(
            color = CardBg,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.35f)),
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .clickable { onOpenAdvancedTab(0) }
                .testTag("open_advanced_controls_drawer")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "More Controls",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                        color = TextPrimaryColor
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf(
                        "Audio" to 0,
                        "Touch" to 1,
                        "Sys" to 2,
                        "Media" to 3,
                        "SMS" to 4
                    ).forEach { (tag, tabIdx) ->
                        Surface(
                            color = ConsoleBg,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, BorderSubtleColor),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onOpenAdvancedTab(tabIdx) }
                        ) {
                            Text(
                                text = tag,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold
                                ),
                                color = CyanAccent,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun IconTileButton(
    label: String,
    icon: ImageVector,
    isActive: Boolean,
    activeColor: Color,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor = if (isActive) activeColor.copy(alpha = 0.6f) else BorderSubtleColor
    val bgColor = if (isActive) activeColor.copy(alpha = 0.12f) else CardBg

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, borderColor),
        modifier = modifier
            .height(82.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isActive) activeColor else TextSecondaryColor,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium
                ),
                color = if (isActive) TextPrimaryColor else TextSecondaryColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun MediaIconBtn(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit
) {
    IconButton(
        onClick = onClick,
        modifier = Modifier.size(48.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = TextPrimaryColor.copy(alpha = 0.85f),
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun TerminalDrawerTriggerBar(
    latestLog: String?,
    logCount: Int,
    onClick: () -> Unit
) {
    Surface(
        color = CardBg,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, BorderSubtleColor),
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .testTag("open_terminal_drawer_bar")
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Default.Terminal,
                    contentDescription = null,
                    tint = EmeraldAccent,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = latestLog ?: "Terminal & Live Logs",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp
                    ),
                    color = if (latestLog != null) TextPrimaryColor else TextSecondaryColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (logCount > 0) {
                Spacer(modifier = Modifier.width(8.dp))
                Surface(
                    color = CardElevatedBg,
                    shape = RoundedCornerShape(50)
                ) {
                    Text(
                        text = "$logCount",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp
                        ),
                        color = CyanAccent,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TerminalAndLogsBottomSheet(
    logs: List<String>,
    selectedFilter: String,
    onFilterSelect: (String) -> Unit,
    shellInput: String,
    onShellInputChange: (String) -> Unit,
    lastCommandOutput: String?,
    onDismissCommandOutput: () -> Unit,
    onExecuteCommand: () -> Unit,
    onClearLogs: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = CardBg,
        contentColor = TextPrimaryColor
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = null,
                        tint = EmeraldAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "Terminal & Logs",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = TextPrimaryColor
                    )
                }

                IconButton(
                    onClick = onClearLogs,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("clear_logs_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ClearAll,
                        contentDescription = "Clear Logs",
                        tint = TextSecondaryColor
                    )
                }
            }

            // Shell Input Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = shellInput,
                    onValueChange = onShellInputChange,
                    singleLine = true,
                    placeholder = {
                        Text(
                            text = "sh -c command (e.g. uname -a)...",
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                            color = TextSecondaryColor.copy(alpha = 0.6f)
                        )
                    },
                    textStyle = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = FontFamily.Monospace,
                        color = EmeraldAccent
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { onExecuteCommand() }),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EmeraldAccent,
                        unfocusedBorderColor = BorderSubtleColor,
                        focusedContainerColor = ConsoleBg,
                        unfocusedContainerColor = ConsoleBg
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("shell_command_input")
                )

                Button(
                    onClick = onExecuteCommand,
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .height(52.dp)
                        .testTag("shell_exec_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Run Command",
                        tint = Color.Black,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Filter Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("ALL", "HTTP", "WS", "SHELL", "SYSTEM").forEach { filter ->
                    val selected = selectedFilter == filter
                    FilterChip(
                        selected = selected,
                        onClick = { onFilterSelect(filter) },
                        label = {
                            Text(
                                text = filter,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyanAccent.copy(alpha = 0.2f),
                            selectedLabelColor = CyanAccent,
                            containerColor = CardElevatedBg,
                            labelColor = TextSecondaryColor
                        )
                    )
                }
            }

            if (!lastCommandOutput.isNullOrBlank()) {
                Surface(
                    color = ConsoleBg,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, EmeraldAccent.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Output",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = EmeraldAccent
                            )
                            Text(
                                text = "Clear",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondaryColor,
                                modifier = Modifier.clickable(onClick = onDismissCommandOutput)
                            )
                        }
                        Text(
                            text = lastCommandOutput,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            ),
                            color = TextPrimaryColor
                        )
                    }
                }
            }

            Surface(
                color = ConsoleBg,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, BorderSubtleColor),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 200.dp, max = 360.dp)
            ) {
                if (logs.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No events yet",
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                            color = TextSecondaryColor
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(logs.take(100)) { entry ->
                            val lineColor = when {
                                entry.contains("ERR", ignoreCase = true) ||
                                        entry.contains("FAIL", ignoreCase = true) -> CoralError
                                entry.contains("SHELL", ignoreCase = true) ||
                                        entry.contains("200 OK", ignoreCase = true) -> EmeraldAccent
                                entry.contains("HTTP", ignoreCase = true) -> CyanAccent
                                else -> TextPrimaryColor.copy(alpha = 0.9f)
                            }
                            Text(
                                text = entry,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    lineHeight = 15.sp
                                ),
                                color = lineColor
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun UnifiedControlCenterSheet(
    viewModel: DashboardViewModel,
    permissionManager: PermissionManager,
    onOpenPermissionsModal: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var selectedTab by remember { mutableIntStateOf(0) }
    var refreshNonce by remember { mutableIntStateOf(0) }
    val context = LocalContext.current

    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                refreshNonce++
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val batchLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        refreshNonce++
    }

    val specialItems = remember(refreshNonce) {
        permissionManager.allDefinedPermissions
            .filter { it.specialSettingType != com.example.capabilities.permissions.SpecialSettingType.NONE }
            .map { item ->
                val state = permissionManager.getPermissionItemState(item)
                item to (state == com.example.capabilities.permissions.PermissionState.GRANTED ||
                        state == com.example.capabilities.permissions.PermissionState.NOT_REQUIRED)
            }
    }

    val missingRuntime = remember(refreshNonce) {
        permissionManager.getRuntimePermissionsToRequest()
    }

    val pairedDevices = remember(selectedTab) { viewModel.securityShield.listPairedDevices() }
    val pairingCodeInfo = remember(selectedTab) { viewModel.securityShield.getActivePairingCode() }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = CardBg,
        contentColor = TextPrimaryColor
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = ConsoleBg,
                contentColor = CyanAccent
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Access", style = MaterialTheme.typography.labelMedium) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Security", style = MaterialTheme.typography.labelMedium) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("API", style = MaterialTheme.typography.labelMedium) }
                )
            }

            when (selectedTab) {
                0 -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (missingRuntime.isNotEmpty()) {
                                    batchLauncher.launch(missingRuntime.toTypedArray())
                                } else {
                                    onOpenPermissionsModal()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                        ) {
                            Text(
                                text = if (missingRuntime.isNotEmpty()) "Grant Runtime (${missingRuntime.size})" else "All Runtime Granted",
                                color = Color.Black,
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }

                        OutlinedButton(
                            onClick = onOpenPermissionsModal,
                            border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                        ) {
                            Text(
                                text = "All 55+ Permissions",
                                color = CyanAccent,
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                            )
                        }
                    }

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 380.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(specialItems, key = { it.first.id }) { (item, isGranted) ->
                            PermissionShortcutRow(
                                title = item.displayName,
                                isGranted = isGranted,
                                onClick = {
                                    try {
                                        context.startActivity(permissionManager.createSpecialIntent(item))
                                    } catch (_: Exception) {}
                                }
                            )
                        }

                        item {
                            PermissionShortcutRow(
                                title = "Save Server Scripts (/sdcard/Download/AeroShare)",
                                isGranted = true,
                                onClick = {
                                    viewModel.exportServerScripts()
                                    onDismiss()
                                }
                            )
                        }
                    }
                }

                1 -> {
                    var currentAuthMode by remember { mutableStateOf(viewModel.securityShield.authMode) }
                    val masterToken = remember { viewModel.securityShield.masterApiToken }

                    Surface(
                        color = ConsoleBg,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, BorderSubtleColor),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Mode: $currentAuthMode",
                                    style = MaterialTheme.typography.labelLarge.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = if (currentAuthMode == "OPEN") AmberAccent else EmeraldAccent
                                )
                                OutlinedButton(
                                    onClick = {
                                        val nextMode = if (currentAuthMode == "OPEN") "STRICT" else "OPEN"
                                        viewModel.securityShield.authMode = nextMode
                                        currentAuthMode = nextMode
                                    },
                                    border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.6f)),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                    modifier = Modifier.height(34.dp)
                                ) {
                                    Text(
                                        text = if (currentAuthMode == "OPEN") "Switch to STRICT" else "Switch to OPEN",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CyanAccent
                                    )
                                }
                            }

                            Text(
                                text = "6-Digit Pair Code: ${pairingCodeInfo.first}",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = TextPrimaryColor
                            )

                            Text(
                                text = "Master Token: ${masterToken.take(20)}...",
                                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                                color = TextSecondaryColor
                            )

                            Text(
                                text = "Authorized Devices: ${pairedDevices.size}",
                                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                                color = TextSecondaryColor
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        viewModel.updateClipboard(masterToken)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(40.dp)
                                ) {
                                    Text(
                                        text = "Copy Master Token",
                                        color = Color.Black,
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                }
                                OutlinedButton(
                                    onClick = {
                                        viewModel.exportServerScripts()
                                    },
                                    border = BorderStroke(1.dp, CyanAccent.copy(alpha = 0.6f)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(40.dp)
                                ) {
                                    Text(
                                        text = "Update Scripts",
                                        color = CyanAccent,
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                                    )
                                }
                            }
                        }
                    }
                }

                2 -> {
                    val endpoints = listOf(
                        "POST /api/shell/exec",
                        "POST /api/screen/capture",
                        "POST /api/ui/tree",
                        "POST /api/ui/action",
                        "POST /api/system/toggle (torch, dnd, rotate, vibrate, hotspot, location, lock, shade, screenshot, brightness, volume, media)",
                        "GET  /api/system/status",
                        "POST /api/fs/list | read | write | delete",
                        "POST /api/clipboard/get | set",
                        "POST /api/server/export"
                    )
                    Surface(
                        color = ConsoleBg,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, BorderSubtleColor),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            endpoints.forEach { ep ->
                                Text(
                                    text = ep,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.sp
                                    ),
                                    color = TextPrimaryColor
                                )
                                HorizontalDivider(color = BorderSubtleColor.copy(alpha = 0.5f))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionShortcutRow(
    title: String,
    isGranted: Boolean = true,
    onClick: () -> Unit
) {
    val badgeColor = if (isGranted) EmeraldAccent else AmberAccent
    Surface(
        color = ConsoleBg,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, if (isGranted) EmeraldAccent.copy(alpha = 0.35f) else BorderSubtleColor),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                color = TextPrimaryColor,
                modifier = Modifier.weight(1f)
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = if (isGranted) "Active" else "Enable",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 10.sp
                    ),
                    color = badgeColor
                )
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = badgeColor,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun borderBrush() = BorderStroke(
    width = 1.dp,
    color = BorderSubtleColor
)

@Composable
private fun StationPillButton(
    label: String,
    icon: ImageVector,
    tint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = ConsoleBg,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, tint.copy(alpha = 0.45f)),
        modifier = modifier
            .height(36.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = tint,
                modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                ),
                color = TextPrimaryColor,
                maxLines = 1
            )
        }
    }
}
