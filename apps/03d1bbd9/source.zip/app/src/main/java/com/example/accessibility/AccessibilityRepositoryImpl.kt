package com.example.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import com.example.accessibility.models.AccessibilityEventModel
import com.example.accessibility.models.AccessibilityNodeModel
import com.example.accessibility.models.AccessibilityServiceStatus
import com.example.accessibility.models.GestureRequestModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object AccessibilityServiceRegistry {
    @Volatile
    var activeService: AccessibilityService? = null
        set(value) {
            field = value
            onServiceStateChangedListener?.invoke(value != null)
        }

    var onServiceStateChangedListener: ((Boolean) -> Unit)? = null
}

class AccessibilityRepositoryImpl : AccessibilityRepository {

    private val _serviceStatus = MutableStateFlow(AccessibilityServiceStatus())
    override val serviceStatus: StateFlow<AccessibilityServiceStatus> = _serviceStatus.asStateFlow()

    private val _recentEvents = MutableStateFlow<List<AccessibilityEventModel>>(emptyList())
    override val recentEvents: StateFlow<List<AccessibilityEventModel>> = _recentEvents.asStateFlow()

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    override val logs: StateFlow<List<String>> = _logs.asStateFlow()

    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    init {
        // Track connection and active status changes
        updateStatus()
        AccessibilityServiceRegistry.onServiceStateChangedListener = {
            updateStatus()
        }
    }

    private fun updateStatus() {
        val isEnabled = AccessibilityServiceRegistry.activeService != null
        _serviceStatus.value = AccessibilityServiceStatus(
            isEnabled = isEnabled,
            lastConnectedTime = if (isEnabled) System.currentTimeMillis() else _serviceStatus.value.lastConnectedTime,
            recentEventsCount = _recentEvents.value.size,
            recentGesturesCount = _serviceStatus.value.recentGesturesCount
        )
        addLog("Accessibility service status updated. isEnabled = $isEnabled")
    }

    override fun triggerGesture(gesture: GestureRequestModel, onComplete: (Boolean) -> Unit) {
        val service = AccessibilityServiceRegistry.activeService
        if (service == null) {
            addLog("GESTURE ERROR: Cannot perform gesture; Accessibility Service is disabled.")
            onComplete(false)
            return
        }

        val typeUpper = gesture.type.uppercase()
        if (typeUpper == "BACK" || typeUpper == "GLOBAL_BACK") {
            val success = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            addLog("GLOBAL ACTION BACK: success=$success")
            onComplete(success)
            return
        }
        if (typeUpper == "HOME" || typeUpper == "GLOBAL_HOME") {
            val success = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            addLog("GLOBAL ACTION HOME: success=$success")
            onComplete(success)
            return
        }
        if (typeUpper == "RECENTS" || typeUpper == "GLOBAL_RECENTS") {
            val success = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
            addLog("GLOBAL ACTION RECENTS: success=$success")
            onComplete(success)
            return
        }
        if (typeUpper == "NOTIFICATIONS" || typeUpper == "GLOBAL_NOTIFICATIONS") {
            val success = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            addLog("GLOBAL ACTION NOTIFICATIONS: success=$success")
            onComplete(success)
            return
        }
        if (typeUpper == "QUICK_SETTINGS" || typeUpper == "GLOBAL_QUICK_SETTINGS") {
            val success = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
            addLog("GLOBAL ACTION QUICK_SETTINGS: success=$success")
            onComplete(success)
            return
        }
        if (typeUpper == "POWER_DIALOG" || typeUpper == "GLOBAL_POWER_DIALOG") {
            val success = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG)
            addLog("GLOBAL ACTION POWER_DIALOG: success=$success")
            onComplete(success)
            return
        }
        if (typeUpper == "LOCK_SCREEN" || typeUpper == "GLOBAL_LOCK_SCREEN") {
            val success = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            } else false
            addLog("GLOBAL ACTION LOCK_SCREEN: success=$success")
            onComplete(success)
            return
        }
        if (typeUpper == "TAKE_SCREENSHOT" || typeUpper == "SCREENSHOT") {
            val success = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            } else false
            addLog("GLOBAL ACTION TAKE_SCREENSHOT: success=$success")
            onComplete(success)
            return
        }

        try {
            val path = Path()
            path.moveTo(gesture.startX, gesture.startY)
            if (typeUpper == "SWIPE" || typeUpper == "DRAG") {
                path.lineTo(gesture.endX, gesture.endY)
            } else {
                // Click or Long-Click gesture
                path.lineTo(gesture.startX + 1f, gesture.startY + 1f)
            }

            val defaultDur = if (typeUpper == "LONG_CLICK" || typeUpper == "LONG_PRESS") 650L else 100L
            val stroke = GestureDescription.StrokeDescription(
                path,
                0L,
                if (gesture.durationMs <= 0) defaultDur else gesture.durationMs
            )

            val builder = GestureDescription.Builder()
            builder.addStroke(stroke)
            val desc = builder.build()

            addLog("DISPATCH GESTURE: type=${gesture.type}, start=(${gesture.startX}, ${gesture.startY}), duration=${gesture.durationMs}ms")
            
            service.dispatchGesture(desc, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    addLog("GESTURE SUCCESS: id=${gesture.id}")
                    _serviceStatus.value = _serviceStatus.value.copy(
                        recentGesturesCount = _serviceStatus.value.recentGesturesCount + 1
                    )
                    onComplete(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    addLog("GESTURE CANCELLED: id=${gesture.id}")
                    onComplete(false)
                }
            }, null)

        } catch (e: Exception) {
            addLog("GESTURE FAILURE: id=${gesture.id}, error=${e.message}")
            onComplete(false)
        }
    }

    override fun clickNodeByText(text: String, onComplete: (Boolean) -> Unit) {
        val matches = searchNodes(text = text, contentDescription = text, viewId = null)
        val target = matches.firstOrNull { it.isClickable } ?: matches.firstOrNull()
        if (target != null) {
            val bounds = target.bounds
            val regex = java.util.regex.Pattern.compile("\\d+")
            val matcher = regex.matcher(bounds)
            val nums = mutableListOf<Int>()
            while (matcher.find()) {
                nums.add(matcher.group().toInt())
            }
            if (nums.size == 4) {
                val cx = ((nums[0] + nums[2]) / 2).toFloat()
                val cy = ((nums[1] + nums[3]) / 2).toFloat()
                val req = GestureRequestModel(
                    id = "click_text_" + System.currentTimeMillis(),
                    type = "CLICK",
                    startX = cx,
                    startY = cy,
                    durationMs = 100
                )
                triggerGesture(req, onComplete)
                return
            }
        }
        onComplete(false)
    }

    override fun performScroll(forward: Boolean, onComplete: (Boolean) -> Unit) {
        val req = GestureRequestModel(
            id = "scroll_" + System.currentTimeMillis(),
            type = "SWIPE",
            startX = 500f,
            startY = if (forward) 1400f else 400f,
            endX = 500f,
            endY = if (forward) 300f else 1400f,
            durationMs = 250
        )
        triggerGesture(req, onComplete)
    }

    override fun inputText(text: String, targetLabel: String?, onComplete: (Boolean) -> Unit) {
        val service = AccessibilityServiceRegistry.activeService
        if (service == null) {
            addLog("INPUT TEXT ERROR: Accessibility Service is disabled.")
            onComplete(false)
            return
        }
        val root = service.rootInActiveWindow
        if (root == null) {
            addLog("INPUT TEXT ERROR: rootInActiveWindow is null.")
            onComplete(false)
            return
        }

        fun findEditableNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (node == null) return null
            if (!targetLabel.isNullOrBlank()) {
                val matchesTarget = (node.text?.toString()?.contains(targetLabel, ignoreCase = true) == true) ||
                        (node.contentDescription?.toString()?.contains(targetLabel, ignoreCase = true) == true) ||
                        (node.viewIdResourceName?.contains(targetLabel, ignoreCase = true) == true)
                if (matchesTarget && (node.isEditable || node.className?.toString()?.contains("EditText", ignoreCase = true) == true)) {
                    return node
                }
            } else if (node.isEditable && node.isFocused) {
                return node
            }
            for (i in 0 until node.childCount) {
                val found = findEditableNode(node.getChild(i))
                if (found != null) return found
            }
            return null
        }

        fun findAnyEditableNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (node == null) return null
            if (node.isEditable || node.className?.toString()?.contains("EditText", ignoreCase = true) == true) {
                return node
            }
            for (i in 0 until node.childCount) {
                val found = findAnyEditableNode(node.getChild(i))
                if (found != null) return found
            }
            return null
        }

        val targetNode = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }
            ?: findEditableNode(root)
            ?: findAnyEditableNode(root)

        if (targetNode != null) {
            val args = android.os.Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            targetNode.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val ok = targetNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            addLog("INPUT TEXT: '$text' -> success=$ok")
            onComplete(ok)
        } else {
            addLog("INPUT TEXT FAILED: No editable text field found on screen.")
            onComplete(false)
        }
    }

    override fun takeScreenshotBase64(quality: Int, maxDimension: Int): org.json.JSONObject {
        val result = org.json.JSONObject()
        val service = AccessibilityServiceRegistry.activeService
        if (service != null && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            val latch = java.util.concurrent.CountDownLatch(1)
            var capturedBitmap: android.graphics.Bitmap? = null
            var errorCode = -1
            try {
                service.takeScreenshot(
                    android.view.Display.DEFAULT_DISPLAY,
                    java.util.concurrent.Executors.newSingleThreadExecutor(),
                    object : AccessibilityService.TakeScreenshotCallback {
                        override fun onSuccess(screenshot: AccessibilityService.ScreenshotResult) {
                            try {
                                val hwBitmap = android.graphics.Bitmap.wrapHardwareBuffer(
                                    screenshot.hardwareBuffer,
                                    screenshot.colorSpace
                                )
                                capturedBitmap = hwBitmap?.copy(android.graphics.Bitmap.Config.ARGB_8888, false)
                                screenshot.hardwareBuffer.close()
                            } catch (e: Exception) {
                                addLog("SCREENSHOT BUFFER ERROR: ${e.message}")
                            } finally {
                                latch.countDown()
                            }
                        }

                        override fun onFailure(errCode: Int) {
                            errorCode = errCode
                            addLog("SCREENSHOT FAILED: code=$errCode")
                            latch.countDown()
                        }
                    }
                )
                latch.await(4, java.util.concurrent.TimeUnit.SECONDS)
            } catch (e: Exception) {
                addLog("SCREENSHOT EXCEPTION: ${e.message}")
            }

            val bmp = capturedBitmap
            if (bmp != null) {
                val origW = bmp.width
                val origH = bmp.height
                val scale = if (origW > maxDimension || origH > maxDimension) {
                    maxDimension.toFloat() / kotlin.math.max(origW, origH).toFloat()
                } else 1.0f
                val finalBmp = if (scale < 1.0f) {
                    android.graphics.Bitmap.createScaledBitmap(
                        bmp,
                        (origW * scale).toInt().coerceAtLeast(1),
                        (origH * scale).toInt().coerceAtLeast(1),
                        true
                    )
                } else bmp

                val baos = java.io.ByteArrayOutputStream()
                finalBmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, quality.coerceIn(10, 100), baos)
                val bytes = baos.toByteArray()
                val b64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)

                addLog("SCREENSHOT CAPTURED: ${finalBmp.width}x${finalBmp.height} (${bytes.size / 1024} KB)")
                result.put("success", true)
                result.put("format", "jpeg")
                result.put("width", finalBmp.width)
                result.put("height", finalBmp.height)
                result.put("sizeBytes", bytes.size)
                result.put("base64", b64)
                return result
            } else {
                result.put("success", false)
                result.put("error", "Accessibility takeScreenshot failed (errorCode=$errorCode). Rate limit is 1 screenshot/sec on Android.")
                return result
            }
        }

        // Fallback: try shell screencap if AccessibilityService is not active
        try {
            val proc = ProcessBuilder("sh", "-c", "screencap -p").start()
            val bytes = proc.inputStream.readBytes()
            val finished = proc.waitFor(3, java.util.concurrent.TimeUnit.SECONDS)
            if (finished && proc.exitValue() == 0 && bytes.size > 100) {
                val bmp = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (bmp != null) {
                    val baos = java.io.ByteArrayOutputStream()
                    bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, quality.coerceIn(10, 100), baos)
                    val jpgBytes = baos.toByteArray()
                    val b64 = android.util.Base64.encodeToString(jpgBytes, android.util.Base64.NO_WRAP)
                    result.put("success", true)
                    result.put("format", "jpeg")
                    result.put("width", bmp.width)
                    result.put("height", bmp.height)
                    result.put("sizeBytes", jpgBytes.size)
                    result.put("base64", b64)
                    return result
                }
            }
        } catch (_: Exception) {}

        result.put("success", false)
        result.put("error", if (service == null) {
            "Accessibility Service is not enabled. Enable 'AeroShare / Termux Accessibility' in Android Settings > Accessibility to capture screenshots."
        } else {
            "Live screenshot capture requires Android 11 (API 30) or higher."
        })
        return result
    }

    override fun getFullNodeTree(): List<AccessibilityNodeModel> {
        val service = AccessibilityServiceRegistry.activeService
        if (service == null) {
            addLog("INSPECT ERROR: Service not active.")
            return emptyList()
        }

        val rootNode = service.rootInActiveWindow
        if (rootNode == null) {
            addLog("INSPECT WARNING: rootInActiveWindow returned null.")
            return emptyList()
        }

        val nodes = mutableListOf<AccessibilityNodeModel>()
        convertNodeInfo(rootNode)?.let { nodes.add(it) }
        return nodes
    }

    override fun searchNodes(text: String?, contentDescription: String?, viewId: String?): List<AccessibilityNodeModel> {
        val allNodes = getFullNodeTree()
        val results = mutableListOf<AccessibilityNodeModel>()
        
        fun searchRecursive(node: AccessibilityNodeModel) {
            var match = false
            if (text != null && node.text?.contains(text, ignoreCase = true) == true) match = true
            if (contentDescription != null && node.contentDescription?.contains(contentDescription, ignoreCase = true) == true) match = true
            if (viewId != null && node.viewId?.contains(viewId, ignoreCase = true) == true) match = true
            
            if (match) {
                results.add(node)
            }
            
            for (child in node.children) {
                searchRecursive(child)
            }
        }

        for (node in allNodes) {
            searchRecursive(node)
        }

        addLog("SEARCH NODES: query(text=$text, desc=$contentDescription, id=$viewId) -> found ${results.size} matches")
        return results
    }

    override fun addLog(message: String) {
        val timestamp = timeFormat.format(Date())
        val formatted = "[$timestamp] $message"
        _logs.value = (listOf(formatted) + _logs.value).take(150)
    }

    override fun addEvent(event: AccessibilityEventModel) {
        _recentEvents.value = (listOf(event) + _recentEvents.value).take(100)
        _serviceStatus.value = _serviceStatus.value.copy(
            recentEventsCount = _recentEvents.value.size
        )
    }

    private fun convertNodeInfo(node: AccessibilityNodeInfo?): AccessibilityNodeModel? {
        if (node == null) return null
        val bounds = Rect()
        node.getBoundsInScreen(bounds)

        val childList = mutableListOf<AccessibilityNodeModel>()
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            if (child != null) {
                convertNodeInfo(child)?.let { childList.add(it) }
            }
        }

        return AccessibilityNodeModel(
            text = node.text?.toString(),
            contentDescription = node.contentDescription?.toString(),
            viewId = node.viewIdResourceName,
            className = node.className?.toString(),
            isClickable = node.isClickable,
            isScrollable = node.isScrollable,
            isEditable = node.isEditable,
            isFocused = node.isFocused,
            bounds = "[${bounds.left},${bounds.top}][${bounds.right},${bounds.bottom}]",
            children = childList
        )
    }
}
