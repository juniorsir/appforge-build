package com.example.services

import android.app.Notification
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class NotificationItemUi(
    val key: String,
    val packageName: String,
    val title: String,
    val text: String,
    val postTime: Long,
    val isClearable: Boolean
)

/**
 * Real Android NotificationListenerService that registers AeroShare in
 * Android's "Notification read, reply & control" special access settings
 * and exposes live status bar notifications to the Device Bridge and UI.
 */
class AeroNotificationListenerService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        activeInstance = this
        _isConnected.value = true
        refreshActiveNotifications()
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        if (activeInstance === this) {
            activeInstance = null
        }
        _isConnected.value = false
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        refreshActiveNotifications()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
        refreshActiveNotifications()
    }

    fun refreshActiveNotifications(): JSONArray {
        val arr = JSONArray()
        val uiItems = mutableListOf<NotificationItemUi>()
        try {
            val list = activeNotifications ?: emptyArray()
            for (sbn in list.take(50)) {
                val extras = sbn.notification?.extras
                val title = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: ""
                val text = extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim() ?: ""
                val keyStr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) sbn.key else sbn.id.toString()
                val pkg = sbn.packageName ?: ""
                arr.put(JSONObject().apply {
                    put("key", keyStr)
                    put("id", sbn.id)
                    put("packageName", pkg)
                    put("title", title)
                    put("text", text)
                    put("postTime", sbn.postTime)
                    put("isClearable", sbn.isClearable)
                })
                if (title.isNotEmpty() || text.isNotEmpty()) {
                    uiItems.add(
                        NotificationItemUi(
                            key = keyStr,
                            packageName = pkg,
                            title = title.ifEmpty { pkg.substringAfterLast('.') },
                            text = text,
                            postTime = sbn.postTime,
                            isClearable = sbn.isClearable
                        )
                    )
                }
            }
            _notificationsFlow.value = uiItems
        } catch (_: Exception) {}
        return arr
    }

    fun dismissNotificationKey(key: String): Boolean {
        return try {
            cancelNotification(key)
            refreshActiveNotifications()
            true
        } catch (_: Exception) {
            false
        }
    }

    fun dismissAllNotifications(): Boolean {
        return try {
            cancelAllNotifications()
            refreshActiveNotifications()
            true
        } catch (_: Exception) {
            false
        }
    }

    companion object {
        @Volatile
        var activeInstance: AeroNotificationListenerService? = null
            private set

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

        private val _notificationsFlow = MutableStateFlow<List<NotificationItemUi>>(emptyList())
        val notificationsFlow: StateFlow<List<NotificationItemUi>> = _notificationsFlow.asStateFlow()
    }
}
