package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.presentation.dashboard.DashboardScreen
import com.example.presentation.dashboard.DashboardViewModel
import com.example.ui.security.FaceDeviceAuthDialog
import com.example.ui.theme.MyApplicationTheme

/**
 * Main Activity hosting the single-screen AeroShare Device Bridge & Command Console.
 */
class MainActivity : ComponentActivity() {
    private val requestMultiplePermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        permissions.entries.forEach {
            android.util.Log.d("MainActivity", "Permission ${it.key} granted: ${it.value}")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleAuthIntent(intent)

        val permissionsToRequest = mutableListOf(
            android.Manifest.permission.CAMERA,
            android.Manifest.permission.RECORD_AUDIO,
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            permissionsToRequest.add(android.Manifest.permission.POST_NOTIFICATIONS)
        }
        requestMultiplePermissionsLauncher.launch(permissionsToRequest.toTypedArray())

        enableEdgeToEdge()

        try {
            com.example.services.RealtimeConnectionService.connect(applicationContext)
        } catch (e: Exception) {
            android.util.Log.w("MainActivity", "Failed starting RealtimeConnectionService", e)
        }

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val appContainer = (applicationContext as? BaseApplication)?.container
                    val pendingPairRequest = appContainer?.securityShield?.latestPendingPairRequest?.collectAsStateWithLifecycle()?.value

                    if (pendingPairRequest != null && appContainer != null) {
                        FaceDeviceAuthDialog(
                            request = pendingPairRequest,
                            onAuthorize = { reqId ->
                                appContainer.securityShield.approvePendingPairRequest(reqId)
                            },
                            onDeny = { reqId ->
                                appContainer.securityShield.denyPendingPairRequest(reqId)
                            },
                            onDismiss = {
                                appContainer.securityShield.dismissPendingPairRequest()
                            }
                        )
                    }

                    val dashboardViewModel: DashboardViewModel = viewModel(
                        factory = DashboardViewModel.Factory
                    )
                    DashboardScreen(viewModel = dashboardViewModel)
                }
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleAuthIntent(intent)
    }

    private fun handleAuthIntent(intent: android.content.Intent?) {
        val reqId = intent?.getStringExtra("AUTH_REQUEST_ID") ?: return
        val appContainer = (applicationContext as? BaseApplication)?.container ?: return
        val req = appContainer.securityShield.getPendingPairRequest(reqId)
        if (req != null) {
            appContainer.securityShield.showPendingPairRequest(req)
        }
    }
}
