package com.example.presentation.dashboard

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.BaseApplication
import com.example.accessibility.AccessibilityRepository
import com.example.accessibility.models.AccessibilityServiceStatus
import com.example.audio.AudioCaptureEngine
import com.example.domain.model.AudioCaptureState
import com.example.domain.model.ChatMessage
import com.example.domain.model.CompanionConfig
import com.example.domain.model.SessionState
import com.example.domain.repository.WebSocketRepository
import com.example.domain.usecase.GetCompanionConfigUseCase
import com.example.domain.usecase.GetSessionHistoryUseCase
import com.example.domain.usecase.GetSessionStateUseCase
import com.example.domain.usecase.SaveCompanionConfigUseCase
import com.example.domain.usecase.SendMessageUseCase
import com.example.domain.usecase.ToggleStreamConnectionUseCase
import com.example.hardware.DeviceBridgeManager
import com.example.security.AuraSecurityShield
import com.example.services.RealtimeConnectionService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Unified UI State for the Dashboard screen.
 */
data class DashboardUiState(
    val config: CompanionConfig = CompanionConfig(),
    val sessionState: SessionState = SessionState(sessionId = ""),
    val history: List<ChatMessage> = emptyList(),
    val isMicMuted: Boolean = false,
    val isCameraEnabled: Boolean = false,
    val textInput: String = ""
)

/**
 * MVVM ViewModel for the Clean Utilitarian Command Console.
 * Manages WebSocket/HTTP bridge state, system hardware toggles, shell command execution,
 * accessibility UI automation, and live telemetry logs.
 */
class DashboardViewModel(
    private val getCompanionConfigUseCase: GetCompanionConfigUseCase,
    private val saveCompanionConfigUseCase: SaveCompanionConfigUseCase,
    private val getSessionHistoryUseCase: GetSessionHistoryUseCase,
    private val sendMessageUseCase: SendMessageUseCase,
    private val getSessionStateUseCase: GetSessionStateUseCase,
    private val toggleStreamConnectionUseCase: ToggleStreamConnectionUseCase,
    private val audioCaptureEngine: AudioCaptureEngine,
    val permissionEventBus: com.example.capabilities.permissions.PermissionEventBus,
    private val webSocketRepository: WebSocketRepository,
    private val deviceBridgeManager: DeviceBridgeManager,
    private val accessibilityRepository: AccessibilityRepository,
    val securityShield: AuraSecurityShield
) : ViewModel() {

    val permissionAlerts = permissionEventBus.permissionAlerts

    private val _textInput = MutableStateFlow("")
    val audioState: StateFlow<AudioCaptureState> = audioCaptureEngine.state
    val realtimeAudioStatus: StateFlow<com.example.hardware.RealtimeAudioStatus> = deviceBridgeManager.realtimeAudioState

    // Live WebSocket & Bridge Telemetry Flows
    val wsConnectionState: StateFlow<SessionState.ConnectionState> = webSocketRepository.connectionState
    val activeUrl: StateFlow<String> = webSocketRepository.activeUrlFlow
    val connectionLogs: StateFlow<List<String>> = webSocketRepository.connectionLogs
    val lastFailureReason: StateFlow<String?> = webSocketRepository.lastFailureReason
    val latencyMs: StateFlow<Long> = webSocketRepository.latencyMs

    // Live System Hardware & Clipboard Flows
    val isTorchOn: StateFlow<Boolean> = deviceBridgeManager.isTorchOn
    val isDndActive: StateFlow<Boolean> = deviceBridgeManager.isDndActive
    val isAutoRotateOn: StateFlow<Boolean> = deviceBridgeManager.isAutoRotateOn
    val ringerMode: StateFlow<String> = deviceBridgeManager.ringerMode
    val brightnessLevel: StateFlow<Int> = deviceBridgeManager.brightnessLevel
    val isLocationEnabled: StateFlow<Boolean> = deviceBridgeManager.isLocationEnabled
    val locationSnapshot = deviceBridgeManager.locationSnapshot
    val isLiveLocationTracking = deviceBridgeManager.isLiveLocationTracking
    val clipboardPreview: StateFlow<String> = deviceBridgeManager.clipboardPreview
    val accessibilityStatus: StateFlow<AccessibilityServiceStatus> = accessibilityRepository.serviceStatus

    // Expanded Controls Flows
    val volumeStreams = deviceBridgeManager.volumeStreams
    val systemTelemetry = deviceBridgeManager.systemTelemetry
    val isRecordingAudio: StateFlow<Boolean> = deviceBridgeManager.isRecordingAudio
    val isSpeakingTts: StateFlow<Boolean> = deviceBridgeManager.isSpeakingTts
    val activeNotifications = com.example.services.AeroNotificationListenerService.notificationsFlow
    val isNotificationListenerConnected = com.example.services.AeroNotificationListenerService.isConnected

    private val _installedApps = MutableStateFlow<List<com.example.hardware.AppItemUi>>(emptyList())
    val installedApps: StateFlow<List<com.example.hardware.AppItemUi>> = _installedApps.asStateFlow()

    private val _contactsList = MutableStateFlow<List<com.example.hardware.ContactItemUi>>(emptyList())
    val contactsList: StateFlow<List<com.example.hardware.ContactItemUi>> = _contactsList.asStateFlow()

    private val _lastCommandOutput = MutableStateFlow<String?>(null)
    val lastCommandOutput: StateFlow<String?> = _lastCommandOutput.asStateFlow()

    val uiState: StateFlow<DashboardUiState> = combine(
        getCompanionConfigUseCase(),
        getSessionStateUseCase(),
        getSessionHistoryUseCase(),
        _textInput
    ) { config, sessionState, history, textInput ->
        DashboardUiState(
            config = config,
            sessionState = sessionState,
            history = history,
            isMicMuted = config.isMicMuted,
            isCameraEnabled = config.isCameraEnabled,
            textInput = textInput
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DashboardUiState()
    )

    fun refreshStates() {
        deviceBridgeManager.refreshSystemStates()
    }

    fun onTextInputChange(text: String) {
        _textInput.value = text
    }

    fun connectToServer(context: Context, url: String) {
        val cleanUrl = url.trim().ifEmpty { RealtimeConnectionService.DEFAULT_SERVER_URL }
        RealtimeConnectionService.reconnect(context, cleanUrl)
    }

    fun disconnectServer(context: Context) {
        RealtimeConnectionService.disconnect(context)
    }

    fun toggleTorch() {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.handleSystemToggle(JSONObject().put("target", "torch"))
            val stateStr = if (res.optBoolean("enabled")) "ON" else "OFF"
            webSocketRepository.addLog("SYSTEM: Torch toggled -> $stateStr")
        }
    }

    fun toggleDnd() {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.handleSystemToggle(JSONObject().put("target", "dnd"))
            if (res.optBoolean("requiresPermission")) {
                webSocketRepository.addLog("SYSTEM: DND policy permission requested on device")
            } else {
                val stateStr = if (res.optBoolean("enabled")) "ACTIVE" else "NORMAL"
                webSocketRepository.addLog("SYSTEM: Do Not Disturb -> $stateStr")
            }
        }
    }

    fun toggleAutoRotate() {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.handleSystemToggle(JSONObject().put("target", "rotate"))
            if (res.optBoolean("requiresPermission")) {
                webSocketRepository.addLog("SYSTEM: Write Settings permission requested for Auto-Rotate")
            } else {
                val stateStr = if (res.optBoolean("enabled")) "ON" else "LOCKED"
                webSocketRepository.addLog("SYSTEM: Auto-Rotate -> $stateStr")
            }
        }
    }

    fun cycleRingerAndVibrate() {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.handleSystemToggle(
                JSONObject().put("target", "ringer_cycle").put("action", "cycle")
            )
            webSocketRepository.addLog("SYSTEM: Ringer & Haptics -> ${res.optString("ringerMode", "VIBRATE")}")
        }
    }

    fun captureScreenshot() {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.handleSystemToggle(JSONObject().put("target", "screenshot"))
            if (res.optBoolean("success")) {
                val path = res.optString("path")
                _lastCommandOutput.value = "Screenshot saved to $path"
                webSocketRepository.addLog("SCREENSHOT: Saved to $path")
            } else {
                val err = res.optString("error", "Enable Accessibility Service")
                _lastCommandOutput.value = err
                webSocketRepository.addLog("SCREENSHOT ERR: $err")
            }
        }
    }

    fun openHotspotPanel() {
        viewModelScope.launch(Dispatchers.IO) {
            deviceBridgeManager.handleSystemToggle(JSONObject().put("target", "hotspot"))
            webSocketRepository.addLog("SYSTEM: Opened Hotspot & Tethering panel")
        }
    }

    fun openLocationSettings() {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.handleSystemToggle(JSONObject().put("target", "location"))
            webSocketRepository.addLog("SYSTEM: Opened Location settings (GPS=${res.optBoolean("locationEnabled")})")
        }
    }

    fun refreshLocationDetails() {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.getCurrentLocationDetails()
            if (res.optBoolean("success")) {
                val lat = res.optDouble("latitude", 0.0)
                val lon = res.optDouble("longitude", 0.0)
                val acc = res.optDouble("accuracy", 0.0)
                val prov = res.optString("provider", "GPS")
                val mapsUrl = res.optString("mapsUrl", "")
                val summary = String.format(java.util.Locale.US, "GPS [%s]: %.6f, %.6f (±%.1fm) %s", prov, lat, lon, acc, mapsUrl)
                _lastCommandOutput.value = summary
                webSocketRepository.addLog("LOCATION: $summary")
            } else {
                val err = res.optString("error", "Location unavailable")
                _lastCommandOutput.value = err
                webSocketRepository.addLog("LOCATION ERR: $err")
            }
        }
    }

    fun startLiveLocationTracking(intervalMs: Long = 1000L) {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.startLiveLocationTracking(intervalMs)
            webSocketRepository.addLog("LOCATION: Started Realtime GPS Tracking (${intervalMs}ms) -> ok=${res.optBoolean("success")}")
        }
    }

    fun stopLiveLocationTracking() {
        viewModelScope.launch(Dispatchers.IO) {
            deviceBridgeManager.stopLiveLocationTracking()
            webSocketRepository.addLog("LOCATION: Stopped Realtime GPS Tracking")
        }
    }

    fun toggleLiveLocationTracking() {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.toggleLiveLocationTracking()
            val isLive = res.optBoolean("isLiveTracking")
            webSocketRepository.addLog("LOCATION: Live Tracking -> ${if (isLive) "ACTIVE (Realtime 1s)" else "PAUSED"}")
        }
    }

    fun lockDeviceScreen() {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.handleSystemToggle(JSONObject().put("target", "lock"))
            if (res.optBoolean("success")) {
                webSocketRepository.addLog("SYSTEM: Screen locked")
            } else {
                webSocketRepository.addLog("SYSTEM: Lock screen requires Accessibility Service")
            }
        }
    }

    fun triggerGlobalUiAction(globalKey: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val res = if (globalKey in listOf("NOTIFICATIONS", "QUICK_SETTINGS")) {
                deviceBridgeManager.handleSystemToggle(JSONObject().put("target", globalKey.lowercase()))
            } else {
                deviceBridgeManager.handleUiAction(JSONObject().put("action", globalKey))
            }
            webSocketRepository.addLog("UI_GLOBAL: $globalKey -> ok=${res.optBoolean("success")}")
        }
    }

    fun setBrightnessLevel(level: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.handleSystemToggle(
                JSONObject().put("target", "brightness").put("level", level.coerceIn(10, 255))
            )
            webSocketRepository.addLog("SYSTEM: Brightness -> ${res.optInt("brightness")}/255")
        }
    }

    fun openWifiPanel() {
        viewModelScope.launch(Dispatchers.IO) {
            deviceBridgeManager.handleSystemToggle(JSONObject().put("target", "wifi"))
            webSocketRepository.addLog("SYSTEM: Opened Wi-Fi settings panel")
        }
    }

    fun openBluetoothPanel() {
        viewModelScope.launch(Dispatchers.IO) {
            deviceBridgeManager.handleSystemToggle(JSONObject().put("target", "bluetooth"))
            webSocketRepository.addLog("SYSTEM: Opened Bluetooth settings panel")
        }
    }

    fun adjustVolume(action: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.handleSystemToggle(
                JSONObject().put("target", "volume").put("action", action)
            )
            webSocketRepository.addLog("SYSTEM: Volume [$action] -> ${res.optInt("mediaVolume")}/${res.optInt("mediaMax")}")
        }
    }

    fun triggerMediaControl(command: String) {
        viewModelScope.launch(Dispatchers.IO) {
            deviceBridgeManager.handleSystemToggle(
                JSONObject().put("target", "media").put("command", command)
            )
            webSocketRepository.addLog("SYSTEM: Media control [$command] dispatched")
        }
    }

    fun refreshClipboard() {
        viewModelScope.launch(Dispatchers.IO) {
            val text = deviceBridgeManager.getClipboardText()
            webSocketRepository.addLog("CLIPBOARD: Synced (${text.length} chars)")
        }
    }

    fun updateClipboard(text: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = deviceBridgeManager.setClipboardText(text)
            webSocketRepository.addLog("CLIPBOARD: Set (${text.length} chars) -> ok=$ok")
        }
    }

    fun inspectUiHierarchy() {
        viewModelScope.launch(Dispatchers.IO) {
            val nodes = accessibilityRepository.getFullNodeTree()
            if (nodes.isEmpty()) {
                webSocketRepository.addLog("UI_TREE: No nodes returned (verify Accessibility Service is enabled)")
                _lastCommandOutput.value = "Accessibility Service is not active. Tap 'Permissions' to enable."
            } else {
                var totalNodes = 0
                var clickableCount = 0
                fun countRecursive(n: com.example.accessibility.models.AccessibilityNodeModel) {
                    totalNodes++
                    if (n.isClickable) clickableCount++
                    n.children.forEach { countRecursive(it) }
                }
                nodes.forEach { countRecursive(it) }
                val summary = "UI Tree Snapshot: $totalNodes nodes ($clickableCount clickable)"
                webSocketRepository.addLog("UI_TREE: $summary")
                _lastCommandOutput.value = summary
            }
        }
    }

    fun executeConsoleCommand(rawInput: String) {
        val cmd = rawInput.trim()
        if (cmd.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            webSocketRepository.addLog("SHELL $ $cmd")
            val res = deviceBridgeManager.executeShellCommand(cmd, timeoutMs = 15000L)
            val exitCode = res.optInt("exit_code", -1)
            val dur = res.optLong("duration_ms", 0L)
            val stdout = res.optString("stdout", "").trim()
            val stderr = res.optString("stderr", "").trim()
            val combined = buildString {
                if (stdout.isNotEmpty()) append(stdout)
                if (stderr.isNotEmpty()) {
                    if (isNotEmpty()) append("\n")
                    append("[stderr] ").append(stderr)
                }
                if (isEmpty()) append("(exit $exitCode in ${dur}ms)")
            }
            _lastCommandOutput.value = "$ $cmd  [exit=$exitCode, ${dur}ms]\n$combined"
            val logPreview = combined.replace("\n", " | ").take(140)
            webSocketRepository.addLog("SHELL [exit=$exitCode, ${dur}ms]: $logPreview")
        }
    }

    fun clearCommandOutput() {
        _lastCommandOutput.value = null
    }

    fun clearLogs() {
        webSocketRepository.clearLogs()
        _lastCommandOutput.value = null
    }

    fun startAudioCapture(context: Context) {
        RealtimeConnectionService.start(context)
    }

    fun stopAudioCapture(context: Context) {
        RealtimeConnectionService.stop(context)
    }

    fun toggleAudioPause(context: Context) {
        val current = audioState.value
        if (current.isRecording) {
            if (current.isPaused) {
                RealtimeConnectionService.resume(context)
            } else {
                RealtimeConnectionService.pause(context)
            }
        }
    }

    fun restartAudioCapture(context: Context) {
        viewModelScope.launch {
            RealtimeConnectionService.stop(context)
            kotlinx.coroutines.delay(400)
            RealtimeConnectionService.start(context)
        }
    }

    fun toggleConnection() {
        viewModelScope.launch {
            val isConnected = uiState.value.sessionState.connectionState == SessionState.ConnectionState.CONNECTED
            toggleStreamConnectionUseCase(!isConnected)
        }
    }

    fun toggleMicrophone() {
        viewModelScope.launch {
            val currentConfig = uiState.value.config
            saveCompanionConfigUseCase(currentConfig.copy(isMicMuted = !currentConfig.isMicMuted))
        }
    }

    fun toggleCamera() {
        viewModelScope.launch {
            val currentConfig = uiState.value.config
            saveCompanionConfigUseCase(currentConfig.copy(isCameraEnabled = !currentConfig.isCameraEnabled))
        }
    }

    fun sendMessage() {
        val text = _textInput.value.trim()
        if (text.isEmpty()) return

        viewModelScope.launch {
            _textInput.value = ""
            sendMessageUseCase(text)
        }
    }

    fun exportServerScripts() {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.exportServerScriptsToStorage()
            val dir = res.optString("directory", "/sdcard/Download/AeroShare")
            val count = res.optInt("count", 0)
            _lastCommandOutput.value = "Exported $count server files to $dir"
            webSocketRepository.addLog("SYSTEM: Exported $count server files to $dir")
        }
    }

    // -------------------------------------------------------------------------
    // Expanded Controls Actions (Audio/TTS, Gesture Pad, Apps/System, Media, Comms)
    // -------------------------------------------------------------------------

    fun speakText(text: String, rate: Float = 1.0f, pitch: Float = 1.0f) {
        if (text.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            deviceBridgeManager.speakText(text, rate, pitch)
            webSocketRepository.addLog("AUDIO_TTS: Speaking '${text.take(40)}'")
        }
    }

    fun stopTts() {
        viewModelScope.launch(Dispatchers.IO) {
            deviceBridgeManager.stopTts()
            webSocketRepository.addLog("AUDIO_TTS: Stopped")
        }
    }

    fun setStreamVolumePercent(streamType: String, percent: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.setStreamVolumePercent(streamType, percent)
            webSocketRepository.addLog("AUDIO_VOL: $streamType -> ${res.optInt("percent")}%")
        }
    }

    fun recordAudioClip(durationSec: Int = 5) {
        viewModelScope.launch(Dispatchers.IO) {
            webSocketRepository.addLog("AUDIO_MIC: Recording ${durationSec}s audio clip...")
            val res = deviceBridgeManager.recordAudioClip(durationSec)
            if (res.optBoolean("success")) {
                val path = res.optString("path")
                _lastCommandOutput.value = "Saved ${durationSec}s mic clip: $path"
                webSocketRepository.addLog("AUDIO_MIC: Saved to $path")
            } else {
                val err = res.optString("error", "Mic recording failed")
                _lastCommandOutput.value = err
                webSocketRepository.addLog("AUDIO_MIC ERR: $err")
            }
        }
    }

    fun performCoordinateTap(x: Float, y: Float, isLongPress: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.performCoordinateTap(x, y, isLongPress)
            val label = if (isLongPress) "LONG_PRESS" else "TAP"
            webSocketRepository.addLog("UI_PAD: $label (${x.toInt()}, ${y.toInt()}) -> ok=${res.optBoolean("success")}")
        }
    }

    fun performDirectionalSwipe(direction: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.performDirectionalSwipe(direction)
            webSocketRepository.addLog("UI_PAD: SWIPE_$direction -> ok=${res.optBoolean("success")}")
        }
    }

    fun performScroll(direction: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.handleUiAction(
                JSONObject().put("action", "SCROLL").put("direction", direction)
            )
            webSocketRepository.addLog("UI_PAD: SCROLL_$direction -> ok=${res.optBoolean("success")}")
        }
    }

    fun injectInputText(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.injectInputText(text)
            webSocketRepository.addLog("UI_INPUT: Injected '${text.take(30)}' -> ok=${res.optBoolean("success")}")
        }
    }

    fun sendHardwareKey(keyName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.sendHardwareKey(keyName)
            webSocketRepository.addLog("UI_KEY: $keyName -> ok=${res.optBoolean("success")}")
        }
    }

    fun loadInstalledApps(query: String = "") {
        viewModelScope.launch(Dispatchers.IO) {
            _installedApps.value = deviceBridgeManager.getInstalledApps(query)
        }
    }

    fun launchApp(packageName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.launchApp(packageName)
            webSocketRepository.addLog("APP_LAUNCH: $packageName -> ok=${res.optBoolean("success")}")
        }
    }

    fun refreshNotifications() {
        viewModelScope.launch(Dispatchers.IO) {
            com.example.services.AeroNotificationListenerService.activeInstance?.refreshActiveNotifications()
            deviceBridgeManager.refreshTelemetrySnapshot()
        }
    }

    fun dismissNotification(key: String) {
        viewModelScope.launch(Dispatchers.IO) {
            com.example.services.AeroNotificationListenerService.activeInstance?.dismissNotificationKey(key)
        }
    }

    fun dismissAllNotifications() {
        viewModelScope.launch(Dispatchers.IO) {
            com.example.services.AeroNotificationListenerService.activeInstance?.dismissAllNotifications()
            webSocketRepository.addLog("NOTIFS: Cleared all active notifications")
        }
    }

    fun openCameraCapture() {
        viewModelScope.launch(Dispatchers.IO) {
            deviceBridgeManager.openCameraCapture()
            webSocketRepository.addLog("MEDIA: Opened camera capture")
        }
    }

    fun openUrlOnDevice(url: String) {
        if (url.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.openUrlOnDevice(url)
            webSocketRepository.addLog("MEDIA_URL: Opened ${res.optString("url", url)}")
        }
    }

    fun shareTextContent(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            deviceBridgeManager.shareTextContent(text)
            webSocketRepository.addLog("MEDIA_SHARE: Opened share sheet")
        }
    }

    fun sendQuickSms(phone: String, message: String) {
        if (phone.isBlank() || message.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.sendQuickSms(phone, message)
            webSocketRepository.addLog("COMMS_SMS: To $phone (${res.optString("mode")}) -> ok=${res.optBoolean("success")}")
        }
    }

    fun dialPhoneNumber(phone: String) {
        if (phone.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            val res = deviceBridgeManager.dialPhoneNumber(phone)
            webSocketRepository.addLog("COMMS_DIAL: $phone (${res.optString("mode")}) -> ok=${res.optBoolean("success")}")
        }
    }

    fun searchContacts(query: String = "") {
        viewModelScope.launch(Dispatchers.IO) {
            _contactsList.value = deviceBridgeManager.searchContacts(query)
        }
    }

    fun getCameraStationDetails(): org.json.JSONObject = deviceBridgeManager.getCameraStationDetails()
    fun getMicrophoneStationDetails(): org.json.JSONObject = deviceBridgeManager.getMicrophoneStationDetails()
    fun getNotificationStationDetails(): org.json.JSONObject = deviceBridgeManager.getNotificationStationDetails()
    fun getStorageStationDetails(): org.json.JSONObject = deviceBridgeManager.getStorageStationDetails()

    fun testCameraCapture(): org.json.JSONObject = deviceBridgeManager.openCameraCapture()
    suspend fun testAudioRecording(durationSec: Int = 3): org.json.JSONObject = withContext(Dispatchers.IO) {
        deviceBridgeManager.testRecordMicrophone(durationSec)
    }
    fun startRealtimeRecording(): org.json.JSONObject = deviceBridgeManager.startRealtimeRecording()
    fun stopRealtimeRecording(): org.json.JSONObject = deviceBridgeManager.stopRealtimeRecording()
    fun getRealtimeAudioStatus(): org.json.JSONObject = deviceBridgeManager.getRealtimeAudioStatus()
    fun playRecordedAudio(path: String): org.json.JSONObject = deviceBridgeManager.playAudioFile(path)
    fun sendHardwareTestNotification(title: String, message: String): org.json.JSONObject = deviceBridgeManager.sendTestNotification(title, message)

    fun requestPermissionDirect(permission: String, feature: String, reason: String) {
        permissionEventBus.postAlert(permission, feature, reason)
    }

    fun openPermissionSetting(permissionIdOrKey: String) {
        deviceBridgeManager.requestPermissionOrSetting(permissionIdOrKey, openSettings = true)
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as BaseApplication
                val container = app.container
                DashboardViewModel(
                    getCompanionConfigUseCase = container.getCompanionConfigUseCase,
                    saveCompanionConfigUseCase = container.saveCompanionConfigUseCase,
                    getSessionHistoryUseCase = container.getSessionHistoryUseCase,
                    sendMessageUseCase = container.sendMessageUseCase,
                    getSessionStateUseCase = container.getSessionStateUseCase,
                    toggleStreamConnectionUseCase = container.toggleStreamConnectionUseCase,
                    audioCaptureEngine = container.audioCaptureEngine,
                    permissionEventBus = container.permissionEventBus,
                    webSocketRepository = container.webSocketRepository,
                    deviceBridgeManager = container.deviceBridgeManager,
                    accessibilityRepository = container.accessibilityRepository,
                    securityShield = container.securityShield
                )
            }
        }
    }
}
