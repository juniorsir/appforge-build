package com.example.presentation.permissions

import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.BorderStroke
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.capabilities.permissions.PermissionCategory
import com.example.capabilities.permissions.PermissionItem
import com.example.capabilities.permissions.PermissionManager
import com.example.capabilities.permissions.PermissionState
import com.example.capabilities.permissions.SpecialSettingType
import com.example.ui.theme.AuraColors
import com.example.ui.theme.AuraTypography

private val EmeraldAccent = Color(0xFF10B981)

/**
 * High-performance, full-spectrum 45+ Permission & Capability Access Hub.
 * Allows inspecting, batch requesting, and toggling all Android permissions using modern interactive switches.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PermissionsManagerDialog(
    onDismissRequest: () -> Unit,
    permissionManager: PermissionManager,
    onOpenCameraStation: () -> Unit = {},
    onOpenMicStation: () -> Unit = {},
    onOpenNotifStation: () -> Unit = {},
    onOpenStorageStation: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activity = context as? Activity

    // Refresh trigger state
    var refreshNonce by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<PermissionCategory?>(null) }
    var showOnlyMissing by remember { mutableStateOf(false) }

    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                refreshNonce++
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Multi-permission launcher for batch grant
    val batchPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val grantedCount = results.values.count { it }
        Toast.makeText(
            context,
            "Granted $grantedCount of ${results.size} requested permissions",
            Toast.LENGTH_SHORT
        ).show()
        refreshNonce++
    }

    // Single permission launcher
    val singlePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        refreshNonce++
    }

    val allPermissions = permissionManager.allDefinedPermissions

    // Map permissions with their evaluated state, excluding unsupported SDK/hardware items
    // and sorting so Missing & Interactive (Special/Runtime) toggles appear first
    val evaluatedPermissions = remember(refreshNonce, allPermissions) {
        allPermissions
            .map { item -> item to permissionManager.getPermissionItemState(item, activity) }
            .filter { (_, state) ->
                state != PermissionState.NOT_REQUIRED && state != PermissionState.HARDWARE_UNAVAILABLE
            }
            .sortedWith(
                compareBy<Pair<PermissionItem, PermissionState>>(
                    { (_, state) -> state == PermissionState.GRANTED },
                    { (item, _) -> !(item.isRuntime || item.specialSettingType != SpecialSettingType.NONE) },
                    { (item, _) -> item.specialSettingType == SpecialSettingType.NONE }
                )
            )
    }

    val totalCount = evaluatedPermissions.size
    val grantedCount = evaluatedPermissions.count { it.second == PermissionState.GRANTED }
    val missingCount = evaluatedPermissions.count { it.second == PermissionState.DENIED }
    val missingRuntimeList = remember(refreshNonce, evaluatedPermissions) {
        permissionManager.getRuntimePermissionsToRequest()
    }
    val missingRuntimeCount = missingRuntimeList.size
    val progressFraction = if (totalCount > 0) grantedCount.toFloat() / totalCount else 1f

    val filteredList = evaluatedPermissions.filter { (item, state) ->
        val matchesCategory = selectedCategory == null || item.category == selectedCategory
        val matchesQuery = searchQuery.isEmpty() ||
                item.displayName.contains(searchQuery, ignoreCase = true) ||
                item.permission.contains(searchQuery, ignoreCase = true) ||
                item.category.displayName.contains(searchQuery, ignoreCase = true)
        val matchesMissing = !showOnlyMissing || (state == PermissionState.DENIED)

        matchesCategory && matchesQuery && matchesMissing
    }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.88f))
                .padding(horizontal = 12.dp, vertical = 18.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 680.dp)
                    .fillMaxHeight(0.92f)
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, AuraColors.BorderFocused, RoundedCornerShape(20.dp)),
                color = AuraColors.SurfaceDark
            ) {
                Column(
                    modifier = Modifier.fillMaxSize()
                ) {
                    // Top Header Bar (Clean single-line title + properly weighted layout so Close X is always visible)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(AuraColors.SurfaceDarker)
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(EmeraldAccent.copy(alpha = 0.15f))
                                    .border(1.dp, EmeraldAccent.copy(alpha = 0.4f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = EmeraldAccent,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Permissions",
                                    style = AuraTypography.SectionTitle.copy(fontSize = 17.sp, fontWeight = FontWeight.Bold),
                                    color = AuraColors.TextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "$grantedCount of $totalCount Active",
                                    style = AuraTypography.TechnicalMono.copy(fontSize = 11.sp),
                                    color = if (missingCount == 0) EmeraldAccent else AuraColors.StatusWarning,
                                    maxLines = 1
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = onDismissRequest,
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(AuraColors.GlassLevel3)
                                .border(1.dp, AuraColors.BorderSubtle, CircleShape)
                                .testTag("close_permissions_dialog_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = AuraColors.TextPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Progress & Fast Actions
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(AuraColors.GlassLevel1)
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        LinearProgressIndicator(
                            progress = { progressFraction },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(5.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = EmeraldAccent,
                            trackColor = AuraColors.BorderSubtle
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    if (missingRuntimeList.isNotEmpty()) {
                                        batchPermissionLauncher.launch(missingRuntimeList.toTypedArray())
                                    } else {
                                        val firstMissingSpecial = evaluatedPermissions.firstOrNull {
                                            it.second == PermissionState.DENIED && it.first.specialSettingType != SpecialSettingType.NONE
                                        }?.first
                                        if (firstMissingSpecial != null) {
                                            showOnlyMissing = true
                                            try {
                                                context.startActivity(permissionManager.createSpecialIntent(firstMissingSpecial))
                                            } catch (_: Exception) {}
                                        } else {
                                            Toast.makeText(context, "All permissions are active!", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .weight(1.2f)
                                    .height(42.dp)
                                    .testTag("batch_grant_permissions_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = EmeraldAccent,
                                    contentColor = Color.Black
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LockOpen,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = when {
                                        missingRuntimeCount > 0 -> "Grant Runtime ($missingRuntimeCount)"
                                        missingCount > 0 -> "Enable Special ($missingCount)"
                                        else -> "All Active"
                                    },
                                    style = AuraTypography.ButtonLabel.copy(fontSize = 12.sp, fontWeight = FontWeight.Bold),
                                    maxLines = 1
                                )
                            }

                            OutlinedButton(
                                onClick = {
                                    try {
                                        context.startActivity(permissionManager.createAppSettingsIntent())
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Could not open settings", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .testTag("open_app_settings_button"),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = AuraColors.TextPrimary
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = null,
                                    modifier = Modifier.size(15.dp),
                                    tint = AuraColors.TextSecondary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "OS Settings",
                                    style = AuraTypography.ButtonLabel.copy(fontSize = 12.sp),
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    val isCameraActive = remember(refreshNonce) { permissionManager.hasPermission(android.Manifest.permission.CAMERA) }
                    val isMicActive = remember(refreshNonce) { permissionManager.hasPermission(android.Manifest.permission.RECORD_AUDIO) }
                    val isNotifActive = remember(refreshNonce) {
                        if (android.os.Build.VERSION.SDK_INT >= 33) permissionManager.hasPermission("android.permission.POST_NOTIFICATIONS") else true
                    }
                    val isStorageActive = remember(refreshNonce) {
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                            android.os.Environment.isExternalStorageManager()
                        } else {
                            permissionManager.hasPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                        }
                    }

                    // Interactive Hardware Stations Row
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "CORE HARDWARE STATIONS",
                            style = AuraTypography.TechnicalMono.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                            color = AuraColors.TextMuted
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            StationQuickCard(
                                label = "Camera",
                                icon = Icons.Default.CameraAlt,
                                isActive = isCameraActive,
                                activeColor = Color(0xFF38BDF8),
                                onClick = onOpenCameraStation,
                                modifier = Modifier.weight(1f)
                            )
                            StationQuickCard(
                                label = "Mic",
                                icon = Icons.Default.Mic,
                                isActive = isMicActive,
                                activeColor = Color(0xFFF59E0B),
                                onClick = onOpenMicStation,
                                modifier = Modifier.weight(1f)
                            )
                            StationQuickCard(
                                label = "Notif",
                                icon = Icons.Default.Notifications,
                                isActive = isNotifActive,
                                activeColor = Color(0xFFA855F7),
                                onClick = onOpenNotifStation,
                                modifier = Modifier.weight(1f)
                            )
                            StationQuickCard(
                                label = "Storage",
                                icon = Icons.Default.Folder,
                                isActive = isStorageActive,
                                activeColor = EmeraldAccent,
                                onClick = onOpenStorageStation,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Search & Filter Controls
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = {
                                Text(
                                    text = "Search permissions...",
                                    style = AuraTypography.BodyMedium.copy(fontSize = 13.sp),
                                    color = AuraColors.TextMuted
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = null,
                                    tint = AuraColors.TextMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Clear search",
                                            tint = AuraColors.TextMuted,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("permissions_search_field"),
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = EmeraldAccent,
                                unfocusedBorderColor = AuraColors.BorderSubtle,
                                focusedContainerColor = AuraColors.SurfaceDarker,
                                unfocusedContainerColor = AuraColors.SurfaceDarker,
                                focusedTextColor = AuraColors.TextPrimary,
                                unfocusedTextColor = AuraColors.TextPrimary
                            )
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        // Filter Chips Row
                        LazyRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            contentPadding = PaddingValues(vertical = 2.dp)
                        ) {
                            item {
                                FilterChip(
                                    selected = selectedCategory == null && !showOnlyMissing,
                                    onClick = {
                                        selectedCategory = null
                                        showOnlyMissing = false
                                    },
                                    label = { Text("All ($totalCount)", fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = EmeraldAccent.copy(alpha = 0.2f),
                                        selectedLabelColor = EmeraldAccent,
                                        containerColor = AuraColors.GlassLevel1,
                                        labelColor = AuraColors.TextSecondary
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true,
                                        selected = selectedCategory == null && !showOnlyMissing,
                                        borderColor = AuraColors.BorderSubtle,
                                        selectedBorderColor = EmeraldAccent
                                    )
                                )
                            }

                            item {
                                FilterChip(
                                    selected = showOnlyMissing,
                                    onClick = { showOnlyMissing = !showOnlyMissing },
                                    label = { Text("Missing ($missingCount)", fontSize = 11.sp) },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.Warning,
                                            contentDescription = null,
                                            modifier = Modifier.size(13.dp),
                                            tint = if (showOnlyMissing) AuraColors.StatusWarning else AuraColors.TextMuted
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = AuraColors.StatusWarning.copy(alpha = 0.2f),
                                        selectedLabelColor = AuraColors.StatusWarning,
                                        containerColor = AuraColors.GlassLevel1,
                                        labelColor = AuraColors.TextSecondary
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true,
                                        selected = showOnlyMissing,
                                        borderColor = AuraColors.BorderSubtle,
                                        selectedBorderColor = AuraColors.StatusWarning
                                    )
                                )
                            }

                            items(PermissionCategory.values()) { category ->
                                val categoryCount = evaluatedPermissions.count { it.first.category == category }
                                if (categoryCount > 0) {
                                    FilterChip(
                                        selected = selectedCategory == category,
                                        onClick = {
                                            selectedCategory = if (selectedCategory == category) null else category
                                        },
                                        label = { Text("${category.displayName} ($categoryCount)", fontSize = 11.sp) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = EmeraldAccent.copy(alpha = 0.2f),
                                            selectedLabelColor = EmeraldAccent,
                                            containerColor = AuraColors.GlassLevel1,
                                            labelColor = AuraColors.TextSecondary
                                        ),
                                        border = FilterChipDefaults.filterChipBorder(
                                            enabled = true,
                                            selected = selectedCategory == category,
                                            borderColor = AuraColors.BorderSubtle,
                                            selectedBorderColor = EmeraldAccent
                                        )
                                    )
                                }
                            }
                        }
                    }

                    // Permissions List
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(top = 4.dp, bottom = 16.dp)
                    ) {
                        if (filteredList.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 32.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "No matching permissions",
                                        style = AuraTypography.BodyMedium,
                                        color = AuraColors.TextMuted
                                    )
                                }
                            }
                        } else {
                            items(
                                items = filteredList,
                                key = { it.first.id }
                            ) { (item, state) ->
                                PermissionItemCard(
                                    item = item,
                                    state = state,
                                    onToggle = { enable ->
                                        if (item.isRuntime) {
                                            if (enable) {
                                                singlePermissionLauncher.launch(item.permission)
                                            } else {
                                                try {
                                                    context.startActivity(permissionManager.createAppSettingsIntent())
                                                } catch (_: Exception) {}
                                            }
                                        } else if (item.specialSettingType != SpecialSettingType.NONE) {
                                            try {
                                                context.startActivity(permissionManager.createSpecialIntent(item))
                                            } catch (_: Exception) {}
                                        } else {
                                            try {
                                                context.startActivity(permissionManager.createAppSettingsIntent())
                                            } catch (_: Exception) {}
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionItemCard(
    item: PermissionItem,
    state: PermissionState,
    onToggle: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val isGranted = state == PermissionState.GRANTED || state == PermissionState.NOT_REQUIRED
    val isInteractive = item.isRuntime || item.specialSettingType != SpecialSettingType.NONE

    val cardBorderColor by animateColorAsState(
        targetValue = when {
            !isGranted -> AuraColors.StatusWarning.copy(alpha = 0.5f)
            isInteractive -> EmeraldAccent.copy(alpha = 0.35f)
            else -> AuraColors.BorderSubtle
        },
        label = "cardBorderColor"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("permission_card_${item.id}")
            .clickable(enabled = isInteractive) {
                onToggle(!isGranted)
            },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = AuraColors.GlassLevel1
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(cardBorderColor)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.displayName,
                    style = AuraTypography.SectionTitle.copy(fontSize = 14.sp, fontWeight = FontWeight.SemiBold),
                    color = AuraColors.TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = "${item.category.displayName} • ${item.permission.substringAfterLast(".")}",
                    style = AuraTypography.TechnicalMono.copy(fontSize = 10.sp),
                    color = AuraColors.TextMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            if (isInteractive) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (item.specialSettingType != SpecialSettingType.NONE) {
                        Icon(
                            imageVector = Icons.Default.OpenInNew,
                            contentDescription = "System Setting",
                            modifier = Modifier.size(14.dp),
                            tint = if (isGranted) EmeraldAccent else AuraColors.StatusWarning
                        )
                    }

                    Switch(
                        checked = isGranted,
                        onCheckedChange = { onToggle(it) },
                        modifier = Modifier.testTag("permission_toggle_${item.id}"),
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.Black,
                            checkedTrackColor = EmeraldAccent,
                            checkedBorderColor = EmeraldAccent,
                            uncheckedThumbColor = AuraColors.TextMuted,
                            uncheckedTrackColor = AuraColors.SurfaceDarker,
                            uncheckedBorderColor = AuraColors.BorderSubtle
                        ),
                        thumbContent = if (isGranted) {
                            {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    modifier = Modifier.size(12.dp),
                                    tint = Color.Black
                                )
                            }
                        } else null
                    )
                }
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(EmeraldAccent.copy(alpha = 0.12f))
                        .border(1.dp, EmeraldAccent.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Enabled",
                        tint = EmeraldAccent,
                        modifier = Modifier.size(12.dp)
                    )
                    Text(
                        text = "Active",
                        style = AuraTypography.TechnicalLabel.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                        color = EmeraldAccent
                    )
                }
            }
        }
    }
}

@Composable
private fun StationQuickCard(
    label: String,
    icon: ImageVector,
    isActive: Boolean,
    activeColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = AuraColors.GlassLevel2,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, if (isActive) activeColor.copy(alpha = 0.5f) else AuraColors.BorderSubtle),
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isActive) activeColor else AuraColors.TextMuted,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = label,
                style = AuraTypography.ButtonLabel.copy(fontSize = 11.sp, fontWeight = FontWeight.SemiBold),
                color = AuraColors.TextPrimary,
                maxLines = 1
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (isActive) activeColor.copy(alpha = 0.16f) else AuraColors.GlassLevel3)
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                Text(
                    text = if (isActive) "ACTIVE" else "REQ",
                    style = AuraTypography.TechnicalMono.copy(fontSize = 8.sp, fontWeight = FontWeight.Bold),
                    color = if (isActive) activeColor else AuraColors.StatusWarning
                )
            }
        }
    }
}
