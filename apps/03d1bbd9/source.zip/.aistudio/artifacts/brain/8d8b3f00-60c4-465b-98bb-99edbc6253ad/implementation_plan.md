# Full-Spectrum Interactive Hardware Permission & Capability Access Hub

Interactive, on-demand permission access, telemetry inspection, and live testing for all core Android hardware capabilities—**Camera**, **Microphone**, **Notifications**, and **Storage**—across both the Android Jetpack Compose dashboard and the Termux CLI.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following design decisions were aligned during the interactive interview:
> - **Target Scope**: Prioritizing core hardware permissions: **Camera & Vision**, **Microphone & Voice Capture**, **Notifications & Badging**, and **Storage & Media Files**.
> - **Termux CLI Access**: Dual-mode controls—providing both remote on-device permission prompts (pushing approval dialog to phone screen) and direct system settings launch commands, plus dedicated live capability execution (`camera`, `mic`, `notif`, `storage`, `permissions`).
> - **Android UI Presentation**: Dedicated interactive feature dialogs with live status telemetry, instant test actions (e.g., photo snapshot test, audio VU meter recorder test, push test notification, and directory file inspector), and one-tap permission grant/settings triggers.

---

## 1. Overview & Core Concept

### What It Does
Elevates all core permissions from passive Android toggles into active, inspectable, and remotely controllable hardware stations:
1. **Camera Station (`CAMERA`)**:
   - Live hardware status (available lens IDs, flash capability, hardware level).
   - Test action: Instant test snapshot capture and preview.
   - CLI commands: `python send_cmd.py camera [perm|test|open]`.
2. **Microphone Station (`RECORD_AUDIO`)**:
   - Live microphone status (sample rate, channel count, audio source).
   - Test action: 3-second live audio recorder test with real-time decibel VU meter.
   - CLI commands: `python send_cmd.py mic [perm|test|record]`.
3. **Notification Station (`POST_NOTIFICATIONS`)**:
   - Notification channel status, DND override status, and system post permissions.
   - Test action: Dispatches an interactive test notification with sound and haptic vibration.
   - CLI commands: `python send_cmd.py notif [perm|test|send <msg>]`.
4. **Storage & Media Station (`READ_MEDIA_IMAGES` / All Files)**:
   - Volume mount status, free/total disk space, accessible file counters.
   - Test action: Quick storage sanity audit and sample file picker test.
   - CLI commands: `python send_cmd.py storage [perm|stat|ls]`.
5. **Universal Permission Controller**:
   - `python send_cmd.py permissions [list|request <perm>|settings <perm>]` to view and request any permission directly from Termux.

### Target Audience & Persona
Power users, developers, and Termux terminal operators who need seamless access to physical phone hardware without getting blocked by hidden Android permission barriers.

---

## 2. User Experience & Visual Design

### Key User Flows

```
┌────────────────────────────────────────────────────────────────────────┐
│                        MAIN DASHBOARD (4x3 GRID)                       │
│                                                                        │
│   [ Torch ]     [ DND ]        [ Inspect ]       [ Wi-Fi ]             │
│   [ Camera ]    [ Mic ]        [ Notifs ]        [ Storage ]           │
│   [ GPS (Live)] [ Rotate ]     [ Vibrate ]       [ Lock ]              │
└────────────────────────────────────────────────────────────────────────┘
          │              │             │               │
          ▼              ▼             ▼               ▼
┌──────────────────┐┌───────────┐┌───────────┐┌──────────────────┐
│  CAMERA DIALOG   ││MIC DIALOG ││NOTIF DIAL.││ STORAGE DIALOG   │
│ • Lens Specs     ││• VU Meter ││• Channels ││ • Disk Capacity  │
│ • Live Test Snap ││• Live Rec ││• Push Test││ • File Explorer  │
│ • [Grant / Open] ││• [Grant]  ││• [Grant]  ││ • [Grant / Open] │
└──────────────────┘└───────────┘└───────────┘└──────────────────┘
```

### Visual Identity & Theme
- **Theme**: Luxury Cyber / Command Center dark mode matching existing AeroShare aesthetic (`ConsoleBg` #0A0E14, `CardBg` #111722, `CardElevatedBg` #182030).
- **Accents by Capability**:
  - **Camera**: Cyan Accent (`#38BDF8`)
  - **Microphone**: Amber Accent (`#F59E0B`)
  - **Notifications**: Purple Accent (`#A855F7`)
  - **Storage**: Emerald Accent (`#10B981`)
- **Status Indicators**:
  - `GRANTED`: Bright emerald badge (`● GRANTED`) with active border.
  - `DENIED` / `REQUIRED`: Amber alert badge (`⚠️ ACTION REQUIRED`).
  - `PERMANENTLY DENIED`: Coral badge (`🔒 SETTINGS REQUIRED`).

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Direct Dialogs vs Re-routing to Android Settings**
  - *Approach*: Each tile opens a high-fidelity in-app dialog with live hardware diagnostics and instant test triggers, with direct "Grant Permission" or "Open Settings" fallback buttons.
  - *Rationale*: Eliminates guesswork. Users can immediately verify *why* a permission is needed and test if hardware works as soon as granted.
- **Decision 2: Remote Permission Request Flow via Termux CLI**
  - *Approach*: When Termux runs `python send_cmd.py perm request <name>`, the Android bridge triggers an immediate on-screen permission prompt or foreground confirmation sheet via `permissionAlerts`.
  - *Rationale*: Standard Android OS security prohibits background processes from silently granting permissions; popping the native Android prompt directly to the phone screen provides a seamless 1-tap grant flow for the user.

---

## 4. Technical Architecture & Data Strategy

### Architecture & Component Diagram

```
┌────────────────────────────────────────────────────────────────────────┐
│                           TERMUX WORKSTATION                           │
│   python send_cmd.py permissions / camera / mic / notif / storage      │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ HTTP REST & WebSocket (Port 8080/8000)
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                        APP CONTAINER & REST ROUTER                     │
│   /api/permissions/status       /api/permissions/request               │
│   /api/camera/test              /api/audio/test_record                 │
│   /api/notif/test               /api/storage/status                    │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
        ┌───────────────────────────┼───────────────────────────┐
        ▼                           ▼                           ▼
┌──────────────┐            ┌──────────────┐            ┌──────────────┐
│  PERMISSION  │            │DEVICE BRIDGE │            │ DASHBOARD VM │
│   MANAGER    │            │   MANAGER    │            │ & COMPOSE UI │
│ • Evaluates  │            │ • CameraX/API│            │ • Dialogs    │
│   45+ perms  │            │ • AudioRecord│            │ • Live M3    │
│ • Ints/Launch│            │ • Notif test │            │   Controls   │
└──────────────┘            └──────────────┘            └──────────────┘
```

### API Endpoints Added
1. `GET /api/permissions/status` -> Full list of permissions with `name`, `granted`, `category`, `settingsType`.
2. `POST /api/permissions/request` -> Triggers dynamic runtime permission launcher or settings intent on phone.
3. `POST /api/camera/test` -> Captures test frame & returns hardware specs.
4. `POST /api/audio/test_record` -> Records short audio clip & returns peak decibels.
5. `POST /api/notif/test` -> Sends test notification to notification shade.
6. `GET /api/storage/status` -> Returns disk capacity, free bytes, and media counts.
