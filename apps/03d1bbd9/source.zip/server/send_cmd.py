#!/usr/bin/env python3
"""
CLI Controller for Termux AIOS & Android Automation Bridge
Sends commands over localhost WebSocket or HTTP REST to the Android device.

Features:
- List installed applications (with search filter & system app toggle)
- Open / Launch applications by name, package name, or URL
- Inspect on-screen UI hierarchy (Accessibility tree)
- Tap elements by label or coordinates
- Dispatch gestures (swipe, click, scroll next)
- Trigger system actions (Back, Home, Recents, Notifications)
- Display live toast messages
- Seamless auto-fallback to HTTP REST (Port 8080) if WebSocket server (Port 8000) is offline

Usage:
    python send_cmd.py apps [filter] [--system] [--json]
    python send_cmd.py open <appName | packageName | url>
    python send_cmd.py inspect [delay_sec]
    python send_cmd.py click <x> <y>
    python send_cmd.py tap <label>
    python send_cmd.py swipe <x1> <y1> <x2> <y2> [duration_ms]
    python send_cmd.py next
    python send_cmd.py back | home | recents | notifications
    python send_cmd.py toast <text>
"""

import asyncio
import concurrent.futures
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

CLOUDFLARE_TUNNEL_URL = "https://magic-llp-strict-vincent.trycloudflare.com"
CLOUDFLARE_WS_URL = "wss://magic-llp-strict-vincent.trycloudflare.com/ws"
LOCAL_HTTP_URL = "http://127.0.0.1:8080"
LOCAL_WS_URL = "ws://127.0.0.1:8000/ws"
BUNDLED_MASTER_TOKEN = ""

WS_SERVER_URL = os.environ.get("AURA_WS_URL", CLOUDFLARE_WS_URL)
HTTP_SERVER_URL = os.environ.get("AURA_HTTP_URL", CLOUDFLARE_TUNNEL_URL)

try:
    import websockets
    HAS_WEBSOCKETS = True
except ImportError:
    HAS_WEBSOCKETS = False


def parse_center(bounds_str):
    try:
        nums = [int(n) for n in re.findall(r'\d+', bounds_str)]
        if len(nums) == 4:
            return (nums[0] + nums[2]) // 2, (nums[1] + nums[3]) // 2
    except Exception:
        pass
    return None


def print_tree(nodes, depth=0, find_text=None, matched_targets=None):
    if not isinstance(nodes, list):
        nodes = [nodes]

    for node in nodes:
        indent = "  " * depth
        class_name = node.get("className", "").split(".")[-1]
        text = node.get("text", "") or ""
        desc = node.get("contentDescription", "") or ""
        clickable = node.get("isClickable", False)
        bounds = node.get("boundsInScreen", "")

        center = parse_center(bounds)
        cx, cy = center if center else (0, 0)
        coord_str = f" -> click {cx} {cy}" if (clickable and center) else ""

        if find_text and matched_targets is not None:
            clean_search = find_text.strip().lower()
            if (clean_search in text.lower() or clean_search in desc.lower()) and center:
                matched_targets.append((text or desc or class_name, cx, cy))

        info = []
        if text:
            info.append(f'"{text}"')
        if desc and desc != text:
            info.append(f'desc="{desc}"')
        if not info and clickable:
            info.append("(clickable area)")

        label = " ".join(info) if info else ""
        marker = "•" if (clickable or text or desc) else "·"
        print(f"{indent}{marker} [{class_name}] {label}{coord_str}")

        children = node.get("children", [])
        if children:
            print_tree(children, depth + 1, find_text, matched_targets)


# ---------------------------------------------------------------------------
# HTTP REST Fallback Helpers & Security Shield (Zero external dependencies)
# ---------------------------------------------------------------------------

TOKEN_FILE = os.path.expanduser("~/.aura_token")
LOCAL_TOKEN_FILE = os.path.join(os.path.dirname(__file__), ".aura_token")
SDCARD_TOKEN_FILES = [
    "/sdcard/Download/AeroShare/.aura_token",
    "/sdcard/Download/.aura_token",
    "/storage/emulated/0/Download/AeroShare/.aura_token",
    "/storage/emulated/0/Download/.aura_token"
]

def load_stored_token():
    if os.environ.get("AURA_API_TOKEN"):
        return os.environ.get("AURA_API_TOKEN").strip()
    if os.environ.get("AERO_TOKEN"):
        return os.environ.get("AERO_TOKEN").strip()
    for candidate in [TOKEN_FILE, LOCAL_TOKEN_FILE] + SDCARD_TOKEN_FILES:
        if os.path.exists(candidate):
            try:
                with open(candidate, "r") as f:
                    val = f.read().strip()
                    if val:
                        return val
            except Exception:
                pass
    if BUNDLED_MASTER_TOKEN:
        return BUNDLED_MASTER_TOKEN.strip()
    return ""

def save_stored_token(token):
    try:
        with open(TOKEN_FILE, "w") as f:
            f.write(token.strip())
    except Exception:
        pass
    try:
        with open(LOCAL_TOKEN_FILE, "w") as f:
            f.write(token.strip())
    except Exception:
        pass

AUTH_TOKEN = load_stored_token()

def get_http_headers():
    headers = {
        "User-Agent": "AuraTermuxCLI/3.0",
        "Accept": "application/json"
    }
    if AUTH_TOKEN:
        headers["Authorization"] = f"Bearer {AUTH_TOKEN}"
        headers["X-API-Key"] = AUTH_TOKEN
    return headers


def check_unauthorized_response(res):
    global AUTH_TOKEN
    if isinstance(res, dict) and (res.get("error") == "UNAUTHORIZED_DEVICE" or res.get("action") == "AUTHENTICATION_REQUIRED"):
        AUTH_TOKEN = ""
        save_stored_token("")
        print("\n" + "=" * 68)
        print(" 🔒 ACCESS DENIED: UNAUTHORIZED DEVICE")
        print("=" * 68)
        print(" 401 Unauthorized: This device is not authenticated with AeroShare.")
        print(" Please run the login command to authenticate on your phone:")
        print("   python send_cmd.py login")
        print(" Approve with Face, Fingerprint, or PIN when prompted.")
        print("=" * 68 + "\n")
        return True
    return False


def normalize_api_error(err_dict_or_str, status_code=None, reason=None):
    if isinstance(err_dict_or_str, dict):
        if err_dict_or_str.get("cloudflare_error") or err_dict_or_str.get("status") in [502, 503, 504] or status_code in [502, 503, 504]:
            detail = err_dict_or_str.get("detail") or err_dict_or_str.get("title") or "Bad gateway"
            code = err_dict_or_str.get("status") or status_code or 502
            return f"Cloudflare {code} ({detail}): Phone origin server is unreachable or offline. Ensure AeroShare is running on device (Port 8080)."
        if err_dict_or_str.get("server") == "termux-aios" and not err_dict_or_str.get("success", False):
            return "Connected to WebSocket relay on Port 8000 instead of AeroShare REST on Port 8080. Start AeroShare on the device or ensure mock_server.py is running."
        if err_dict_or_str.get("error"):
            return err_dict_or_str.get("error")
        if err_dict_or_str.get("message"):
            return err_dict_or_str.get("message")
        if err_dict_or_str.get("detail"):
            return err_dict_or_str.get("detail")
    if status_code:
        return f"HTTP {status_code}: {reason or 'Server Error'}"
    return str(err_dict_or_str) if err_dict_or_str else "Unknown error"


async def _ws_rpc_async(endpoint, payload=None):
    if not HAS_WEBSOCKETS:
        return None
    req_id = f"req_{uuid.uuid4().hex[:8]}"
    p = dict(payload) if isinstance(payload, dict) else {}
    ws_msg = {"requestId": req_id, "reqId": req_id, "token": AUTH_TOKEN}

    if endpoint == "/api/auth/login":
        ws_msg.update({"type": "AUTH_LOGIN", **p})
        expected = ["AUTH_LOGIN_RESULT", "HTTP_RPC_RESULT"]
    elif endpoint == "/api/auth/poll":
        ws_msg.update({"type": "AUTH_POLL", **p})
        expected = ["AUTH_POLL_RESULT", "HTTP_RPC_RESULT"]
    elif endpoint in ["/api/auth/pair", "/api/pair/verify"]:
        ws_msg.update({"type": "REGISTER_REQUEST", **p})
        expected = ["REGISTER_SUCCESS", "REGISTER_FAILED", "HTTP_RPC_RESULT"]
    elif endpoint == "/api/shell/exec":
        ws_msg.update({"type": "SHELL_EXEC", **p})
        expected = ["SHELL_EXEC_RESULT", "HTTP_RPC_RESULT", "AUTH_REQUIRED"]
    elif endpoint == "/api/system/status":
        ws_msg.update({"type": "SYSTEM_STATUS", **p})
        expected = ["SYSTEM_STATUS_RESULT", "HTTP_RPC_RESULT", "AUTH_REQUIRED"]
    elif endpoint == "/api/system/toggle":
        ws_msg.update({"type": "SYSTEM_TOGGLE", **p})
        expected = ["SYSTEM_TOGGLE_RESULT", "HTTP_RPC_RESULT", "AUTH_REQUIRED"]
    elif endpoint == "/api/screen/capture":
        ws_msg.update({"type": "SCREEN_CAPTURE", **p})
        expected = ["SCREEN_CAPTURE_RESULT", "HTTP_RPC_RESULT", "AUTH_REQUIRED"]
    elif endpoint == "/api/ui/tree":
        ws_msg.update({"type": "UI_TREE", **p})
        expected = ["ACCESSIBILITY_INSPECT_RESULT", "HTTP_RPC_RESULT", "AUTH_REQUIRED"]
    elif endpoint == "/api/ui/action":
        ws_msg.update({"type": "UI_ACTION", **p})
        expected = ["UI_ACTION_RESULT", "HTTP_RPC_RESULT", "AUTH_REQUIRED"]
    elif endpoint.startswith("/api/fs/"):
        op = endpoint.split("/api/fs/")[-1].strip("/")
        ws_msg.update({"type": "FS_OP", "op": op, **p})
        expected = ["FS_OP_RESULT", "HTTP_RPC_RESULT", "AUTH_REQUIRED"]
    elif endpoint.startswith("/api/clipboard/"):
        op = endpoint.split("/api/clipboard/")[-1].strip("/")
        ws_msg.update({"type": "CLIPBOARD_OP", "op": op, **p})
        expected = ["CLIPBOARD_RESULT", "HTTP_RPC_RESULT", "AUTH_REQUIRED"]
    elif endpoint.startswith("/api/"):
        ws_msg.update({"type": "HTTP_RPC", "endpoint": endpoint, **p})
        expected = ["HTTP_RPC_RESULT", "AUTH_REQUIRED"]
    else:
        return None

    ws_targets = [LOCAL_WS_URL]
    if WS_SERVER_URL and WS_SERVER_URL not in ws_targets:
        ws_targets.append(WS_SERVER_URL)

    timeout_sec = 18.0 if endpoint in ["/api/shell/exec", "/api/screen/capture"] else 4.5
    for ws_url in ws_targets:
        try:
            async with websockets.connect(ws_url, open_timeout=2.5, max_size=16 * 1024 * 1024) as ws:
                await ws.send(json.dumps(ws_msg))
                deadline = time.time() + timeout_sec
                while time.time() < deadline:
                    rem = max(0.2, deadline - time.time())
                    raw = await asyncio.wait_for(ws.recv(), timeout=rem)
                    resp = json.loads(raw)
                    rtype = resp.get("type", "")
                    if rtype in expected:
                        if rtype == "AUTH_REQUIRED":
                            resp["error"] = "UNAUTHORIZED_DEVICE"
                        return resp
        except Exception:
            continue
    return None


def ws_rpc_fallback(endpoint, payload=None):
    if not HAS_WEBSOCKETS:
        return None

    def _runner():
        return asyncio.run(_ws_rpc_async(endpoint, payload))

    try:
        try:
            asyncio.get_running_loop()
            in_loop = True
        except RuntimeError:
            in_loop = False

        if not in_loop:
            return _runner()

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            return pool.submit(_runner).result(timeout=22.0)
    except Exception:
        return None


def http_get(path_and_query):
    parts = path_and_query.split("?", 1)
    endpoint = parts[0]
    query_payload = {}
    if len(parts) > 1 and parts[1]:
        for k, v in urllib.parse.parse_qsl(parts[1]):
            query_payload[k] = v

    # 1. Try local loopback HTTP server on port 8080 first (fast 1.5s check)
    local_url = f"{LOCAL_HTTP_URL}{path_and_query}"
    last_error = None
    try:
        req = urllib.request.Request(local_url, headers=get_http_headers())
        with urllib.request.urlopen(req, timeout=1.5) as resp:
            data = resp.read().decode("utf-8")
            parsed = json.loads(data)
            if isinstance(parsed, dict) and not parsed.get("success", False) and not parsed.get("error"):
                parsed["error"] = normalize_api_error(parsed, resp.status, resp.reason)
            return parsed
    except urllib.error.HTTPError as e:
        try:
            err_data = e.read().decode("utf-8")
            parsed = json.loads(err_data)
            if check_unauthorized_response(parsed):
                return parsed
            if isinstance(parsed, dict):
                if not parsed.get("error"):
                    parsed["error"] = normalize_api_error(parsed, e.code, e.reason)
                return parsed
        except Exception:
            pass
        return {"success": False, "error": f"HTTP {e.code}: {e.reason}"}
    except Exception as e:
        last_error = str(e)

    # 2. Try WebSocket RPC via ws_relay.py (ws://127.0.0.1:8000/ws or Cloudflare WSS)
    ws_res = ws_rpc_fallback(endpoint, query_payload)
    if isinstance(ws_res, dict):
        check_unauthorized_response(ws_res)
        return ws_res

    # 3. Fallback to remote HTTP URL if distinct from LOCAL_HTTP_URL
    if HTTP_SERVER_URL and HTTP_SERVER_URL != LOCAL_HTTP_URL:
        remote_url = f"{HTTP_SERVER_URL}{path_and_query}"
        try:
            req = urllib.request.Request(remote_url, headers=get_http_headers())
            with urllib.request.urlopen(req, timeout=4.0) as resp:
                data = resp.read().decode("utf-8")
                parsed = json.loads(data)
                if isinstance(parsed, dict) and not parsed.get("success", False) and not parsed.get("error"):
                    parsed["error"] = normalize_api_error(parsed, resp.status, resp.reason)
                return parsed
        except urllib.error.HTTPError as e:
            try:
                err_data = e.read().decode("utf-8")
                parsed = json.loads(err_data)
                if check_unauthorized_response(parsed):
                    return parsed
                if isinstance(parsed, dict):
                    if not parsed.get("error"):
                        parsed["error"] = normalize_api_error(parsed, e.code, e.reason)
                    return parsed
            except Exception:
                pass
        except Exception as e:
            last_error = str(e)

    return {"success": False, "error": last_error or "Connection failed to AeroShare bridge"}


def http_post(endpoint, payload):
    data_bytes = json.dumps(payload).encode("utf-8")
    headers = get_http_headers()
    headers["Content-Type"] = "application/json"

    timeout_sec = 18.0 if ("/shell" in endpoint or "/screen" in endpoint or "/fs/" in endpoint) else 2.0
    last_error = None

    # 1. Try local loopback HTTP server on port 8080 first
    local_url = f"{LOCAL_HTTP_URL}{endpoint}"
    try:
        req = urllib.request.Request(local_url, data=data_bytes, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
            data = resp.read().decode("utf-8")
            parsed = json.loads(data)
            if isinstance(parsed, dict) and not parsed.get("success", False) and not parsed.get("error"):
                parsed["error"] = normalize_api_error(parsed, resp.status, resp.reason)
            return parsed
    except urllib.error.HTTPError as e:
        try:
            err_data = e.read().decode("utf-8")
            parsed = json.loads(err_data)
            if endpoint not in ["/api/auth/login", "/api/auth/poll"]:
                if check_unauthorized_response(parsed):
                    return parsed
            if isinstance(parsed, dict):
                if not parsed.get("error"):
                    parsed["error"] = normalize_api_error(parsed, e.code, e.reason)
                return parsed
        except Exception:
            pass
        return {"success": False, "error": f"HTTP {e.code}: {e.reason}"}
    except Exception as e:
        last_error = str(e)

    # 2. Try WebSocket RPC via ws_relay.py (ws://127.0.0.1:8000/ws or Cloudflare WSS)
    ws_res = ws_rpc_fallback(endpoint, payload)
    if isinstance(ws_res, dict):
        if endpoint not in ["/api/auth/login", "/api/auth/poll"]:
            check_unauthorized_response(ws_res)
        return ws_res

    # 3. Fallback to remote HTTP URL if distinct from LOCAL_HTTP_URL
    if HTTP_SERVER_URL and HTTP_SERVER_URL != LOCAL_HTTP_URL:
        remote_url = f"{HTTP_SERVER_URL}{endpoint}"
        try:
            req = urllib.request.Request(remote_url, data=data_bytes, headers=headers)
            with urllib.request.urlopen(req, timeout=4.0) as resp:
                data = resp.read().decode("utf-8")
                parsed = json.loads(data)
                if isinstance(parsed, dict) and not parsed.get("success", False) and not parsed.get("error"):
                    parsed["error"] = normalize_api_error(parsed, resp.status, resp.reason)
                return parsed
        except urllib.error.HTTPError as e:
            try:
                err_data = e.read().decode("utf-8")
                parsed = json.loads(err_data)
                if endpoint not in ["/api/auth/login", "/api/auth/poll"]:
                    if check_unauthorized_response(parsed):
                        return parsed
                if isinstance(parsed, dict):
                    if not parsed.get("error"):
                        parsed["error"] = normalize_api_error(parsed, e.code, e.reason)
                    return parsed
            except Exception:
                pass
        except Exception as e:
            last_error = str(e)

    return {"success": False, "error": last_error or "Connection failed to AeroShare bridge"}


def execute_login(client_name="Termux Bridge", as_json=False):
    global AUTH_TOKEN
    sec_dev_id = f"SEC-DEV-{uuid.uuid4().hex[:8].upper()}"

    payload = {
        "clientName": client_name,
        "securityDeviceId": sec_dev_id,
        "deviceId": sec_dev_id
    }

    res = http_post("/api/auth/login", payload)
    if not res.get("success", False):
        fallback_tok = load_stored_token()
        if fallback_tok:
            save_stored_token(fallback_tok)
            AUTH_TOKEN = fallback_tok
            if as_json:
                print(json.dumps({"success": True, "status": "APPROVED", "clientToken": fallback_tok}, indent=2))
            else:
                print("\n" + "=" * 68)
                print(" ✅ VERIFIED! ACCESS GRANTED TO TERMUX (LOCAL DEVICE TOKEN)")
                print("=" * 68)
                print(f" Security Device ID : {sec_dev_id}")
                print(f" Authorized Token   : {fallback_tok[:16]}... (Saved to ~/.aura_token)")
                print(f" Status             : FULLY AUTHORIZED")
                print("-" * 68)
                print(" You can now execute commands from Termux freely!")
                print(" Example: python send_cmd.py status")
                print("=" * 68 + "\n")
            return
        if as_json:
            print(json.dumps(res, indent=2))
        else:
            print(f"\n[ERROR] Login request failed: {res.get('error', 'Unknown error')}")
            print(f"Hint: Ensure AeroShare is connected to ws_relay.py or running at {LOCAL_HTTP_URL}\n")
        return

    req_id = res.get("requestId", "")
    if as_json and not sys.stdout.isatty():
        pass

    print("\n" + "=" * 68)
    print(" 🔐 AUTHENTICATION REQUIRED: PENDING ON-DEVICE VERIFICATION")
    print("=" * 68)
    print(f" Security Device ID : {sec_dev_id}")
    print(f" Client Name        : {client_name}")
    print(f" Notification       : Sent to Android phone notification drawer!")
    print(f" Status             : Waiting for Face, Fingerprint, or PIN on phone...")
    print("-" * 68)
    print(" 📱 Action Required On Phone:")
    print(" 1. Look at your Android phone screen (or tap the incoming notification).")
    print(" 2. Confirm verification using Face, Fingerprint, or PIN/Pattern.")
    print("=" * 68)
    print(" Polling for verification (press Ctrl+C to cancel)", end="", flush=True)

    start_time = time.time()
    poll_payload = {
        "requestId": req_id,
        "securityDeviceId": sec_dev_id
    }

    while time.time() - start_time < 90:
        time.sleep(1.5)
        print(".", end="", flush=True)
        poll_res = http_post("/api/auth/poll", poll_payload)
        if poll_res.get("success", False):
            status = poll_res.get("status", "")
            if status == "APPROVED":
                token = poll_res.get("clientToken", "")
                save_stored_token(token)
                AUTH_TOKEN = token
                print("\n\n" + "=" * 68)
                print(" ✅ VERIFIED! ACCESS GRANTED TO TERMUX")
                print("=" * 68)
                print(f" Security Device ID : {sec_dev_id}")
                print(f" Authorized Token   : {token[:16]}... (Saved to ~/.aura_token)")
                print(f" Status             : FULLY AUTHORIZED")
                print("-" * 68)
                print(" You can now execute commands from Termux freely!")
                print(" Example: python send_cmd.py apps")
                print("=" * 68 + "\n")
                return
            elif status == "DENIED":
                save_stored_token("")
                AUTH_TOKEN = ""
                print("\n\n" + "=" * 68)
                print(" ❌ ACCESS DENIED: Verification was rejected or cancelled on phone.")
                print("=" * 68 + "\n")
                return

    save_stored_token("")
    AUTH_TOKEN = ""
    print("\n\n[TIMEOUT] Verification timed out after 90 seconds. Try running 'python send_cmd.py login' again.\n")


# ---------------------------------------------------------------------------
# App Listing & Formatting
# ---------------------------------------------------------------------------

def display_apps(apps_list, filter_query="", as_json=False):
    if as_json:
        print(json.dumps(apps_list, indent=2))
        return

    if not apps_list:
        if filter_query:
            print(f"\n[!] No installed applications found matching '{filter_query}'.")
            print("    Try running without a filter: python send_cmd.py apps")
        else:
            print("\n[!] No installed applications found.")
        return

    print("\n" + "=" * 80)
    title = f" INSTALLED APPLICATIONS ({len(apps_list)} found)"
    if filter_query:
        title += f" [Filter: '{filter_query}']"
    print(title)
    print("=" * 80)
    print(f" {'#':<4} {'APP NAME':<28} {'PACKAGE NAME':<34} {'TYPE':<8}")
    print("-" * 80)

    for idx, app in enumerate(apps_list, start=1):
        name = app.get("appName", "Unknown")[:26]
        pkg = app.get("packageName", "")[:33]
        is_sys = app.get("isSystemApp", False)
        app_type = "[System]" if is_sys else "[User]"
        print(f" {idx:<4} {name:<28} {pkg:<34} {app_type:<8}")

    print("=" * 80)
    print("💡 Tip: To launch an app, run:")
    print("   python send_cmd.py open <appName | packageName | url>")
    print("   Example: python send_cmd.py open Termux\n")


# ---------------------------------------------------------------------------
# App List & Launch Execution (HTTP REST Port 8080)
# ---------------------------------------------------------------------------

async def execute_list_apps(include_system=False, filter_query="", as_json=False, force_http=False):
    return run_http_list_apps(include_system, filter_query, as_json)


def run_http_list_apps(include_system=False, filter_query="", as_json=False):
    params = []
    if include_system:
        params.append("includeSystem=true")
    if filter_query:
        params.append(f"filter={urllib.parse.quote(filter_query)}")
    q_str = "?" + "&".join(params) if params else ""

    res = http_get(f"/api/app/list{q_str}")
    if res.get("success", False):
        apps = res.get("apps", [])
        if filter_query and not q_str:
            q = filter_query.lower()
            apps = [a for a in apps if q in a.get("appName", "").lower() or q in a.get("packageName", "").lower()]
        display_apps(apps, filter_query, as_json)
        return True
    else:
        err = res.get("error", "Unknown error")
        if err != "UNAUTHORIZED_DEVICE":
            print(f"[ERROR] Could not fetch apps via HTTP: {err}")
            print("Ensure AeroShare is running on the device (HTTP REST active on port 8080).")
        return False


async def execute_launch_app(target, force_http=False):
    clean_target = target.strip()
    is_url = clean_target.startswith(("http://", "https://", "www."))
    return run_http_launch_app(clean_target, is_url)


def run_http_launch_app(clean_target, is_url):
    payload = {
        "packageName": clean_target if not is_url else None,
        "url": clean_target if is_url else None
    }
    res = http_post("/api/app/launch", payload)
    if res.get("success", False):
        target_name = res.get("target") or clean_target
        print(f"✓ Successfully launched: '{target_name}'")
        return True
    else:
        err = res.get("error", "Target not found or launch failed")
        print(f"✗ Failed to launch '{clean_target}': {err}")
        print("  💡 Run 'python send_cmd.py apps' to view installed applications.")
        return False


# ---------------------------------------------------------------------------
# AeroShare Peer-to-Peer File Transfer & Local Device Discovery
# ---------------------------------------------------------------------------

def execute_devices(as_json=False):
    res = http_get("/api/share/devices")
    if as_json:
        print(json.dumps(res, indent=2))
        return
    if not res.get("success", False):
        print(f"[ERROR] Could not fetch devices: {res.get('error', 'Unknown')}")
        return

    local_name = res.get("localDeviceName", "Android Device")
    local_ip = res.get("localIp", "Unknown")
    is_radar = res.get("isRadarActive", True)
    devices = res.get("devices", [])

    print("\n" + "=" * 80)
    print(f" AEROSHARE LOCAL RADAR & PEER DISCOVERY")
    print(f" Local Device: {local_name} ({local_ip}) | Radar: {'[ON - Scanning]' if is_radar else '[OFF]'}")
    print("=" * 80)
    if not devices:
        print(" [!] No nearby AeroShare peers discovered yet.")
        print("     • Ensure devices are connected to the same Wi-Fi or Hotspot.")
        print("     • You can manually beam to any device IP via: python send_cmd.py share <file> <IP>")
    else:
        print(f" {'#':<4} {'DEVICE NAME':<28} {'IP ADDRESS':<18} {'PORT':<8} {'TYPE':<10} {'SIGNAL':<8}")
        print("-" * 80)
        for idx, dev in enumerate(devices, start=1):
            name = dev.get("name", "Peer")[:26]
            ip = dev.get("ip", "")[:16]
            port = dev.get("port", 8080)
            dtype = dev.get("deviceType", "PHONE")[:8]
            rssi = f"{dev.get('rssi', -50)}dBm"
            print(f" {idx:<4} {name:<28} {ip:<18} {port:<8} {dtype:<10} {rssi:<8}")
    print("=" * 80 + "\n")


def execute_share(target_input, peer_ip="", as_json=False):
    if not target_input:
        print("[ERROR] Please specify a file path or text snippet to share.")
        print("Usage: python send_cmd.py share <filePath | text> [targetDeviceIp]")
        return

    is_file = os.path.exists(target_input) and os.path.isfile(target_input)
    payload = {}
    if is_file:
        payload["filePath"] = os.path.abspath(target_input)
    else:
        payload["text"] = target_input

    if peer_ip:
        payload["ip"] = peer_ip

    res = http_post("/api/share/send", payload)
    if as_json:
        print(json.dumps(res, indent=2))
        return

    if res.get("success", False):
        if is_file:
            print(f"✓ Started AeroShare transfer of '{res.get('fileName')}' ({res.get('sizeBytes', 0)} bytes)")
            print(f"  Transfer ID : {res.get('transferId')}")
            print(f"  Target Peer : {res.get('targetIp')}")
            print("  Run 'python send_cmd.py transfers' to inspect live progress.")
        else:
            print(f"✓ Sent text snippet to {res.get('targetIp')}: \"{res.get('text')}\"")
    else:
        print(f"✗ Failed to initiate transfer: {res.get('error', 'Unknown error')}")


def execute_transfers(as_json=False):
    res = http_get("/api/share/transfers")
    if as_json:
        print(json.dumps(res, indent=2))
        return
    transfers = res.get("transfers", [])
    print("\n" + "=" * 80)
    print(f" AEROSHARE ACTIVE TRANSFERS ({len(transfers)} active)")
    print("=" * 80)
    if not transfers:
        print(" No active transfers currently running.")
    else:
        for tx in transfers:
            fn = tx.get("fileName", "file")
            pct = tx.get("progressPct", 0)
            status = tx.get("status", "TRANSFERRING")
            speed = tx.get("speedBytesPerSec", 0) / (1024 * 1024)
            eta = tx.get("etaSeconds", 0)
            direction = tx.get("direction", "SEND")
            peer = tx.get("peerName", tx.get("peerIp", "Peer"))
            tx_id = tx.get("id", "")
            bar_len = 20
            filled = int(bar_len * pct / 100)
            bar = "█" * filled + "░" * (bar_len - filled)
            print(f" [{direction}] {fn} -> {peer}")
            print(f"   [{bar}] {pct}% | {speed:.2f} MB/s | ETA: {eta}s | Status: {status} | ID: {tx_id}")
    print("=" * 80 + "\n")


def execute_history(as_json=False):
    res = http_get("/api/share/history")
    if as_json:
        print(json.dumps(res, indent=2))
        return
    history = res.get("history", [])
    print("\n" + "=" * 80)
    print(f" AEROSHARE TRANSFER HISTORY ({len(history)} items)")
    print("=" * 80)
    if not history:
        print(" No completed transfers recorded.")
    else:
        print(f" {'FILE NAME':<30} {'STATUS':<12} {'DIR':<8} {'PEER':<20}")
        print("-" * 80)
        for item in history[:20]:
            fn = item.get("fileName", "file")[:28]
            status = item.get("status", "DONE")[:10]
            direction = item.get("direction", "SEND")[:6]
            peer = item.get("peerName", "Peer")[:18]
            print(f" {fn:<30} {status:<12} {direction:<8} {peer:<20}")
    print("=" * 80 + "\n")


def execute_cancel(transfer_id):
    if not transfer_id:
        print("[ERROR] Missing transfer ID to cancel.")
        return
    res = http_post("/api/share/cancel", {"id": transfer_id})
    if res.get("success", False):
        print(f"✓ Cancelled transfer: {transfer_id}")
    else:
        print(f"✗ Could not cancel transfer: {transfer_id}")


def execute_clip(text=None, as_json=False):
    if text:
        res = http_post("/api/share/clip", {"text": text})
        if as_json:
            print(json.dumps(res, indent=2))
        else:
            print(f"✓ Beamed clipboard snippet: \"{text}\"")
    else:
        res = http_get("/api/share/clip")
        if as_json:
            print(json.dumps(res, indent=2))
        else:
            clip_text = res.get("clipboardText", "")
            print(f"Clipboard Content: {clip_text}")


def execute_radar(enable=None, as_json=False):
    payload = {}
    if enable is not None:
        payload["enabled"] = enable
    res = http_post("/api/share/radar", payload)
    if as_json:
        print(json.dumps(res, indent=2))
    else:
        status_str = "ACTIVE (Scanning)" if res.get("isRadarActive", True) else "PAUSED"
        print(f"✓ AeroShare Radar is now: {status_str}")


def execute_battery(as_json=False):
    res = http_get("/api/battery")
    if as_json:
        print(json.dumps(res, indent=2))
        return
    pct = res.get("batteryPct", 0)
    charging = "⚡ Charging" if res.get("isCharging", False) else "Discharging"
    temp = res.get("batteryTempC", 0.0)
    uptime_sec = res.get("uptimeSeconds", 0)
    uptime_str = f"{uptime_sec // 3600}h {(uptime_sec % 3600) // 60}m"
    is_opt = res.get("isIgnoringBatteryOptimizations", False)
    print("\n" + "=" * 55)
    print(" 🔋 DEVICE BATTERY & POWER STATUS")
    print("=" * 55)
    print(f" Level:           {pct}% [{charging}]")
    print(f" Temperature:     {temp}°C")
    print(f" Throttling:      {'Yes ⚠️' if res.get('isThermalThrottling', False) else 'Normal'}")
    print(f" Background Mode: {'✓ UNRESTRICTED (Exempt from Doze)' if is_opt else '⚠️ OPTIMIZED (Restricted in Doze)'}")
    print(f" Uptime:          {uptime_str}")
    print("=" * 55 + "\n")


def execute_location(as_json=False):
    res = http_get("/api/location")
    if as_json:
        print(json.dumps(res, indent=2))
        return
    print("\n" + "=" * 68)
    print(" 📍 DEVICE GPS & LOCATION TELEMETRY")
    print("=" * 68)
    if res.get("success", False):
        lat = res.get("latitude", 0.0)
        lon = res.get("longitude", 0.0)
        acc = res.get("accuracy", 0.0)
        alt = res.get("altitude", 0.0)
        spd = res.get("speed", 0.0)
        spd_kmh = res.get("speedKmh", spd * 3.6)
        spd_mph = res.get("speedMph", spd * 2.23694)
        bearing = res.get("bearing", 0.0)
        compass = res.get("bearingCompass", "")
        prov = res.get("provider", "GPS")
        is_live = res.get("isLiveTracking", False)
        up_cnt = res.get("updateCount", 0)
        maps_url = res.get("mapsUrl", f"https://maps.google.com/?q={lat},{lon}")

        print(f" Status           : {'🟢 LIVE REALTIME STREAMING (1s Active)' if is_live else '🔵 Fixed Snapshot'}")
        print(f" Latitude         : {lat:.6f}")
        print(f" Longitude        : {lon:.6f}")
        print(f" Coordinates      : {lat:.6f}, {lon:.6f}")
        print(f" Accuracy         : ±{acc:.1f} meters")
        print(f" Speed            : {spd_kmh:.1f} km/h ({spd_mph:.1f} mph | {spd:.2f} m/s)")
        if compass:
            print(f" Heading/Bearing  : {compass} ({bearing:.0f}°)")
        print(f" Altitude         : {alt:.1f} meters")
        print(f" Provider         : {prov.upper()}")
        if up_cnt > 0:
            print(f" Fix Counter      : Update #{up_cnt}")
        print(f" Google Maps URL  : {maps_url}")
        print("-" * 68)
        print(" 💡 Tip: For continuous real-time live GPS streaming, run:")
        print("    python send_cmd.py location --live")
    else:
        print(f" [!] {res.get('error', 'Location unavailable')}")
        print(" 💡 Tip: Ensure Location is enabled on the phone and AeroShare has Location permission.")
    print("=" * 68 + "\n")


def execute_live_location(interval_sec=1.0, as_json=False):
    # Activate live location tracking on phone
    start_res = http_post("/api/location/live", {"action": "START", "intervalMs": int(interval_sec * 1000)})
    if not start_res.get("success", False):
        err = start_res.get("error", "Unknown error")
        print(f"\n[ERROR] Could not start live GPS tracking: {err}")
        print("Ensure Location is enabled in phone settings and AeroShare has Location permission.\n")
        return

    print("\n" + "=" * 80)
    print(" 🛰️  REAL-TIME GPS TELEMETRY STREAM (Continuous 1-Second Updates)")
    print("=" * 80)
    print(f" Provider : High-Accuracy Fused GPS + Network Provider")
    print(f" Interval : {interval_sec}s updates")
    print(f" Controls : Press Ctrl+C at any time to stop streaming")
    print("-" * 80)
    print(f" {'TIME':<10} {'FIX#':<7} {'LATITUDE':<12} {'LONGITUDE':<12} {'ACCURACY':<10} {'SPEED':<14} {'HEADING':<10}")
    print("-" * 80)

    try:
        last_count = -1
        while True:
            res = http_get("/api/location")
            if as_json:
                print(json.dumps(res))
            elif res.get("success", False) and res.get("hasCoordinates", False):
                now_str = time.strftime("%H:%M:%S")
                fix_num = res.get("updateCount", 0)
                lat = res.get("latitude", 0.0)
                lon = res.get("longitude", 0.0)
                acc = res.get("accuracy", 0.0)
                spd_kmh = res.get("speedKmh", res.get("speed", 0.0) * 3.6)
                bearing = res.get("bearing", 0.0)
                compass = res.get("bearingCompass", "")
                head_str = f"{compass} {int(bearing)}°" if compass else f"{int(bearing)}°"

                prefix = "🟢" if fix_num != last_count else "  "
                print(f" {prefix} {now_str:<8} #{fix_num:<5} {lat:<12.6f} {lon:<12.6f} ±{acc:<7.1f}m {spd_kmh:<7.1f} km/h {head_str:<10}")
                last_count = fix_num
            else:
                now_str = time.strftime("%H:%M:%S")
                msg = res.get("statusMessage", res.get("error", "Acquiring GPS fix..."))
                print(f"    {now_str:<8} [ACQUIRING] {msg}")

            time.sleep(interval_sec)
    except KeyboardInterrupt:
        print("\n\n" + "-" * 80)
        print(" ⏹️  Stopping live GPS telemetry on device...")
        http_post("/api/location/live", {"action": "STOP"})
        print(" ✓ Live GPS stream stopped. Device returned to standby.")
        print("=" * 80 + "\n")


def execute_battery_opt(action="STATUS", as_json=False):
    res = http_post("/api/battery/optimization", {"action": action.upper()})
    if as_json:
        print(json.dumps(res, indent=2))
        return
    status = res.get("status", "OPTIMIZED")
    print("\n" + "=" * 60)
    print(f" ⚡ BATTERY OPTIMIZATION & BACKGROUND EXECUTION: [{status}]")
    print("=" * 60)
    if status == "UNRESTRICTED":
        print(" ✓ App is UNRESTRICTED. Background transfers & radar run uninterrupted.")
    else:
        print(" ⚠️ App is OPTIMIZED. Android Doze may pause background transfers.")
        print(f" 💡 {res.get('hint', '')}")
    if res.get("actionRequested", False):
        print(" ✓ System authorization intent dispatched to phone screen.")
    print("=" * 60 + "\n")


def execute_sensors(as_json=False):
    res = http_get("/api/sensors")
    if as_json:
        print(json.dumps(res, indent=2))
        return
    print("\n" + "=" * 60)
    print(" 📡 LIVE HARDWARE SENSORS SNAPSHOT")
    print("=" * 60)
    if "ambientLightLux" in res:
        print(f" Ambient Light:    {res['ambientLightLux']:.1f} lux")
    if "proximityCm" in res:
        is_near = " (NEAR)" if res.get("isNear", False) else " (FAR)"
        print(f" Proximity:        {res['proximityCm']:.1f} cm{is_near}")
    if "compassHeadingDegrees" in res:
        cardinal = res.get("compassCardinal", "")
        print(f" Compass:          {res['compassHeadingDegrees']:.1f}° ({cardinal})")
    if "pressureHpa" in res:
        print(f" Barometer:        {res['pressureHpa']:.1f} hPa")
    if "stepCount" in res:
        print(f" Step Counter:     {int(res['stepCount'])} steps")
    if "accelerometer" in res:
        acc = res["accelerometer"]
        print(f" Accelerometer:    X={acc.get('x', 0):.2f}, Y={acc.get('y', 0):.2f}, Z={acc.get('z', 0):.2f} m/s²")
    if "gyroscope" in res:
        gyro = res["gyroscope"]
        print(f" Gyroscope:        X={gyro.get('x', 0):.2f}, Y={gyro.get('y', 0):.2f}, Z={gyro.get('z', 0):.2f} rad/s")
    print("=" * 60 + "\n")


def execute_torch(enable=True, as_json=False):
    res = http_post("/api/torch", {"enabled": enable})
    if as_json:
        print(json.dumps(res, indent=2))
    else:
        state_str = "ON 🔦" if enable else "OFF"
        print(f"✓ Camera Torch set to: {state_str}")


def execute_vibrate(duration_ms=200, preset=None, as_json=False):
    payload = {"durationMs": duration_ms}
    if preset:
        payload["preset"] = preset
    res = http_post("/api/vibrate", payload)
    if as_json:
        print(json.dumps(res, indent=2))
    else:
        print(f"✓ Triggered haptic vibration ({duration_ms}ms)")


def execute_tts(text, pitch=1.0, rate=1.0, as_json=False):
    if not text:
        print("[ERROR] Missing text to speak.")
        return
    res = http_post("/api/tts", {"text": text, "pitch": pitch, "rate": rate})
    if as_json:
        print(json.dumps(res, indent=2))
    else:
        print(f"✓ Spoke aloud: \"{text}\"")


def execute_volume(level=None, stream="MEDIA", as_json=False):
    if level is not None:
        try:
            vol_int = int(level)
            res = http_post("/api/volume", {"stream": stream.upper(), "volume": vol_int})
            if as_json:
                print(json.dumps(res, indent=2))
            else:
                print(f"✓ Set {stream.upper()} volume to: {vol_int}")
        except ValueError:
            print(f"[ERROR] Invalid volume level: {level}")
    else:
        res = http_get("/api/volume")
        if as_json:
            print(json.dumps(res, indent=2))
            return
        print("\n" + "=" * 50)
        print(" 🔊 AUDIO STREAMS & VOLUME STATUS")
        print("=" * 50)
        print(f" Ringer Mode: {res.get('ringerMode', 'NORMAL')}")
        print("-" * 50)
        for s in res.get("streams", []):
            st = s.get("stream", "STREAM")
            cur = s.get("volume", 0)
            max_v = s.get("max", 15)
            pct = s.get("percentage", 0)
            print(f" {st:<16} {cur:>2}/{max_v:<2} ({pct}%)")
        print("=" * 50 + "\n")


def execute_tone(freq_hz=440, duration_ms=500, as_json=False):
    res = http_post("/api/audio/tone", {"frequency": freq_hz, "durationMs": duration_ms})
    if as_json:
        print(json.dumps(res, indent=2))
    else:
        print(f"✓ Played audio tone ({freq_hz} Hz for {duration_ms}ms)")


def execute_hud(text, title="⚡ Termux HUD", as_json=False):
    res = http_post("/api/floating", {"title": title, "text": text, "type": "HUD", "isDraggable": True})
    if as_json:
        print(json.dumps(res, indent=2))
    else:
        if res.get("displayedAsToast", False):
            print(f"✓ HUD displayed as Toast (overlay permission pending): \"{text}\"")
        else:
            print(f"✓ Floating HUD displayed: \"{text}\"")


def execute_notify(title, message, as_json=False):
    res = http_post("/api/notification", {"title": title, "message": message})
    if as_json:
        print(json.dumps(res, indent=2))
    else:
        print(f"✓ System notification posted: [{title}] {message}")


def execute_media(action="PLAY_PAUSE", as_json=False):
    res = http_post("/api/media/control", {"command": action})
    if as_json:
        print(json.dumps(res, indent=2))
    else:
        print(f"✓ Media action '{action.upper()}' dispatched")


def execute_storage(folder="DOWNLOADS", limit=30, as_json=False):
    res = http_post("/api/storage/files", {"folder": folder, "limit": limit})
    if as_json:
        print(json.dumps(res, indent=2))
        return
    files = res.get("files", [])
    directory = res.get("directory", folder)
    print("\n" + "=" * 80)
    print(f" 📁 STORAGE FILE EXPLORER: {directory} ({len(files)} files)")
    print("=" * 80)
    print(f" {'#':<4} {'NAME':<38} {'SIZE':<12} {'TYPE':<8}")
    print("-" * 80)
    for idx, f in enumerate(files, start=1):
        name = f.get("name", "")[:36]
        sz_bytes = f.get("sizeBytes", 0)
        is_dir = f.get("isDirectory", False)
        if is_dir:
            sz_str = "<DIR>"
            ftype = "[DIR]"
        else:
            if sz_bytes > 1024 * 1024:
                sz_str = f"{sz_bytes / (1024 * 1024):.1f} MB"
            elif sz_bytes > 1024:
                sz_str = f"{sz_bytes / 1024:.1f} KB"
            else:
                sz_str = f"{sz_bytes} B"
            ftype = "[FILE]"
        print(f" {idx:<4} {name:<38} {sz_str:<12} {ftype:<8}")
    print("=" * 80)
    print("💡 Tip: Share any file instantly:")
    print("   python send_cmd.py share <filePath>\n")


def execute_sms(phone, message="", as_json=False):
    if not phone:
        print("[ERROR] Missing phone number.")
        return
    res = http_post("/api/sms/compose", {"phone": phone, "message": message})
    if as_json:
        print(json.dumps(res, indent=2))
    else:
        print(f"✓ SMS Composer opened for: {phone}")


def execute_shell(cmd_str, timeout_ms=15000, cwd=None, as_json=False):
    if not cmd_str:
        print("[ERROR] Missing shell command.")
        print("Usage: python send_cmd.py shell <command>")
        return
    payload = {"cmd": cmd_str, "timeout_ms": timeout_ms}
    if cwd:
        payload["cwd"] = cwd
    res = http_post("/api/shell/exec", payload)
    if as_json:
        print(json.dumps(res, indent=2))
        return
    exit_code = res.get("exit_code", -1)
    dur = res.get("duration_ms", 0)
    stdout = res.get("stdout", "")
    stderr = res.get("stderr", "")
    if stdout:
        print(stdout, end="" if stdout.endswith("\n") else "\n")
    if stderr:
        print(stderr, file=sys.stderr, end="" if stderr.endswith("\n") else "\n")
    if not res.get("success", False) and not stdout and not stderr:
        print(f"[ERROR] Shell execution failed: {res.get('error', 'Unknown error')}")
    else:
        print(f"[exit={exit_code} | {dur}ms]")


def execute_screenshot(out_path="screenshot.jpg", quality=80, as_json=False):
    res = http_post("/api/screen/capture", {"quality": quality, "maxDimension": 1440})
    if as_json:
        print(json.dumps(res, indent=2))
        return
    if res.get("success", False) and res.get("base64"):
        import base64
        raw_bytes = base64.b64decode(res["base64"])
        with open(out_path, "wb") as f:
            f.write(raw_bytes)
        w = res.get("width", 0)
        h = res.get("height", 0)
        print(f"✓ Screenshot saved to '{out_path}' ({w}x{h}, {len(raw_bytes) // 1024} KB)")
    else:
        print(f"✗ Screenshot failed: {res.get('error', 'Unknown error')}")


def execute_system_toggle(target, state="toggle", extra=None, as_json=False):
    payload = {"target": target, "state": state}
    if extra:
        payload.update(extra)
    res = http_post("/api/system/toggle", payload)
    if as_json:
        print(json.dumps(res, indent=2))
        return
    if res.get("success", False):
        print(f"✓ System toggle '{target}' -> {json.dumps({k: v for k, v in res.items() if k not in ['success', 'target']})}")
    else:
        print(f"✗ System toggle '{target}' failed: {res.get('error', 'Unknown error')}")


def execute_system_status(as_json=False):
    res = http_get("/api/system/status")
    if as_json:
        print(json.dumps(res, indent=2))
        return
    if not res.get("success", False):
        print(f"[ERROR] {res.get('error', 'Failed to fetch system status')}")
        return
    print("\n" + "=" * 60)
    print(" 📱 AEROSHARE SYSTEM & BRIDGE STATUS")
    print("=" * 60)
    print(f" Flashlight (Torch) : {'ON 🔦' if res.get('torchEnabled') else 'OFF'}")
    print(f" Do Not Disturb     : {'ACTIVE 🔕' if res.get('dndEnabled') else 'NORMAL'}")
    print(f" Wi-Fi              : {'ENABLED' if res.get('wifiEnabled') else 'DISABLED'} ({res.get('wifiSsid') or 'No SSID'})")
    print(f" Local IPv4         : {res.get('localIp', '127.0.0.1')}")
    print(f" Bluetooth          : {'ENABLED' if res.get('bluetoothEnabled') else 'DISABLED'}")
    print(f" Media Volume       : {res.get('mediaVolume', 0)}/{res.get('mediaMaxVolume', 15)} [{res.get('ringerMode', 'NORMAL')}]")
    print(f" Screen Brightness  : {res.get('brightness', 0)}/255")
    print(f" UI Accessibility   : {'READY ✓' if res.get('accessibilityEnabled') else 'DISABLED ⚠️'}")
    print(f" Clipboard Preview  : {res.get('clipboardPreview', '')[:50]}")
    print("=" * 60 + "\n")


def execute_fs_op(op, path="", extra=None, as_json=False):
    payload = {"path": path}
    if extra:
        payload.update(extra)
    res = http_post(f"/api/fs/{op}", payload)
    if as_json:
        print(json.dumps(res, indent=2))
        return res
    if not res.get("success", False):
        print(f"✗ File '{op}' failed: {res.get('error', 'Unknown error')}")
        return res
    if op == "list":
        files = res.get("files", [])
        print(f"\n📁 Directory: {res.get('path')} ({len(files)} entries)")
        print("-" * 72)
        for item in files:
            marker = "[DIR] " if item.get("isDirectory") else "[FILE]"
            sz = item.get("sizeBytes", 0)
            sz_str = "<DIR>" if item.get("isDirectory") else f"{sz} B"
            print(f" {marker} {item.get('name', ''):<42} {sz_str:>12}")
        print("-" * 72 + "\n")
    elif op == "read":
        if res.get("encoding") == "base64":
            print(f"[Binary file: {res.get('sizeBytes', 0)} bytes, base64 encoded]")
        else:
            content = res.get("content", "")
            print(content, end="" if content.endswith("\n") else "\n")
    elif op == "write":
        print(f"✓ Wrote {res.get('writtenBytes', 0)} bytes to {res.get('path')}")
    elif op == "delete":
        print(f"✓ Deleted {res.get('path')}")
    elif op == "stat":
        print(json.dumps(res, indent=2))
    return res


def execute_ui_http(action, payload, as_json=False):
    body = {"action": action}
    body.update(payload)
    res = http_post("/api/ui/action", body)
    if as_json:
        print(json.dumps(res, indent=2))
    elif res.get("success", False):
        print(f"✓ UI action '{action}' succeeded")
    else:
        print(f"✗ UI action '{action}' failed: {res.get('error', 'Unknown error')}")
    return res


# ---------------------------------------------------------------------------
# Hardware Stations & Interactive Permissions Hub
# ---------------------------------------------------------------------------

def execute_permissions(subcmd="list", target=None, as_json=False):
    subcmd = (subcmd or "list").lower()
    if subcmd in ["list", "status", "overview", "ls"]:
        res = http_get("/api/permissions")
        if as_json:
            print(json.dumps(res, indent=2))
            return res
        perms = res.get("permissions", [])
        print("\n" + "=" * 80)
        print(f" 🛡️ ANDROID PERMISSIONS & HARDWARE STATIONS OVERVIEW ({len(perms)} monitored)")
        print("=" * 80)
        print(f" {'#':<3} {'ID':<20} {'NAME':<18} {'STATUS':<12} {'PERMISSION'}")
        print("-" * 80)
        for idx, p in enumerate(perms, start=1):
            pid = p.get("id", "")
            pname = p.get("name", "")
            granted = p.get("isGranted", False)
            status_str = "✅ GRANTED" if granted else "❌ DENIED"
            perm_str = p.get("permission", "").replace("android.permission.", "")
            print(f" {idx:<3} {pid:<20} {pname:<18} {status_str:<12} {perm_str}")
        print("=" * 80)
        print("💡 Tip: Request permission or open settings:")
        print("   python send_cmd.py permissions request <camera|mic|notif|storage|location>")
        print("   python send_cmd.py permissions settings <camera|mic|notif|storage|location>\n")
        return res

    elif subcmd in ["request", "ask", "grant", "prompt"]:
        if not target:
            print("[ERROR] Missing target permission.")
            print("Usage: python send_cmd.py permissions request <camera|mic|notif|storage|location>")
            return
        res = http_post("/api/permissions/request", {"idOrName": target, "openSettings": False})
        if as_json:
            print(json.dumps(res, indent=2))
        else:
            print(f"✓ Requested '{target}' permission on device! Alert dispatched to phone screen.")
        return res

    elif subcmd in ["settings", "open", "config"]:
        target = target or "app"
        res = http_post("/api/permissions/request", {"idOrName": target, "openSettings": True})
        if as_json:
            print(json.dumps(res, indent=2))
        else:
            print(f"✓ Opened Android Settings for '{target}' on device display.")
        return res

    else:
        print(f"[ERROR] Unknown permissions subcommand: '{subcmd}'. Available: list, request, settings")


def execute_camera(subcmd="status", as_json=False):
    subcmd = (subcmd or "status").lower()
    if subcmd in ["status", "info", "details"]:
        res = http_get("/api/camera/status")
        if as_json:
            print(json.dumps(res, indent=2))
            return res
        granted = res.get("isGranted", False)
        status_str = "✅ GRANTED" if granted else "❌ DENIED"
        cameras = res.get("cameras", [])
        print("\n" + "=" * 70)
        print(" 📸 CAMERA HARDWARE STATION")
        print("=" * 70)
        print(f" Permission Status  : {status_str}")
        print(f" Total Cameras      : {res.get('cameraCount', len(cameras))}")
        print(f" Back Facing        : {res.get('backCameras', 0)}")
        print(f" Front Facing       : {res.get('frontCameras', 0)}")
        print(f" Flash Available    : {'YES' if res.get('hasFlash') else 'NO'}")
        if cameras:
            print("-" * 70)
            print(f" {'ID':<6} {'FACING':<12} {'FLASH':<10}")
            for c in cameras:
                print(f" {c.get('id', ''):<6} {c.get('facing', ''):<12} {'YES' if c.get('hasFlash') else 'NO':<10}")
        print("=" * 70)
        print("💡 Tip: Test or manage camera:")
        print("   python send_cmd.py camera test      # Launch camera capture on phone")
        print("   python send_cmd.py camera perm      # Trigger on-screen permission prompt")
        print("   python send_cmd.py camera settings  # Open camera settings\n")
        return res

    elif subcmd in ["test", "capture", "shot", "snap"]:
        res = http_post("/api/camera/test", {})
        if as_json:
            print(json.dumps(res, indent=2))
        elif res.get("success", False):
            print("✓ Camera capture activity launched successfully on device!")
        else:
            print(f"✗ Camera test failed: {res.get('error', 'Camera not accessible')}")
        return res

    elif subcmd in ["perm", "request", "grant"]:
        return execute_permissions("request", "camera", as_json=as_json)

    elif subcmd in ["settings", "open"]:
        return execute_permissions("settings", "camera", as_json=as_json)

    else:
        print(f"[ERROR] Unknown camera subcommand: '{subcmd}'. Available: status, test, perm, settings")


def execute_mic(subcmd="status", duration_sec=3, as_json=False):
    subcmd = (subcmd or "status").lower()
    if subcmd in ["status", "info", "details"]:
        res = http_get("/api/mic/status")
        if as_json:
            print(json.dumps(res, indent=2))
            return res
        granted = res.get("isGranted", False)
        status_str = "✅ GRANTED" if granted else "❌ DENIED"
        has_hw = res.get("hasMicrophoneHardware", True)
        is_muted = res.get("isMicrophoneMuted", False)
        sample_rate = res.get("sampleRateHz", "44100")
        print("\n" + "=" * 70)
        print(" 🎙️ MICROPHONE HARDWARE STATION")
        print("=" * 70)
        print(f" Permission Status  : {status_str}")
        print(f" Hardware Available : {'YES' if has_hw else 'NO'}")
        print(f" Microphone Muted   : {'YES' if is_muted else 'NO'}")
        print(f" Output Sample Rate : {sample_rate} Hz")
        print("=" * 70)
        print("💡 Tip: Record audio or manage mic:")
        print("   python send_cmd.py mic --live       # Real-time continuous audio recording & live VU meter")
        print("   python send_cmd.py mic test [sec]   # Record test audio clip (default 3s)")
        print("   python send_cmd.py mic play <file>  # Play back audio file on device")
        print("   python send_cmd.py mic perm         # Trigger on-screen permission prompt")
        print("   python send_cmd.py mic settings     # Open microphone settings\n")
        return res

    elif subcmd in ["live", "--live", "-l", "stream", "record-live", "realtime", "start"]:
        return execute_live_mic(as_json=as_json)

    elif subcmd in ["stop", "unrecord", "finish"]:
        res = http_post("/api/mic/live/stop", {})
        if as_json:
            print(json.dumps(res, indent=2))
        elif res.get("success", False):
            print(f"✓ Real-time recording stopped: {res.get('filePath')}")
        else:
            print(f"✗ Failed to stop recording: {res.get('error', 'No active recording')}")
        return res

    elif subcmd in ["play", "listen"]:
        path = target_arg or ""
        res = http_post("/api/mic/play", {"filePath": path})
        if as_json:
            print(json.dumps(res, indent=2))
        elif res.get("success", False):
            print(f"✓ Playing audio on phone: {path}")
        else:
            print(f"✗ Playback failed: {res.get('error', 'Could not play audio')}")
        return res

    elif subcmd in ["test", "record", "rec", "sample"]:
        print(f"🎙️ Recording {duration_sec}s audio sample on device...")
        res = http_post("/api/audio/test_record", {"durationSec": duration_sec})
        if as_json:
            print(json.dumps(res, indent=2))
        elif res.get("success", False):
            print("\n" + "=" * 70)
            print(" 🎙️ MICROPHONE TEST RECORDING COMPLETE")
            print("=" * 70)
            print(f" Duration        : {res.get('durationSec', duration_sec)}s")
            print(f" Sample Rate     : {res.get('sampleRate', 44100)} Hz")
            print(f" Channels        : {res.get('channels', 1)}")
            print(f" Peak Amplitude  : {res.get('maxAmplitude', 0)}")
            print(f" Total Bytes     : {res.get('sizeBytes', 0):,} bytes")
            print("=" * 70 + "\n")
        else:
            print(f"✗ Microphone recording failed: {res.get('error', 'Microphone not accessible')}")
        return res

    elif subcmd in ["perm", "request", "grant"]:
        return execute_permissions("request", "record_audio", as_json=as_json)

    elif subcmd in ["settings", "open"]:
        return execute_permissions("settings", "record_audio", as_json=as_json)

    else:
        print(f"[ERROR] Unknown mic subcommand: '{subcmd}'. Available: --live, test, stop, play, perm, settings")


def execute_live_mic(as_json=False):
    res = http_post("/api/mic/live/start", {})
    if as_json:
        print(json.dumps(res, indent=2))
        return res
    if not res.get("success", False):
        print(f"✗ Failed to start real-time recording: {res.get('error', 'Microphone error')}")
        return res

    file_path = res.get("filePath", "")
    print("\n" + "=" * 76)
    print(" 🎙️ REAL-TIME LIVE AUDIO RECORDING STARTED")
    print("=" * 76)
    print(f" Target File   : {file_path}")
    print(" Live VU Meter : Streaming audio telemetry (Press Ctrl+C to stop & save)...")
    print("-" * 76)

    try:
        while True:
            time.sleep(0.12)
            st = http_get("/api/mic/live/status")
            if not st.get("isRecording", False):
                break
            dur_ms = st.get("durationMs", 0)
            sec = dur_ms // 1000
            min_part = sec // 60
            sec_part = sec % 60
            tenth = (dur_ms % 1000) // 100
            time_str = f"{min_part:02d}:{sec_part:02d}.{tenth}"

            bytes_rec = st.get("bytesRecorded", 0)
            kb_str = f"{bytes_rec / 1024.0:.1f} KB"
            rms = int(st.get("rms", 0))
            db = st.get("decibels", -60.0)

            norm_db = max(0.0, min(60.0, db + 60.0))
            bar_len = int((norm_db / 60.0) * 20)
            meter_bar = "█" * bar_len + "░" * (20 - bar_len)

            sys.stdout.write(f"\r 🔴 [{time_str}] | {kb_str:>9} | RMS:{rms:>5} | {db:>5.1f} dB [{meter_bar}] ")
            sys.stdout.flush()
    except KeyboardInterrupt:
        pass
    finally:
        print("\n\nStopping real-time recording and finalizing WAV audio header...")
        stop_res = http_post("/api/mic/live/stop", {})
        if as_json:
            print(json.dumps(stop_res, indent=2))
        elif stop_res.get("success", False):
            print("\n" + "=" * 76)
            print(" ✅ REAL-TIME AUDIO RECORDING SAVED")
            print("=" * 76)
            print(f" Duration       : {stop_res.get('durationSec', 0)}s ({stop_res.get('durationMs', 0)} ms)")
            print(f" Total Size     : {stop_res.get('sizeBytes', 0) / 1024.0:.1f} KB")
            print(f" Sample Rate    : {stop_res.get('sampleRate', 44100)} Hz")
            print(f" Saved File     : {stop_res.get('filePath', file_path)}")
            print("=" * 76)
            print("💡 Tip: Play back recording on phone:")
            print(f"   python send_cmd.py mic play \"{stop_res.get('filePath', file_path)}\"\n")
        else:
            print(f"✗ Failed to stop recording: {stop_res.get('error', 'Unknown error')}")


def execute_notif(subcmd="status", text=None, as_json=False):
    subcmd = (subcmd or "status").lower()
    if subcmd in ["status", "info", "details"]:
        res = http_get("/api/notif/status")
        if as_json:
            print(json.dumps(res, indent=2))
            return res
        granted = res.get("isGranted", False)
        status_str = "✅ GRANTED" if granted else "❌ DENIED"
        are_enabled = res.get("areNotificationsEnabled", False)
        can_dnd = res.get("canBypassDnd", False)
        channels = res.get("channels", [])
        print("\n" + "=" * 70)
        print(" 🔔 NOTIFICATIONS HARDWARE STATION")
        print("=" * 70)
        print(f" Permission Status  : {status_str}")
        print(f" System Enabled     : {'YES' if are_enabled else 'NO'}")
        print(f" Can Bypass DND     : {'YES' if can_dnd else 'NO'}")
        print(f" Active Channels    : {res.get('channelCount', len(channels))}")
        if channels:
            print("-" * 70)
            print(f" {'ID':<28} {'NAME':<24} {'IMPORTANCE'}")
            for ch in channels:
                print(f" {ch.get('id', ''):<28} {ch.get('name', ''):<24} {ch.get('importance', '')}")
        print("=" * 70)
        print("💡 Tip: Test notifications:")
        print("   python send_cmd.py notif test [msg] # Send test notification to phone")
        print("   python send_cmd.py notif perm       # Trigger on-screen permission prompt")
        print("   python send_cmd.py notif settings   # Open notification settings\n")
        return res

    elif subcmd in ["test", "send", "alert", "dispatch"]:
        msg = text or "Hardware station test notification from Termux CLI!"
        res = http_post("/api/notif/test", {"title": "🔔 Hardware Station Test", "message": msg})
        if as_json:
            print(json.dumps(res, indent=2))
        elif res.get("success", False):
            print(f"✓ Dispatched high-priority test notification to phone: '{msg}'")
        else:
            print(f"✗ Failed to dispatch notification: {res.get('error', 'Notification dispatch error')}")
        return res

    elif subcmd in ["perm", "request", "grant"]:
        return execute_permissions("request", "post_notifications", as_json=as_json)

    elif subcmd in ["settings", "open"]:
        return execute_permissions("settings", "post_notifications", as_json=as_json)

    else:
        print(f"[ERROR] Unknown notif subcommand: '{subcmd}'. Available: status, test, perm, settings")


def execute_storage_station(subcmd="status", as_json=False):
    subcmd = (subcmd or "status").lower()
    if subcmd in ["status", "info", "details"]:
        res = http_get("/api/storage/status")
        if as_json:
            print(json.dumps(res, indent=2))
            return res
        granted = res.get("isGranted", False)
        status_str = "✅ GRANTED" if granted else "❌ DENIED"
        media_img = res.get("mediaImagesGranted", False)
        all_files = res.get("allFilesAccessGranted", False)
        total_gb = res.get("totalSpaceGb", "0.0")
        free_gb = res.get("freeSpaceGb", "0.0")
        used_gb = res.get("usedSpaceGb", "0.0")
        used_pct = res.get("usedPercent", 0)
        pics_cnt = res.get("picturesCount", 0)
        dls_cnt = res.get("downloadsCount", 0)
        print("\n" + "=" * 70)
        print(" 💾 STORAGE & MEDIA HARDWARE STATION")
        print("=" * 70)
        print(f" Permission Status  : {status_str}")
        print(f" Media Images Access: {'YES' if media_img else 'NO'}")
        print(f" All Files Access   : {'YES' if all_files else 'NO'}")
        print(f" Total Capacity     : {total_gb} GB")
        print(f" Used Space         : {used_gb} GB ({used_pct}% used)")
        print(f" Free Available     : {free_gb} GB")
        print(f" Indexed Pictures   : {pics_cnt}")
        print(f" Indexed Downloads  : {dls_cnt}")
        print("=" * 70)
        print("💡 Tip: Storage actions:")
        print("   python send_cmd.py storage test     # Run storage access check")
        print("   python send_cmd.py storage files    # Browse storage files")
        print("   python send_cmd.py storage perm     # Trigger on-screen permission prompt")
        print("   python send_cmd.py storage settings # Open storage settings\n")
        return res

    elif subcmd in ["test", "check", "bench"]:
        res = http_post("/api/storage/test", {})
        if as_json:
            print(json.dumps(res, indent=2))
        elif res.get("success", False):
            print("\n" + "=" * 70)
            print(" 💾 STORAGE ACCESS TEST: PASSED")
            print("=" * 70)
            print(f" Total Space    : {res.get('totalSpaceGb', '0.0')} GB")
            print(f" Free Space     : {res.get('freeSpaceGb', '0.0')} GB")
            print(f" Test Status    : {res.get('testStatus', 'ACCESSIBLE')}")
            print("=" * 70 + "\n")
        else:
            print(f"✗ Storage test failed: {res.get('error', 'Storage not accessible')}")
        return res

    elif subcmd in ["perm", "request", "grant"]:
        return execute_permissions("request", "storage", as_json=as_json)

    elif subcmd in ["settings", "open"]:
        return execute_permissions("settings", "storage", as_json=as_json)

    else:
        print(f"[ERROR] Unknown storage subcommand: '{subcmd}'. Available: status, test, perm, settings")


# ---------------------------------------------------------------------------
# Main CLI Router
# ---------------------------------------------------------------------------

def print_help():
    print("""
================================================================================
  AeroShare Clean Command Center & Device Bridge CLI (send_cmd.py)
================================================================================

HARDWARE STATIONS & PERMISSIONS HUB:
  python send_cmd.py permissions [list|request|settings <id>] # Interactive Android permission manager
  python send_cmd.py camera [status|test|perm|settings]       # Camera hardware station & capture test
  python send_cmd.py mic [--live|test|stop|play|perm]          # Real-time continuous recording & live VU meter
  python send_cmd.py notif [status|test [msg]|perm|settings]  # Notification manager & alert test
  python send_cmd.py storage [status|test|perm|settings|files]# Storage capacity, test & file explorer

SHELL & REMOTE EXECUTION:
  python send_cmd.py shell <cmd>               # Execute direct sh -c command on device
  python send_cmd.py status                    # Full hardware, network & bridge status

SCREEN CAPTURE & UI AUTOMATION:
  python send_cmd.py screenshot [out.jpg]      # Capture live device screen to JPEG
  python send_cmd.py inspect [delay_sec]       # Dump interactive UI node hierarchy
  python send_cmd.py tap <label>               # Find UI element by text/desc and tap it
  python send_cmd.py click <x> <y>             # Tap exact screen coordinates
  python send_cmd.py swipe <x1> <y1> <x2> <y2> # Perform drag or swipe gesture
  python send_cmd.py type <text>               # Input text into focused/editable field
  python send_cmd.py key <BACK|HOME|RECENTS|LOCK_SCREEN|QUICK_SETTINGS>

SYSTEM HARDWARE TOGGLES:
  python send_cmd.py torch [on|off|toggle]     # Toggle camera flashlight
  python send_cmd.py dnd [on|off|toggle]       # Toggle Do Not Disturb mode
  python send_cmd.py wifi                      # Open Wi-Fi quick panel & view SSID/IP
  python send_cmd.py bluetooth                 # Open Bluetooth settings & view status
  python send_cmd.py volume [0-15|up|down|mute]# View or control audio stream volumes
  python send_cmd.py brightness <0-255>        # Set screen brightness level
  python send_cmd.py media <play|next|prev>    # Control system media playback

GPS & LIVE TELEMETRY:
  python send_cmd.py location                  # Get current device GPS fix & telemetry
  python send_cmd.py location --live [sec]     # Real-time continuous GPS stream (default 1s)
  python send_cmd.py track [sec]               # Live GPS telemetry radar (Ctrl+C to stop)

DEVICE FILE MANAGER & CLIPBOARD SYNC:
  python send_cmd.py fs-ls [path]              # List directory contents on device
  python send_cmd.py cat <remote_path>         # Read text file from device
  python send_cmd.py put <local> <remote_path> # Upload local file to device path
  python send_cmd.py rm <remote_path>          # Delete file or folder on device
  python send_cmd.py stat <remote_path>        # Inspect file metadata
  python send_cmd.py clip [text]               # Read or set Android system clipboard

APPLICATION & P2P CONTROLS:
  python send_cmd.py login [client_name]       # Authenticate CLI via Biometrics/PIN on phone
  python send_cmd.py apps [filter] [--system]  # List installed applications
  python send_cmd.py open <appName|pkg|url>    # Launch app or URL on device
  python send_cmd.py devices                   # Discover nearby AeroShare peers
  python send_cmd.py share <file|text> [ip]    # Beam file or text to peer

FLAGS:
  --url <http_or_ws_url>   Override target server URL
  --http                   Force HTTP REST execution
  --json                   Output raw JSON response
================================================================================
""")


async def main():
    global AUTH_TOKEN, HTTP_SERVER_URL, WS_SERVER_URL
    raw_args = sys.argv[1:]
    if not raw_args or raw_args[0] in ["-h", "--help", "help"]:
        print_help()
        return

    # Extract global flags
    force_http = "--http" in raw_args
    include_system = "--system" in raw_args or "-s" in raw_args
    as_json = "--json" in raw_args

    # Check for --token <val>, --key <val>, or --url <val>
    cleaned_args = []
    skip_next = False
    for i, a in enumerate(raw_args):
        if skip_next:
            skip_next = False
            continue
        if a in ["--token", "--key", "-k"] and i + 1 < len(raw_args):
            AUTH_TOKEN = raw_args[i + 1]
            skip_next = True
            continue
        if a.startswith("--token="):
            AUTH_TOKEN = a.split("=", 1)[1]
            continue
        if a.startswith("--key="):
            AUTH_TOKEN = a.split("=", 1)[1]
            continue
        if a in ["--url", "-u"] and i + 1 < len(raw_args):
            custom_url = raw_args[i + 1].rstrip("/")
            HTTP_SERVER_URL = custom_url
            WS_SERVER_URL = custom_url.replace("http://", "ws://").replace("https://", "wss://") + ("/ws" if not custom_url.endswith("/ws") else "")
            skip_next = True
            continue
        if a.startswith("--url="):
            custom_url = a.split("=", 1)[1].rstrip("/")
            HTTP_SERVER_URL = custom_url
            WS_SERVER_URL = custom_url.replace("http://", "ws://").replace("https://", "wss://") + ("/ws" if not custom_url.endswith("/ws") else "")
            continue
        if a not in ["--http", "--system", "-s", "--json"]:
            cleaned_args.append(a)

    args = cleaned_args
    if not args:
        print_help()
        return

    cmd = args[0].lower()

    # Authentication (Face Scan on Android Device)
    if cmd in ["login", "auth", "pair"]:
        cname = args[1] if len(args) > 1 else "Termux-Workstation"
        execute_login(cname, as_json=as_json)
        return

    # ZERO-TRUST ACCESS GATE: Termux MUST be authenticated before executing ANY command
    if not AUTH_TOKEN:
        print("\n" + "=" * 72)
        print(" 🔒 ACCESS DENIED: TERMINAL NOT AUTHORIZED")
        print("=" * 72)
        print(" AeroShare requires on-device biometric or PIN authorization.")
        print(" Termux has not been authorized, or authorization was rejected.")
        print()
        print(" To authorize this terminal, run:")
        print("   python send_cmd.py login")
        print()
        print(" Then confirm with Face, Fingerprint, or PIN on your phone.")
        print("=" * 72 + "\n")
        return

    # Direct Shell Execution Bridge
    if cmd in ["shell", "sh", "exec", "cmd"]:
        shell_cmd = " ".join(args[1:])
        execute_shell(shell_cmd, as_json=as_json)
        return

    # System Status Snapshot
    if cmd in ["status", "sys-status", "info"]:
        execute_system_status(as_json=as_json)
        return

    # Live Screenshot Capture
    if cmd in ["screenshot", "screencap", "shot", "capture"]:
        out_file = args[1] if len(args) > 1 else "screenshot.jpg"
        execute_screenshot(out_file, as_json=as_json)
        return

    # System Toggles (DND, Wi-Fi, Bluetooth, Brightness)
    if cmd in ["dnd", "donotdisturb"]:
        st = args[1] if len(args) > 1 else "toggle"
        execute_system_toggle("dnd", state=st, as_json=as_json)
        return

    if cmd in ["wifi", "wi-fi"]:
        execute_system_toggle("wifi", as_json=as_json)
        return

    if cmd in ["bluetooth", "bt"]:
        execute_system_toggle("bluetooth", as_json=as_json)
        return

    if cmd in ["brightness", "bright"]:
        lvl = int(args[1]) if len(args) > 1 and args[1].isdigit() else 128
        execute_system_toggle("brightness", extra={"brightness": lvl}, as_json=as_json)
        return

    # File Manager Operations (fs-ls, cat, put, rm, stat)
    if cmd in ["fs-ls", "ls-dir"]:
        path = args[1] if len(args) > 1 else "/sdcard"
        execute_fs_op("list", path=path, as_json=as_json)
        return

    if cmd in ["cat", "read-file", "fs-read"]:
        if len(args) < 2:
            print("[ERROR] Usage: python send_cmd.py cat <remote_path>")
            return
        execute_fs_op("read", path=args[1], as_json=as_json)
        return

    if cmd in ["put", "upload", "fs-write"]:
        if len(args) < 3:
            print("[ERROR] Usage: python send_cmd.py put <local_file_or_text> <remote_path>")
            return
        src = args[1]
        dst = args[2]
        import base64
        if os.path.exists(src) and os.path.isfile(src):
            with open(src, "rb") as f:
                b64 = base64.b64encode(f.read()).decode("ascii")
            execute_fs_op("write", path=dst, extra={"base64": b64}, as_json=as_json)
        else:
            execute_fs_op("write", path=dst, extra={"content": src}, as_json=as_json)
        return

    if cmd in ["rm", "del", "delete", "fs-rm"]:
        if len(args) < 2:
            print("[ERROR] Usage: python send_cmd.py rm <remote_path>")
            return
        execute_fs_op("delete", path=args[1], as_json=as_json)
        return

    if cmd in ["stat", "file-info"]:
        if len(args) < 2:
            print("[ERROR] Usage: python send_cmd.py stat <remote_path>")
            return
        execute_fs_op("stat", path=args[1], as_json=as_json)
        return

    # Clipboard Get / Set
    if cmd in ["clip-get"]:
        res = http_get("/api/clipboard/get")
        if as_json:
            print(json.dumps(res, indent=2))
        else:
            print(res.get("text", ""))
        return

    if cmd in ["clip-set"]:
        txt = " ".join(args[1:])
        res = http_post("/api/clipboard/set", {"text": txt})
        if as_json:
            print(json.dumps(res, indent=2))
        else:
            print(f"✓ Clipboard updated ({len(txt)} chars)")
        return

    # UI Text Input & Key Events over HTTP
    if cmd in ["type", "input", "input-text"]:
        if len(args) < 2:
            print("[ERROR] Usage: python send_cmd.py type <text>")
            return
        execute_ui_http("INPUT_TEXT", {"text": " ".join(args[1:])}, as_json=as_json)
        return

    if cmd in ["key", "keyevent"]:
        key_name = args[1].upper() if len(args) > 1 else "BACK"
        execute_ui_http("KEY", {"key": key_name}, as_json=as_json)
        return

    if cmd in ["ui-tree"]:
        res = http_get("/api/ui/tree")
        if as_json:
            print(json.dumps(res, indent=2))
        elif res.get("success", False):
            nodes = res.get("nodes", [])
            print("\n" + "=" * 60)
            print(f" PHONE SCREEN UI MAP ({len(nodes)} root node(s)):")
            print("=" * 60)
            print_tree(nodes)
            print("=" * 60 + "\n")
        else:
            print(f"✗ UI Tree inspection failed: {res.get('error', 'Accessibility service disabled')}")
        return

    # AeroShare P2P & File Sharing Controls
    if cmd in ["devices", "peers", "nearby"]:
        execute_devices(as_json=as_json)
        return

    if cmd in ["share", "send"]:
        if len(args) < 2:
            print("[ERROR] Missing file path or text to share.")
            print("Usage: python send_cmd.py share <filePath | text> [targetDeviceIp]")
            return
        target_input = args[1]
        peer_ip = args[2] if len(args) > 2 else ""
        execute_share(target_input, peer_ip, as_json=as_json)
        return

    if cmd in ["transfers", "tx"]:
        execute_transfers(as_json=as_json)
        return

    if cmd in ["history", "transfers-history"]:
        execute_history(as_json=as_json)
        return

    if cmd in ["cancel", "abort"]:
        if len(args) < 2:
            print("[ERROR] Missing transfer ID to cancel.")
            print("Usage: python send_cmd.py cancel <transferId>")
            return
        execute_cancel(args[1])
        return

    if cmd in ["clip", "clipboard"]:
        text_arg = " ".join(args[1:]) if len(args) > 1 else None
        execute_clip(text_arg, as_json=as_json)
        return

    if cmd in ["radar"]:
        enable_arg = None
        if len(args) > 1:
            enable_arg = args[1].lower() in ["on", "true", "start", "enable"]
        execute_radar(enable_arg, as_json=as_json)
        return

    # Hardware Stations & Interactive Permissions Hub
    if cmd in ["permissions", "permission", "perms", "perm"]:
        if len(args) > 1 and args[1].lower() in ["request", "ask", "grant", "settings", "open", "config", "list", "status", "ls"]:
            sub = args[1].lower()
            tgt = args[2] if len(args) > 2 else None
        elif len(args) > 1:
            sub = "request"
            tgt = args[1]
        else:
            sub = "list"
            tgt = None
        execute_permissions(sub, tgt, as_json=as_json)
        return

    if cmd in ["camera", "cam"]:
        sub = args[1].lower() if len(args) > 1 else "status"
        execute_camera(sub, as_json=as_json)
        return

    if cmd in ["mic", "microphone", "audio-station", "record", "rec"]:
        sub = args[1].lower() if len(args) > 1 else "status"
        dur = int(args[2]) if len(args) > 2 and args[2].isdigit() else (int(args[1]) if len(args) > 1 and args[1].isdigit() else 3)
        tgt = args[2] if len(args) > 2 else (args[1] if len(args) > 1 and sub in ["play", "listen"] else None)
        execute_mic(sub, duration_sec=dur, target_arg=tgt, as_json=as_json)
        return

    if cmd in ["notif", "notification-station", "notifications"]:
        sub = args[1].lower() if len(args) > 1 else "status"
        txt = " ".join(args[2:]) if len(args) > 2 else None
        execute_notif(sub, text=txt, as_json=as_json)
        return

    if cmd in ["storage-station", "disk"]:
        sub = args[1].lower() if len(args) > 1 else "status"
        execute_storage_station(sub, as_json=as_json)
        return

    # Hardware & Diagnostics
    if cmd in ["battery", "batt", "power"]:
        execute_battery(as_json=as_json)
        return

    if cmd in ["battery-opt", "battery-optimization", "doze", "unrestricted"]:
        action_arg = args[1] if len(args) > 1 else "STATUS"
        execute_battery_opt(action_arg, as_json=as_json)
        return

    if cmd in ["sensors", "sensor"]:
        execute_sensors(as_json=as_json)
        return

    if cmd in ["location", "gps", "loc", "where", "coords", "track", "live-location"]:
        sub = args[1].lower() if len(args) > 1 else ""
        if sub in ["settings", "open"]:
            execute_system_toggle("location", as_json=as_json)
        elif sub in ["live", "--live", "-l", "stream", "track", "watch", "start"]:
            interval = float(args[2]) if len(args) > 2 and args[2].replace('.', '', 1).isdigit() else 1.0
            execute_live_location(interval_sec=interval, as_json=as_json)
        elif sub in ["stop", "untrack"]:
            http_post("/api/location/live", {"action": "STOP"})
            print("[✓] Live GPS stream stopped on phone.")
        elif cmd in ["track", "live-location"]:
            interval = float(args[1]) if len(args) > 1 and args[1].replace('.', '', 1).isdigit() else 1.0
            execute_live_location(interval_sec=interval, as_json=as_json)
        else:
            execute_location(as_json=as_json)
        return

    if cmd in ["torch", "flash", "flashlight"]:
        if len(args) > 1 and args[1].lower() == "toggle":
            execute_system_toggle("torch", state="toggle", as_json=as_json)
            return
        enable = True
        if len(args) > 1 and args[1].lower() in ["off", "false", "0", "disable"]:
            enable = False
        execute_torch(enable, as_json=as_json)
        return

    if cmd in ["vibrate", "vib", "haptic"]:
        duration = int(args[1]) if len(args) > 1 and args[1].isdigit() else 200
        execute_vibrate(duration, as_json=as_json)
        return

    if cmd in ["tts", "speak", "voice"]:
        if len(args) < 2:
            print("[ERROR] Missing text to speak.")
            print("Usage: python send_cmd.py tts <text>")
            return
        execute_tts(" ".join(args[1:]), as_json=as_json)
        return

    if cmd in ["tone", "beep"]:
        freq = int(args[1]) if len(args) > 1 and args[1].isdigit() else 440
        dur = int(args[2]) if len(args) > 2 and args[2].isdigit() else 500
        execute_tone(freq, dur, as_json=as_json)
        return

    if cmd in ["volume", "vol"]:
        if len(args) > 1 and args[1].lower() in ["up", "down", "mute", "unmute"]:
            execute_system_toggle("volume", state=args[1].lower(), as_json=as_json)
            return
        level = args[1] if len(args) > 1 else None
        stream = args[2] if len(args) > 2 else "MEDIA"
        execute_volume(level, stream, as_json=as_json)
        return

    if cmd in ["hud", "floating"]:
        if len(args) < 2:
            print("[ERROR] Missing text for HUD overlay.")
            print("Usage: python send_cmd.py hud <text> [title]")
            return
        title = args[2] if len(args) > 2 else "⚡ Termux HUD"
        execute_hud(args[1], title, as_json=as_json)
        return

    if cmd in ["notify", "notification"]:
        if len(args) < 2:
            print("[ERROR] Missing message for notification.")
            print("Usage: python send_cmd.py notify <title> <message>")
            return
        title = args[1] if len(args) > 2 else "Aura Alert"
        msg = " ".join(args[2:]) if len(args) > 2 else args[1]
        execute_notify(title, msg, as_json=as_json)
        return

    if cmd in ["media", "player", "music"]:
        action = args[1].upper() if len(args) > 1 else "PLAY_PAUSE"
        execute_media(action, as_json=as_json)
        return

    if cmd in ["files", "storage", "ls-files", "dir"]:
        if cmd == "storage":
            if len(args) > 1 and args[1].lower() in ["status", "info", "details", "test", "check", "bench", "perm", "settings", "request"]:
                execute_storage_station(args[1].lower(), as_json=as_json)
                return
            elif len(args) == 1:
                execute_storage_station("status", as_json=as_json)
                return
            elif len(args) > 1 and args[1].lower() == "files":
                folder = args[2] if len(args) > 2 else "DOWNLOADS"
                limit = int(args[3]) if len(args) > 3 and args[3].isdigit() else 30
                execute_storage(folder, limit, as_json=as_json)
                return
        folder = args[1] if len(args) > 1 else "DOWNLOADS"
        limit = int(args[2]) if len(args) > 2 and args[2].isdigit() else 30
        execute_storage(folder, limit, as_json=as_json)
        return

    if cmd in ["sms", "text"]:
        if len(args) < 2:
            print("[ERROR] Missing phone number.")
            print("Usage: python send_cmd.py sms <phone_number> [message_text]")
            return
        phone = args[1]
        msg = " ".join(args[2:]) if len(args) > 2 else ""
        execute_sms(phone, msg, as_json=as_json)
        return

    # 1. LIST APPS: apps, list-apps, list_apps, list, ls
    if cmd in ["apps", "list-apps", "list_apps", "list", "ls"]:
        filter_query = " ".join(args[1:]) if len(args) > 1 else ""
        await execute_list_apps(include_system=include_system, filter_query=filter_query, as_json=as_json, force_http=force_http)
        return

    # 2. OPEN / LAUNCH APPS: open, launch, run, start
    if cmd in ["open", "launch", "run", "start"]:
        if len(args) < 2:
            print("[ERROR] Missing app name, package name, or URL.")
            print("Usage: python send_cmd.py open <appName | packageName | url>")
            return
        target = " ".join(args[1:])
        await execute_launch_app(target, force_http=force_http)
        return

    # HTTP REST Fallback for UI / Gesture commands when --http is specified or websockets is missing
    if force_http or not HAS_WEBSOCKETS:
        if cmd in ["back", "home", "recents", "notifications", "quick_settings", "lock_screen"]:
            execute_ui_http("KEY", {"key": cmd.upper()}, as_json=as_json)
            return
        if cmd == "inspect":
            delay = int(args[1]) if len(args) > 1 and args[1].isdigit() else 0
            if delay > 0:
                time.sleep(delay)
            res = http_get("/api/ui/tree")
            if as_json:
                print(json.dumps(res, indent=2))
            elif res.get("success", False):
                nodes = res.get("nodes", [])
                print_tree(nodes)
            else:
                print(f"[ERROR] {res.get('error', 'Inspect failed')}")
            return
        if cmd == "tap" and len(args) >= 2:
            execute_ui_http("CLICK_TEXT", {"text": " ".join(args[1:])}, as_json=as_json)
            return
        if cmd == "click" and len(args) >= 3:
            execute_ui_http("TAP", {"x": float(args[1]), "y": float(args[2])}, as_json=as_json)
            return
        if cmd == "swipe" and len(args) >= 5:
            dur = int(args[5]) if len(args) > 5 else 300
            execute_ui_http("SWIPE", {
                "x1": float(args[1]), "y1": float(args[2]),
                "x2": float(args[3]), "y2": float(args[4]),
                "durationMs": dur
            }, as_json=as_json)
            return
        if cmd == "next":
            execute_ui_http("SCROLL", {"direction": "DOWN"}, as_json=as_json)
            return
        if cmd == "toast" and len(args) >= 2:
            res = http_post("/api/toast", {"message": " ".join(args[1:])})
            print(f"✓ Dispatched toast: '{' '.join(args[1:])}'")
            return

    if not HAS_WEBSOCKETS:
        print("[ERROR] The 'websockets' library is required for streaming WebSocket operations.")
        print("Install via: pip install websockets (or pass --http to use HTTP REST)")
        return

    now_ms = int(time.time() * 1000)

    candidate_ws_urls = [WS_SERVER_URL]
    if LOCAL_WS_URL not in candidate_ws_urls:
        candidate_ws_urls.append(LOCAL_WS_URL)

    ws = None
    for ws_url in candidate_ws_urls:
        try:
            ws = await asyncio.wait_for(websockets.connect(ws_url), timeout=4.0)
            break
        except Exception:
            continue

    if not ws:
        print(f"[ERROR] Could not connect to WebSocket at {WS_SERVER_URL} or {LOCAL_WS_URL}")
        return

    try:
        async with ws:
            try:
                await asyncio.wait_for(ws.recv(), timeout=1.0)
            except asyncio.TimeoutError:
                pass

            if cmd in ["back", "home", "recents", "notifications"]:
                packet = {
                    "type": "ACCESSIBILITY_GESTURE",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "gestureId": f"{cmd}-{now_ms}",
                    "gestureType": cmd.upper(),
                    "startX": 0.0,
                    "startY": 0.0,
                    "durationMs": 50,
                    "token": AUTH_TOKEN
                }
                await ws.send(json.dumps(packet))
                print(f"Dispatched system action: {cmd.upper()}")

            elif cmd == "inspect":
                delay = int(args[1]) if len(args) > 1 and args[1].isdigit() else 0
                if delay > 0:
                    print(f"Switch to target app! Inspecting in {delay}s...")
                    for i in range(delay, 0, -1):
                        print(f" {i}...", end="", flush=True)
                        await asyncio.sleep(1)
                    print(" Inspecting!")

                packet = {
                    "type": "ACCESSIBILITY_INSPECT",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "target": "active_window",
                    "token": AUTH_TOKEN
                }
                print("Sent ACCESSIBILITY_INSPECT -> Waiting for screen nodes...")
                await ws.send(json.dumps(packet))

                while True:
                    msg = await asyncio.wait_for(ws.recv(), timeout=8.0)
                    data = json.loads(msg)
                    if data.get("type") == "ACCESSIBILITY_INSPECT_RESULT":
                        nodes = data.get("nodes", [])
                        print("\n" + "=" * 60)
                        print(f" PHONE SCREEN UI MAP ({len(nodes)} root node(s)):")
                        print("=" * 60)
                        print_tree(nodes)
                        print("=" * 60 + "\n")
                        break

            elif cmd == "tap" and len(args) >= 2:
                target_label = " ".join(args[1:])
                packet = {
                    "type": "ACCESSIBILITY_INSPECT",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "target": "active_window",
                    "token": AUTH_TOKEN
                }
                print(f"Searching screen for '{target_label}'...")
                await ws.send(json.dumps(packet))

                matched_targets = []
                while True:
                    msg = await asyncio.wait_for(ws.recv(), timeout=8.0)
                    data = json.loads(msg)
                    if data.get("type") == "ACCESSIBILITY_INSPECT_RESULT":
                        nodes = data.get("nodes", [])
                        print_tree(nodes, depth=0, find_text=target_label, matched_targets=matched_targets)
                        break

                if matched_targets:
                    found_name, tx, ty = matched_targets[0]
                    click_packet = {
                        "type": "ACCESSIBILITY_GESTURE",
                        "timestamp": now_ms,
                        "sessionId": "cli-" + str(now_ms),
                        "gestureId": f"click-{now_ms}",
                        "gestureType": "CLICK",
                        "action": "CLICK",
                        "startX": float(tx),
                        "startY": float(ty),
                        "x": int(tx),
                        "y": int(ty),
                        "durationMs": 100,
                        "token": AUTH_TOKEN
                    }
                    await ws.send(json.dumps(click_packet))
                    print(f"✓ Tapped '{found_name}' at ({tx}, {ty})")
                else:
                    print(f"✗ Could not find element matching '{target_label}' on screen.")
                    print("  Try running 'python send_cmd.py inspect' to see full UI structure.")

            elif cmd == "click" and len(args) >= 3:
                x, y = int(args[1]), int(args[2])
                packet = {
                    "type": "ACCESSIBILITY_GESTURE",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "gestureId": f"click-{now_ms}",
                    "gestureType": "CLICK",
                    "action": "CLICK",
                    "startX": float(x),
                    "startY": float(y),
                    "x": x,
                    "y": y,
                    "durationMs": 100,
                    "token": AUTH_TOKEN
                }
                await ws.send(json.dumps(packet))
                print(f"Dispatched CLICK at ({x}, {y})")

            elif cmd == "swipe" and len(args) >= 5:
                x1, y1 = int(args[1]), int(args[2])
                x2, y2 = int(args[3]), int(args[4])
                dur = int(args[5]) if len(args) > 5 else 300
                packet = {
                    "type": "ACCESSIBILITY_GESTURE",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "gestureId": f"swipe-{now_ms}",
                    "gestureType": "SWIPE",
                    "action": "SWIPE",
                    "startX": float(x1),
                    "startY": float(y1),
                    "endX": float(x2),
                    "endY": float(y2),
                    "x": x1,
                    "y": y1,
                    "durationMs": dur,
                    "token": AUTH_TOKEN
                }
                await ws.send(json.dumps(packet))
                print(f"Dispatched SWIPE from ({x1}, {y1}) to ({x2}, {y2}) [{dur}ms]")

            elif cmd == "next":
                packet = {
                    "type": "ACCESSIBILITY_GESTURE",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "gestureId": f"next-{now_ms}",
                    "gestureType": "SWIPE",
                    "action": "SWIPE",
                    "startX": 500.0,
                    "startY": 1400.0,
                    "endX": 500.0,
                    "endY": 300.0,
                    "durationMs": 250,
                    "token": AUTH_TOKEN
                }
                await ws.send(json.dumps(packet))
                print("Dispatched scroll to next item")

            elif cmd == "toast" and len(args) >= 2:
                msg = " ".join(args[1:])
                packet = {
                    "type": "AI_STREAM",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "textChunk": msg,
                    "isFinal": True,
                    "token": AUTH_TOKEN
                }
                await ws.send(json.dumps(packet))
                print(f"Dispatched toast: '{msg}'")

            else:
                prompt_text = " ".join(args)
                packet = {
                    "type": "AI_STREAM",
                    "timestamp": now_ms,
                    "sessionId": "cli-" + str(now_ms),
                    "textChunk": prompt_text,
                    "isFinal": True
                }
                await ws.send(json.dumps(packet))
                print(f"Dispatched message: '{prompt_text}'")

    except ConnectionRefusedError:
        print(f"[!] Could not connect to WebSocket at {WS_SERVER_URL}.")
        print("    If Termux relay is offline, start it with: python mock_server.py")
        print("    Or pass --http to execute directly against port 8080.")
    except Exception as e:
        print(f"[ERROR] {type(e).__name__}: {e}")


if __name__ == "__main__":
    asyncio.run(main())
