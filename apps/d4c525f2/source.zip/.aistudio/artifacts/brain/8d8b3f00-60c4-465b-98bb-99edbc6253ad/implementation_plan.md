# Advanced Agy HUD Suite — Implementation Plan

## 1. Overview & Selected Features
We will extend the Agy Floating HUD and Termux Daemon (`server/agy_hud_daemon.py`) with four advanced co-pilot capabilities:

1. **Demonstration Recorder (Teach-by-Example)**:
   - Lets the user record a sequence of screen demonstrations (taps, swipes/scrolls, text inputs, and matched UI nodes from the live accessibility tree) via an interactive recording mode, then either **send the demonstration to Agy** (`DEMO_RECORDED`), **save it directly as a reusable HUD Macro**, or **replay** the recorded steps.
2. **Smart Clipboard & Cross-App Scratchpad Dropzone**:
   - A multi-slot floating scratchpad drawer in the HUD that automatically captures or lets the user/Agy pin text snippets, URLs, code blocks, and command outputs across apps—with one-tap **Copy**, **Insert into Prompt**, **Attach as Context**, and `/api/hud/scratchpad` sync with the Termux daemon.
3. **Live Screen Diff & Visual Watchdog Triggers**:
   - Monitors a target screen region or UI node predicate (e.g., waiting for `"Build Successful"`, price/number changes, or a new message in a region) in the background, updates a live HUD Watchdog status badge, and automatically triggers a queued Agy prompt or WebSocket/HTTP `WATCHDOG_TRIGGERED` event when a diff or condition matches.
4. **Voice Co-Pilot (Spoken TTS & Continuous Hands-Free Reply)**:
   - Uses Android on-device `TextToSpeech` to speak Agy's completion summaries, alerts, and questions aloud when Voice Co-Pilot is enabled (`🔊 Voice`), and automatically starts `AgyVoiceInputController` listening after speaking a `NEEDS_INPUT` question so the user can reply hands-free without touching the screen.

---

## 2. User Experience & Visual Design

```
┌────────────────────────────────────────────────────────────────┐
│ ✦ Ready  00:12                    [🎙 Voice] [👁 Watch] [···] ─ │
├────────────────────────────────────────────────────────────────┤
│ [90%] [Map] [Cursor] [✂ Snip] [⏺ Record] [📋 Pad (3)] [👁 Diff]│
├────────────────────────────────────────────────────────────────┤
│ 🔴 REC Demo (3 steps) • Tap UI or add step   [⏹ Finish] [✕]   │
│   1. TAP "Wi-Fi" @(320, 480) in com.android.settings           │
│   2. TAP "Search settings" @(540, 180)                         │
│   3. TYPE "DNS"                                                │
├────────────────────────────────────────────────────────────────┤
│ 📋 Smart Scratchpad (3 items)                 [+ Clip] [Clear] │
│  • [URL] https://api.example.com/v2/status    [↗ Ask] [Copy] ✕ │
│  • [CODE] export AURA_TOKEN="9f8a..."         [↗ Ask] [Copy] ✕ │
├────────────────────────────────────────────────────────────────┤
│ 👁 Watchdog Active • Region [120,300]-[880,620] • Poll 2.0s    │
│    Condition: contains "Complete"  ──► Run: "Notify & summarize"│
└────────────────────────────────────────────────────────────────┘
```

### Key UX Flows
- **Demonstration Recorder (`⏺ Record` in Tools Tray or `/api/hud/demo`)**:
  - Tapping **`⏺ Record`** opens a translucent pass-through capture banner and optional touch/accessibility tap interceptor that logs each user interaction (`TAP`, `SWIPE`, `TYPE`) enriched with the underlying UI node (`text`, `viewId`, `packageName`, `(x, y)` coordinates).
  - Tapping **`⏹ Finish`** stops recording and offers **`[🤖 Teach Agy]`** (sends structured `DEMO_RECORDED` command with step JSON to the daemon) and **`[★ Save Macro]`** (converts the demonstration into a 1-tap macro).
- **Smart Clipboard & Scratchpad Dropzone (`📋 Pad` in Tools Tray or `/api/hud/scratchpad`)**:
  - Listens for clipboard changes (and accepts items pushed by Agy via `/api/hud/scratchpad` or manual **`+ Clip`** capture), auto-classifying each entry as `TEXT`, `URL`, `CODE`, or `JSON`.
  - Tapping **`[↗ Ask]`** injects the snippet into the HUD prompt composer or attaches it to the next prompt; tapping **`[Copy]`** copies it to the system clipboard.
- **Live Screen Diff & Visual Watchdog (`👁 Diff` in Tools Tray or `/api/hud/watchdog`)**:
  - Lets the user or Agy arm a watchdog on either a **Snipped Screen Region** or the active foreground window with a rule (`ANY_CHANGE`, `TEXT_CONTAINS`, `TEXT_DISAPPEARS`, `NODE_APPEARS`) and an automatic `triggerPrompt` (e.g., `"Summarize the new output"`).
  - Periodically diffs the live accessibility node signatures inside the watched region; when triggered, flashes an emerald alert banner in the HUD and dispatches `WATCHDOG_TRIGGERED` + the configured `triggerPrompt` to Agy.
- **Voice Co-Pilot (`🔊 Voice` Toggle or `/api/hud/voice`)**:
  - When toggled on, speaks concise updates when Agy transitions to `DONE` or `NEEDS_INPUT` (or when Agy sends `speakText` in `/api/hud/state`, `/api/hud/patch`, or `/api/hud/voice`).
  - When Agy enters `NEEDS_INPUT` with a question and `autoListenOnQuestion` is enabled, as soon as TTS finishes speaking the question, the HUD automatically activates the microphone (`AgyVoiceInputController`) and submits the user's spoken answer.

---

## 3. Technical Architecture & Data Strategy

```
Termux Daemon (server/agy_hud_daemon.py)
  │  ▲
  │  │  HTTP: /api/hud/demo, /api/hud/scratchpad, /api/hud/watchdog, /api/hud/voice
  │  │  WS:   HUD_DEMO, HUD_SCRATCHPAD, HUD_WATCHDOG, HUD_VOICE
  │  │  Poll: DEMO_RECORDED, WATCHDOG_TRIGGERED, PROMPT (with scratchpad/demo context)
  ▼  │
AppContainer (Ktor Server) ──► AgyHudOverlayManager
                                  ├── AgyDemoRecorderManager (Teach-by-Example Recorder)
                                  ├── AgyScratchpadManager (Smart Clipboard & Multi-Slot Pad)
                                  ├── AgyScreenWatchdogManager (Live Screen Diff & Triggers)
                                  └── AgyVoiceCoPilotManager (On-Device TTS + Auto-Listen Loop)
```

### Files to Create & Update
1. **`AgyHudDynamicModels.kt`**:
   - Add data models & JSON serializers for:
     - `DemoStepItem` (`index`, `actionType`, `x`, `y`, `endX`, `endY`, `text`, `nodeLabel`, `viewId`, `packageName`, `timestampMs`) & `DemoRecordingSession` (`id`, `title`, `active`, `steps`).
     - `ScratchpadItem` (`id`, `kind`: `text|url|code|json`, `content`, `label`, `sourcePackage`, `pinned`, `timestampMs`).
     - `ScreenWatchdogConfig` (`id`, `active`, `rule`: `any_change|text_contains|text_disappears|node_appears`, `targetText`, `region`: `SnippedRegionContext?`, `intervalMs`, `triggerPrompt`, `oneShot`, `triggeredCount`).
     - `VoiceCoPilotConfig` (`enabled`, `autoSpeakDone`, `autoSpeakQuestion`, `autoListenOnQuestion`, `speechRate`, `speakText`).
2. **`AgyDemoRecorderManager.kt` (New)**:
   - Manages demonstration recording state, step capture from screen coordinates + `nodeTreeProvider` accessibility node lookup, touch/tap capture overlay bar (`agy_hud_demo_recorder`), macro prompt synthesis (`toMacroPrompt()`), and `DEMO_RECORDED` payload generation.
3. **`AgyScratchpadManager.kt` (New)**:
   - Manages the multi-slot scratchpad (`StateFlow<List<ScratchpadItem>>`), `ClipboardManager` sync, automatic content classification (`url`, `code`, `json`, `text`), deduplication, pinning, and JSON serialization.
4. **`AgyScreenWatchdogManager.kt` (New)**:
   - Runs a periodic main-thread/coroutine diff checker comparing the live accessibility tree (`nodeTreeProvider`) within the watched region/package against the baseline snapshot or target text rule, invoking `onWatchdogTriggered` when matched.
5. **`AgyVoiceCoPilotManager.kt` (New)**:
   - Wraps `android.speech.tts.TextToSpeech` with `UtteranceProgressListener`, queuing spoken announcements and invoking `onQuestionSpokenReadyForListen` on completion so `AgyHudOverlayManager` seamlessly triggers `AgyVoiceInputController` for hands-free replies.
6. **`AgyHudOverlayManager.kt`, `AppContainer.kt`, `AuraManifestProvider.kt`, & `server/agy_hud_daemon.py`**:
   - Integrate the 4 managers into the HUD tools tray, inline status/drawer cards, `/api/hud/demo`, `/api/hud/scratchpad`, `/api/hud/watchdog`, `/api/hud/voice` endpoints, WebSocket handlers, and `server/agy_hud_daemon.py` client helpers + `--self-test` suite.
7. **Verification**:
   - Add Robolectric unit tests in `AgyAdvancedHudFeaturesTest.kt` verifying all 4 features end-to-end, run `compile_applet`, `gradle :app:testDebugUnitTest --tests "com.example.ui.overlay.*"`, and `python3 server/agy_hud_daemon.py --self-test`.
