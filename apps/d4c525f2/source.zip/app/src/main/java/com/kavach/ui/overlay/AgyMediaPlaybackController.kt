package com.kavach.ui.overlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Surface
import android.webkit.WebView
import androidx.core.app.NotificationCompat
import java.io.File
import java.util.Locale

/**
 * Unified Media Playback Controller for the Left-Window Custom Player (`agy_task_map`).
 *
 * - Drives native [MediaPlayer] for local files (`/sdcard/...`, `file://`, `content://`)
 *   and direct HTTP/HTTPS audio & video streams (`.mp3`, `.mp4`, `.m4a`, `.wav`, `.ogg`, `.webm`, `.m3u8`).
 * - Bridges YouTube / web embed tracks via an attached [WebView] so Agy can play web videos or music embeds.
 * - Supports seamless transitions between **Video Mode** (`"video"`), **Audio-Only Mode** (`"audio"`),
 *   and **Background Mini-Pill Mode** (`backgroundMode = true`) without restarting or interrupting audio.
 * - Posts an ongoing media status notification when playing so background playback is visible in the shade.
 */
class AgyMediaPlaybackController(
    private val context: Context
) {
    companion object {
        private const val TAG = "AgyMediaPlaybackCtrl"
        const val MEDIA_NOTIFICATION_CHANNEL_ID = "agy_hud_media_channel"
        const val MEDIA_NOTIFICATION_ID = 4409
        val SPEED_PRESETS = floatArrayOf(0.75f, 1.0f, 1.25f, 1.5f, 2.0f)

        fun formatTimeMs(ms: Long): String {
            val totalSeconds = (ms.coerceAtLeast(0L) / 1000L).toInt()
            val hours = totalSeconds / 3600
            val minutes = (totalSeconds % 3600) / 60
            val seconds = totalSeconds % 60
            return if (hours > 0) {
                String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
            } else {
                String.format(Locale.US, "%02d:%02d", minutes, seconds)
            }
        }
    }

    data class PlaybackSnapshot(
        val playlist: List<AgyHudDynamicModels.PlayerTrackItem> = emptyList(),
        val currentIndex: Int = 0,
        val mediaMode: String = "video", // video | audio
        val backgroundMode: Boolean = false,
        val isPlaying: Boolean = false,
        val isPrepared: Boolean = false,
        val isLooping: Boolean = false,
        val isMuted: Boolean = false,
        val volume: Float = 1.0f,
        val speed: Float = 1.0f,
        val positionMs: Long = 0L,
        val durationMs: Long = 0L,
        val videoWidth: Int = 0,
        val videoHeight: Int = 0,
        val errorText: String = ""
    ) {
        val currentTrack: AgyHudDynamicModels.PlayerTrackItem?
            get() = playlist.getOrNull(currentIndex.coerceIn(0, (playlist.size - 1).coerceAtLeast(0)))

        val elapsedLabel: String
            get() = formatTimeMs(positionMs)

        val durationLabel: String
            get() = if (durationMs > 0L) formatTimeMs(durationMs) else "--:--"

        val progressPermille: Int
            get() = if (durationMs > 0L) {
                ((positionMs.toDouble() / durationMs.toDouble()) * 1000.0).toInt().coerceIn(0, 1000)
            } else 0
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val notificationManager: NotificationManager? by lazy {
        context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
    }

    private var mediaPlayer: MediaPlayer? = null
    private var videoSurface: Surface? = null
    private var attachedWebView: WebView? = null
    private var loadedTrackSignature: String = ""
    private var lastAppliedConfigSignature: String = ""

    private var snapshot = PlaybackSnapshot()

    var onStateChanged: ((PlaybackSnapshot) -> Unit)? = null

    private val progressTicker = object : Runnable {
        override fun run() {
            if (!snapshot.isPlaying) return
            val track = snapshot.currentTrack
            if (track != null && !track.isWebEmbed) {
                val mp = mediaPlayer
                if (mp != null && snapshot.isPrepared) {
                    try {
                        val pos = mp.currentPosition.toLong().coerceAtLeast(0L)
                        val dur = mp.duration.takeIf { it > 0 }?.toLong() ?: snapshot.durationMs
                        snapshot = snapshot.copy(
                            positionMs = pos,
                            durationMs = dur
                        )
                        notifyListeners(updateNotification = false)
                    } catch (_: Exception) {}
                } else {
                    advanceSimulatedPositionIfNeeded()
                }
            } else if (track != null) {
                advanceSimulatedPositionIfNeeded()
            }
            mainHandler.postDelayed(this, 250L)
        }
    }

    private fun advanceSimulatedPositionIfNeeded() {
        val dur = snapshot.durationMs
        val nextPos = snapshot.positionMs + 250L
        if (dur > 0L && nextPos >= dur) {
            if (snapshot.isLooping) {
                snapshot = snapshot.copy(positionMs = 0L)
            } else if (snapshot.playlist.size > 1 && snapshot.currentIndex < snapshot.playlist.lastIndex) {
                selectTrack(snapshot.currentIndex + 1, autoPlay = true)
                return
            } else {
                snapshot = snapshot.copy(positionMs = dur, isPlaying = false)
                notifyListeners(updateNotification = true)
                return
            }
        } else {
            snapshot = snapshot.copy(positionMs = nextPos)
        }
        notifyListeners(updateNotification = false)
    }

    fun currentSnapshot(): PlaybackSnapshot = snapshot

    fun bindVideoSurface(surface: Surface?) {
        videoSurface = surface
        try {
            mediaPlayer?.setSurface(surface)
        } catch (e: Exception) {
            Log.w(TAG, "Failed binding video surface: ${e.message}")
        }
    }

    fun bindWebView(webView: WebView?) {
        attachedWebView = webView
    }

    /**
     * Applies a [AgyHudDynamicModels.PlayerTaskMapData] payload from Agy or a patch update.
     * Preserves seamless playback when only mode (`video` <-> `audio`), `backgroundMode`,
     * or transport parameters change for the currently loaded track.
     */
    fun applyPlayerData(data: AgyHudDynamicModels.PlayerTaskMapData) {
        val nextPlaylist = data.playlist
        val safeIdx = if (nextPlaylist.isEmpty()) 0 else data.currentIndex.coerceIn(0, nextPlaylist.lastIndex)
        val nextTrack = nextPlaylist.getOrNull(safeIdx)
        val nextTrackSig = nextTrack?.let { "${it.id}|${it.uri}" }.orEmpty()
        val trackChanged = nextTrackSig.isNotEmpty() && nextTrackSig != loadedTrackSignature

        val resolvedDuration = when {
            data.durationMs > 0L -> data.durationMs
            nextTrack != null && nextTrack.durationMs > 0L -> nextTrack.durationMs
            !trackChanged -> snapshot.durationMs
            else -> 0L
        }

        val resolvedPosition = when {
            data.action == "seek" || (data.positionMs > 0L && data.positionMs != snapshot.positionMs) -> data.positionMs
            trackChanged -> data.positionMs
            else -> snapshot.positionMs
        }

        val prevPlaying = snapshot.isPlaying
        snapshot = snapshot.copy(
            playlist = nextPlaylist,
            currentIndex = safeIdx,
            mediaMode = data.mediaMode,
            backgroundMode = data.backgroundMode,
            isPlaying = data.playing && nextTrack != null,
            isLooping = data.loop,
            isMuted = data.muted,
            volume = data.volume.coerceIn(0f, 1f),
            speed = data.speed.coerceIn(0.5f, 2.5f),
            positionMs = resolvedPosition,
            durationMs = resolvedDuration,
            errorText = if (trackChanged) "" else snapshot.errorText
        )

        if (nextTrack == null) {
            releasePlayerInternal()
            notifyListeners(updateNotification = true)
            return
        }

        if (trackChanged) {
            loadCurrentTrackInternal(autoPlay = snapshot.isPlaying, startPosMs = resolvedPosition)
        } else {
            applyRuntimeControlsToActiveEngine(
                playStateChanged = prevPlaying != snapshot.isPlaying,
                seekToMs = if (data.action == "seek") resolvedPosition else null
            )
            notifyListeners(updateNotification = true)
        }
    }

    fun setMediaMode(mode: String) {
        val normalized = if (mode.lowercase().trim() == "audio") "audio" else "video"
        if (snapshot.mediaMode == normalized) return
        snapshot = snapshot.copy(mediaMode = normalized)
        notifyListeners(updateNotification = true)
    }

    fun toggleMediaMode(): String {
        val next = if (snapshot.mediaMode == "video") "audio" else "video"
        setMediaMode(next)
        return next
    }

    fun setBackgroundMode(bg: Boolean) {
        if (snapshot.backgroundMode == bg) return
        snapshot = snapshot.copy(backgroundMode = bg)
        notifyListeners(updateNotification = true)
    }

    fun togglePlayPause(): Boolean {
        val nextPlaying = !snapshot.isPlaying
        setPlaying(nextPlaying)
        return nextPlaying
    }

    fun setPlaying(playing: Boolean) {
        if (snapshot.currentTrack == null) return
        if (snapshot.isPlaying == playing) return
        snapshot = snapshot.copy(isPlaying = playing)
        applyRuntimeControlsToActiveEngine(playStateChanged = true, seekToMs = null)
        notifyListeners(updateNotification = true)
    }

    fun seekTo(positionMs: Long) {
        val clamped = if (snapshot.durationMs > 0L) {
            positionMs.coerceIn(0L, snapshot.durationMs)
        } else {
            positionMs.coerceAtLeast(0L)
        }
        snapshot = snapshot.copy(positionMs = clamped)
        applyRuntimeControlsToActiveEngine(playStateChanged = false, seekToMs = clamped)
        notifyListeners(updateNotification = false)
    }

    fun seekByPermille(permille: Int) {
        val dur = snapshot.durationMs
        if (dur <= 0L) return
        val targetMs = ((permille.coerceIn(0, 1000) / 1000.0) * dur.toDouble()).toLong()
        seekTo(targetMs)
    }

    fun nextTrack(): Boolean {
        val list = snapshot.playlist
        if (list.isEmpty()) return false
        val nextIdx = (snapshot.currentIndex + 1) % list.size
        selectTrack(nextIdx, autoPlay = true)
        return true
    }

    fun previousTrack(): Boolean {
        val list = snapshot.playlist
        if (list.isEmpty()) return false
        if (snapshot.positionMs > 4000L && list.size == 1) {
            seekTo(0L)
            return true
        }
        val prevIdx = if (snapshot.currentIndex - 1 < 0) list.lastIndex else snapshot.currentIndex - 1
        selectTrack(prevIdx, autoPlay = true)
        return true
    }

    fun selectTrack(index: Int, autoPlay: Boolean = true) {
        val list = snapshot.playlist
        if (index !in list.indices) return
        val track = list[index]
        snapshot = snapshot.copy(
            currentIndex = index,
            positionMs = 0L,
            durationMs = track.durationMs,
            isPlaying = autoPlay,
            isPrepared = false,
            errorText = ""
        )
        loadCurrentTrackInternal(autoPlay = autoPlay, startPosMs = 0L)
    }

    fun cycleSpeed(): Float {
        val cur = snapshot.speed
        val idx = SPEED_PRESETS.indexOfFirst { kotlin.math.abs(it - cur) < 0.05f }
        val nextSpeed = SPEED_PRESETS[(idx + 1) % SPEED_PRESETS.size]
        setSpeed(nextSpeed)
        return nextSpeed
    }

    fun setSpeed(speed: Float) {
        val clamped = speed.coerceIn(0.5f, 2.5f)
        snapshot = snapshot.copy(speed = clamped)
        applyRuntimeControlsToActiveEngine(playStateChanged = false, seekToMs = null)
        notifyListeners(updateNotification = false)
    }

    fun toggleLoop(): Boolean {
        val nextLoop = !snapshot.isLooping
        snapshot = snapshot.copy(isLooping = nextLoop)
        applyRuntimeControlsToActiveEngine(playStateChanged = false, seekToMs = null)
        notifyListeners(updateNotification = false)
        return nextLoop
    }

    fun toggleMute(): Boolean {
        val nextMute = !snapshot.isMuted
        snapshot = snapshot.copy(isMuted = nextMute)
        applyRuntimeControlsToActiveEngine(playStateChanged = false, seekToMs = null)
        notifyListeners(updateNotification = false)
        return nextMute
    }

    fun setVolume(volume: Float) {
        val clamped = volume.coerceIn(0f, 1f)
        snapshot = snapshot.copy(volume = clamped, isMuted = clamped <= 0.001f)
        applyRuntimeControlsToActiveEngine(playStateChanged = false, seekToMs = null)
        notifyListeners(updateNotification = false)
    }

    fun cycleVolumePreset(): Float {
        if (snapshot.isMuted) {
            snapshot = snapshot.copy(isMuted = false, volume = snapshot.volume.coerceAtLeast(0.5f))
        } else {
            val nextVol = when {
                snapshot.volume >= 0.9f -> 0.5f
                snapshot.volume >= 0.4f -> 0.0f
                else -> 1.0f
            }
            snapshot = snapshot.copy(volume = nextVol, isMuted = nextVol <= 0.001f)
        }
        applyRuntimeControlsToActiveEngine(playStateChanged = false, seekToMs = null)
        notifyListeners(updateNotification = false)
        return if (snapshot.isMuted) 0f else snapshot.volume
    }

    fun stopAndRelease() {
        releasePlayerInternal()
        snapshot = snapshot.copy(isPlaying = false, isPrepared = false, positionMs = 0L)
        cancelMediaNotification()
        notifyListeners(updateNotification = false)
    }

    private fun loadCurrentTrackInternal(autoPlay: Boolean, startPosMs: Long) {
        mainHandler.removeCallbacks(progressTicker)
        val track = snapshot.currentTrack ?: return
        loadedTrackSignature = "${track.id}|${track.uri}"

        // Release any previous native MediaPlayer instance before starting the new track
        try {
            mediaPlayer?.stop()
        } catch (_: Exception) {}
        try {
            mediaPlayer?.release()
        } catch (_: Exception) {}
        mediaPlayer = null

        if (track.isWebEmbed) {
            snapshot = snapshot.copy(
                isPrepared = true,
                isPlaying = autoPlay,
                positionMs = startPosMs,
                durationMs = track.durationMs
            )
            loadWebEmbedTrack(track, autoPlay)
            if (autoPlay) {
                mainHandler.postDelayed(progressTicker, 250L)
            }
            notifyListeners(updateNotification = true)
            return
        }

        // Clear WebView when switching back to native playback
        try {
            attachedWebView?.loadUrl("about:blank")
        } catch (_: Exception) {}

        val uri = resolvePlayableUri(track.uri)
        if (uri == null) {
            snapshot = snapshot.copy(
                isPrepared = false,
                errorText = "No media URI provided"
            )
            notifyListeners(updateNotification = true)
            return
        }

        try {
            val mp = MediaPlayer()
            mediaPlayer = mp
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(
                            if (track.isVideo) AudioAttributes.CONTENT_TYPE_MOVIE
                            else AudioAttributes.CONTENT_TYPE_MUSIC
                        )
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
            }
            videoSurface?.let { mp.setSurface(it) }
            mp.isLooping = snapshot.isLooping
            val effectiveVol = if (snapshot.isMuted) 0f else snapshot.volume
            mp.setVolume(effectiveVol, effectiveVol)

            mp.setOnPreparedListener { player ->
                val dur = player.duration.takeIf { it > 0 }?.toLong() ?: snapshot.durationMs
                snapshot = snapshot.copy(
                    isPrepared = true,
                    durationMs = dur,
                    videoWidth = player.videoWidth,
                    videoHeight = player.videoHeight,
                    errorText = ""
                )
                if (startPosMs > 0L) {
                    try {
                        player.seekTo(startPosMs.toInt())
                    } catch (_: Exception) {}
                }
                applyPlaybackSpeedInternal(player, snapshot.speed)
                if (snapshot.isPlaying) {
                    try {
                        player.start()
                    } catch (_: Exception) {}
                    mainHandler.removeCallbacks(progressTicker)
                    mainHandler.postDelayed(progressTicker, 250L)
                }
                notifyListeners(updateNotification = true)
            }

            mp.setOnVideoSizeChangedListener { _, width, height ->
                if (width > 0 && height > 0) {
                    snapshot = snapshot.copy(videoWidth = width, videoHeight = height)
                    notifyListeners(updateNotification = false)
                }
            }

            mp.setOnCompletionListener {
                if (snapshot.isLooping) {
                    seekTo(0L)
                    setPlaying(true)
                } else if (snapshot.playlist.size > 1 && snapshot.currentIndex < snapshot.playlist.lastIndex) {
                    selectTrack(snapshot.currentIndex + 1, autoPlay = true)
                } else {
                    snapshot = snapshot.copy(
                        isPlaying = false,
                        positionMs = snapshot.durationMs
                    )
                    mainHandler.removeCallbacks(progressTicker)
                    notifyListeners(updateNotification = true)
                }
            }

            mp.setOnErrorListener { _, what, extra ->
                Log.w(TAG, "MediaPlayer warning/error what=$what extra=$extra for ${track.uri}")
                // Keep controller operational for progress/state even if codec isn't available in headless JVM/emulator
                if (snapshot.isPlaying) {
                    mainHandler.removeCallbacks(progressTicker)
                    mainHandler.postDelayed(progressTicker, 250L)
                }
                true
            }

            mp.setDataSource(context, uri)
            mp.prepareAsync()
            if (autoPlay) {
                mainHandler.removeCallbacks(progressTicker)
                mainHandler.postDelayed(progressTicker, 250L)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Native MediaPlayer fallback for ${track.uri}: ${e.message}")
            // Graceful fallback when running in local JVM / Robolectric or stream requires external codec
            if (autoPlay) {
                mainHandler.removeCallbacks(progressTicker)
                mainHandler.postDelayed(progressTicker, 250L)
            }
        }
        notifyListeners(updateNotification = true)
    }

    private fun loadWebEmbedTrack(track: AgyHudDynamicModels.PlayerTrackItem, autoPlay: Boolean) {
        val wv = attachedWebView ?: return
        val embedUrl = AgyHudDynamicModels.PlayerTrackItem.resolveWebEmbedUrl(track.uri)
        try {
            wv.loadUrl(embedUrl)
            if (!autoPlay) {
                wv.onPause()
            } else {
                wv.onResume()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed loading web embed $embedUrl: ${e.message}")
        }
    }

    private fun applyRuntimeControlsToActiveEngine(playStateChanged: Boolean, seekToMs: Long?) {
        mainHandler.removeCallbacks(progressTicker)
        val track = snapshot.currentTrack
        val mp = mediaPlayer

        if (track?.isWebEmbed == true) {
            val wv = attachedWebView
            if (wv != null && playStateChanged) {
                try {
                    if (snapshot.isPlaying) {
                        wv.onResume()
                        wv.evaluateJavascript(
                            "(function(){var v=document.querySelector('video,audio');if(v)v.play();})();",
                            null
                        )
                    } else {
                        wv.evaluateJavascript(
                            "(function(){var v=document.querySelector('video,audio');if(v)v.pause();})();",
                            null
                        )
                    }
                } catch (_: Exception) {}
            }
        } else if (mp != null) {
            try {
                mp.isLooping = snapshot.isLooping
                val effectiveVol = if (snapshot.isMuted) 0f else snapshot.volume
                mp.setVolume(effectiveVol, effectiveVol)
                if (snapshot.isPrepared) {
                    if (seekToMs != null) {
                        mp.seekTo(seekToMs.toInt())
                    }
                    applyPlaybackSpeedInternal(mp, snapshot.speed)
                    if (playStateChanged) {
                        if (snapshot.isPlaying && !mp.isPlaying) {
                            mp.start()
                        } else if (!snapshot.isPlaying && mp.isPlaying) {
                            mp.pause()
                        }
                    }
                }
            } catch (_: Exception) {}
        }

        if (snapshot.isPlaying) {
            mainHandler.postDelayed(progressTicker, 250L)
        }
    }

    private fun applyPlaybackSpeedInternal(player: MediaPlayer, speed: Float) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                if (snapshot.isPlaying || player.isPlaying) {
                    val params = player.playbackParams ?: PlaybackParams()
                    params.speed = speed.coerceIn(0.5f, 2.5f)
                    player.playbackParams = params
                }
            } catch (_: Exception) {}
        }
    }

    private fun resolvePlayableUri(rawUri: String): Uri? {
        val clean = rawUri.trim()
        if (clean.isEmpty()) return null
        return try {
            if (clean.startsWith("/")) {
                Uri.fromFile(File(clean))
            } else {
                Uri.parse(clean)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun releasePlayerInternal() {
        mainHandler.removeCallbacks(progressTicker)
        loadedTrackSignature = ""
        try {
            mediaPlayer?.stop()
        } catch (_: Exception) {}
        try {
            mediaPlayer?.release()
        } catch (_: Exception) {}
        mediaPlayer = null
        try {
            attachedWebView?.loadUrl("about:blank")
        } catch (_: Exception) {}
    }

    private fun notifyListeners(updateNotification: Boolean) {
        onStateChanged?.invoke(snapshot)
        if (updateNotification) {
            syncMediaNotification()
        }
    }

    private fun syncMediaNotification() {
        val nm = notificationManager ?: return
        val track = snapshot.currentTrack
        if (track == null || (!snapshot.isPlaying && !snapshot.backgroundMode)) {
            cancelMediaNotification()
            return
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    MEDIA_NOTIFICATION_CHANNEL_ID,
                    "Agy Left-Window Player",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Background audio and video playback controls for Agy HUD"
                    setShowBadge(false)
                }
                nm.createNotificationChannel(channel)
            }
            val modeTag = when {
                snapshot.backgroundMode -> "BG Audio"
                snapshot.mediaMode == "audio" -> "Audio-Only"
                else -> "Video"
            }
            val statusTag = if (snapshot.isPlaying) "Playing" else "Paused"
            val subLine = buildString {
                if (track.subtitle.isNotBlank()) {
                    append(track.subtitle).append(" • ")
                }
                append(modeTag).append(" • ").append(statusTag)
            }
            val notification = NotificationCompat.Builder(context, MEDIA_NOTIFICATION_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(track.title)
                .setContentText(subLine)
                .setOngoing(snapshot.isPlaying)
                .setOnlyAlertOnce(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
                .build()
            nm.notify(MEDIA_NOTIFICATION_ID, notification)
        } catch (e: Exception) {
            Log.w(TAG, "Failed posting media notification: ${e.message}")
        }
    }

    private fun cancelMediaNotification() {
        try {
            notificationManager?.cancel(MEDIA_NOTIFICATION_ID)
        } catch (_: Exception) {}
    }
}
