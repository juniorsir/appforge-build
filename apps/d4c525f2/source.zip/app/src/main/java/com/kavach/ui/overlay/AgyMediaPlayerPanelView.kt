package com.kavach.ui.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.sin

/**
 * Custom In-Window Media Player Panel rendered inside Window 3 (`agy_task_map`) when
 * `mode == "player"` (or `"media"` with playable tracks).
 *
 * Features:
 * - Instant `[🎬 Video | 🎵 Audio]` toggle switching between 16:9 video surface and sleek Audio-Only music deck
 * - `[🎧 BG]` background button collapsing the left window into an interactive floating mini-pill
 * - `[⤢]` pop-out button launching full-screen lightbox view
 * - Play/Pause, Previous/Next track, interactive SeekBar, and live `elapsed / duration` counter
 * - Playback speed (`0.75x`–`2.0x`), Loop toggle, Mute/Volume control, and expandable Playlist Queue
 */
@SuppressLint("SetJavaScriptEnabled")
class AgyMediaPlayerPanelView(
    context: Context,
    val controller: AgyMediaPlaybackController = AgyMediaPlaybackController(context)
) : LinearLayout(context) {

    companion object {
        const val PLAYER_TAG_PREFIX = "${AgyTaskMapOverlayManager.TASK_MAP_NODE_TAG}_player"
    }

    var onRequestBackgroundPill: (() -> Unit)? = null
    var onRequestFullscreenLightbox: ((List<AgyHudDynamicModels.ResultMediaItem>, Int) -> Unit)? = null
    var onPlayerStateChanged: ((AgyMediaPlaybackController.PlaybackSnapshot) -> Unit)? = null

    private val d = context.resources.displayMetrics.density.coerceAtLeast(1f)

    private val videoModeBtn: TextView
    private val audioModeBtn: TextView
    private val bgModeBtn: TextView
    private val popOutBtn: TextView

    private val videoViewportContainer: FrameLayout
    private val videoTextureView: TextureView
    private val embedWebView: WebView
    private val videoOverlayBadge: TextView

    private val audioDeckContainer: LinearLayout
    private val audioThumbImage: ImageView
    private val audioWaveformView: AudioWaveformView
    private val audioModeBadgeText: TextView

    private val trackTitleText: TextView
    private val trackSubtitleText: TextView
    private val seekBar: SeekBar
    private val elapsedTimeText: TextView
    private val durationTimeText: TextView

    private val prevBtn: TextView
    private val playPauseBtn: TextView
    private val nextBtn: TextView

    private val speedBtn: TextView
    private val loopBtn: TextView
    private val volumeMuteBtn: TextView
    private val queueToggleBtn: TextView

    private val queueScrollView: ScrollView
    private val queueListContainer: LinearLayout

    private var activeSurface: Surface? = null
    private var isUserSeeking: Boolean = false
    private var isQueueExpanded: Boolean = false
    private var lastLoadedThumbUri: String = ""
    private var lastRenderedPlaylistSig: String = ""

    private var currentTheme: AgyHudDynamicModels.ResolvedHudTheme =
        AgyHudDynamicModels.resolveTheme(AgyHudDynamicModels.HudThemeConfig(), Color.parseColor("#EC4899"))

    init {
        orientation = VERTICAL
        tag = PLAYER_TAG_PREFIX
        contentDescription = PLAYER_TAG_PREFIX
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS

        // 1. Mode Switcher Row: [🎬 Video | 🎵 Audio]   [🎧 BG] [⤢]
        val modeRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = (6 * d).toInt()
            }
        }

        fun pillTab(label: String, suffix: String, weight: Float = 0f, onClick: () -> Unit): TextView {
            return TextView(context).apply {
                text = label
                textSize = 9.5f
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                gravity = Gravity.CENTER
                minHeight = (28 * d).toInt()
                setPadding((7 * d).toInt(), (4 * d).toInt(), (7 * d).toInt(), (4 * d).toInt())
                contentDescription = "${PLAYER_TAG_PREFIX}_$suffix"
                tag = "${PLAYER_TAG_PREFIX}_$suffix"
                layoutParams = if (weight > 0f) {
                    LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight).apply {
                        marginEnd = (4 * d).toInt()
                    }
                } else {
                    LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        marginStart = (3 * d).toInt()
                    }
                }
                setOnClickListener { onClick() }
            }
        }

        videoModeBtn = pillTab("🎬 Video", "mode_video", weight = 1f) {
            controller.setMediaMode("video")
        }
        audioModeBtn = pillTab("🎵 Audio", "mode_audio", weight = 1f) {
            controller.setMediaMode("audio")
        }
        bgModeBtn = pillTab("🎧 BG", "mode_bg") {
            controller.setBackgroundMode(true)
            onRequestBackgroundPill?.invoke()
        }
        popOutBtn = pillTab("⤢", "popout_btn") {
            val snap = controller.currentSnapshot()
            val items = snap.playlist.map { it.toResultMediaItem() }
            if (items.isNotEmpty()) {
                onRequestFullscreenLightbox?.invoke(items, snap.currentIndex)
            }
        }

        modeRow.addView(videoModeBtn)
        modeRow.addView(audioModeBtn)
        modeRow.addView(bgModeBtn)
        modeRow.addView(popOutBtn)
        addView(modeRow)

        // 2A. 16:9 Video Surface Container
        videoViewportContainer = FrameLayout(context).apply {
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (118 * d).toInt()).apply {
                bottomMargin = (6 * d).toInt()
            }
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 12f * d
                setColor(Color.parseColor("#FF020617"))
                setStroke((1f * d).toInt().coerceAtLeast(1), Color.parseColor("#FF1E293B"))
            }
            clipChildren = true
            clipToPadding = true
            contentDescription = "${PLAYER_TAG_PREFIX}_video_viewport"
        }

        videoTextureView = TextureView(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.CENTER
            )
            surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                    activeSurface?.release()
                    val s = Surface(surface)
                    activeSurface = s
                    controller.bindVideoSurface(s)
                }

                override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}

                override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                    controller.bindVideoSurface(null)
                    activeSurface?.release()
                    activeSurface = null
                    return true
                }

                override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
            }
            setOnClickListener { controller.togglePlayPause() }
        }

        embedWebView = WebView(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
            try {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.loadWithOverviewMode = true
                settings.useWideViewPort = true
                settings.cacheMode = WebSettings.LOAD_DEFAULT
                webViewClient = WebViewClient()
                webChromeClient = WebChromeClient()
            } catch (_: Exception) {}
        }
        controller.bindWebView(embedWebView)

        videoOverlayBadge = TextView(context).apply {
            text = "▶"
            textSize = 16f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams((36 * d).toInt(), (36 * d).toInt(), Gravity.CENTER)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#990F172A"))
                setStroke((1f * d).toInt().coerceAtLeast(1), Color.parseColor("#80FFFFFF"))
            }
            visibility = View.GONE
        }

        videoViewportContainer.addView(videoTextureView)
        videoViewportContainer.addView(embedWebView)
        videoViewportContainer.addView(videoOverlayBadge)
        addView(videoViewportContainer)

        // 2B. Audio-Only Music Deck (shown when mediaMode == "audio")
        audioDeckContainer = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((9 * d).toInt(), (8 * d).toInt(), (9 * d).toInt(), (8 * d).toInt())
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = (6 * d).toInt()
            }
            visibility = View.GONE
            contentDescription = "${PLAYER_TAG_PREFIX}_audio_deck"
            setOnClickListener { controller.togglePlayPause() }
        }

        audioThumbImage = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = LayoutParams((42 * d).toInt(), (42 * d).toInt()).apply {
                marginEnd = (8 * d).toInt()
            }
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 10f * d
                setColor(Color.parseColor("#FF1E293B"))
            }
        }

        val audioRightCol = LinearLayout(context).apply {
            orientation = VERTICAL
            layoutParams = LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        audioModeBadgeText = TextView(context).apply {
            text = "🎵 AUDIO-ONLY • BACKGROUND READY"
            textSize = 8f
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }

        audioWaveformView = AudioWaveformView(context).apply {
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (24 * d).toInt()).apply {
                topMargin = (4 * d).toInt()
            }
        }

        audioRightCol.addView(audioModeBadgeText)
        audioRightCol.addView(audioWaveformView)
        audioDeckContainer.addView(audioThumbImage)
        audioDeckContainer.addView(audioRightCol)
        addView(audioDeckContainer)

        // 3. Track Title & Subtitle
        trackTitleText = TextView(context).apply {
            text = "Ready to Play"
            textSize = 11.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            contentDescription = "${PLAYER_TAG_PREFIX}_track_title"
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        addView(trackTitleText)

        trackSubtitleText = TextView(context).apply {
            text = "Agy Custom Player"
            textSize = 9.5f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            contentDescription = "${PLAYER_TAG_PREFIX}_track_subtitle"
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = (1 * d).toInt()
                bottomMargin = (4 * d).toInt()
            }
        }
        addView(trackSubtitleText)

        // 4. Interactive Seek Bar + Time Counter Row
        seekBar = SeekBar(context).apply {
            max = 1000
            progress = 0
            contentDescription = "${PLAYER_TAG_PREFIX}_seek_bar"
            tag = "${PLAYER_TAG_PREFIX}_seek_bar"
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val dur = controller.currentSnapshot().durationMs
                        if (dur > 0L) {
                            val previewMs = ((progress / 1000.0) * dur).toLong()
                            elapsedTimeText.text = AgyMediaPlaybackController.formatTimeMs(previewMs)
                        }
                    }
                }

                override fun onStartTrackingTouch(sb: SeekBar?) {
                    isUserSeeking = true
                }

                override fun onStopTrackingTouch(sb: SeekBar?) {
                    isUserSeeking = false
                    controller.seekByPermille(sb?.progress ?: 0)
                }
            })
        }
        addView(seekBar)

        val timeRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = (6 * d).toInt()
            }
        }

        elapsedTimeText = TextView(context).apply {
            text = "00:00"
            textSize = 8.5f
            typeface = Typeface.MONOSPACE
            contentDescription = "${PLAYER_TAG_PREFIX}_elapsed_time"
            layoutParams = LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        durationTimeText = TextView(context).apply {
            text = "--:--"
            textSize = 8.5f
            typeface = Typeface.MONOSPACE
            gravity = Gravity.END
            contentDescription = "${PLAYER_TAG_PREFIX}_duration_time"
            layoutParams = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        timeRow.addView(elapsedTimeText)
        timeRow.addView(durationTimeText)
        addView(timeRow)

        // 5. Primary Transport Controls Row: [⏮] [ ⏸ Pause / ▶ Play ] [⏭]
        val transportRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = (6 * d).toInt()
            }
        }

        fun transportBtn(label: String, suffix: String, isPrimary: Boolean = false, onClick: () -> Unit): TextView {
            return TextView(context).apply {
                text = label
                textSize = if (isPrimary) 10.5f else 11f
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                gravity = Gravity.CENTER
                minHeight = (34 * d).toInt()
                minWidth = if (isPrimary) (84 * d).toInt() else (40 * d).toInt()
                setPadding((10 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
                contentDescription = "${PLAYER_TAG_PREFIX}_$suffix"
                tag = "${PLAYER_TAG_PREFIX}_$suffix"
                layoutParams = if (isPrimary) {
                    LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                        marginStart = (6 * d).toInt()
                        marginEnd = (6 * d).toInt()
                    }
                } else {
                    LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                }
                setOnClickListener { onClick() }
            }
        }

        prevBtn = transportBtn("⏮", "prev_btn") { controller.previousTrack() }
        playPauseBtn = transportBtn("⏸ Pause", "play_pause_btn", isPrimary = true) { controller.togglePlayPause() }
        nextBtn = transportBtn("⏭", "next_btn") { controller.nextTrack() }

        transportRow.addView(prevBtn)
        transportRow.addView(playPauseBtn)
        transportRow.addView(nextBtn)
        addView(transportRow)

        // 6. Secondary Controls Row: [1.0x] [🔁] [🔊 100%] [☰ Queue]
        val secondaryRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        fun auxChip(label: String, suffix: String, onClick: () -> Unit): TextView {
            return TextView(context).apply {
                text = label
                textSize = 8.5f
                setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
                gravity = Gravity.CENTER
                minHeight = (26 * d).toInt()
                setPadding((5 * d).toInt(), (3 * d).toInt(), (5 * d).toInt(), (3 * d).toInt())
                contentDescription = "${PLAYER_TAG_PREFIX}_$suffix"
                tag = "${PLAYER_TAG_PREFIX}_$suffix"
                layoutParams = LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginEnd = (3 * d).toInt()
                }
                setOnClickListener { onClick() }
            }
        }

        speedBtn = auxChip("1.0x", "speed_btn") { controller.cycleSpeed() }
        loopBtn = auxChip("🔁 Off", "loop_btn") { controller.toggleLoop() }
        volumeMuteBtn = auxChip("🔊 100%", "mute_vol_btn") { controller.cycleVolumePreset() }.apply {
            setOnLongClickListener {
                controller.toggleMute()
                true
            }
        }
        queueToggleBtn = auxChip("☰ (1)", "queue_toggle_btn") {
            isQueueExpanded = !isQueueExpanded
            renderSnapshot(controller.currentSnapshot())
        }.apply {
            (layoutParams as? LayoutParams)?.marginEnd = 0
        }

        secondaryRow.addView(speedBtn)
        secondaryRow.addView(loopBtn)
        secondaryRow.addView(volumeMuteBtn)
        secondaryRow.addView(queueToggleBtn)
        addView(secondaryRow)

        // 7. Expandable Playlist Queue Drawer
        queueListContainer = LinearLayout(context).apply {
            orientation = VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        queueScrollView = ScrollView(context).apply {
            layoutParams = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (96 * d).toInt()).apply {
                topMargin = (6 * d).toInt()
            }
            visibility = View.GONE
            contentDescription = "${PLAYER_TAG_PREFIX}_queue_drawer"
            addView(queueListContainer)
        }
        addView(queueScrollView)

        controller.onStateChanged = { snap ->
            renderSnapshot(snap)
            onPlayerStateChanged?.invoke(snap)
        }
    }

    fun updatePlayer(
        config: AgyHudDynamicModels.TaskMapConfig,
        theme: AgyHudDynamicModels.ResolvedHudTheme
    ) {
        currentTheme = theme
        val playerData = config.player ?: AgyHudDynamicModels.PlayerTaskMapData(
            mediaMode = "audio",
            playing = config.media?.playing ?: true,
            playlist = listOf(
                AgyHudDynamicModels.PlayerTrackItem(
                    id = "trk_0",
                    title = config.media?.title ?: config.title.ifBlank { "Now Playing" },
                    subtitle = config.media?.subtitle.orEmpty(),
                    uri = "",
                    isVideo = false
                )
            )
        )
        controller.applyPlayerData(playerData)
        renderSnapshot(controller.currentSnapshot())
    }

    fun stopPlayback() {
        controller.stopAndRelease()
    }

    private fun renderSnapshot(snap: AgyMediaPlaybackController.PlaybackSnapshot) {
        val theme = currentTheme
        val track = snap.currentTrack
        val isVideoMode = snap.mediaMode == "video"

        // Style Mode Tabs
        stylePillButton(videoModeBtn, active = isVideoMode, theme = theme)
        stylePillButton(audioModeBtn, active = !isVideoMode, theme = theme)
        stylePillButton(bgModeBtn, active = snap.backgroundMode, theme = theme)
        stylePillButton(popOutBtn, active = false, theme = theme)

        // Toggle Video Surface vs Audio-Only Music Deck without destroying active surface/WebView
        if (isVideoMode) {
            videoViewportContainer.layoutParams = (videoViewportContainer.layoutParams as LayoutParams).apply {
                height = (118 * d).toInt()
                bottomMargin = (6 * d).toInt()
            }
            videoViewportContainer.visibility = View.VISIBLE
            audioDeckContainer.visibility = View.GONE
            if (track?.isWebEmbed == true) {
                embedWebView.visibility = View.VISIBLE
                videoTextureView.visibility = View.INVISIBLE
            } else {
                embedWebView.visibility = View.GONE
                videoTextureView.visibility = View.VISIBLE
            }
            videoOverlayBadge.visibility = if (snap.isPlaying) View.GONE else View.VISIBLE
        } else {
            // Keep videoViewportContainer attached with 1px height so WebView/TextureView audio keeps playing seamlessly
            videoViewportContainer.layoutParams = (videoViewportContainer.layoutParams as LayoutParams).apply {
                height = 1
                bottomMargin = 0
            }
            videoViewportContainer.visibility = View.INVISIBLE
            audioDeckContainer.visibility = View.VISIBLE
            audioDeckContainer.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 12f * d
                setColor(theme.secondarySurface)
                setStroke((1f * d).toInt().coerceAtLeast(1), theme.border)
            }
            audioModeBadgeText.setTextColor(theme.accent)
            audioModeBadgeText.text = when {
                track?.isWebEmbed == true -> "🎵 WEB AUDIO STREAM • PLAYING"
                snap.isPlaying -> "🎵 AUDIO-ONLY • ACTIVE"
                else -> "🎵 AUDIO-ONLY • PAUSED"
            }
            audioWaveformView.updateState(isPlaying = snap.isPlaying, accentColor = theme.accent)

            val thumbUri = track?.thumbnailUri.orEmpty().ifBlank { track?.uri.orEmpty() }
            if (thumbUri != lastLoadedThumbUri) {
                lastLoadedThumbUri = thumbUri
                if (thumbUri.isNotBlank() && !track!!.isWebEmbed) {
                    AgyResultsMediaLoader.loadPreviewBitmap(
                        context = context,
                        item = track.toResultMediaItem(),
                        maxDimensionPx = 240
                    ) { bmp ->
                        audioThumbImage.setImageBitmap(bmp)
                    }
                } else {
                    audioThumbImage.setImageDrawable(null)
                }
            }
        }

        // Track Title & Subtitle
        trackTitleText.text = track?.title ?: "No Track Loaded"
        trackTitleText.setTextColor(theme.textPrimary)

        val totalTracks = snap.playlist.size
        val subBuilder = StringBuilder()
        if (!track?.subtitle.isNullOrBlank()) {
            subBuilder.append(track?.subtitle).append(" • ")
        }
        if (totalTracks > 1) {
            subBuilder.append("Track ${snap.currentIndex + 1}/$totalTracks")
        } else {
            subBuilder.append(if (isVideoMode) "Video Mode" else "Audio Mode")
        }
        trackSubtitleText.text = subBuilder.toString()
        trackSubtitleText.setTextColor(theme.textSecondary)

        // SeekBar & Time Counter
        if (!isUserSeeking) {
            seekBar.progress = snap.progressPermille
            elapsedTimeText.text = snap.elapsedLabel
        }
        durationTimeText.text = snap.durationLabel
        elapsedTimeText.setTextColor(theme.textSecondary)
        durationTimeText.setTextColor(theme.textSecondary)

        // Transport Buttons
        stylePillButton(prevBtn, active = false, theme = theme)
        playPauseBtn.text = if (snap.isPlaying) "⏸ Pause" else "▶ Play"
        playPauseBtn.setTextColor(Color.WHITE)
        playPauseBtn.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 999f * d
            setColor(theme.accent)
        }
        stylePillButton(nextBtn, active = false, theme = theme)

        // Secondary Controls
        val speedStr = if (snap.speed % 1.0f == 0f) {
            String.format( java.util.Locale.US, "%.1fx", snap.speed)
        } else {
            String.format(java.util.Locale.US, "%.2fx", snap.speed).trimEnd('0')
        }
        speedBtn.text = speedStr
        stylePillButton(speedBtn, active = kotlin.math.abs(snap.speed - 1.0f) > 0.05f, theme = theme)

        loopBtn.text = if (snap.isLooping) "🔁 On" else "🔁 Off"
        stylePillButton(loopBtn, active = snap.isLooping, theme = theme)

        val volPercent = if (snap.isMuted) 0 else (snap.volume * 100).toInt()
        volumeMuteBtn.text = if (snap.isMuted || volPercent == 0) "🔇 Mute" else "🔊 $volPercent%"
        stylePillButton(volumeMuteBtn, active = snap.isMuted, theme = theme)

        queueToggleBtn.text = "☰ (${snap.playlist.size})"
        stylePillButton(queueToggleBtn, active = isQueueExpanded, theme = theme)

        // Playlist Queue Drawer
        if (isQueueExpanded && snap.playlist.isNotEmpty()) {
            queueScrollView.visibility = View.VISIBLE
            queueScrollView.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 10f * d
                setColor(theme.secondarySurface)
                setStroke((0.8f * d).toInt().coerceAtLeast(1), theme.border)
            }
            val sig = "${snap.currentIndex}|${snap.isPlaying}|${snap.playlist.joinToString(",") { "${it.id}:${it.title}" }}"
            if (sig != lastRenderedPlaylistSig) {
                lastRenderedPlaylistSig = sig
                rebuildQueueRows(snap, theme)
            }
        } else {
            queueScrollView.visibility = View.GONE
        }
    }

    private fun rebuildQueueRows(
        snap: AgyMediaPlaybackController.PlaybackSnapshot,
        theme: AgyHudDynamicModels.ResolvedHudTheme
    ) {
        queueListContainer.removeAllViews()
        snap.playlist.forEachIndexed { idx, item ->
            val isCurrent = idx == snap.currentIndex
            val row = LinearLayout(context).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding((8 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (6 * d).toInt())
                contentDescription = "${PLAYER_TAG_PREFIX}_queue_item_$idx"
                tag = "${PLAYER_TAG_PREFIX}_queue_item_$idx"
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 8f * d
                    setColor(
                        if (isCurrent) Color.argb(38, Color.red(theme.accent), Color.green(theme.accent), Color.blue(theme.accent))
                        else Color.TRANSPARENT
                    )
                }
                setOnClickListener {
                    controller.selectTrack(idx, autoPlay = true)
                }
            }

            val prefixIcon = if (isCurrent) (if (snap.isPlaying) "▸" else "⏸") else "${idx + 1}."
            val titleTv = TextView(context).apply {
                text = "$prefixIcon ${item.title}"
                textSize = 9.5f
                setTypeface(Typeface.SANS_SERIF, if (isCurrent) Typeface.BOLD else Typeface.NORMAL)
                setTextColor(if (isCurrent) theme.accent else theme.textPrimary)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                layoutParams = LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }

            val badgeTv = TextView(context).apply {
                text = if (item.isVideo) "🎬" else "🎵"
                textSize = 9f
                setPadding((4 * d).toInt(), 0, 0, 0)
            }

            row.addView(titleTv)
            row.addView(badgeTv)
            queueListContainer.addView(row)
        }
    }

    private fun stylePillButton(
        tv: TextView,
        active: Boolean,
        theme: AgyHudDynamicModels.ResolvedHudTheme
    ) {
        tv.setTextColor(if (active) theme.accent else theme.textPrimary)
        tv.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 999f * d
            setColor(
                if (active) Color.argb(42, Color.red(theme.accent), Color.green(theme.accent), Color.blue(theme.accent))
                else theme.secondarySurface
            )
            setStroke(
                (if (active) (1.2f * d) else (0.8f * d)).toInt().coerceAtLeast(1),
                if (active) theme.accent else theme.border
            )
        }
    }

    /**
     * Lightweight animated equalizer waveform bar strip for Audio-Only mode.
     */
    private class AudioWaveformView(context: Context) : View(context) {
        private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
        }
        private val barRect = RectF()
        private var isPlaying: Boolean = false
        private var phase: Float = 0f

        fun updateState(isPlaying: Boolean, accentColor: Int) {
            this.isPlaying = isPlaying
            barPaint.color = accentColor
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f) return
            val barCount = 16
            val gap = w / (barCount * 2.2f)
            val barW = (w - gap * (barCount - 1)) / barCount
            val radius = barW / 2f

            for (i in 0 until barCount) {
                val ratio = if (isPlaying) {
                    (0.28f + 0.68f * kotlin.math.abs(sin(phase + i * 0.65f))).coerceIn(0.2f, 0.96f)
                } else {
                    0.24f + (i % 3) * 0.08f
                }
                val barH = (h * ratio).coerceAtLeast(4f)
                val left = i * (barW + gap)
                val top = (h - barH) / 2f
                barRect.set(left, top, left + barW, top + barH)
                canvas.drawRoundRect(barRect, radius, radius, barPaint)
            }
            if (isPlaying) {
                phase += 0.28f
                postInvalidateDelayed(120L)
            }
        }
    }
}
