package com.example.media.playback

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.media.DecoderCapabilityManager
import com.example.media.probe.MediaProbeEngine
import com.example.media.probe.MediaProbeInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object PlaybackFallbackEngine {
    private const val TAG = "PlaybackFallbackEngine"

    suspend fun evaluatePlaybackStrategy(context: Context, uri: Uri): PlaybackCompatibilityResult = withContext(Dispatchers.IO) {
        com.example.media.preview.FrpPreviewEngine.setActivePlaybackSource(uri, uri.path)
        val probeResult = MediaProbeEngine.probeMedia(context, uri)

        if (probeResult.isFailure) {
            return@withContext PlaybackCompatibilityResult(
                strategy = PlaybackStrategy.DIRECT_HARDWARE,
                reason = "Probe skipped; attempting default ExoPlayer hardware playback",
                containerFormat = "unknown",
                videoCodec = "unknown",
                audioCodec = "unknown"
            )
        }
        val probeInfo = probeResult.getOrThrow()
        val format = probeInfo.format.lowercase()
        val video = probeInfo.primaryVideo
        val audio = probeInfo.primaryAudio
        val videoCodec = video?.codec?.lowercase() ?: "none"
        val audioCodec = audio?.codec?.lowercase() ?: "none"

        Log.d(TAG, "Evaluating playback: format=$format, video=$videoCodec, audio=$audioCodec")

        val isStandardContainer = format.contains("mp4") ||
                format.contains("m4v") ||
                format.contains("matroska") ||
                format.contains("mkv") ||
                format.contains("webm") ||
                format.contains("mov") ||
                format.contains("mp3") ||
                format.contains("aac") ||
                format.contains("ogg") ||
                format.contains("flac") ||
                format.contains("ts")

        val vSupport = if (video != null) DecoderCapabilityManager.checkCodecSupport(mapCodecToMime(video.codec, true)).hardwareAvailable else true
        val aSupport = if (audio != null) DecoderCapabilityManager.checkCodecSupport(mapCodecToMime(audio.codec, false)).hardwareAvailable else true

        if (isStandardContainer && vSupport && aSupport) {
            return@withContext PlaybackCompatibilityResult(
                strategy = PlaybackStrategy.DIRECT_HARDWARE,
                reason = "Hardware acceleration available for container and codecs",
                containerFormat = format,
                videoCodec = videoCodec,
                audioCodec = audioCodec
            )
        }

        if (vSupport && aSupport) {
            return@withContext PlaybackCompatibilityResult(
                strategy = PlaybackStrategy.REMUX_REQUIRED,
                reason = "Codecs are hardware-compatible; remuxing to MP4 container recommended",
                containerFormat = format,
                videoCodec = videoCodec,
                audioCodec = audioCodec,
                requiresRemux = true
            )
        }

        if (!vSupport && aSupport) {
            return@withContext PlaybackCompatibilityResult(
                strategy = PlaybackStrategy.TRANSCODE_VIDEO_ONLY,
                reason = "Video codec ($videoCodec) unsupported. Transcode video, copy audio.",
                containerFormat = format,
                videoCodec = videoCodec,
                audioCodec = audioCodec,
                requiresTranscode = true
            )
        }

        if (vSupport && !aSupport) {
            return@withContext PlaybackCompatibilityResult(
                strategy = PlaybackStrategy.TRANSCODE_AUDIO_ONLY,
                reason = "Audio codec ($audioCodec) unsupported. Copy video, transcode audio.",
                containerFormat = format,
                videoCodec = videoCodec,
                audioCodec = audioCodec,
                requiresTranscode = true
            )
        }

        return@withContext PlaybackCompatibilityResult(
            strategy = PlaybackStrategy.TRANSCODE_BOTH,
            reason = "Both codecs unsupported ($videoCodec / $audioCodec). Full transcode required.",
            containerFormat = format,
            videoCodec = videoCodec,
            audioCodec = audioCodec,
            requiresTranscode = true
        )
    }
    
    private fun mapCodecToMime(codec: String, isVideo: Boolean): String {
        val c = codec.lowercase()
        return if (isVideo) {
            when (c) {
                "h264", "avc1" -> "video/avc"
                "hevc", "h265" -> "video/hevc"
                "vp8" -> "video/x-vnd.on2.vp8"
                "vp9" -> "video/x-vnd.on2.vp9"
                "av1", "av01" -> "video/av01"
                "mpeg4" -> "video/mp4v-es"
                "mpeg2" -> "video/mpeg2"
                else -> "video/$c"
            }
        } else {
            when (c) {
                "aac" -> "audio/mp4a-latm"
                "mp3" -> "audio/mpeg"
                "ac3" -> "audio/ac3"
                "eac3" -> "audio/eac3"
                "dts" -> "audio/vnd.dts"
                "truehd" -> "audio/true-hd"
                "flac" -> "audio/flac"
                "opus" -> "audio/opus"
                "vorbis" -> "audio/vorbis"
                else -> "audio/$c"
            }
        }
    }
}
