package com.example.media.probe

import android.os.Build
import com.example.media.DecoderCapabilityManager
import com.example.media.playback.PlaybackCompatibilityResult

object DiagnosticReportGenerator {

    fun generateReport(
        probeInfo: MediaProbeInfo,
        compatibilityResult: PlaybackCompatibilityResult?,
        playbackExceptionMessage: String?
    ): String {
        val sb = StringBuilder()
        sb.appendLine("════════════════════════════════════")
        sb.appendLine("MEDIA CODEC REPORT")
        sb.appendLine("════════════════════════════════════")
        sb.appendLine()
        
        sb.appendLine("APPLICATION")
        sb.appendLine("Android API: ${Build.VERSION.SDK_INT}")
        sb.appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}")
        sb.appendLine()
        
        sb.appendLine("FILE")
        sb.appendLine("Path: ${redactPath(probeInfo.pathOrUri)}")
        sb.appendLine("Size: ${formatSize(probeInfo.sizeBytes)}")
        sb.appendLine()
        
        sb.appendLine("CONTAINER")
        sb.appendLine("Format: ${probeInfo.format}")
        sb.appendLine("Format Name: ${probeInfo.formatLongName ?: "Unknown"}")
        sb.appendLine("Duration: ${formatDuration(probeInfo.durationMs)}")
        sb.appendLine("Overall Bitrate: ${formatBitrate(probeInfo.overallBitrate)}")
        sb.appendLine()
        
        for (v in probeInfo.videoStreams) {
            sb.appendLine("VIDEO STREAM #${v.index}")
            sb.appendLine("Codec: ${v.codec.uppercase()} / ${v.codecLongName ?: "Unknown"}")
            if (!v.profile.isNullOrBlank()) sb.appendLine("Profile: ${v.profile}")
            if (!v.level.isNullOrBlank()) sb.appendLine("Level: ${v.level}")
            sb.appendLine("Resolution: ${v.width}x${v.height}")
            if (!v.pixelFormat.isNullOrBlank()) sb.appendLine("Pixel Format: ${v.pixelFormat}")
            sb.appendLine("Frame Rate: ${v.frameRate} FPS")
            if (v.bitrate > 0) sb.appendLine("Bitrate: ${formatBitrate(v.bitrate)}")
            if (!v.colorSpace.isNullOrBlank()) {
                val hdr = if (v.colorTransfer?.contains("smpte2084") == true) "HDR10" 
                          else if (v.colorTransfer?.contains("arib-std-b67") == true) "HLG"
                          else "SDR"
                sb.appendLine("HDR: $hdr")
                sb.appendLine("Color Space: ${v.colorSpace}")
                sb.appendLine("Transfer: ${v.colorTransfer}")
                sb.appendLine("Primaries: ${v.colorPrimaries}")
            }
            sb.appendLine()
        }
        
        for (a in probeInfo.audioStreams) {
            sb.appendLine("AUDIO STREAM #${a.index}")
            sb.appendLine("Codec: ${a.codec.uppercase()} / ${a.codecLongName ?: "Unknown"}")
            sb.appendLine("Channels: ${a.channels}")
            if (!a.channelLayout.isNullOrBlank()) sb.appendLine("Layout: ${a.channelLayout}")
            sb.appendLine("Sample Rate: ${a.sampleRate} Hz")
            if (a.bitrate > 0) sb.appendLine("Bitrate: ${formatBitrate(a.bitrate)}")
            sb.appendLine("Language: ${a.language}")
            sb.appendLine()
        }
        
        for (s in probeInfo.subtitleStreams) {
            sb.appendLine("SUBTITLE STREAM #${s.index}")
            sb.appendLine("Codec: ${s.codec.uppercase()}")
            sb.appendLine("Language: ${s.language}")
            sb.appendLine("Default: ${if (s.isDefault) "yes" else "no"}")
            sb.appendLine("Forced: ${if (s.isForced) "yes" else "no"}")
            sb.appendLine()
        }
        
        sb.appendLine("ANDROID DECODER CAPABILITIES")
        val primaryVideo = probeInfo.primaryVideo
        if (primaryVideo != null) {
            val mime = mapCodecToMime(primaryVideo.codec, true)
            val support = DecoderCapabilityManager.checkCodecSupport(mime)
            sb.appendLine("[VIDEO: ${primaryVideo.codec}]")
            val dec = support.hardwareDecoders.firstOrNull() ?: support.softwareDecoders.firstOrNull() ?: "None"
            sb.appendLine("Hardware Available: ${support.hardwareAvailable}")
            sb.appendLine("Primary Decoder: $dec")
            sb.appendLine()
        }
        
        val primaryAudio = probeInfo.primaryAudio
        if (primaryAudio != null) {
            val mime = mapCodecToMime(primaryAudio.codec, false)
            val support = DecoderCapabilityManager.checkCodecSupport(mime)
            sb.appendLine("[AUDIO: ${primaryAudio.codec}]")
            val dec = support.hardwareDecoders.firstOrNull() ?: support.softwareDecoders.firstOrNull() ?: "None"
            sb.appendLine("Hardware Available: ${support.hardwareAvailable}")
            sb.appendLine("Primary Decoder: $dec")
            sb.appendLine()
        }
        
        if (compatibilityResult != null || playbackExceptionMessage != null) {
            sb.appendLine("PLAYER COMPATIBILITY")
            val containerOk = isContainerOk(probeInfo.format)
            
            sb.appendLine("Container:        ${if (containerOk) "✓" else "✕"}")
            
            var overallMsg = "PLAYABLE"
            if (compatibilityResult != null) {
                sb.appendLine("Strategy:         ${compatibilityResult.strategy.name}")
                if (compatibilityResult.requiresRemux) overallMsg = "REMUX RECOMMENDED"
                if (compatibilityResult.requiresTranscode) overallMsg = "TRANSCODE REQUIRED"
            }
            if (playbackExceptionMessage != null) {
                overallMsg = "NOT DIRECTLY PLAYABLE (ERROR)"
            }
            sb.appendLine("Overall:          $overallMsg")
            sb.appendLine()
        }
        
        if (playbackExceptionMessage != null) {
            sb.appendLine("PLAYBACK FAILURE ANALYSIS")
            sb.appendLine("Error: $playbackExceptionMessage")
            sb.appendLine()
            
            val vSupport = if (primaryVideo != null) DecoderCapabilityManager.checkCodecSupport(mapCodecToMime(primaryVideo.codec, true)).hardwareAvailable else true
            val aSupport = if (primaryAudio != null) DecoderCapabilityManager.checkCodecSupport(mapCodecToMime(primaryAudio.codec, false)).hardwareAvailable else true
            
            sb.appendLine("Likely Problem:")
            if (!vSupport) {
                sb.appendLine("Video codec ${primaryVideo?.codec} is not supported by hardware.")
            } else if (!aSupport) {
                sb.appendLine("Audio codec ${primaryAudio?.codec} is not supported by hardware.")
            } else if (!isContainerOk(probeInfo.format)) {
                sb.appendLine("Container format ${probeInfo.format} is likely problematic for this player.")
            } else {
                sb.appendLine("Specific codec profile/level or internal player limitation.")
            }
            
            sb.appendLine()
            sb.appendLine("RECOMMENDED ACTION")
            if (vSupport && aSupport && !isContainerOk(probeInfo.format)) {
                sb.appendLine("Try remuxing first. Codecs appear compatible.")
            } else {
                sb.appendLine("If the codec itself is unsupported, transcode the incompatible stream.")
            }
        }
        
        sb.appendLine("════════════════════════════════════")
        return sb.toString()
    }
    
    private fun isContainerOk(format: String): Boolean {
        val f = format.lowercase()
        return f.contains("mp4") || f.contains("m4v") || f.contains("mkv") || f.contains("matroska") || f.contains("webm") || f.contains("mp3") || f.contains("aac") || f.contains("ts") || f.contains("mov")
    }
    
    private fun mapCodecToMime(codec: String, isVideo: Boolean): String {
        val c = codec.lowercase()
        return if (isVideo) {
            when (c) {
                "h264", "avc1" -> "video/avc"
                "hevc", "h265" -> "video/hevc"
                "vp8" -> "video/x-vnd.on2.vp8"
                "vp9" -> "video/x-vnd.on2.vp9"
                "av1", "av01" -> "video/av01"
                "mpeg4" -> "video/mp4v-es"
                "mpeg2" -> "video/mpeg2"
                else -> "video/$c"
            }
        } else {
            when (c) {
                "aac" -> "audio/mp4a-latm"
                "mp3" -> "audio/mpeg"
                "ac3" -> "audio/ac3"
                "eac3" -> "audio/eac3"
                "dts" -> "audio/vnd.dts"
                "truehd" -> "audio/true-hd"
                "flac" -> "audio/flac"
                "opus" -> "audio/opus"
                "vorbis" -> "audio/vorbis"
                else -> "audio/$c"
            }
        }
    }

    private fun redactPath(path: String): String {
        if (path.startsWith("content://") || path.startsWith("http")) return path
        val parts = path.split("/")
        if (parts.size > 2) {
            return ".../" + parts.takeLast(2).joinToString("/")
        }
        return path
    }

    private fun formatSize(bytes: Long): String {
        if (bytes <= 0) return "Unknown"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb > 1.0 -> String.format("%.2f GB", gb)
            mb > 1.0 -> String.format("%.2f MB", mb)
            else -> String.format("%.2f KB", kb)
        }
    }

    private fun formatDuration(ms: Long): String {
        if (ms <= 0) return "Unknown"
        val totalSecs = ms / 1000
        val h = totalSecs / 3600
        val m = (totalSecs % 3600) / 60
        val s = totalSecs % 60
        return if (h > 0) String.format("%02d:%02d:%02d", h, m, s)
        else String.format("%02d:%02d", m, s)
    }

    private fun formatBitrate(bps: Long): String {
        if (bps <= 0) return "Unknown"
        val kbps = bps / 1000.0
        val mbps = kbps / 1000.0
        return if (mbps > 1.0) String.format("%.1f Mbps", mbps)
        else String.format("%.0f kbps", kbps)
    }
}
