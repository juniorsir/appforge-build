package com.example.media.probe

data class VideoStreamInfo(
    val index: Int = 0,
    val codec: String = "unknown",
    val codecLongName: String? = null,
    val codecTagString: String? = null,
    val profile: String? = null,
    val level: String? = null,
    val width: Int = 0,
    val height: Int = 0,
    val frameRate: Float = 0f,
    val averageFrameRate: String? = null,
    val timeBase: String? = null,
    val bitrate: Long = 0L,
    val pixelFormat: String? = null,
    val colorSpace: String? = null,
    val colorTransfer: String? = null,
    val colorPrimaries: String? = null,
    val isDefault: Boolean = false,
    val isForced: Boolean = false,
    val language: String? = null,
    val disposition: String? = null,
    val rotation: Int = 0
)

data class AudioStreamInfo(
    val index: Int = 0,
    val codec: String = "unknown",
    val codecLongName: String? = null,
    val codecTagString: String? = null,
    val profile: String? = null,
    val sampleRate: Int = 0,
    val channels: Int = 0,
    val channelLayout: String? = null,
    val sampleFormat: String? = null,
    val timeBase: String? = null,
    val bitrate: Long = 0L,
    val language: String = "und",
    val title: String? = null,
    val isDefault: Boolean = false,
    val isForced: Boolean = false,
    val disposition: String? = null
)

data class SubtitleStreamInfo(
    val index: Int = 0,
    val codec: String = "unknown",
    val codecLongName: String? = null,
    val codecTagString: String? = null,
    val language: String = "und",
    val title: String? = null,
    val isDefault: Boolean = false,
    val isForced: Boolean = false,
    val disposition: String? = null
)

data class MediaProbeInfo(
    val pathOrUri: String,
    val format: String = "unknown",
    val formatLongName: String? = null,
    val durationMs: Long = 0L,
    val sizeBytes: Long = 0L,
    val overallBitrate: Long = 0L,
    val startTime: String? = null,
    val streamCount: Int = 0,
    val programCount: Int = 0,
    val videoStreams: List<VideoStreamInfo> = emptyList(),
    val audioStreams: List<AudioStreamInfo> = emptyList(),
    val subtitleStreams: List<SubtitleStreamInfo> = emptyList(),
    val metadataTags: Map<String, String> = emptyMap(),
    val rawProperties: String? = null
) {
    val primaryVideo: VideoStreamInfo?
        get() = videoStreams.firstOrNull { it.isDefault } ?: videoStreams.firstOrNull()

    val primaryAudio: AudioStreamInfo?
        get() = audioStreams.firstOrNull { it.isDefault } ?: audioStreams.firstOrNull()

    val isVideo: Boolean
        get() = videoStreams.isNotEmpty()

    val isAudioOnly: Boolean
        get() = videoStreams.isEmpty() && audioStreams.isNotEmpty()
}
