package com.example.media.playback

enum class PlaybackStrategy {
    DIRECT_HARDWARE,
    REMUX_REQUIRED,
    TRANSCODE_REQUIRED,
    TRANSCODE_AUDIO_ONLY,
    TRANSCODE_VIDEO_ONLY,
    TRANSCODE_BOTH,
    UNSUPPORTED
}

data class PlaybackCompatibilityResult(
    val strategy: PlaybackStrategy,
    val reason: String,
    val containerFormat: String,
    val videoCodec: String,
    val audioCodec: String,
    val requiresRemux: Boolean = false,
    val requiresTranscode: Boolean = false
)
