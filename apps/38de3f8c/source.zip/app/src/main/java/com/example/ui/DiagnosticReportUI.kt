package com.example.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.media.probe.DiagnosticReportGenerator
import com.example.media.probe.MediaProbeEngine
import com.example.media.playback.PlaybackFallbackEngine
import kotlinx.coroutines.launch
import android.net.Uri

@Composable
fun CopyCodecReportButton(
    context: Context,
    mediaPath: String,
    playerError: String? = null
) {
    val coroutineScope = rememberCoroutineScope()
    var isGenerating by remember { mutableStateOf(false) }
    
    Button(
        onClick = {
            if (isGenerating) return@Button
            isGenerating = true
            coroutineScope.launch {
                try {
                    val uri = if (mediaPath.startsWith("/")) {
                        Uri.parse("file://$mediaPath")
                    } else {
                        Uri.parse(mediaPath)
                    }
                    val probeResult = MediaProbeEngine.probeMedia(context, uri)
                    if (probeResult.isSuccess) {
                        val fallbackStrategy = PlaybackFallbackEngine.evaluatePlaybackStrategy(context, uri)
                        val report = DiagnosticReportGenerator.generateReport(
                            probeResult.getOrThrow(),
                            fallbackStrategy,
                            playerError
                        )
                        val clipboardManager = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        val clipData = android.content.ClipData.newPlainText("Codec Report", report)
                        clipboardManager.setPrimaryClip(clipData)
                        Toast.makeText(context, "Codec report copied to clipboard", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Failed to probe media for report", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(context, "Error generating report: ${e.message}", Toast.LENGTH_SHORT).show()
                } finally {
                    isGenerating = false
                }
            }
        },
        colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFF2C2C3E),
            contentColor = Color.White
        )
    ) {
        if (isGenerating) {
            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
            Spacer(modifier = Modifier.width(6.dp))
            Text("Generating...", fontWeight = FontWeight.Bold)
        } else {
            Icon(Icons.Default.Assignment, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Copy Codec Report", fontWeight = FontWeight.Bold)
        }
    }
}
