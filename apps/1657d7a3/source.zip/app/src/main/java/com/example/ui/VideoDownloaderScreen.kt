package com.example.ui

import android.content.Context
import android.util.Log
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.DownloadEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.text.selection.SelectionContainer

// Sleek Interface Color Palette - Light Theme
val SleekBg = Color(0xFFFEF7FF)
val SleekCard = Color(0xFFFFFFFF) // White containers
val SleekCardDark = Color(0xFFF3EDF7) // Soft lavender-grey containers
val SleekPurpleDark = Color(0xFF21005D) // Deep royal purple accent
val SleekPurpleLight = Color(0xFFD0BCFF) // Accent frame/border
val SleekPurpleContainer = Color(0xFFEADDFF) // Selected active container
val SleekTextPrimary = Color(0xFF1D1B20) // Deep dark text
val SleekTextSecondary = Color(0xFF49454F) // Muted slate text
val SleekTextMuted = Color(0xFF79747E) // Light gray boundary text
val SleekBorderColor = Color(0xFFCAC4D0) // Frame border

// Backwards compatibility mappings for existing layouts
val SlateBg = SleekBg
val SlateCard = SleekCard
val SlateCardDark = SleekCardDark
val AmberAccent = SleekPurpleDark
val AmberAccentLight = SleekPurpleDark
val EmeraldSuccess = Color(0xFF2E7D32) // Forest green
val CrimsonFailure = Color(0xFFB3261E) // Soft Coral/Crimson
val SilverText = SleekTextSecondary
val WhiteText = SleekTextPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoDownloaderScreen(
    viewModel: VideoDownloaderViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val urlInput by viewModel.videoUrlInput.collectAsStateWithLifecycle()
    val isAnalyzing by viewModel.isAnalyzing.collectAsStateWithLifecycle()
    val analyzedVideo by viewModel.analyzedVideo.collectAsStateWithLifecycle()
    val analysisError by viewModel.analysisError.collectAsStateWithLifecycle()
    val activeDownloads by viewModel.activeDownloads.collectAsStateWithLifecycle()
    val downloadHistory by viewModel.downloadHistory.collectAsStateWithLifecycle()
    val executionLogs by viewModel.executionLogs.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableStateOf(0) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var playingDownload by remember { mutableStateOf<DownloadEntity?>(null) }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(SleekBg),
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // DL/TubeStream icon box
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(SleekPurpleLight, shape = RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "DL",
                                color = SleekPurpleDark,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.SansSerif
                                )
                            )
                        }
                        Column {
                            Text(
                                text = "TubeStream",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = SleekTextPrimary,
                                    letterSpacing = (-0.5).sp
                                )
                            )
                            Text(
                                text = "POWERED BY YT-DLP",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp,
                                    color = SleekTextSecondary,
                                    letterSpacing = 1.2.sp
                                )
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SleekBg,
                    titleContentColor = SleekTextPrimary
                ),
                actions = {
                    IconButton(
                        onClick = { showSettingsDialog = true },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = SleekTextSecondary
                        )
                    }
                }
            )
        },
        containerColor = SleekBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            // Tabs Row
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = SleekBg,
                contentColor = SleekPurpleDark
            ) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text("DOWNLOAD", fontWeight = FontWeight.SemiBold)
                        }
                    },
                    selectedContentColor = SleekPurpleDark,
                    unselectedContentColor = SleekTextSecondary
                )
                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text("LIBRARY (${downloadHistory.size})", fontWeight = FontWeight.SemiBold)
                        }
                    },
                    selectedContentColor = SleekPurpleDark,
                    unselectedContentColor = SleekTextSecondary
                )
                Tab(
                    selected = selectedTabIndex == 2,
                    onClick = { selectedTabIndex = 2 },
                    text = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text("YT-DLP CLI", fontWeight = FontWeight.SemiBold)
                        }
                    },
                    selectedContentColor = SleekPurpleDark,
                    unselectedContentColor = SleekTextSecondary
                )
            }

            AnimatedContent(
                targetState = selectedTabIndex,
                transitionSpec = {
                    if (targetState > initialState) {
                        slideInHorizontally { width -> width } + fadeIn() togetherWith
                                slideOutHorizontally { width -> -width } + fadeOut()
                    } else {
                        slideInHorizontally { width -> -width } + fadeIn() togetherWith
                                slideOutHorizontally { width -> width } + fadeOut()
                    }.using(SizeTransform(clip = false))
                },
                label = "TabTransition",
                modifier = Modifier.weight(1f)
            ) { targetTab ->
                when (targetTab) {
                    0 -> DownloadTab(
                        urlInput = urlInput,
                        isAnalyzing = isAnalyzing,
                        analyzedVideo = analyzedVideo,
                        analysisError = analysisError,
                        activeDownloads = activeDownloads,
                        executionLogs = executionLogs,
                        onClearLogs = { viewModel.clearLogs() },
                        onUrlChange = { viewModel.updateUrlInput(it) },
                        onPasteClick = {
                            clipboardManager.getText()?.text?.let { viewModel.updateUrlInput(it) }
                        },
                        onClearClick = { viewModel.updateUrlInput("") },
                        onAnalyzeClick = { viewModel.analyzeVideo() },
                        onDownloadFormat = { format ->
                            analyzedVideo?.let { video ->
                                viewModel.startDownload(video, format)
                            }
                        },
                        onCancelActiveTask = { taskId ->
                            viewModel.removeActiveTask(taskId)
                        }
                    )
                    1 -> LibraryTab(
                        downloads = downloadHistory,
                        onPlayClick = { playingDownload = it },
                        onShareClick = { viewModel.shareVideo(context, it) },
                        onDeleteClick = { viewModel.deleteDownload(it) }
                    )
                    2 -> YtdlpTab(
                        viewModel = viewModel
                    )
                }
            }
        }
    }

    if (showSettingsDialog) {
        SettingsDialog(
            downloadCount = downloadHistory.size,
            onClearAllDownloads = { viewModel.clearAllDownloads() },
            onDismiss = { showSettingsDialog = false }
        )
    }

    if (playingDownload != null) {
        VideoPlayerDialog(
            download = playingDownload!!,
            onDismiss = { playingDownload = null }
        )
    }
}

@Composable
fun DownloadTab(
    urlInput: String,
    isAnalyzing: Boolean,
    analyzedVideo: AnalyzedVideo?,
    analysisError: String?,
    activeDownloads: Map<String, ActiveDownloadTask>,
    executionLogs: List<String>,
    onClearLogs: () -> Unit,
    onUrlChange: (String) -> Unit,
    onPasteClick: () -> Unit,
    onClearClick: () -> Unit,
    onAnalyzeClick: () -> Unit,
    onDownloadFormat: (VideoFormatUi) -> Unit,
    onCancelActiveTask: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome and link parsing card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SleekCard),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.5f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Universal Downloader & Link Extractor",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = SleekPurpleDark
                        )
                    )
                    Text(
                        text = "Paste any streaming video, direct download link, or YouTube URL below to extract and download instantly.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = SleekTextSecondary)
                    )

                    // URL Input Field
                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = onUrlChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("url_input_field"),
                        placeholder = { Text("https://example.com/video.mp4 or YouTube URL...", color = SleekTextSecondary.copy(alpha = 0.6f)) },
                        trailingIcon = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(end = 8.dp)
                            ) {
                                if (urlInput.isNotEmpty()) {
                                    IconButton(onClick = onClearClick) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = SleekTextSecondary)
                                    }
                                }
                                TextButton(
                                    onClick = onPasteClick,
                                    colors = ButtonDefaults.textButtonColors(contentColor = SleekPurpleDark),
                                    modifier = Modifier.testTag("paste_button")
                                ) {
                                    Text("PASTE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = SleekCardDark,
                            unfocusedContainerColor = SleekCardDark,
                            focusedBorderColor = SleekPurpleDark,
                            unfocusedBorderColor = SleekBorderColor,
                            focusedTextColor = SleekTextPrimary,
                            unfocusedTextColor = SleekTextPrimary,
                            cursorColor = SleekPurpleDark
                        ),
                        shape = RoundedCornerShape(50),
                        singleLine = true
                    )

                    // Action buttons
                    Button(
                        onClick = onAnalyzeClick,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("analyze_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SleekPurpleDark,
                            contentColor = Color.White,
                            disabledContainerColor = SleekPurpleDark.copy(alpha = 0.4f),
                            disabledContentColor = Color.White.copy(alpha = 0.6f)
                        ),
                        shape = RoundedCornerShape(50),
                        enabled = !isAnalyzing && urlInput.trim().isNotEmpty()
                    ) {
                        if (isAnalyzing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("SCANNING LINKS...", fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("ANALYZE VIDEO", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 🚀 LIVE CONSOLE LOGS TERMINAL
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF151515)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, SleekPurpleDark.copy(alpha = 0.15f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(Color(0xFF00FF00), shape = CircleShape)
                            )
                            Text(
                                text = "LIVE EXTRACTOR CONSOLE LOGS",
                                color = Color(0xFF999999),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    letterSpacing = 0.5.sp
                                )
                            )
                        }
                        
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current
                            val context = androidx.compose.ui.platform.LocalContext.current
                            TextButton(
                                onClick = {
                                    val logsText = executionLogs.joinToString("\n")
                                    clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(logsText))
                                    android.widget.Toast.makeText(context, "Logs copied!", android.widget.Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.textButtonColors(contentColor = SleekPurpleDark),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Text("COPY", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            TextButton(
                                onClick = onClearLogs,
                                colors = ButtonDefaults.textButtonColors(contentColor = SleekPurpleDark),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Text("CLEAR", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 130.dp, max = 220.dp)
                            .background(Color(0xFF0B0B0B), shape = RoundedCornerShape(8.dp))
                            .border(1.dp, Color(0xFF222222), shape = RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        val scrollState = rememberLazyListState()
                        // Automatically scroll to the end of logs when size changes
                        LaunchedEffect(executionLogs.size) {
                            if (executionLogs.isNotEmpty()) {
                                scrollState.animateScrollToItem(executionLogs.size - 1)
                            }
                        }
                        
                        LazyColumn(
                            state = scrollState,
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            items(executionLogs) { logLine ->
                                val color = when {
                                    logLine.contains("❌") || logLine.contains("💀") -> CrimsonFailure
                                    logLine.contains("✔") || logLine.contains("🎉") -> Color(0xFF4CAF50)
                                    logLine.contains("⚠️") -> Color(0xFFFFC107)
                                    logLine.contains("📡") || logLine.contains("🎬") -> SleekPurpleLight
                                    else -> Color(0xFFD4D4D4)
                                }
                                Text(
                                    text = logLine,
                                    color = color,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Active Diagnostics / Error Info
        if (analysisError != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CrimsonFailure.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, CrimsonFailure.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = "Error", tint = CrimsonFailure, modifier = Modifier.size(24.dp))
                        Text(
                            text = analysisError,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = CrimsonFailure,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }
        }

        // Active Downloads section
        if (activeDownloads.isNotEmpty()) {
            item {
                Text(
                    text = "ACTIVE DOWNLOADS",
                    style = MaterialTheme.typography.titleSmall.copy(
                        color = AmberAccent,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    ),
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }

            items(activeDownloads.values.toList(), key = { it.id }) { task ->
                ActiveDownloadCard(task = task, onCancelClick = { onCancelActiveTask(task.id) })
            }
        }

        // Analyzed Video details card
        if (analyzedVideo != null) {
            item {
                AnalyzedVideoCard(
                    video = analyzedVideo,
                    onDownloadFormat = onDownloadFormat
                )
            }
        }
    }
}

@Composable
fun ActiveDownloadCard(
    task: ActiveDownloadTask,
    onCancelClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SleekCard),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, if (task.status == DownloadStatus.FAILED) CrimsonFailure.copy(alpha = 0.6f) else SleekPurpleLight)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = task.title,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = SleekTextPrimary,
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Format: .${task.ext.uppercase()}  |  ${task.speedText}",
                        color = SleekTextSecondary,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                
                IconButton(onClick = onCancelClick) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Cancel",
                        tint = if (task.status == DownloadStatus.FAILED) CrimsonFailure else SleekTextSecondary
                    )
                }
            }

            if (task.status == DownloadStatus.FAILED) {
                Text(
                    text = task.error ?: "Download terminated unexpectedly.",
                    color = CrimsonFailure,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val progressPercent = (task.progress * 100).toInt()
                    
                    LinearProgressIndicator(
                        progress = { task.progress },
                        modifier = Modifier
                            .weight(1f)
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = if (task.status == DownloadStatus.COMPLETED) EmeraldSuccess else SleekPurpleDark,
                        trackColor = SleekCardDark
                    )

                    Text(
                        text = "$progressPercent%",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = SleekPurpleDark,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun AnalyzedVideoCard(
    video: AnalyzedVideo,
    onDownloadFormat: (VideoFormatUi) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("analyzed_video_card"),
        colors = CardDefaults.cardColors(containerColor = SleekPurpleContainer),
        shape = RoundedCornerShape(28.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // Visual Banner Header as a padded, floating aspect-ratio island
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.Black)
            ) {
                AsyncImage(
                    model = video.thumbnailUrl,
                    contentDescription = "Video Thumbnail",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    alpha = 0.9f
                )
                // Gradient Overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.6f)),
                                startY = 100f
                            )
                        )
                )

                // Duration badge overlaid
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(12.dp)
                        .background(Color.Black.copy(alpha = 0.7f), shape = RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                    Text(
                        text = video.durationText,
                        color = Color.White,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                }

                // Center play action representation overlay (Material Symbols style)
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Play",
                    tint = Color.White.copy(alpha = 0.9f),
                    modifier = Modifier
                        .size(48.dp)
                        .align(Alignment.Center)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Info details
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = video.title,
                        color = SleekPurpleDark,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.Person, contentDescription = "Channel", tint = SleekTextSecondary, modifier = Modifier.size(16.dp))
                        Text(
                            text = video.author,
                            color = SleekTextSecondary,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }

                Divider(color = SleekPurpleDark.copy(alpha = 0.12f))

                // Extract separate list of combined video formats vs audio formats
                val videoFormats = video.formats.filter { it.type == "combined" || it.type == "video_only" }
                val audioFormats = video.formats.filter { it.type == "audio" }

                // Video formats header
                if (videoFormats.isNotEmpty()) {
                    Text(
                        text = "VIDEO FORMATS",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = SleekPurpleDark,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        videoFormats.forEach { format ->
                            FormatRowItem(format = format, onDownloadClick = { onDownloadFormat(format) })
                        }
                    }
                }

                if (videoFormats.isNotEmpty() && audioFormats.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Audio formats header
                if (audioFormats.isNotEmpty()) {
                    Text(
                        text = "AUDIO ONLY FORMATS",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = SleekPurpleDark,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        audioFormats.forEach { format ->
                            FormatRowItem(format = format, onDownloadClick = { onDownloadFormat(format) })
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FormatRowItem(
    format: VideoFormatUi,
    onDownloadClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White, shape = RoundedCornerShape(16.dp))
            .border(1.dp, SleekBorderColor, shape = RoundedCornerShape(16.dp))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(SleekPurpleContainer, shape = RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = SleekPurpleDark,
                    modifier = Modifier.size(18.dp)
                )
            }
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = format.quality,
                        color = SleekTextPrimary,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Box(
                        modifier = Modifier
                            .background(SleekPurpleLight.copy(alpha = 0.5f), shape = RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = format.ext.uppercase(),
                            color = SleekPurpleDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    if (format.type == "video_only") {
                        Box(
                            modifier = Modifier
                                .background(Color(0xFFE8F5E9), shape = RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "⚡ MERGING",
                                color = Color(0xFF2E7D32),
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
                Text(
                    text = format.sizeText,
                    color = SleekTextSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        Button(
            onClick = onDownloadClick,
            colors = ButtonDefaults.buttonColors(
                containerColor = SleekPurpleDark,
                contentColor = Color.White
            ),
            shape = RoundedCornerShape(50),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
            modifier = Modifier.height(36.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("GET", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

@Composable
fun LibraryTab(
    downloads: List<DownloadEntity>,
    onPlayClick: (DownloadEntity) -> Unit,
    onShareClick: (DownloadEntity) -> Unit,
    onDeleteClick: (DownloadEntity) -> Unit
) {
    if (downloads.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = "Empty",
                tint = SleekTextMuted.copy(alpha = 0.5f),
                modifier = Modifier.size(80.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "YOUR LIBRARY IS EMPTY",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = SleekTextPrimary,
                    letterSpacing = 1.sp
                )
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Downloaded media will show up here. Try copying a YouTube link, analyzing format options, and hitting GET!",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = SleekTextSecondary,
                    textAlign = TextAlign.Center
                )
            )
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = "DOWNLOAD HISTORY (${downloads.size})",
                    style = MaterialTheme.typography.titleSmall.copy(
                        color = SleekPurpleDark,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    ),
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
                )
            }

            items(downloads, key = { it.id }) { item ->
                LibraryItemCard(
                    item = item,
                    onPlayClick = { onPlayClick(item) },
                    onShareClick = { onShareClick(item) },
                    onDeleteClick = { onDeleteClick(item) }
                )
            }
        }
    }
}

@Composable
fun LibraryItemCard(
    item: DownloadEntity,
    onPlayClick: () -> Unit,
    onShareClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("library_item_card"),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.6f))
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Mini Thumbnail
                Box(
                    modifier = Modifier
                        .size(width = 110.dp, height = 75.dp)
                        .clip(RoundedCornerShape(10.dp))
                ) {
                    AsyncImage(
                        model = item.thumbnailUrl,
                        contentDescription = "Cover",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    // Length badge
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(4.dp)
                            .background(Color.Black.copy(alpha = 0.7f), shape = RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = item.durationText,
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Info details
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .height(75.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = item.title,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = SleekTextPrimary,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = item.author,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = SleekTextSecondary,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // File size formatted
                        val formattedSize = String.format(Locale.getDefault(), "%.1f MB", item.fileSize.toFloat() / (1024 * 1024))
                        val isAudio = item.localPath.endsWith(".mp3") || item.localPath.endsWith(".m4a")
                        
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = SleekTextMuted,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "$formattedSize  •  ${SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(item.downloadedAt))}",
                                color = SleekTextSecondary,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                }
            }

            // Quick actions line
            Divider(color = SleekBorderColor.copy(alpha = 0.4f))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Play action (Sleek dark purple pill button)
                    Button(
                        onClick = onPlayClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SleekPurpleDark,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(50),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("PLAY", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    // Share action (Sleek outline border pill button)
                    OutlinedButton(
                        onClick = onShareClick,
                        border = BorderStroke(1.dp, SleekBorderColor),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = SleekTextSecondary),
                        shape = RoundedCornerShape(50),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("SHARE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                // Delete action
                IconButton(
                    onClick = { showDeleteConfirmDialog = true },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = CrimsonFailure,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }

    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("Delete downloaded file?", color = SleekTextPrimary, fontWeight = FontWeight.Bold) },
            text = { Text("This will permanently delete this video from your device storage and library cache.", color = SleekTextSecondary) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirmDialog = false
                        onDeleteClick()
                    }
                ) {
                    Text("DELETE", color = CrimsonFailure, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("CANCEL", color = SleekTextSecondary, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color.White,
            titleContentColor = SleekTextPrimary,
            textContentColor = SleekTextSecondary
        )
    }
}

@Composable
fun SettingsDialog(
    downloadCount: Int,
    onClearAllDownloads: () -> Unit,
    onDismiss: () -> Unit
) {
    var showConfirmClear by remember { mutableStateOf(false) }

    if (showConfirmClear) {
        AlertDialog(
            onDismissRequest = { showConfirmClear = false },
            title = { Text("Delete Library & Files?", fontWeight = FontWeight.Bold, color = SleekTextPrimary) },
            text = { Text("This will permanently delete all $downloadCount downloaded videos and media from your device memory. This action cannot be undone.", color = SleekTextSecondary) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showConfirmClear = false
                        onClearAllDownloads()
                        onDismiss()
                    }
                ) {
                    Text("DELETE ALL", color = CrimsonFailure, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmClear = false }) {
                    Text("CANCEL", color = SleekTextSecondary, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color.White,
            titleContentColor = SleekTextPrimary,
            textContentColor = SleekTextSecondary,
            shape = RoundedCornerShape(24.dp)
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Settings, contentDescription = null, tint = SleekPurpleDark)
                Text("Settings & Info", fontWeight = FontWeight.Bold, color = SleekTextPrimary)
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                // About block
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("ABOUT TUBESTREAM", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = SleekPurpleDark))
                    Text(
                        "TubeStream is a high-speed local downloader client powered by the robust YouTube Downloader java ecosystem. Segment extraction downloads stream parts simultaneously to maximize your bandwidth speed.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SleekTextSecondary
                    )
                }

                HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.4f))

                // Storage location block
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("STORAGE PATH", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = SleekPurpleDark))
                    Text(
                        "Files are saved privately to guarantee playback security:\nInternal Storage/Android/data/\ncom.example/files/Movies/",
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                        color = SleekTextSecondary
                    )
                }

                HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.4f))

                // Diagnostics
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("LIBRARY SIZE", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = SleekPurpleDark))
                        Text("$downloadCount items cached", style = MaterialTheme.typography.bodyMedium, color = SleekTextSecondary)
                    }
                    if (downloadCount > 0) {
                        Button(
                            onClick = { showConfirmClear = true },
                            colors = ButtonDefaults.buttonColors(containerColor = CrimsonFailure, contentColor = Color.White),
                            shape = RoundedCornerShape(50),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("CLEAR ALL", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = onDismiss,
                colors = ButtonDefaults.textButtonColors(contentColor = SleekPurpleDark)
            ) {
                Text("DONE", fontWeight = FontWeight.Bold)
            }
        },
        containerColor = Color.White,
        titleContentColor = SleekTextPrimary,
        textContentColor = SleekTextSecondary,
        shape = RoundedCornerShape(24.dp)
    )
}

@Composable
fun VideoPlayerDialog(
    download: DownloadEntity,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = download.title,
                color = SleekTextPrimary,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.titleMedium
            )
        },
        text = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.ui.viewinterop.AndroidView(
                    factory = { ctx ->
                        android.widget.VideoView(ctx).apply {
                            setVideoPath(download.localPath)
                            val mediaController = android.widget.MediaController(ctx)
                            mediaController.setAnchorView(this)
                            setMediaController(mediaController)
                            setOnPreparedListener {
                                start()
                            }
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = onDismiss,
                colors = ButtonDefaults.textButtonColors(contentColor = SleekPurpleDark)
            ) {
                Text("CLOSE", fontWeight = FontWeight.Bold)
            }
        },
        containerColor = Color.White,
        titleContentColor = SleekTextPrimary,
        textContentColor = SleekTextSecondary,
        shape = RoundedCornerShape(24.dp)
    )
}

@Composable
fun YtdlpTab(
    viewModel: VideoDownloaderViewModel
) {
    val context = LocalContext.current
    
    val ytdlpLocalVersion by viewModel.ytdlpLocalVersion.collectAsStateWithLifecycle()
    val ytdlpOnlineVersion by viewModel.ytdlpOnlineVersion.collectAsStateWithLifecycle()
    val ytdlpVerificationStatus by viewModel.ytdlpVerificationStatus.collectAsStateWithLifecycle()
    val isYtdlpLoading by viewModel.isYtdlpLoading.collectAsStateWithLifecycle()
    val ytdlpProgress by viewModel.ytdlpProgress.collectAsStateWithLifecycle()

    // Setup Document Picker for raw uploads
    val systemUploadLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.openInputStream(it)?.use { inputStream ->
                    val bytes = inputStream.readBytes()
                    viewModel.uploadYtdlpBytes(bytes, context)
                }
            } catch (e: Exception) {
                Log.e("YtdlpTab", "Failed to upload file stream bytes.", e)
            }
        }
    }

    // Auto-run verification on compose startup so they immediately see status
    LaunchedEffect(Unit) {
        viewModel.verifyYtdlp(context)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Explanatory Card
        Card(
            colors = CardDefaults.cardColors(containerColor = SleekCard),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.5f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = SleekPurpleDark
                    )
                    Text(
                        text = "YT-DLP CLI Controller",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = SleekPurpleDark
                        )
                    )
                }
                Text(
                    text = "Manage and verify the yt-dlp core engine executable in the local sandboxed application environment. You can pull directly from GitHub or upload custom binary patches to secure the best playback performance.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SleekTextSecondary
                )
            }
        }

        // Diagnostics Card
        Card(
            colors = CardDefaults.cardColors(containerColor = SleekCard),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.5f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "ENGINE DIAGNOSTICS",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = SleekPurpleDark,
                        letterSpacing = 1.sp
                    )
                )

                // Online/Offline version rows
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Default GitHub Release", style = MaterialTheme.typography.titleSmall, color = SleekTextPrimary)
                        Text(ytdlpOnlineVersion, style = MaterialTheme.typography.bodyMedium, color = SleekTextSecondary)
                    }
                    Button(
                        onClick = { viewModel.fetchLatestYtdlpVersionOnline() },
                        colors = ButtonDefaults.buttonColors(containerColor = SleekPurpleDark, contentColor = Color.White),
                        shape = RoundedCornerShape(50)
                    ) {
                        Text("CHECK", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.2f))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Local Installed Version", style = MaterialTheme.typography.titleSmall, color = SleekTextPrimary)
                        Text(ytdlpLocalVersion, style = MaterialTheme.typography.bodyMedium, color = SleekTextSecondary)
                    }
                    Box(
                        modifier = Modifier
                            .background(
                                color = if (ytdlpLocalVersion.contains("Not") || ytdlpLocalVersion.isEmpty()) SleekPurpleLight.copy(alpha = 0.1f) else EmeraldSuccess.copy(alpha = 0.1f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = if (ytdlpLocalVersion.contains("Not") || ytdlpLocalVersion.isEmpty()) "PENDING" else "READY",
                            color = if (ytdlpLocalVersion.contains("Not") || ytdlpLocalVersion.isEmpty()) SleekPurpleDark else EmeraldSuccess,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Action Panel Card
        Card(
            colors = CardDefaults.cardColors(containerColor = SleekCard),
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, SleekBorderColor.copy(alpha = 0.5f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "CONTROLS & COMPILING",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = SleekPurpleDark,
                        letterSpacing = 1.sp
                    )
                )

                if (isYtdlpLoading) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        LinearProgressIndicator(
                            progress = { ytdlpProgress },
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                            color = SleekPurpleDark,
                            trackColor = SleekPurpleLight.copy(alpha = 0.3f)
                        )
                        Text(
                            text = String.format(Locale.getDefault(), "Processing: %.1f%%", ytdlpProgress * 100),
                            style = MaterialTheme.typography.bodySmall,
                            color = SleekTextSecondary
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { viewModel.downloadYtdlp(context) },
                        colors = ButtonDefaults.buttonColors(containerColor = SleekPurpleDark),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.weight(1f).testTag("download_ytdlp_btn"),
                        enabled = !isYtdlpLoading
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("DOWNLOAD", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        onClick = { systemUploadLauncher.launch("*/*") },
                        colors = ButtonDefaults.buttonColors(containerColor = SleekPurpleDark),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.weight(1f).testTag("upload_ytdlp_btn"),
                        enabled = !isYtdlpLoading
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("UPLOAD", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Button(
                    onClick = { viewModel.verifyYtdlp(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = SleekCardDark, contentColor = SleekPurpleDark),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().testTag("verify_ytdlp_btn"),
                    enabled = !isYtdlpLoading,
                    border = BorderStroke(1.dp, SleekPurpleLight)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Text("VERIFY & TEST ENVIRONMENT", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                // Dynamic Adaptive Pipeline Diagnostics Hud Panel
                val report = remember(context) { YtdlpPipelineManager.runDiagnostics(context) }
                Card(
                    colors = CardDefaults.cardColors(containerColor = SleekPurpleLight.copy(alpha = 0.08f)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                    border = BorderStroke(1.dp, SleekPurpleLight.copy(alpha = 0.2f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "ACTIVE PIPELINE STATE",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = SleekPurpleDark,
                                letterSpacing = 1.sp
                            )
                        )
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Selected Route:", style = MaterialTheme.typography.bodyMedium, color = SleekTextSecondary)
                            Box(
                                modifier = Modifier
                                    .background(SleekPurpleDark, shape = RoundedCornerShape(8.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = report.activeBackend.displayName.replace("Fallback 2: ", "").replace("Fallback 3: ", "").replace("Final Bypass: ", ""),
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        
                        HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.15f))
                        
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("CPU / Architecture:", style = MaterialTheme.typography.bodySmall, color = SleekTextSecondary)
                            Text(report.systemArchitecture.split("[").first().trim(), style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = SleekTextPrimary)
                        }
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Android OS Constraints:", style = MaterialTheme.typography.bodySmall, color = SleekTextSecondary)
                            Text("API ${report.sdkInt} (Android ${report.releaseVersion})", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = SleekTextPrimary)
                        }
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("SELinux / W^X restriction:", style = MaterialTheme.typography.bodySmall, color = SleekTextSecondary)
                            Text(
                                text = if (report.wExRestricted) "ELIMINATED VIA FAILSURGE" else "NONE",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                color = if (report.wExRestricted) Color(0xFFE53935) else Color(0xFF43A047)
                            )
                        }
                    }
                }

                HorizontalDivider(color = SleekBorderColor.copy(alpha = 0.2f))

                val customCommandInput by viewModel.customCommandInput.collectAsStateWithLifecycle()

                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "CUSTOM CLI TERMINAL RUNNER",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = SleekPurpleDark,
                            letterSpacing = 1.sp
                        )
                    )
                    OutlinedTextField(
                        value = customCommandInput,
                        onValueChange = { viewModel.updateCustomCommandInput(it) },
                        placeholder = { Text("e.g. --version or --help", color = SleekTextSecondary.copy(alpha = 0.6f)) },
                        leadingIcon = {
                            Text(
                                " ./yt-dlp ",
                                color = SleekPurpleDark,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(start = 12.dp)
                            )
                        },
                        textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                        modifier = Modifier.fillMaxWidth().testTag("custom_command_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = SleekTextPrimary,
                            unfocusedTextColor = SleekTextPrimary,
                            focusedBorderColor = SleekPurpleDark,
                            unfocusedBorderColor = SleekBorderColor,
                            focusedContainerColor = SleekCardDark,
                            unfocusedContainerColor = SleekCardDark
                        )
                    )
                    Button(
                        onClick = { viewModel.executeCustomYtdlpCommand(context) },
                        colors = ButtonDefaults.buttonColors(containerColor = SleekPurpleDark, contentColor = Color.White),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().testTag("run_custom_command_btn"),
                        enabled = !isYtdlpLoading
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("RUN CUSTOM COMMAND", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Terminal Console Logs output block
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "CONSOLE STDOUT / VERIFICATION OUTPUT",
                        color = Color(0xFF888888),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF333333), shape = RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "terminal",
                            color = Color(0xFF00FF00),
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                
                SelectionContainer {
                    Text(
                        text = ytdlpVerificationStatus,
                        color = Color(0xFFD4D4D4),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    )
                }
            }
        }
    }
}
