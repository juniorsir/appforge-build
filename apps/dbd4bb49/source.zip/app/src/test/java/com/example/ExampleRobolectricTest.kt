package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Downly", appName)
  }

  @Test
  fun testCloudBackupManifestSerializationAndValidation() {
      val playlists = listOf(
          com.example.ui.Playlist(
              id = "pl_1",
              name = "My Study List",
              description = "Lecture clips",
              createdAt = 1700000000000L,
              mediaIds = listOf("media_1", "media_2")
          )
      )

      val downloads = listOf(
          com.example.data.DownloadEntity(
              id = "media_1",
              title = "Kotlin Flow Deep Dive",
              author = "Android Team",
              durationText = "12:30",
              thumbnailUrl = "https://example.com/thumb.jpg",
              localPath = "/storage/emulated/0/media_1.mp4",
              fileSize = 52428800L,
              downloadedAt = 1700000000000L,
              isFavorite = true,
              isKept = true,
              isProtected = false
          )
      )

      val progress = listOf(
          com.example.data.PlaybackProgressEntity(
              mediaId = "media_1",
              mediaPath = "/storage/emulated/0/media_1.mp4",
              durationMs = 750000L,
              lastPositionMs = 300000L,
              lastPlayedTimestamp = 1700000100000L,
              isCompleted = false,
              completedTimestamp = 0L
          )
      )

      val markers = listOf(
          com.example.data.MediaMarkerEntity(
              id = 1L,
              mediaId = "media_1",
              positionMs = 120000L,
              note = "StateFlow vs SharedFlow - Key architectural difference",
              createdAt = 1700000050000L
          )
      )

      val preferences = com.example.backup.cloud.PreferencesBackupItem(
          autoCleanPeriod = "DAYS_30",
          keepFavorites = true,
          keepPlaylistItems = true,
          keepMarkedItems = true,
          onlyCleanWhenStorageLow = false
      )

      val manifest = com.example.backup.cloud.CloudBackupManifest.create(
          backupType = com.example.backup.cloud.BackupType.LIBRARY_ONLY,
          playlists = playlists,
          downloads = downloads,
          playbackProgress = progress,
          markers = markers,
          preferences = preferences
      )

      val json = manifest.toJsonString()
      assertNotNull(json)
      assertTrue(json.contains("Kotlin Flow Deep Dive"))
      assertTrue(json.contains("StateFlow vs SharedFlow"))

      val restoredManifest = com.example.backup.cloud.CloudBackupManifest.parseAndValidate(json)
      assertEquals(1, restoredManifest.version)
      assertEquals(com.example.backup.cloud.BackupType.LIBRARY_ONLY, restoredManifest.backupType)
      assertEquals(1, restoredManifest.playlists.size)
      assertEquals("My Study List", restoredManifest.playlists[0].name)
      assertEquals(listOf("media_1", "media_2"), restoredManifest.playlists[0].mediaIds)

      assertEquals(1, restoredManifest.media.size)
      assertEquals("media_1", restoredManifest.media[0].id)
      assertTrue(restoredManifest.media[0].isFavorite)
      assertTrue(restoredManifest.media[0].isKept)

      assertEquals(1, restoredManifest.playbackPositions.size)
      assertEquals(300000L, restoredManifest.playbackPositions[0].lastPositionMs)

      assertEquals(1, restoredManifest.markers.size)
      assertEquals("StateFlow vs SharedFlow - Key architectural difference", restoredManifest.markers[0].note)

      assertNotNull(restoredManifest.preferences)
      assertEquals("DAYS_30", restoredManifest.preferences?.autoCleanPeriod)
      assertTrue(restoredManifest.preferences?.keepFavorites == true)
  }

  @Test
  fun testThemePersistenceAndRestoration() {
      val context = ApplicationProvider.getApplicationContext<Context>()

      val customSettings = com.example.ui.theme.AppThemeSettings(
          themeMode = com.example.ui.theme.AppThemeMode.MIDNIGHT,
          accentPalette = com.example.ui.theme.AccentPalette.CYAN,
          customAccentColor = 0xFF00E5FF,
          gradientConfig = com.example.ui.theme.CustomGradientConfig(
              isEnabled = true,
              colorA = 0xFF00E5FF,
              colorB = 0xFF7C4DFF,
              intensity = 0.85f
          )
      )

      // Save
      com.example.ui.theme.ThemePreferencesManager.saveThemeSettings(context, customSettings)

      // Load
      val loaded = com.example.ui.theme.ThemePreferencesManager.loadThemeSettings(context)
      assertEquals(com.example.ui.theme.AppThemeMode.MIDNIGHT, loaded.themeMode)
      assertEquals(com.example.ui.theme.AccentPalette.CYAN, loaded.accentPalette)
      assertEquals(0xFF00E5FFL, loaded.customAccentColor)
      assertTrue(loaded.gradientConfig.isEnabled)
      assertEquals(0xFF00E5FFL, loaded.gradientConfig.colorA)
      assertEquals(0xFF7C4DFFL, loaded.gradientConfig.colorB)
      assertEquals(0.85f, loaded.gradientConfig.intensity, 0.01f)
  }

  @Test
  fun testPlayerGesturePersistenceAndRestoration() {
      val context = ApplicationProvider.getApplicationContext<Context>()

      var customSettings = com.example.player.gestures.PlayerGestureSettings()
      customSettings = customSettings.withAction(
          com.example.player.gestures.PlayerGesture.THREE_FINGER_TAP,
          com.example.player.gestures.PlayerGestureAction.MUTE_UNMUTE
      )
      customSettings = customSettings.withAction(
          com.example.player.gestures.PlayerGesture.TWO_FINGER_SWIPE_UP,
          com.example.player.gestures.PlayerGestureAction.SPEED_TOGGLE
      )
      customSettings = customSettings.withAction(
          com.example.player.gestures.PlayerGesture.LONG_PRESS,
          com.example.player.gestures.PlayerGestureAction.SCREENSHOT
      )
      customSettings = customSettings.withAction(
          com.example.player.gestures.PlayerGesture.LEFT_EDGE_SWIPE,
          com.example.player.gestures.PlayerGestureAction.SEEK_BACKWARD_10
      )

      // Save
      com.example.player.gestures.PlayerGesturePreferencesManager.saveSettings(context, customSettings)

      // Load and verify
      val loaded = com.example.player.gestures.PlayerGesturePreferencesManager.loadSettings(context)
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.PLAY_PAUSE,
          loaded.getActionFor(com.example.player.gestures.PlayerGesture.TWO_FINGER_DOUBLE_TAP)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.MUTE_UNMUTE,
          loaded.getActionFor(com.example.player.gestures.PlayerGesture.THREE_FINGER_TAP)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.SPEED_TOGGLE,
          loaded.getActionFor(com.example.player.gestures.PlayerGesture.TWO_FINGER_SWIPE_UP)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.SCREENSHOT,
          loaded.getActionFor(com.example.player.gestures.PlayerGesture.LONG_PRESS)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.SEEK_BACKWARD_10,
          loaded.getActionFor(com.example.player.gestures.PlayerGesture.LEFT_EDGE_SWIPE)
      )
      assertEquals(
          com.example.player.gestures.PlayerGestureAction.NONE,
          loaded.getActionFor(com.example.player.gestures.PlayerGesture.RIGHT_EDGE_SWIPE)
      )
  }

  @Test
  fun testMediaConversionRequestValidation() {
      val validRequest = com.example.media.operations.MediaConversionRequest(
          inputUri = android.net.Uri.parse("file:///data/local/tmp/test.mkv"),
          outputFile = java.io.File("/data/local/tmp/test.mp4"),
          videoCodec = "libx264",
          audioCodec = "aac",
          targetWidth = 1920,
          targetHeight = 1080,
          crf = 23,
          preset = "fast"
      )
      assertTrue(validRequest.validate().isSuccess)

      val invalidCodecRequest = validRequest.copy(videoCodec = "invalid_codec_name")
      assertTrue(invalidCodecRequest.validate().isFailure)

      val invalidCrfRequest = validRequest.copy(crf = 99)
      assertTrue(invalidCrfRequest.validate().isFailure)

      val invalidDimensionsRequest = validRequest.copy(targetWidth = -100)
      assertTrue(invalidDimensionsRequest.validate().isFailure)
  }

  @Test
  fun testPlaybackFallbackEvaluationLogic() {
      val directCompat = com.example.media.playback.PlaybackCompatibilityResult(
          strategy = com.example.media.playback.PlaybackStrategy.DIRECT_HARDWARE,
          reason = "Hardware acceleration available",
          containerFormat = "mp4",
          videoCodec = "h264",
          audioCodec = "aac"
      )
      assertEquals(com.example.media.playback.PlaybackStrategy.DIRECT_HARDWARE, directCompat.strategy)
      assertFalse(directCompat.requiresRemux)
      assertFalse(directCompat.requiresTranscode)

      val remuxCompat = com.example.media.playback.PlaybackCompatibilityResult(
          strategy = com.example.media.playback.PlaybackStrategy.REMUX_REQUIRED,
          reason = "Codecs compatible; remuxing to MP4",
          containerFormat = "avi",
          videoCodec = "h264",
          audioCodec = "mp3",
          requiresRemux = true
      )
      assertEquals(com.example.media.playback.PlaybackStrategy.REMUX_REQUIRED, remuxCompat.strategy)
      assertTrue(remuxCompat.requiresRemux)
  }

  @Test
  fun testFrpPreviewEngineStateAndCache() {
      com.example.media.preview.FrpPreviewEngine.clearCache()
      val sampleUri = android.net.Uri.parse("file:///data/local/tmp/test_preview.mp4")
      com.example.media.preview.FrpPreviewEngine.setActivePlaybackSource(sampleUri, "/data/local/tmp/test_preview.mp4")

      assertEquals(sampleUri, com.example.media.preview.FrpPreviewEngine.activePlaybackUri)
      assertEquals("/data/local/tmp/test_preview.mp4", com.example.media.preview.FrpPreviewEngine.activePlaybackPath)

      com.example.media.preview.FrpPreviewEngine.clearCache()
  }

  @Test
  fun testTemporaryMediaManagerLifecycle() {
      val context = ApplicationProvider.getApplicationContext<Context>()
      val tempFile = com.example.media.storage.TemporaryMediaManager.createTempFile(context, "test_", "mp4")
      assertTrue(tempFile.name.startsWith("test_"))
      assertTrue(tempFile.name.endsWith(".mp4"))

      tempFile.writeText("sample-media-test")
      assertTrue(tempFile.exists())

      val deleted = com.example.media.storage.TemporaryMediaManager.deleteSilently(tempFile)
      assertTrue(deleted)
      assertFalse(tempFile.exists())
  }

  @Test
  fun testFFmpegDiagnosticsReportFormatting() {
      val diag = com.example.media.ffmpeg.FFmpegDiagnostics(
          isAvailable = true,
          ffmpegVersion = "7.1",
          ffmpegKitVersion = "8.1.7",
          abi = "arm64-v8a",
          buildConfiguration = "enable-gpl",
          nativeLibraryLoaded = true,
          selfTestPassed = true,
          probeSelfTestPassed = true,
          registeredPackages = listOf("ffmpeg-kit-full")
      )
      val report = diag.toFormattedReport()
      assertTrue(report.contains("=== FFmpegKit Diagnostics Report ==="))
      assertTrue(report.contains("FFmpegKit Version: 8.1.7"))
      assertTrue(report.contains("Target ABI: arm64-v8a"))
      assertTrue(report.contains("FFmpeg Execution Self-Test: PASS"))
      assertTrue(report.contains("FFprobe Self-Test: PASS"))
  }
}
