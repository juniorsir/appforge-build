package com.example.ui
import android.content.Context
import com.example.media.DiagnosticsReportGenerator
import kotlinx.coroutines.runBlocking
import com.example.media.DefaultMediaEngine

fun testReport(context: Context) {
    runBlocking {
        val engine = DefaultMediaEngine(context)
        val workingReport = DiagnosticsReportGenerator.generateFullReport(
            context,
            engine,
            null,
            "test_working.mp4"
        )
        println(workingReport)
        val failingReport = DiagnosticsReportGenerator.generateFullReport(
            context,
            engine,
            "# PLAYBACK ANALYSIS\nFailure: DecoderInitializationException",
            "test_failing.mkv"
        )
        println(failingReport)
    }
}
