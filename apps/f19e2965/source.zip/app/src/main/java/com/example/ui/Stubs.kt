package com.example.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.media3.common.Format
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.TextUnit
import com.example.data.DownloadEntity
import java.io.File

val InstagramSunsetGradient = Brush.linearGradient(colors = listOf(Color.Red, Color.Yellow))

@Composable
fun FloatingPlayerOverlay(
    modifier: Modifier = Modifier,
    media: Any? = null,
    isFullscreen: Boolean = false,
    onToggleFullscreen: () -> Unit = {},
    analyzedVideo: Any? = null,
    onStreamFormat: ((VideoFormatUi) -> Unit)? = null,
    viewModel: Any? = null,
    onOpenAudioFxStudio: () -> Unit = {},
    onClose: () -> Unit = {}
) {}

@Composable
fun FluidIncognitoButton(
    modifier: Modifier = Modifier,
    isIncognitoMode: Boolean = false,
    onToggle: (Boolean) -> Unit = {},
    onClick: () -> Unit = {}
) {}

@Composable
fun MediaTrimmerDialog(
    modifier: Modifier = Modifier,
    state: Any? = null,
    onUpdateRange: (Any, Any) -> Unit = { _, _ -> },
    onPreview: () -> Unit = {},
    onExport: () -> Unit = {},
    onCancelExport: () -> Unit = {},
    onOpenExported: (DownloadEntity) -> Unit = {},
    onShareExported: (Any) -> Unit = {},
    onDismiss: () -> Unit = {}
) {}

@Composable
fun VideoCompressionDialog(
    modifier: Modifier = Modifier,
    state: Any? = null,
    onSelectPreset: (String) -> Unit = {},
    onUpdateCustomOptions: (Any?, Any?, Any?, Any?, Any?) -> Unit = { _, _, _, _, _ -> },
    onCompress: () -> Unit = {},
    onCancelCompress: () -> Unit = {},
    onOpenCompressed: (DownloadEntity) -> Unit = {},
    onShareCompressed: (Any) -> Unit = {},
    onDismiss: () -> Unit = {}
) {}

@Composable
fun AudioFxStudioModal(modifier: Modifier = Modifier, viewModel: Any? = null, onDismiss: () -> Unit = {}) {}

@Composable
fun BatchQueueManagerModal(modifier: Modifier = Modifier, viewModel: Any? = null, onDismiss: () -> Unit = {}) {}

@Composable
fun MetadataEditorModal(modifier: Modifier = Modifier, item: Any? = null, viewModel: Any? = null, onDismiss: () -> Unit = {}) {}

@Composable
fun DownloadSchedulerModal(
    modifier: Modifier = Modifier,
    viewModel: Any? = null,
    videoTitle: Any? = null,
    videoUrl: Any? = null,
    formatQuality: Any? = null,
    formatExt: Any? = null,
    onDismiss: () -> Unit = {}
) {}

@Composable
fun AddToPlaylistModal(
    modifier: Modifier = Modifier,
    item: Any? = null,
    viewModel: Any? = null,
    onCreateNewRequest: () -> Unit = {},
    onDismiss: () -> Unit = {}
) {}

@Composable
fun CreatePlaylistModal(modifier: Modifier = Modifier, viewModel: Any? = null, onDismiss: () -> Unit = {}) {}

@Composable
fun TermsAndConditionsDialog(modifier: Modifier = Modifier, onDismiss: () -> Unit = {}) {}

@Composable
fun PrivacyPolicyDialog(modifier: Modifier = Modifier, onDismiss: () -> Unit = {}) {}

@Composable
fun YouTubeBackgroundMiniPlayerBar(
    modifier: Modifier = Modifier,
    media: Any? = null,
    isPlaying: Boolean = false,
    currentPosMs: Long = 0L,
    durationMs: Long = 0L,
    onTogglePlay: () -> Unit = {},
    onSeekRelative: (Any) -> Unit = {},
    onOpenFullPlayer: () -> Unit = {},
    onClose: () -> Unit = {}
) {}

@Composable
fun LiquidGlassIcon(
    modifier: Modifier = Modifier,
    imageVector: Any? = null,
    contentDescription: String? = null,
    isSelected: Boolean = false,
    containerSize: Any? = null,
    size: Any? = null,
    onClick: () -> Unit = {}
) {}

@Composable
fun CrazyAnimationOrb(modifier: Modifier = Modifier) {}

class CarouselItem(val url: String = "")

@Composable
fun CoverflowCarousel(
    modifier: Modifier = Modifier,
    items: List<Any> = emptyList(),
    onItemSelected: (Any) -> Unit = {},
    onPlayClick: (CarouselItem) -> Unit = {},
    onDownloadClick: (CarouselItem) -> Unit = {}
) {}

@Composable
fun SleepTimerDialog(
    modifier: Modifier = Modifier,
    initialMinutes: Int = 0,
    onSet: (Int) -> Unit = {},
    onDismiss: () -> Unit = {},
    currentMinutes: Int = 0,
    currentSecondsRemaining: Int = 0,
    onSelectMinutes: (Int) -> Unit = {}
) {}

@Composable
fun InstagramIcon(modifier: Modifier = Modifier, useGradient: Boolean = false) {}

class ExoPlayerAudioFxEngine(exoPlayer: Any? = null, viewModel: Any? = null) {
    fun toggleVocalReduction() {}
}

fun calculateVideoColorMatrix(
    brightness: Float = 0f,
    contrast: Float = 0f,
    saturation: Float = 0f,
    gamma: Float = 0f,
    sharpness: Float = 0f,
    temperature: Float = 0f,
    highlights: Float = 0f,
    shadows: Float = 0f,
    vibrance: Float = 0f,
    tint: Float = 0f
): FloatArray = FloatArray(20)

fun openInstagramProfile(context: Any, profileUrl: String) {}

fun isAudioFormat(format: Any?): Boolean = false
fun hasAudio(format: Any?): Boolean = false
val Any?.acodec: String get() = ""
val Any?.sizeBytes: Long get() = 0L
val Any?.downloadUrl: String get() = ""
val Int.responsiveSp: TextUnit get() = this.sp
val Float.responsiveSp: TextUnit get() = this.sp
fun responsiveSp(min: Float, max: Float): TextUnit = ((min + max) / 2f).sp
val Any?.type: String get() = ""
