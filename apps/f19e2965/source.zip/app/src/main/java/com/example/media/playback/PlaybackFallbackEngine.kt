package com.example.media.playback

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.media.DecoderCapabilityManager
import com.example.media.operations.MediaConversionRequest
import com.example.media.operations.MediaConverter
import com.example.media.operations.RemuxEngine
import com.example.media.probe.MediaProbeEngine
import com.example.media.ffmpeg.FFmpegProgress
import com.example.media.ffmpeg.FFmpegState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import java.io.File

object PlaybackFallbackEngine {
    private const val TAG = "PlaybackFallbackEngine"

    suspend fun evaluatePlaybackStrategy(context: Context, uri: Uri): PlaybackCompatibilityResult = withContext(Dispatchers.IO) {
        val probeResult = MediaProbeEngine.probeMedia(context, uri)
        if (probeResult.isFailure) {
            return@withContext PlaybackCompatibilityResult(
                strategy = PlaybackStrategy.DIRECT_HARDWARE,
                reason = "Probe skipped; attempting default ExoPlayer hardware playback",
                containerFormat = "unknown",
                videoCodec = "unknown",
                audioCodec = "unknown"
            )
        }

        val probeInfo = probeResult.getOrThrow()
        val format = probeInfo.format.lowercase()
        val video = probeInfo.primaryVideo
        val audio = probeInfo.primaryAudio

        val videoCodec = video?.codec?.lowercase() ?: "none"
        val audioCodec = audio?.codec?.lowercase() ?: "none"

        Log.d(TAG, "Evaluating playback: format=$format, video=$videoCodec, audio=$audioCodec")

        // 1. Check if container is natively friendly to ExoPlayer/Media3
        val isStandardContainer = format.contains("mp4") ||
                format.contains("matroska") ||
                format.contains("webm") ||
                format.contains("mov") ||
                format.contains("mp3") ||
                format.contains("aac") ||
                format.contains("ogg") ||
                format.contains("flac") ||
                format.contains("mpegts")

        // 2. Check if video codec is supported by Android MediaCodec hardware
        // Android supports H.264, HEVC, VP8, VP9, AV1 natively on most modern devices.
        val isStandardVideoCodec = videoCodec in setOf("h264", "avc1", "hevc", "h265", "vp8", "vp9", "av01", "av1", "none")
        
        // 3. Check if audio codec is supported. AC3/EAC3 often lack hardware support or Media3 FFmpeg extension depending on build.
        val isStandardAudioCodec = audioCodec in setOf("aac", "mp3", "opus", "vorbis", "flac", "pcm_s16le", "pcm_s24le", "alac", "none")

        if (isStandardContainer && isStandardVideoCodec && isStandardAudioCodec) {
            return@withContext PlaybackCompatibilityResult(
                strategy = PlaybackStrategy.DIRECT_HARDWARE,
                reason = "Hardware acceleration available for container and codecs",
                containerFormat = format,
                videoCodec = videoCodec,
                audioCodec = audioCodec
            )
        }

        if (isStandardVideoCodec && isStandardAudioCodec) {
            return@withContext PlaybackCompatibilityResult(
                strategy = PlaybackStrategy.REMUX_REQUIRED,
                reason = "Codecs are hardware-compatible; remuxing to MP4 container for instant hardware playback",
                containerFormat = format,
                videoCodec = videoCodec,
                audioCodec = audioCodec,
                requiresRemux = true
            )
        }

        return@withContext PlaybackCompatibilityResult(
            strategy = PlaybackStrategy.TRANSCODE_REQUIRED,
            reason = "Unsupported codec ($videoCodec / $audioCodec); requires targeted transcode",
            containerFormat = format,
            videoCodec = videoCodec,
            audioCodec = audioCodec,
            requiresTranscode = true
        )
    }

    suspend fun resolveAndProcessFallback(
        context: Context,
        uri: Uri,
        outputFile: File,
        forceRemuxOnly: Boolean = false
    ): Flow<FFmpegProgress> {
        val strategy = evaluatePlaybackStrategy(context, uri)

        if (strategy.strategy == PlaybackStrategy.REMUX_REQUIRED || forceRemuxOnly) {
            Log.i(TAG, "Fallback: Performing remux to MP4 for ${uri.path}")
            return RemuxEngine.remuxToMp4(context, uri, outputFile)
        }

        // Targeted Transcode handling
        val videoCodecTarget = if (strategy.videoCodec in setOf("h264", "hevc", "vp9", "av1", "none")) "copy" else "libx264"
        val audioCodecTarget = if (strategy.audioCodec in setOf("aac", "mp3", "opus", "flac", "none")) "copy" else "aac"
        
        // Avoid transcoding if everything is copy (just remux)
        if (videoCodecTarget == "copy" && audioCodecTarget == "copy") {
            Log.i(TAG, "Fallback: Codecs are copyable despite transcode strategy. Remuxing to MP4 for ${uri.path}")
            return RemuxEngine.remuxToMp4(context, uri, outputFile)
        }

        Log.i(TAG, "Fallback: Targeted transcode to MP4. Video=$videoCodecTarget, Audio=$audioCodecTarget")
        val request = MediaConversionRequest(
            inputUri = uri,
            outputFile = outputFile,
            videoCodec = if (videoCodecTarget == "copy") "copy" else "libx264",
            audioCodec = if (audioCodecTarget == "copy") "copy" else "aac",
            preset = "fast",
            crf = 23,
            fastStart = true
        )

        return MediaConverter.convertMedia(context, request)
    }
}
