package com.example.media

import android.content.Context
import android.os.Build
import com.example.media.ffmpeg.FFmpegEngine

object DiagnosticsReportGenerator {
    suspend fun generateFullReport(
        context: Context,
        mediaEngine: MediaEngine,
        playerError: String?,
        mediaLocalPath: String
    ): String {
        val sb = StringBuilder()
        sb.appendLine("=== DIAGNOSTIC REPORT ===")
        sb.appendLine()
        
        sb.appendLine("[DEVICE INFO]")
        sb.appendLine("Manufacturer: ${Build.MANUFACTURER}")
        sb.appendLine("Model: ${Build.MODEL}")
        sb.appendLine("Android API: ${Build.VERSION.SDK_INT}")
        sb.appendLine("Supported ABIs: ${Build.SUPPORTED_ABIS.joinToString(", ")}")
        sb.appendLine()
        
        sb.appendLine("[FFMPEG INFO]")
        try {
            val diag = FFmpegEngine.getDiagnostics()
            sb.appendLine(diag.toFormattedReport())
        } catch (e: Exception) {
            sb.appendLine("FFmpeg Info Error: ${e.message}")
        }
        sb.appendLine()
        
        sb.appendLine("[MEDIA PROBE INFO]")
        // Redact paths
        val redactedPath = if (mediaLocalPath.contains("/")) mediaLocalPath.substringAfterLast("/") else mediaLocalPath
        sb.appendLine("File: (Redacted path)/$redactedPath")
        
        // Use MediaProbeEngine
        try {
            val uri = android.net.Uri.parse(if(mediaLocalPath.startsWith("http")) mediaLocalPath else "file://$mediaLocalPath")
            val probeResult = com.example.media.probe.MediaProbeEngine.probeMedia(context, uri)
            val info = probeResult.getOrNull()
            if (info != null) {
                sb.appendLine(info.toFormattedReport())
            } else {
                sb.appendLine("Probe Failed: ${probeResult.exceptionOrNull()?.message}")
            }
        } catch (e: Exception) {
             sb.appendLine("Probe Exception: ${e.message}")
        }
        sb.appendLine()
        
        if (!playerError.isNullOrBlank()) {
            sb.appendLine("[PLAYBACK FAILURE]")
            sb.appendLine(playerError)
        } else {
            sb.appendLine("[PLAYBACK STATUS]")
            sb.appendLine("No ExoPlayer exception recorded. Player is in a working state or has not crashed.")
        }
        
        return sb.toString().trimEnd()
    }
}
