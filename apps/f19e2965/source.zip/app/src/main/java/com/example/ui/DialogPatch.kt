package com.example.ui
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import android.content.ClipboardManager
import android.content.ClipData
import android.content.Context
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import com.example.media.DiagnosticsReportGenerator
import android.widget.Toast

@Composable
fun PlayerErrorDialog(
    showDialog: Boolean,
    onDismiss: () -> Unit,
    playerError: String?,
    mediaLocalPath: String,
    mediaEngine: com.example.media.MediaEngine
) {
    if (showDialog) {
        val context = LocalContext.current
        val scope = rememberCoroutineScope()
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Playback Error") },
            text = { Text(playerError ?: "An unknown error occurred.") },
            confirmButton = {
                TextButton(onClick = onDismiss) { Text("OK") }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        scope.launch {
                            try {
                                val report = DiagnosticsReportGenerator.generateFullReport(
                                    context = context,
                                    mediaEngine = mediaEngine,
                                    playerError = playerError,
                                    mediaLocalPath = mediaLocalPath
                                )
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Codec Report", report)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "Codec report copied", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "Failed to copy report", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                ) {
                    Text("COPY CODEC REPORT")
                }
            }
        )
    }
}
