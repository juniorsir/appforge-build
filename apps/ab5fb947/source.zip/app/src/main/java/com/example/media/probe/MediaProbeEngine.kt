package com.example.media.probe

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.media.storage.MediaUriResolver
import com.example.media.storage.TemporaryMediaManager
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

object MediaProbeEngine {
    private const val TAG = "MediaProbeEngine"

    suspend fun probeMedia(context: Context, uri: Uri): Result<MediaProbeInfo> = withContext(Dispatchers.IO) {
        var resolvedSource = MediaUriResolver.resolveUriForFFmpeg(context, uri)
        if (resolvedSource == null) {
            return@withContext Result.failure(IllegalArgumentException("Could not resolve URI for probing: $uri"))
        }

        try {
            val pathOrSaf = resolvedSource.pathOrSaf
            Log.d(TAG, "Probing media at: $pathOrSaf")

            val session = FFprobeKit.getMediaInformation(pathOrSaf)
            val returnCode = session.returnCode
            val mediaInfo = session.mediaInformation

            if (!ReturnCode.isSuccess(returnCode) || mediaInfo == null) {
                val errorMsg = session.failStackTrace ?: session.allLogsAsString ?: "FFprobe returned error code: ${returnCode?.value}"
                Log.e(TAG, "FFprobe inspection failed: $errorMsg")
                return@withContext Result.failure(IllegalStateException("FFprobe failed to inspect media: $errorMsg"))
            }

            val format = mediaInfo.format ?: "unknown"
            val formatLongName = mediaInfo.longFormat
            val durationSec = mediaInfo.duration?.toDoubleOrNull() ?: 0.0
            val durationMs = (durationSec * 1000.0).toLong()
            val sizeBytes = mediaInfo.size?.toLongOrNull() ?: resolvedSource.sizeBytes
            val overallBitrate = mediaInfo.bitrate?.toLongOrNull() ?: 0L

            val videoStreams = mutableListOf<VideoStreamInfo>()
            val audioStreams = mutableListOf<AudioStreamInfo>()
            val subtitleStreams = mutableListOf<SubtitleStreamInfo>()
            val otherStreams = mutableListOf<OtherStreamInfo>()

            val streams = mediaInfo.streams ?: emptyList()
            for (stream in streams) {
                val type = stream.type?.lowercase()
                val index = stream.index?.toInt() ?: 0
                val codec = stream.codec ?: "unknown"
                val allProps = stream.allProperties
                val codecLong = allProps?.optString("codec_long_name") ?: stream.codec
                val codecTag = allProps?.optString("codec_tag_string")

                when (type) {
                    "video" -> {
                        val width = stream.width?.toInt() ?: 0
                        val height = stream.height?.toInt() ?: 0
                        val rFrameRate = stream.realFrameRate ?: stream.averageFrameRate ?: "0/1"
                        val fps = parseFpsFraction(rFrameRate)
                        val avgFps = parseFpsFraction(stream.averageFrameRate ?: "0/1")
                        val bitrate = stream.bitrate?.toLongOrNull() ?: 0L
                        val pixelFormat = allProps?.optString("pix_fmt")
                        val profile = allProps?.optString("profile")
                        val level = allProps?.optString("level")
                        val colorSpace = allProps?.optString("color_space")
                        val colorPrimaries = allProps?.optString("color_primaries")
                        val transferCharacteristics = allProps?.optString("color_transfer")
                        val streamDurationSec = allProps?.optString("duration")?.toDoubleOrNull() ?: 0.0
                        val streamDurationMs = (streamDurationSec * 1000.0).toLong()
                        val rotation = parseRotation(allProps)
                        
                        val tags = allProps?.optJSONObject("tags")
                        val lang = tags?.optString("language", "und") ?: "und"

                        val disposition = allProps?.optJSONObject("disposition")
                        val isDefault = disposition?.optInt("default") == 1
                        val isForced = disposition?.optInt("forced") == 1

                        videoStreams.add(
                            VideoStreamInfo(
                                index = index,
                                codec = codec,
                                codecLongName = codecLong,
                                codecTag = codecTag,
                                profile = profile,
                                level = level,
                                width = width,
                                height = height,
                                frameRate = fps,
                                averageFrameRate = avgFps,
                                bitrate = bitrate,
                                durationMs = streamDurationMs,
                                pixelFormat = pixelFormat,
                                colorSpace = colorSpace,
                                colorPrimaries = colorPrimaries,
                                transferCharacteristics = transferCharacteristics,
                                rotation = rotation,
                                language = lang,
                                isDefault = isDefault,
                                isForced = isForced
                            )
                        )
                    }
                    "audio" -> {
                        val sampleRate = stream.sampleRate?.toIntOrNull() ?: 0
                        val channels = allProps?.optInt("channels") ?: 2
                        val channelLayout = allProps?.optString("channel_layout")
                        val sampleFormat = allProps?.optString("sample_fmt")
                        val profile = allProps?.optString("profile")
                        val bitrate = stream.bitrate?.toLongOrNull() ?: 0L
                        val streamDurationSec = allProps?.optString("duration")?.toDoubleOrNull() ?: 0.0
                        val streamDurationMs = (streamDurationSec * 1000.0).toLong()
                        
                        val tags = allProps?.optJSONObject("tags")
                        val lang = tags?.optString("language", "und") ?: "und"
                        val title = tags?.optString("title")
                        
                        val disposition = allProps?.optJSONObject("disposition")
                        val isDefault = disposition?.optInt("default") == 1
                        val isForced = disposition?.optInt("forced") == 1

                        audioStreams.add(
                            AudioStreamInfo(
                                index = index,
                                codec = codec,
                                codecLongName = codecLong,
                                codecTag = codecTag,
                                profile = profile,
                                sampleRate = sampleRate,
                                channels = channels,
                                channelLayout = channelLayout,
                                sampleFormat = sampleFormat,
                                bitrate = bitrate,
                                durationMs = streamDurationMs,
                                language = lang,
                                title = title,
                                isDefault = isDefault,
                                isForced = isForced
                            )
                        )
                    }
                    "subtitle" -> {
                        val tags = allProps?.optJSONObject("tags")
                        val lang = tags?.optString("language", "und") ?: "und"
                        val title = tags?.optString("title")
                        
                        val disposition = allProps?.optJSONObject("disposition")
                        val isDefault = disposition?.optInt("default") == 1
                        val isForced = disposition?.optInt("forced") == 1

                        subtitleStreams.add(
                            SubtitleStreamInfo(
                                index = index,
                                codec = codec,
                                language = lang,
                                title = title,
                                isDefault = isDefault,
                                isForced = isForced
                            )
                        )
                    }
                    else -> {
                        otherStreams.add(
                            OtherStreamInfo(
                                index = index,
                                type = type ?: "unknown",
                                codec = codec
                            )
                        )
                    }
                }
            }

            val metadataTags = mutableMapOf<String, String>()
            val tagsObj = mediaInfo.allProperties?.optJSONObject("format")?.optJSONObject("tags")
            if (tagsObj != null) {
                val keys = tagsObj.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    metadataTags[key] = tagsObj.optString(key)
                }
            }

            val probeInfo = MediaProbeInfo(
                pathOrUri = uri.toString(),
                format = format,
                formatLongName = formatLongName,
                durationMs = durationMs,
                sizeBytes = sizeBytes,
                overallBitrate = overallBitrate,
                streamCount = streams.size,
                videoStreams = videoStreams,
                audioStreams = audioStreams,
                subtitleStreams = subtitleStreams,
                otherStreams = otherStreams,
                metadataTags = metadataTags,
                rawProperties = mediaInfo.allProperties?.toString()
            )

            evaluateCapabilities(probeInfo)
            Log.i(TAG, "Successfully probed media: ${probeInfo.format}, ${videoStreams.size} video, ${audioStreams.size} audio")
            Result.success(probeInfo)

        } catch (e: Exception) {
            Log.e(TAG, "Exception during media probe: ${e.message}", e)
            Result.failure(e)
        } finally {
            if (resolvedSource?.isTemporaryFile == true) {
                TemporaryMediaManager.deleteSilently(resolvedSource.temporaryFile)
            }
        }
    }

    private fun parseFpsFraction(fraction: String): Float {
        return try {
            if (fraction.contains("/")) {
                val parts = fraction.split("/")
                val num = parts[0].toFloat()
                val den = parts[1].toFloat()
                if (den > 0) num / den else 0f
            } else {
                fraction.toFloat()
            }
        } catch (e: Exception) {
            0f
        }
    }

    private fun parseRotation(properties: JSONObject?): Int {
        if (properties == null) return 0
        try {
            val tags = properties.optJSONObject("tags")
            val rotate = tags?.optString("rotate")
            if (!rotate.isNullOrBlank()) {
                return rotate.toIntOrNull() ?: 0
            }

            val sideData = properties.optJSONArray("side_data_list")
            if (sideData != null) {
                for (i in 0 until sideData.length()) {
                    val item = sideData.optJSONObject(i)
                    val rotation = item?.optInt("rotation")
                    if (rotation != null && rotation != 0) return rotation
                }
            }
        } catch (_: Exception) {}
        return 0
    }

    private fun mapCodecToMimeType(codec: String): String {
        return when (codec.lowercase()) {
            "h264", "avc" -> "video/avc"
            "hevc", "h265" -> "video/hevc"
            "av1" -> "video/av01"
            "vp9" -> "video/x-vnd.on2.vp9"
            "vp8" -> "video/x-vnd.on2.vp8"
            "mpeg4" -> "video/mp4v-es"
            "aac" -> "audio/mp4a-latm"
            "opus" -> "audio/opus"
            "ac3" -> "audio/ac3"
            "eac3" -> "audio/eac3"
            "flac" -> "audio/flac"
            "vorbis" -> "audio/vorbis"
            "mp3" -> "audio/mpeg"
            else -> "unknown"
        }
    }

    private fun evaluateCapabilities(probeInfo: MediaProbeInfo) {
        try {
            val decoders = com.example.media.DecoderCapabilityManager.getSystemDecoders()
            val codecList = android.media.MediaCodecList(android.media.MediaCodecList.ALL_CODECS)

            for (v in probeInfo.videoStreams) {
                val mime = mapCodecToMimeType(v.codec)
                if (mime == "unknown") continue
                
                var format: android.media.MediaFormat? = null
                try {
                    format = android.media.MediaFormat.createVideoFormat(mime, v.width.takeIf { it > 0 } ?: 1920, v.height.takeIf { it > 0 } ?: 1080)
                    if (v.frameRate > 0f) {
                        format.setFloat(android.media.MediaFormat.KEY_FRAME_RATE, v.frameRate)
                    }
                } catch (_: Exception) {}

                val decoderName = try {
                    if (format != null) codecList.findDecoderForFormat(format) else null
                } catch (_: Exception) { null }

                val candidates = decoders.filter { it.mimeType.equals(mime, ignoreCase = true) }
                val actualDecoder = if (decoderName != null) {
                    candidates.firstOrNull { it.name == decoderName } ?: candidates.firstOrNull()
                } else {
                    candidates.firstOrNull { it.classification == com.example.media.DecoderClassification.HARDWARE } ?: candidates.firstOrNull()
                }

                if (actualDecoder != null) {
                    val isSupported = decoderName != null
                    v.decoderEvaluation = DecoderEvaluation(
                        mimeType = mime,
                        deviceDecoderName = actualDecoder.name,
                        type = actualDecoder.classification.name,
                        isSupported = isSupported,
                        isProfileLevelSupported = if (isSupported) true else null,
                        isResolutionSupported = if (isSupported) true else null,
                        isHardware = actualDecoder.classification == com.example.media.DecoderClassification.HARDWARE
                    )
                } else {
                    v.decoderEvaluation = DecoderEvaluation(
                        mimeType = mime,
                        isSupported = false
                    )
                }
            }

            for (a in probeInfo.audioStreams) {
                val mime = mapCodecToMimeType(a.codec)
                if (mime == "unknown") continue

                var format: android.media.MediaFormat? = null
                try {
                    format = android.media.MediaFormat.createAudioFormat(mime, a.sampleRate.takeIf { it > 0 } ?: 48000, a.channels.takeIf { it > 0 } ?: 2)
                } catch (_: Exception) {}

                val decoderName = try {
                    if (format != null) codecList.findDecoderForFormat(format) else null
                } catch (_: Exception) { null }

                val candidates = decoders.filter { it.mimeType.equals(mime, ignoreCase = true) }
                val actualDecoder = if (decoderName != null) {
                    candidates.firstOrNull { it.name == decoderName } ?: candidates.firstOrNull()
                } else {
                    candidates.firstOrNull { it.classification == com.example.media.DecoderClassification.HARDWARE } ?: candidates.firstOrNull()
                }

                if (actualDecoder != null) {
                    a.decoderEvaluation = DecoderEvaluation(
                        mimeType = mime,
                        deviceDecoderName = actualDecoder.name,
                        type = actualDecoder.classification.name,
                        isSupported = decoderName != null,
                        isHardware = actualDecoder.classification == com.example.media.DecoderClassification.HARDWARE
                    )
                } else {
                    a.decoderEvaluation = DecoderEvaluation(
                        mimeType = mime,
                        isSupported = false
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error evaluating decoder capabilities: ${e.message}")
        }
    }
}
