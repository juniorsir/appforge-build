
package com.example.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import android.content.Context
import com.example.data.DownloadEntity

val InstagramSunsetGradient = Brush.linearGradient(colors = listOf(Color.Red, Color.Yellow))
val activeGradient = InstagramSunsetGradient

@Composable fun FloatingPlayerOverlay(media: Any? = null, isFullscreen: Boolean = false, onToggleFullscreen: () -> Unit = {}, onClose: () -> Unit = {}, onStreamFormat: (Any?) -> Unit = {}, analyzedVideo: Any? = null, viewModel: Any? = null, onOpenAudioFxStudio: () -> Unit = {}) {}
@Composable fun FluidIncognitoButton(isIncognito: Boolean = false, isIncognitoMode: Boolean = false, onToggle: (Boolean) -> Unit = {}) {}
@Composable fun MediaTrimmerDialog(media: Any? = null, state: Any? = null, onUpdateRange: (Long, Long) -> Unit = { a, b -> }, onPreview: () -> Unit = {}, onExport: () -> Unit = {}, onCancelExport: () -> Unit = {}, onOpenExported: (DownloadEntity) -> Unit = {}, onShareExported: (String) -> Unit = {}, onDismiss: () -> Unit = {}) {}
@Composable fun VideoCompressionDialog(media: Any? = null, state: Any? = null, onSelectPreset: (String) -> Unit = {}, onUpdateCustomOptions: (Int, Int, Int, Int, Int) -> Unit = { a, b, c, d, e -> }, onCompress: () -> Unit = {}, onCancelCompress: () -> Unit = {}, onOpenCompressed: (DownloadEntity) -> Unit = {}, onShareCompressed: (String) -> Unit = {}, onDismiss: () -> Unit = {}) {}
@Composable fun AudioFxStudioModal(viewModel: Any? = null, onDismiss: () -> Unit = {}) {}
@Composable fun BatchQueueManagerModal(viewModel: Any? = null, onDismiss: () -> Unit = {}) {}
@Composable fun MetadataEditorModal(item: Any? = null, viewModel: Any? = null, onDismiss: () -> Unit = {}) {}
@Composable fun DownloadSchedulerModal(viewModel: Any? = null, videoTitle: Any? = null, videoUrl: Any? = null, formatQuality: Any? = null, formatExt: Any? = null, onDismiss: () -> Unit = {}) {}
@Composable fun AddToPlaylistModal(item: Any? = null, viewModel: Any? = null, onCreateNewRequest: () -> Unit = {}, onDismiss: () -> Unit = {}) {}
@Composable fun CreatePlaylistModal(viewModel: Any? = null, onDismiss: () -> Unit = {}) {}
@Composable fun TermsAndConditionsDialog(onDismiss: () -> Unit = {}) {}
@Composable fun PrivacyPolicyDialog(onDismiss: () -> Unit = {}) {}
fun openInstagramProfile(context: Context, username: String) {}
@Composable fun InstagramIcon(modifier: Modifier = Modifier, useGradient: Boolean = false) {}
@Composable fun YouTubeBackgroundMiniPlayerBar(media: Any? = null, isPlaying: Boolean = false, currentPosMs: Long = 0L, durationMs: Long = 0L, onTogglePlay: () -> Unit = {}, onSeekRelative: (Long) -> Unit = {}, onOpenFullPlayer: () -> Unit = {}, onClose: () -> Unit = {}, modifier: Modifier = Modifier) {}
@Composable fun LiquidGlassIcon(imageVector: Any?, contentDescription: String?, isSelected: Boolean = false, containerSize: Dp = 0.dp, size: Dp = 0.dp, onClick: () -> Unit = {}) {}
@Composable fun CrazyAnimationOrb() {}
@Composable fun CoverflowCarousel(onPlayClick: (Any?) -> Unit = {}, onDownloadClick: (Any?) -> Unit = {}) {}
@Composable fun SleepTimerDialog(currentMinutes: Int = 0, currentSecondsRemaining: Int = 0, onSelectMinutes: (Int) -> Unit = {}, onDismiss: () -> Unit = {}) {}
@Composable fun ExoPlayerAudioFxEngine(exoPlayer: Any? = null, viewModel: Any? = null) {}
fun calculateVideoColorMatrix(brightness: Float, contrast: Float, saturation: Float, gamma: Float, sharpness: Float, temperature: Float, highlights: Float, shadows: Float, vibrance: Float, tint: Float): android.graphics.ColorMatrix = android.graphics.ColorMatrix()
fun responsiveSp(min: Float, max: Float): TextUnit = min.sp

fun isAudioFormat(format: Any?): Boolean = false
val Any?.acodec: String get() = ""
val Any?.hasAudio: Boolean get() = false
val Any?.type: String get() = ""
val Any?.audioBitrateKbps: Int get() = 0
val Any?.sizeBytes: Long get() = 0L
val Any?.downloadUrl: String get() = ""
val Any?.videoUrl: String get() = ""
val Any?.url: String get() = ""

