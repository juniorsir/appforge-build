package com.example

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.data.AppDatabase
import com.example.data.DownloadEntity
import com.example.ui.ActiveDownloadTask
import com.example.ui.DownloadStatus
import com.example.ui.YtdlpPipelineManager
import kotlinx.coroutines.*
import java.io.File
import java.util.Locale

class DownloadForegroundService : Service() {
    private val CHANNEL_ID = "DownloadChannel"
    private val COMPLETED_CHANNEL_ID = "CompletedChannel"
    private val NOTIFICATION_ID = 2026 // unique notification ID
    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)
    
    // Track active runs in service
    private var activeTaskCount = 0

    companion object {
        const val ACTION_START_DOWNLOAD = "ACTION_START_DOWNLOAD"
        const val ACTION_CONVERT_MP3 = "ACTION_CONVERT_MP3"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_START = "ACTION_START"
        
        fun stopService(context: Context) {
            val intent = Intent(context, DownloadForegroundService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        try {
            val initialNotification = createNotification("Downly Background Engine Ready", -1f)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    initialNotification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                )
            } else {
                startForeground(NOTIFICATION_ID, initialNotification)
            }
        } catch (e: Throwable) {
            Log.w("DownloadForegroundService", "startForeground in onCreate warning: ${e.message}")
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) return START_NOT_STICKY
        
        try {
            when (intent.action) {
                ACTION_STOP -> {
                    if (activeTaskCount <= 0) {
                        try {
                            stopForeground(STOP_FOREGROUND_REMOVE)
                        } catch (_: Throwable) {}
                        stopSelf()
                    }
                }
                ACTION_START -> {
                    val title = intent.getStringExtra("title") ?: "Downloading media..."
                    updateForegroundNotification(title)
                }
                ACTION_START_DOWNLOAD -> {
                    activeTaskCount++
                    val idWithFormat = intent.getStringExtra("idWithFormat") ?: ""
                    val videoTitle = intent.getStringExtra("video_title") ?: "Media Download"
                    
                    // Show notification immediately to meet foreground service criteria
                    updateForegroundNotification("Downloading: $videoTitle")
                    
                    val db = AppDatabase.getDatabase(applicationContext)
                    
                    val job = serviceScope.launch(Dispatchers.IO) {
                        try {
                            runDownloadTask(intent, db)
                        } catch (e: Throwable) {
                            Log.e("DownloadForegroundService", "runDownloadTask error: ${e.message}", e)
                        }
                    }
                    if (idWithFormat.isNotEmpty()) {
                        DownloadManager.registerJob(idWithFormat, job)
                    }
                }
                ACTION_CONVERT_MP3 -> {
                    activeTaskCount++
                    val itemTitle = intent.getStringExtra("item_title") ?: "Converting audio..."
                    val targetExt = intent.getStringExtra("target_ext") ?: "mp3"
                    updateForegroundNotification("Converting to ${targetExt.uppercase()}: $itemTitle")
                    
                    val db = AppDatabase.getDatabase(applicationContext)
                    serviceScope.launch(Dispatchers.IO) {
                        try {
                            runConversionTask(intent, db)
                        } catch (e: Throwable) {
                            Log.e("DownloadForegroundService", "runConversionTask error: ${e.message}", e)
                        }
                    }
                }
            }
        } catch (e: Throwable) {
            Log.e("DownloadForegroundService", "onStartCommand exception: ${e.message}", e)
        }
        return START_NOT_STICKY
    }

    private fun isPersistentNotificationEnabled(): Boolean {
        val prefs = applicationContext.getSharedPreferences("꒯ꄲꅐꋊ꒒ꌦPrefs", Context.MODE_PRIVATE)
        return prefs.getBoolean("persistentForegroundNotifications", true)
    }

    private fun updateForegroundNotification(text: String, progress: Float = -1f) {
        try {
            val notification = createNotification(text, progress)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            if (!isPersistentNotificationEnabled() && activeTaskCount <= 0) {
                try {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                } catch (_: Throwable) {}
            }
        } catch (e: Throwable) {
            Log.w("DownloadForegroundService", "updateForegroundNotification warning: ${e.message}")
        }
    }

    private suspend fun runDownloadTask(intent: Intent, db: AppDatabase) {
        val idWithFormat = intent.getStringExtra("idWithFormat") ?: ""
        val videoTitle = intent.getStringExtra("video_title") ?: ""
        val videoId = intent.getStringExtra("video_id") ?: ""
        val videoAuthor = intent.getStringExtra("video_author") ?: ""
        val videoDuration = intent.getStringExtra("video_duration") ?: ""
        val videoThumb = intent.getStringExtra("video_thumb") ?: ""
        val originalUrl = intent.getStringExtra("video_url") ?: ""
        val formatId = intent.getStringExtra("format_id") ?: ""
        val formatExt = intent.getStringExtra("format_ext") ?: ""
        val formatSize = intent.getLongExtra("format_size", 0L)
        val formatQuality = intent.getStringExtra("format_quality") ?: ""
        val formatType = intent.getStringExtra("format_type") ?: ""
        val formatHasAudio = intent.getBooleanExtra("format_has_audio", false)
        val usePublicDownloads = intent.getBooleanExtra("use_public_downloads", false)
        val audioFormatId = intent.getStringExtra("audio_format_id") ?: ""
        val customFolder = intent.getStringExtra("custom_folder") ?: ""

        val directory = com.example.util.DeviceCompatHelper.getSafeDownloadDirectory(
            context = applicationContext,
            customFolder = customFolder.ifEmpty { null },
            preferPublic = usePublicDownloads
        )

        // Sanitize filename
        val sanitizedTitle = videoTitle.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        val isAudioOnly = formatType == "audio"
        val isVideoOnly = !isAudioOnly && (!formatHasAudio || formatType == "video_only" || formatType == "adaptive")
        val actualIsMuxNeeded = isVideoOnly
        val finalExt = if (actualIsMuxNeeded) "mkv" else formatExt
        val fileName = "${sanitizedTitle}_$formatQuality.$finalExt"
        val file = File(directory, fileName)

        DownloadManager.addLog("📁 Target Output File: \"${file.absolutePath}\"")

        // Storage Safety Check before proceeding
        val storageCheck = com.example.download.recovery.SmartDownloadRecoveryManager.checkStorageAvailable(applicationContext, formatSize, directory)
        if (!storageCheck.isSufficient) {
            val errMsg = storageCheck.message ?: "Not enough storage to resume this download."
            DownloadManager.addLog("❌ [Storage Safety] $errMsg")
            val failedTask = ActiveDownloadTask(
                id = idWithFormat,
                title = videoTitle,
                progress = 0f,
                speedText = "Storage Full",
                downloadedBytes = 0,
                totalBytes = formatSize,
                status = DownloadStatus.FAILED,
                ext = formatExt,
                error = errMsg,
                originalUrl = originalUrl,
                formatId = formatId,
                formatQuality = formatQuality,
                author = videoAuthor,
                durationText = videoDuration,
                thumbnailUrl = videoThumb
            )
            DownloadManager.updateActiveDownloads(DownloadManager.activeDownloads.value + (idWithFormat to failedTask))
            updateForegroundNotification("Failed: Insufficient storage")
            activeTaskCount = (activeTaskCount - 1).coerceAtLeast(0)
            return
        }

        // Persist in-flight download entity for Crash / Restart Recovery
        val inFlightRecord = DownloadEntity(
            id = idWithFormat,
            title = videoTitle,
            author = videoAuthor,
            durationText = videoDuration,
            thumbnailUrl = videoThumb,
            localPath = file.absolutePath,
            fileSize = if (file.exists()) file.length() else 0L,
            downloadedAt = System.currentTimeMillis(),
            originalUrl = originalUrl,
            formatId = formatId,
            formatQuality = formatQuality,
            formatExt = finalExt,
            expectedSize = formatSize,
            downloadStatus = "DOWNLOADING",
            statusMessage = "Downloading...",
            isAudioOnly = isAudioOnly
        )
        db.downloadDao().insertDownload(inFlightRecord)

        try {
            if (com.example.util.BatteryOptimizationManager.shouldPauseNewDownload(formatSize)) {
                val batteryInfo = com.example.util.BatteryOptimizationManager.batteryInfo.value
                val reason = if (batteryInfo.isLowBattery) {
                    "Paused: Battery Low (${batteryInfo.batteryPercentage}%)"
                } else {
                    "Paused: Device Not Charging"
                }
                DownloadManager.addLog("⚡ [Battery Optimizer] Auto-paused large download \"$videoTitle\" (${formatSize / (1024 * 1024)}MB): $reason")
                val pausedTask = ActiveDownloadTask(
                    id = idWithFormat,
                    title = videoTitle,
                    progress = 0f,
                    speedText = reason,
                    downloadedBytes = 0,
                    totalBytes = formatSize,
                    status = DownloadStatus.PAUSED,
                    ext = formatExt,
                    originalUrl = originalUrl,
                    formatId = formatId,
                    formatQuality = formatQuality,
                    author = videoAuthor,
                    durationText = videoDuration,
                    thumbnailUrl = videoThumb
                )
                DownloadManager.updateActiveDownloads(DownloadManager.activeDownloads.value + (idWithFormat to pausedTask))
                updateForegroundNotification("$reason: $videoTitle")
                activeTaskCount = (activeTaskCount - 1).coerceAtLeast(0)
                return
            }

            if (originalUrl.isNotEmpty()) {
                DownloadManager.addLog("🚀 [DownloadForegroundService] Submitting target request natively to JNI libraries...")
                val formatOption = buildRobustFormatOption(
                    formatId = formatId,
                    formatQuality = formatQuality,
                    audioFormatId = audioFormatId,
                    isAudioOnly = isAudioOnly,
                    actualIsMuxNeeded = actualIsMuxNeeded
                )

                val targetHeight = parseTargetHeight(formatQuality, formatId)
                val reqQualityLog = if (formatQuality.isNotBlank()) formatQuality else if (targetHeight != null) "${targetHeight}p" else "best"
                val selVideoLog = if (isAudioOnly) "none (audio only)" else if (targetHeight != null) "${targetHeight}p (or best available <= ${targetHeight}p)" else if (formatId.isNotBlank()) formatId else "best available"
                val selAudioLog = if (isAudioOnly) (if (formatId.isNotBlank()) formatId else "best available") else if (audioFormatId.isNotBlank()) audioFormatId else "best available"

                DownloadManager.addLog("📊 [Format Selector] Final selection details:")
                DownloadManager.addLog("Requested quality: $reqQualityLog")
                DownloadManager.addLog("Selected video: $selVideoLog")
                DownloadManager.addLog("Selected audio: $selAudioLog")

                val progressCallback: (Float, Long, String) -> Unit = { progress, etaInSeconds, line ->
                    if (com.example.util.BatteryOptimizationManager.shouldPauseNewDownload(formatSize)) {
                        val batteryInfo = com.example.util.BatteryOptimizationManager.batteryInfo.value
                        val reason = if (batteryInfo.isLowBattery) "Battery Low (${batteryInfo.batteryPercentage}%)" else "Device Not Charging"
                        DownloadManager.addLog("⚡ [Battery Optimizer] Active download \"$videoTitle\" paused in-flight: $reason")
                        DownloadManager.pauseDownload(idWithFormat, "Paused ($reason)")
                        throw CancellationException("Download paused by Battery Optimizer: $reason")
                    }
                    val percent = progress / 100f
                    val task = DownloadManager.activeDownloads.value[idWithFormat]
                    if (task != null) {
                        val etaFormatted = if (etaInSeconds > 0) " (ETA ${etaInSeconds}s)" else ""
                        val speedText = String.format(Locale.getDefault(), "Downloading: %.1f%% %s", progress, etaFormatted)
                        
                        // Update shared state
                        val updatedMap = DownloadManager.activeDownloads.value + (idWithFormat to task.copy(
                            progress = percent,
                            speedText = speedText,
                            status = DownloadStatus.DOWNLOADING,
                            downloadedBytes = (formatSize * percent).toLong(),
                            totalBytes = formatSize,
                            originalUrl = originalUrl,
                            formatId = formatId,
                            formatQuality = formatQuality,
                            author = videoAuthor,
                            durationText = videoDuration,
                            thumbnailUrl = videoThumb
                        ))
                        DownloadManager.updateActiveDownloads(updatedMap)
                        
                        // Live update notification progress
                        updateForegroundNotification("Downloading: $videoTitle", progress)
                    }
                }
                
                try {
                    YtdlpPipelineManager.downloadUrlWithNative(
                        context = applicationContext,
                        url = originalUrl,
                        formatId = formatOption,
                        outputFile = file,
                        onProgress = progressCallback
                    )
                    DownloadManager.addLog("🟢 [DownloadForegroundService] Native JNI execute session finished successfully.")
                } catch (e: Throwable) {
                    if (e is CancellationException) throw e

                    val errMessage = e.localizedMessage ?: e.message ?: ""
                    val isFormatUnavailable = errMessage.contains("Requested format is not available", ignoreCase = true) ||
                            errMessage.contains("format is not available", ignoreCase = true) ||
                            errMessage.contains("No video formats found", ignoreCase = true)

                    val safeFallback = if (isAudioOnly) "bestaudio/best" else "bestvideo+bestaudio/best"

                    if (isFormatUnavailable && formatOption != safeFallback) {
                        DownloadManager.addLog("⚠️ Requested format specifier ($formatOption) unavailable. Attempting safe fallback ($safeFallback)...")
                        try {
                            YtdlpPipelineManager.downloadUrlWithNative(
                                context = applicationContext,
                                url = originalUrl,
                                formatId = safeFallback,
                                outputFile = file,
                                onProgress = progressCallback
                            )
                            DownloadManager.addLog("🟢 [DownloadForegroundService] Safe fallback execution completed successfully.")
                        } catch (fallbackErr: Throwable) {
                            if (fallbackErr is CancellationException) throw fallbackErr
                            val finalErrMsg = "No compatible downloadable format exists for this media item: ${fallbackErr.localizedMessage ?: fallbackErr.message}"
                            DownloadManager.addLog("❌ [Format Selector] $finalErrMsg")
                            throw Exception(finalErrMsg)
                        }
                    } else {
                        DownloadManager.addLog("❌ [DownloadForegroundService] Native execution interrupted: ${e.localizedMessage}")
                        val currentLen = if (file.exists()) file.length() else 0L
                        val isRecoverable = currentLen > 0L && originalUrl.isNotBlank()
                        val fallbackStatus = if (isRecoverable) DownloadStatus.RECOVERABLE else DownloadStatus.INCOMPLETE
                        val fallbackStatusStr = if (isRecoverable) "RECOVERABLE" else "INCOMPLETE"
                        val msg = if (isRecoverable) "Interrupted ($currentLen bytes)" else (e.localizedMessage ?: "Interrupted")

                        val interruptedTask = ActiveDownloadTask(
                            id = idWithFormat,
                            title = videoTitle,
                            progress = if (formatSize > 0) (currentLen.toFloat() / formatSize).coerceIn(0f, 1f) else 0f,
                            speedText = if (isRecoverable) "Recoverable" else "Incomplete",
                            downloadedBytes = currentLen,
                            totalBytes = formatSize,
                            status = fallbackStatus,
                            ext = finalExt,
                            error = e.localizedMessage,
                            originalUrl = originalUrl,
                            formatId = formatId,
                            formatQuality = formatQuality,
                            author = videoAuthor,
                            durationText = videoDuration,
                            thumbnailUrl = videoThumb
                        )
                        DownloadManager.updateActiveDownloads(DownloadManager.activeDownloads.value + (idWithFormat to interruptedTask))

                        val interruptedEntity = inFlightRecord.copy(
                            fileSize = currentLen,
                            downloadStatus = fallbackStatusStr,
                            statusMessage = msg
                        )
                        db.downloadDao().insertDownload(interruptedEntity)
                        updateForegroundNotification("Interrupted: $videoTitle")
                        activeTaskCount = (activeTaskCount - 1).coerceAtLeast(0)
                        return
                    }
                }
            }

            // Perform Smart File Validation before marking as COMPLETED
            val fileSizeFinal = file.length()
            val validation = com.example.download.recovery.DownloadValidator.validateFile(file, formatSize)

            if (validation !is com.example.download.recovery.DownloadValidator.ValidationResult.Valid) {
                val validationStatus = when (validation) {
                    is com.example.download.recovery.DownloadValidator.ValidationResult.Incomplete -> DownloadStatus.INCOMPLETE
                    is com.example.download.recovery.DownloadValidator.ValidationResult.Corrupted -> DownloadStatus.CORRUPTED
                    is com.example.download.recovery.DownloadValidator.ValidationResult.ZeroByte -> DownloadStatus.INCOMPLETE
                    is com.example.download.recovery.DownloadValidator.ValidationResult.MissingFile -> DownloadStatus.FAILED
                    else -> DownloadStatus.INCOMPLETE
                }
                val validationStatusStr = validationStatus.name
                val validationMsg = when (validation) {
                    is com.example.download.recovery.DownloadValidator.ValidationResult.Corrupted -> validation.reason
                    is com.example.download.recovery.DownloadValidator.ValidationResult.Incomplete -> "Incomplete file"
                    is com.example.download.recovery.DownloadValidator.ValidationResult.ZeroByte -> "0-byte file"
                    else -> "Validation failed"
                }

                DownloadManager.addLog("⚠️ Validation failed ($validationStatusStr): $validationMsg")

                val incompleteTask = ActiveDownloadTask(
                    id = idWithFormat,
                    title = videoTitle,
                    progress = if (formatSize > 0) (fileSizeFinal.toFloat() / formatSize).coerceIn(0f, 1f) else 0f,
                    speedText = validationStatusStr,
                    downloadedBytes = fileSizeFinal,
                    totalBytes = formatSize,
                    status = validationStatus,
                    ext = finalExt,
                    error = validationMsg,
                    originalUrl = originalUrl,
                    formatId = formatId,
                    formatQuality = formatQuality,
                    author = videoAuthor,
                    durationText = videoDuration,
                    thumbnailUrl = videoThumb
                )
                DownloadManager.updateActiveDownloads(DownloadManager.activeDownloads.value + (idWithFormat to incompleteTask))

                val incompleteRecord = inFlightRecord.copy(
                    fileSize = fileSizeFinal,
                    downloadStatus = validationStatusStr,
                    statusMessage = validationMsg
                )
                db.downloadDao().insertDownload(incompleteRecord)
                return
            }

            DownloadManager.addLog("✔ Stream transfer complete and validated: $fileSizeFinal bytes.")
            val completedTask = ActiveDownloadTask(
                id = idWithFormat,
                title = videoTitle,
                progress = 1f,
                speedText = "Finished",
                downloadedBytes = fileSizeFinal,
                totalBytes = fileSizeFinal,
                status = DownloadStatus.COMPLETED,
                ext = finalExt,
                originalUrl = originalUrl,
                formatId = formatId,
                formatQuality = formatQuality,
                author = videoAuthor,
                durationText = videoDuration,
                thumbnailUrl = videoThumb
            )
            DownloadManager.updateActiveDownloads(DownloadManager.activeDownloads.value + (idWithFormat to completedTask))

            // Extract and store local thumbnail for offline display
            val finalThumb = com.example.data.MediaThumbnailExtractor.getOrExtractThumbnail(
                applicationContext,
                file.absolutePath,
                idWithFormat,
                videoThumb
            )

            // Add details to persistent Room History
            val downloadRecord = DownloadEntity(
                id = idWithFormat,
                title = videoTitle,
                author = videoAuthor,
                durationText = videoDuration,
                thumbnailUrl = if (finalThumb.isNotBlank()) finalThumb else videoThumb,
                localPath = file.absolutePath,
                fileSize = fileSizeFinal,
                downloadedAt = System.currentTimeMillis(),
                originalUrl = originalUrl,
                formatId = formatId,
                formatQuality = formatQuality,
                formatExt = finalExt,
                expectedSize = formatSize,
                downloadStatus = "COMPLETED",
                statusMessage = "Verified Complete",
                isAudioOnly = isAudioOnly
            )
            
            val isAudioCodec = listOf("mp3", "m4a", "aac", "wav", "flac", "opus", "ogg").contains(formatExt.lowercase()) ||
                               listOf("MP3", "M4A", "AAC", "WAV", "FLAC", "OPUS", "OGG").contains(formatQuality.uppercase())

            if (isAudioCodec) {
                val targetExt = if (listOf("mp3", "m4a", "aac", "wav", "flac", "opus", "ogg").contains(formatExt.lowercase())) {
                    formatExt.lowercase()
                } else if (listOf("MP3", "M4A", "AAC", "WAV", "FLAC", "OPUS", "OGG").contains(formatQuality.uppercase())) {
                    formatQuality.lowercase()
                } else {
                    "mp3"
                }

                DownloadManager.addLog("🎵 Post-download ${targetExt.uppercase()} auto-conversion started for: $videoTitle")
                serviceScope.launch(Dispatchers.IO) {
                    val conversionIntent = Intent().apply {
                        putExtra("item_id", idWithFormat)
                        putExtra("item_title", videoTitle)
                        putExtra("item_author", videoAuthor)
                        putExtra("item_duration", videoDuration)
                        putExtra("item_thumb", videoThumb)
                        putExtra("item_path", file.absolutePath)
                        putExtra("target_ext", targetExt)
                        putExtra("delete_source", true)
                    }
                    runConversionTask(conversionIntent, db)
                }
            } else {
                db.downloadDao().insertDownload(downloadRecord)
                DownloadManager.addLog("🎉 Record successfully written to SQLite Database history.")
                showDownloadCompleteNotification(videoTitle, isAudio = false)
                try {
                    android.media.MediaScannerConnection.scanFile(
                        applicationContext,
                        arrayOf(file.absolutePath),
                        null
                    ) { path, uri ->
                        DownloadManager.addLog("📺 MediaScanner indexed download video file: $path -> $uri")
                    }
                } catch (scannerEx: Exception) {
                    DownloadManager.addLog("⚠️ MediaScanner failed: ${scannerEx.localizedMessage}")
                }
            }
            
            // Automatically clear active download card from list 2 seconds after completion
            serviceScope.launch {
                delay(2000)
                DownloadManager.removeActiveTask(idWithFormat)
            }

        } catch (ce: CancellationException) {
            DownloadManager.addLog("⚠️ Stream transfer was explicitly cancelled by user.")
            try {
                if (file.exists()) {
                    file.delete()
                }
            } catch (e: Exception) {
                DownloadManager.addLog("⚠️ Failed clean deletion of incomplete caching chunks: ${e.message}")
            }
            DownloadManager.removeActiveTask(idWithFormat)
        } catch (e: Throwable) {
            val errMsg = e.localizedMessage ?: e.javaClass.simpleName ?: "Failed to completely stream video chunk buffers."
            DownloadManager.addLog("❌ Download failed: $errMsg")
            DownloadManager.updateActiveDownloads(DownloadManager.activeDownloads.value + (idWithFormat to ActiveDownloadTask(
                id = idWithFormat,
                title = videoTitle,
                progress = 0f,
                speedText = "Failed",
                downloadedBytes = 0,
                totalBytes = formatSize,
                status = DownloadStatus.FAILED,
                ext = formatExt,
                error = errMsg
            )))
        } finally {
            decrementTaskCount()
        }
    }

    private suspend fun runConversionTask(intent: Intent, db: AppDatabase) {
        val itemId = intent.getStringExtra("item_id") ?: ""
        val itemTitle = intent.getStringExtra("item_title") ?: "Audio"
        val itemAuthor = intent.getStringExtra("item_author") ?: ""
        val itemDuration = intent.getStringExtra("item_duration") ?: ""
        val itemThumb = intent.getStringExtra("item_thumb") ?: ""
        val itemPath = intent.getStringExtra("item_path") ?: ""
        val targetExt = (intent.getStringExtra("target_ext") ?: "mp3").lowercase()

        try {
            val inputFile = File(itemPath)
            if (!inputFile.exists()) {
                DownloadManager.addLog("❌ Source file not found for conversion: ${inputFile.name}")
                return
            }
            
            val downloadsDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "꒯ꄲꅐꋊ꒒ꌦ")
            if (!downloadsDir.exists()) downloadsDir.mkdirs()
            
            val titleEscaped = itemTitle.replace(Regex("[^a-zA-Z0-9.\\-]"), "_")
            val outputFile = File(downloadsDir, "${titleEscaped}_audio.${targetExt}")

            DownloadManager.addLog("🎵 Starting ${targetExt.uppercase()} extraction for: $itemTitle")
            
            val args = when (targetExt) {
                "mp3" -> arrayOf(
                    "-y",
                    "-i", inputFile.absolutePath,
                    "-vn",
                    "-acodec", "libmp3lame",
                    "-q:a", "2",
                    outputFile.absolutePath
                )
                "aac" -> arrayOf(
                    "-y",
                    "-i", inputFile.absolutePath,
                    "-vn",
                    "-acodec", "aac",
                    "-b:a", "192k",
                    outputFile.absolutePath
                )
                "m4a" -> arrayOf(
                    "-y",
                    "-i", inputFile.absolutePath,
                    "-vn",
                    "-acodec", "aac",
                    "-b:a", "192k",
                    outputFile.absolutePath
                )
                "opus" -> arrayOf(
                    "-y",
                    "-i", inputFile.absolutePath,
                    "-vn",
                    "-acodec", "libopus",
                    "-b:a", "128k",
                    outputFile.absolutePath
                )
                "wav" -> arrayOf(
                    "-y",
                    "-i", inputFile.absolutePath,
                    "-vn",
                    "-acodec", "pcm_s16le",
                    outputFile.absolutePath
                )
                "flac" -> arrayOf(
                    "-y",
                    "-i", inputFile.absolutePath,
                    "-vn",
                    "-acodec", "flac",
                    outputFile.absolutePath
                )
                "ogg" -> arrayOf(
                    "-y",
                    "-i", inputFile.absolutePath,
                    "-vn",
                    "-acodec", "libvorbis",
                    "-q:a", "4",
                    outputFile.absolutePath
                )
                else -> arrayOf(
                    "-y",
                    "-i", inputFile.absolutePath,
                    "-vn",
                    "-c:a", "copy",
                    outputFile.absolutePath
                )
            }

            YtdlpPipelineManager.init(applicationContext)
            
            // Invoke FFmpeg via our secure and robust reflection wrapper
            try {
                DownloadManager.addLog("⚡ Executing Native FFmpeg JNI conversion to ${targetExt.uppercase()}...")
                executeFFmpeg(args)
                DownloadManager.addLog("⚡ Native FFmpeg execution command returned.")
            } catch (ffmpegEx: Exception) {
                DownloadManager.addLog("❌ Primary FFmpeg execution failed: ${ffmpegEx.localizedMessage}")
            }
            
            if (outputFile.exists() && outputFile.length() > 0) {
                DownloadManager.addLog("✅ ${targetExt.uppercase()} extracted successfully: ${outputFile.name}")
                if (intent.getBooleanExtra("delete_source", false)) {
                    inputFile.delete()
                    DownloadManager.addLog("🗑 Original raw cached file deleted to save storage: ${inputFile.name}")
                }
                val convId = "conv_${System.currentTimeMillis()}"
                val convThumb = com.example.data.MediaThumbnailExtractor.getOrExtractThumbnail(
                    applicationContext,
                    outputFile.absolutePath,
                    convId,
                    itemThumb
                )
                val newEntity = DownloadEntity(
                    id = convId,
                    title = "$itemTitle (${targetExt.uppercase()})",
                    author = itemAuthor,
                    durationText = itemDuration,
                    thumbnailUrl = if (convThumb.isNotBlank()) convThumb else itemThumb,
                    localPath = outputFile.absolutePath,
                    fileSize = outputFile.length(),
                    downloadedAt = System.currentTimeMillis()
                )
                db.downloadDao().insertDownload(newEntity)
                showDownloadCompleteNotification(itemTitle, isAudio = true)
                try {
                    android.media.MediaScannerConnection.scanFile(
                        applicationContext,
                        arrayOf(outputFile.absolutePath),
                        null
                    ) { path, uri ->
                        DownloadManager.addLog("🎵 MediaScanner indexed converted audio file: $path -> $uri")
                    }
                } catch (scannerEx: Exception) {
                    DownloadManager.addLog("⚠️ MediaScanner failed for conversion: ${scannerEx.localizedMessage}")
                }
            } else {
                DownloadManager.addLog("🔴 FFmpeg ${targetExt.uppercase()} Extraction failed. Trying generic copy to file as last resort...")
                // General stream copy to native/original audio format as fallback
                val fallbackFile = File(downloadsDir, "${titleEscaped}_audio.m4a")
                val fallbackArgs = arrayOf(
                    "-y",
                    "-i", inputFile.absolutePath,
                    "-vn",
                    "-c:a", "copy",
                    fallbackFile.absolutePath
                )
                try {
                    DownloadManager.addLog("⚡ Executing fallback AAC copy command...")
                    executeFFmpeg(fallbackArgs)
                } catch (e: Exception) {
                    DownloadManager.addLog("❌ Fallback conversion failed: ${e.localizedMessage}")
                }
                
                if (fallbackFile.exists() && fallbackFile.length() > 0) {
                    DownloadManager.addLog("✅ Conversion fallback (M4A stream copy) succeeded.")
                    if (intent.getBooleanExtra("delete_source", false)) {
                        inputFile.delete()
                        DownloadManager.addLog("🗑 Original raw cached file deleted to save storage: ${inputFile.name}")
                    }
                    val convId = "conv_${System.currentTimeMillis()}"
                    val convThumb = com.example.data.MediaThumbnailExtractor.getOrExtractThumbnail(
                        applicationContext,
                        fallbackFile.absolutePath,
                        convId,
                        itemThumb
                    )
                    val newEntity = DownloadEntity(
                        id = convId,
                        title = "$itemTitle (Audio M4A Fallback)",
                        author = itemAuthor,
                        durationText = itemDuration,
                        thumbnailUrl = if (convThumb.isNotBlank()) convThumb else itemThumb,
                        localPath = fallbackFile.absolutePath,
                        fileSize = fallbackFile.length(),
                        downloadedAt = System.currentTimeMillis()
                    )
                    db.downloadDao().insertDownload(newEntity)
                    showDownloadCompleteNotification(itemTitle, isAudio = true)
                    try {
                        android.media.MediaScannerConnection.scanFile(
                            applicationContext,
                            arrayOf(fallbackFile.absolutePath),
                            null
                        ) { path, uri ->
                            DownloadManager.addLog("🎵 MediaScanner indexed fallback audio file: $path -> $uri")
                        }
                    } catch (scannerEx: Exception) {
                        DownloadManager.addLog("⚠️ MediaScanner failed for fallback: ${scannerEx.localizedMessage}")
                    }
                } else {
                    DownloadManager.addLog("🔴 Audio Extraction fallback failed completely.")
                }
            }
        } catch (e: Exception) {
            DownloadManager.addLog("💀 Convert Audio Error: ${e.message}")
        } finally {
            decrementTaskCount()
        }
    }

    @Synchronized
    private fun decrementTaskCount() {
        try {
            activeTaskCount = maxOf(0, activeTaskCount - 1)
            if (activeTaskCount == 0) {
                try {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                } catch (_: Throwable) {}
                stopSelf()
            } else {
                if (isPersistentNotificationEnabled()) {
                    val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    notificationManager.notify(NOTIFICATION_ID, createNotification("$activeTaskCount media tasks active background...", -1f))
                } else {
                    try {
                        stopForeground(STOP_FOREGROUND_REMOVE)
                    } catch (_: Throwable) {}
                }
            }
        } catch (e: Throwable) {
            Log.w("DownloadForegroundService", "decrementTaskCount error: ${e.message}")
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
    }

    private fun triggerCompletionHaptic() {
        try {
            val prefs = applicationContext.getSharedPreferences("꒯ꄲꅐꋊ꒒ꌦPrefs", Context.MODE_PRIVATE)
            if (!prefs.getBoolean("enableHapticFeedback", true)) return

            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? android.os.VibratorManager
                vibratorManager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
            }

            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val timings = longArrayOf(0, 50, 80, 50)
                    val amplitudes = intArrayOf(0, 255, 0, 255)
                    vibrator.vibrate(android.os.VibrationEffect.createWaveform(timings, amplitudes, -1))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(120)
                }
            }
        } catch (_: Exception) {}
    }

    private fun showDownloadCompleteNotification(title: String, isAudio: Boolean = false) {
        try {
            triggerCompletionHaptic()
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            val pendingIntent = PendingIntent.getActivity(
                this, (System.currentTimeMillis() % 100000).toInt(), intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            
            val contentText = if (isAudio) {
                "Audio extraction completed successfully!"
            } else {
                "Video downloaded successfully!"
            }
            
            val builder = NotificationCompat.Builder(this, COMPLETED_CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(contentText)
                .setSmallIcon(R.drawable.ic_download_modern)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(Notification.DEFAULT_ALL)
                
            notificationManager.notify((System.currentTimeMillis() % 100000).toInt(), builder.build())
        } catch (e: Throwable) {
            DownloadManager.addLog("⚠️ Notification display notice: ${e.localizedMessage}")
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID,
                "Download Service Channel",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps downloads running in the background securely"
            }
            
            val completedChannel = NotificationChannel(
                COMPLETED_CHANNEL_ID,
                "Completed Downloads",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Alerts when a download has completed successfully"
            }
            
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(serviceChannel)
            manager?.createNotificationChannel(completedChannel)
        }
    }

    private fun createNotification(contentText: String, progress: Float): Notification {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Downly Background Engine")
            .setContentText(contentText)
            .setSmallIcon(R.drawable.ic_download_modern)
            .setOngoing(true)
            .setContentIntent(pendingIntent)

        if (progress >= 0f) {
            builder.setProgress(100, progress.toInt(), false)
        } else {
            builder.setProgress(0, 0, true) // indeterminate state
        }

        return builder.build()
    }

    private suspend fun executeFFmpeg(args: Array<String>) {
        try {
            val result = com.example.media.ffmpeg.FFmpegEngine.executeWithArguments(args)
            if (!result.isSuccess) {
                throw IllegalStateException("FFmpeg execution returned non-zero status: ${result.output}")
            }
        } catch (e: Exception) {
            DownloadManager.addLog("❌ FFmpeg execution failed: ${e.localizedMessage}")
            throw e
        }
    }

    private fun parseTargetHeight(qualityStr: String, formatIdStr: String): Int? {
        val regex = Regex("""(\d{3,4})[pP]?""")
        val matchQ = regex.find(qualityStr)
        if (matchQ != null) {
            return matchQ.groupValues[1].toIntOrNull()
        }
        val matchF = regex.find(formatIdStr)
        if (matchF != null) {
            return matchF.groupValues[1].toIntOrNull()
        }
        return null
    }

    private fun buildRobustFormatOption(
        formatId: String,
        formatQuality: String,
        audioFormatId: String,
        isAudioOnly: Boolean,
        actualIsMuxNeeded: Boolean
    ): String {
        if (isAudioOnly) {
            val audioSpec = if (audioFormatId.isNotBlank() && audioFormatId != "bestaudio") audioFormatId else "bestaudio"
            return if (formatId.isNotBlank() && formatId != "best" && formatId != "audio") {
                "$formatId/$audioSpec/bestaudio/best"
            } else {
                "$audioSpec/bestaudio/best"
            }
        }

        val targetHeight = parseTargetHeight(formatQuality, formatId)
        val videoSpec = if (formatId.isNotBlank() && formatId != "best") formatId else null
        val audioSpec = if (audioFormatId.isNotBlank() && audioFormatId != "bestaudio") audioFormatId else "bestaudio"

        return if (videoSpec != null) {
            if (actualIsMuxNeeded) {
                if (targetHeight != null) {
                    "$videoSpec+$audioSpec/$videoSpec/bestvideo[height<=$targetHeight]+bestaudio/best[height<=$targetHeight]/bestvideo+bestaudio/best"
                } else {
                    "$videoSpec+$audioSpec/$videoSpec/bestvideo+bestaudio/best"
                }
            } else {
                if (targetHeight != null) {
                    "$videoSpec/best[height<=$targetHeight]/bestvideo[height<=$targetHeight]+bestaudio/bestvideo+bestaudio/best"
                } else {
                    "$videoSpec/bestvideo+bestaudio/best"
                }
            }
        } else {
            if (targetHeight != null) {
                "bestvideo[height<=$targetHeight]+bestaudio/best[height<=$targetHeight]/bestvideo+bestaudio/best"
            } else {
                "bestvideo+bestaudio/best"
            }
        }
    }
}
