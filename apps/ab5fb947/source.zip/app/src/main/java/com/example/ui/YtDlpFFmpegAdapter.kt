package com.example.ui

import android.util.Log
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import com.yausername.youtubedl_android.YoutubeDLResponse
import com.example.media.ffmpeg.FFmpegEngine
import java.io.File
import kotlinx.coroutines.runBlocking

/**
 * Adapter to bridge yt-dlp with the application's FFmpegKit 8.1.7 engine.
 *
 * LIMITATION DOCUMENTATION:
 * The existing yt-dlp Android implementation executes as a standalone Python process
 * which strictly requires an external standalone executable binary for FFmpeg operations (e.g. merging, extraction).
 * FFmpegKit 8.1.7 is a JNI shared library (`libffmpegkit.so`), NOT a standalone executable.
 * Therefore, yt-dlp cannot directly consume FFmpegKit from within its Python process.
 *
 * BRIDGE IMPLEMENTATION:
 * Instead of pretending the AAR is an executable or breaking yt-dlp, this adapter
 * instructs yt-dlp to preserve the raw video and audio streams (using --keep-video).
 * If yt-dlp's own FFmpeg binary fails to merge the streams (e.g. due to Android 15 16KB page size
 * incompatibilities or missing codecs), this adapter catches the failure, locates the downloaded
 * raw stream files, and securely executes the merge/post-processing using our native FFmpegKit engine.
 */
object YtDlpFFmpegAdapter {
    private const val TAG = "YtDlpFFmpegAdapter"

    fun executeWithFallback(
        request: YoutubeDLRequest,
        processId: String? = null,
        onProgress: (progress: Float, etaInSeconds: Long, line: String) -> Unit
    ): YoutubeDLResponse {
        // Enforce keeping raw files so we can salvage them if yt-dlp's internal ffmpeg fails
        request.addOption("--keep-video")

        return try {
            YoutubeDL.getInstance().execute(request, processId) { progress, eta, line ->
                onProgress(progress, eta, line)
            }
        } catch (e: Exception) {
            val errorMsg = e.localizedMessage ?: ""
            Log.w(TAG, "yt-dlp execution failed: $errorMsg")

            if (errorMsg.contains("ffmpeg", ignoreCase = true) || errorMsg.contains("Postprocessing", ignoreCase = true) || errorMsg.contains("returned non-zero exit status", ignoreCase = true)) {
                Log.w(TAG, "yt-dlp failed during FFmpeg post-processing. Salvaging raw files using FFmpegKit 8.1.7...")
                
                val commandList = getCommandList(request)
                
                // Extract expected output file path from the request options if available
                val outputOption = getOptionValue(commandList, "-o") ?: getOptionValue(commandList, "--output")
                if (outputOption != null) {
                    val outputFile = File(outputOption)
                    val dir = outputFile.parentFile
                    val baseName = outputFile.nameWithoutExtension
                    
                    if (dir != null && dir.exists()) {
                        // Find the raw video and audio files left behind
                        val candidates = dir.listFiles { _, name -> name.startsWith(baseName) && name != outputFile.name }?.toList() ?: emptyList()
                        
                        val videoFile = candidates.firstOrNull { it.name.endsWith(".mp4") || it.name.endsWith(".webm") || it.name.endsWith(".mkv") && !it.name.contains("audio", ignoreCase = true) }
                        val audioFile = candidates.firstOrNull { it.name.endsWith(".m4a") || it.name.endsWith(".webm") || it.name.endsWith(".mp3") || it.name.endsWith(".ogg") }
                        
                        if (videoFile != null && audioFile != null) {
                            Log.i(TAG, "Found salvageable raw streams: Video=${videoFile.name}, Audio=${audioFile.name}")
                            
                            val ext = outputFile.extension.ifBlank { "mkv" }
                            val finalFile = File(dir, "$baseName.$ext")
                            
                            val mergeArgs = arrayOf(
                                "-y",
                                "-i", videoFile.absolutePath,
                                "-i", audioFile.absolutePath,
                                "-c", "copy",
                                finalFile.absolutePath
                            )
                            
                            runBlocking {
                                val result = FFmpegEngine.executeWithArguments(mergeArgs)
                                if (result.isSuccess) {
                                    Log.i(TAG, "FFmpegKit salvaged the merge successfully!")
                                    // Clean up the raw files
                                    videoFile.delete()
                                    audioFile.delete()
                                } else {
                                    Log.e(TAG, "FFmpegKit salvage merge failed: ${result.output}")
                                    throw Exception("Native merge salvage failed: ${result.output}", e)
                                }
                            }
                            return YoutubeDLResponse(commandList, 0, 0, "Native salvage successful", "")
                        } else if (videoFile != null) {
                             Log.i(TAG, "Only video file found: ${videoFile.name}. Renaming to target.")
                             videoFile.renameTo(outputFile)
                             return YoutubeDLResponse(commandList, 0, 0, "Native salvage successful (single stream)", "")
                        } else if (audioFile != null) {
                             Log.i(TAG, "Only audio file found: ${audioFile.name}. Renaming to target.")
                             audioFile.renameTo(outputFile)
                             return YoutubeDLResponse(commandList, 0, 0, "Native salvage successful (single stream)", "")
                        } else {
                             Log.e(TAG, "Could not find raw files to salvage in ${dir.absolutePath}")
                        }
                    }
                }
            }
            throw e
        }
    }

    private fun getCommandList(request: YoutubeDLRequest): List<String> {
        return try {
            val buildCommandMethod = YoutubeDLRequest::class.java.getDeclaredMethod("buildCommand")
            buildCommandMethod.isAccessible = true
            buildCommandMethod.invoke(request) as? List<String> ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun getOptionValue(commandList: List<String>, optionName: String): String? {
        val index = commandList.indexOf(optionName)
        if (index != -1 && index + 1 < commandList.size) {
            return commandList[index + 1]
        }
        return null
    }
}
