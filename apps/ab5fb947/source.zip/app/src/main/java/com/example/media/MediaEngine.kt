package com.example.media

import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.PlaybackException
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory

interface MediaEngine {
    val player: Player
    val decoderManager: DecoderManager

    fun prepareMedia(uriString: String, audioUriString: String? = null, subtitleUriString: String? = null)
    fun setPlaybackSpeed(speed: Float)
    fun setVolume(volume: Float)
    fun release()
    fun getDiagnostics(): MediaDiagnostics
    suspend fun formatPlaybackErrorLog(error: PlaybackException): String
    fun formatSuccessLog(): String
}

class DefaultMediaEngine(
    private val context: Context,
    val renderersFactory: DefaultRenderersFactory = DefaultRenderersFactory(context)
        .setEnableDecoderFallback(true)
        .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
        .setEnableAudioTrackPlaybackParams(true),
    val trackSelector: DefaultTrackSelector = DefaultTrackSelector(context).apply {
        parameters = buildUponParameters()
            .setSelectUndeterminedTextLanguage(true)
            .setAllowMultipleAdaptiveSelections(true)
            .build()
    },
    override val decoderManager: DecoderManager = com.example.media.orchestration.DecoderOrchestrator()
) : MediaEngine {

    private val httpDataSourceFactory = DefaultHttpDataSource.Factory()
        .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
        .setAllowCrossProtocolRedirects(true)
        .setConnectTimeoutMs(15000)
        .setReadTimeoutMs(15000)

    private val dataSourceFactory = DefaultDataSource.Factory(context, httpDataSourceFactory)
    
    private val extractorsFactory = androidx.media3.extractor.DefaultExtractorsFactory()
        .setTextTrackTranscodingEnabled(true)
        .setConstantBitrateSeekingEnabled(true)
        
    private val mediaSourceFactory = DefaultMediaSourceFactory(context, extractorsFactory)
        .setDataSourceFactory(dataSourceFactory)

    private val exoPlayer: ExoPlayer = ExoPlayer.Builder(context, renderersFactory)
        .setMediaSourceFactory(mediaSourceFactory)
        .setTrackSelector(trackSelector)
        .setAudioAttributes(
            androidx.media3.common.AudioAttributes.Builder()
                .setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MUSIC)
                .setUsage(androidx.media3.common.C.USAGE_MEDIA)
                .build(),
            true
        )
        .build().apply {
            playWhenReady = true
            repeatMode = Player.REPEAT_MODE_ONE
            
            addAnalyticsListener(object : androidx.media3.exoplayer.analytics.AnalyticsListener {
                private var startTime = 0L

                override fun onPlaybackStateChanged(eventTime: androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime, state: Int) {
                    if (state == Player.STATE_BUFFERING) {
                        startTime = System.currentTimeMillis()
                    } else if (state == Player.STATE_READY && startTime > 0) {
                        val perf = decoderManager.getPerformanceProfile()
                        perf.startupTimeMs = System.currentTimeMillis() - startTime
                    }
                }

                override fun onVideoDecoderInitialized(
                    eventTime: androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime,
                    decoderName: String,
                    initializedTimestampMs: Long,
                    initializationDurationMs: Long
                ) {
                    val perf = decoderManager.getPerformanceProfile()
                    perf.activeVideoDecoder = decoderName
                    perf.decoderInitTimeMs = initializationDurationMs
                }

                override fun onAudioDecoderInitialized(
                    eventTime: androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime,
                    decoderName: String,
                    initializedTimestampMs: Long,
                    initializationDurationMs: Long
                ) {
                    val perf = decoderManager.getPerformanceProfile()
                    perf.activeAudioDecoder = decoderName
                }

                override fun onDroppedVideoFrames(
                    eventTime: androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime,
                    droppedFrames: Int,
                    elapsedMs: Long
                ) {
                    decoderManager.getPerformanceProfile().droppedFrames.addAndGet(droppedFrames)
                }

                override fun onAudioUnderrun(
                    eventTime: androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime,
                    bufferSize: Int,
                    bufferSizeMs: Long,
                    elapsedSinceLastFeedMs: Long
                ) {
                    decoderManager.getPerformanceProfile().audioUnderruns.incrementAndGet()
                }
            })
        }

    override val player: Player
        get() = exoPlayer

        override fun prepareMedia(uriString: String, audioUriString: String?, subtitleUriString: String?) {
        try {
            val videoUri = when {
                uriString.startsWith("content://") || uriString.startsWith("file://") || uriString.startsWith("http://") || uriString.startsWith("https://") -> {
                    android.net.Uri.parse(uriString)
                }
                uriString.startsWith("/") -> {
                    val f = java.io.File(uriString)
                    if (f.exists()) android.net.Uri.fromFile(f) else android.net.Uri.parse(uriString)
                }
                else -> android.net.Uri.parse(uriString)
            }
            
            val mediaItemBuilder = androidx.media3.common.MediaItem.Builder().setUri(videoUri)
            
            if (!subtitleUriString.isNullOrBlank()) {
                val subUri = when {
                    subtitleUriString.startsWith("content://") || subtitleUriString.startsWith("file://") || subtitleUriString.startsWith("http://") || subtitleUriString.startsWith("https://") -> {
                        android.net.Uri.parse(subtitleUriString)
                    }
                    subtitleUriString.startsWith("/") -> {
                        val f = java.io.File(subtitleUriString)
                        if (f.exists()) android.net.Uri.fromFile(f) else android.net.Uri.parse(subtitleUriString)
                    }
                    else -> android.net.Uri.parse(subtitleUriString)
                }
                val subExt = subtitleUriString.substringAfterLast('.').lowercase()
                val mimeType = when (subExt) {
                    "srt" -> androidx.media3.common.MimeTypes.APPLICATION_SUBRIP
                    "vtt" -> androidx.media3.common.MimeTypes.TEXT_VTT
                    "ass", "ssa" -> androidx.media3.common.MimeTypes.TEXT_SSA
                    "ttml" -> androidx.media3.common.MimeTypes.APPLICATION_TTML
                    else -> androidx.media3.common.MimeTypes.APPLICATION_SUBRIP
                }
                val subtitleConfig = androidx.media3.common.MediaItem.SubtitleConfiguration.Builder(subUri)
                    .setMimeType(mimeType)
                    .setLanguage("en")
                    .setSelectionFlags(androidx.media3.common.C.SELECTION_FLAG_DEFAULT)
                    .build()
                mediaItemBuilder.setSubtitleConfigurations(listOf(subtitleConfig))
            }

            val mediaItem = mediaItemBuilder.build()

            if (audioUriString.isNullOrBlank()) {
                exoPlayer.setMediaItem(mediaItem)
            } else {
                val videoSource = mediaSourceFactory.createMediaSource(mediaItem)
                val audioUri = when {
                    audioUriString.startsWith("content://") || audioUriString.startsWith("file://") || audioUriString.startsWith("http://") || audioUriString.startsWith("https://") -> {
                        android.net.Uri.parse(audioUriString)
                    }
                    audioUriString.startsWith("/") -> {
                        val f = java.io.File(audioUriString)
                        if (f.exists()) android.net.Uri.fromFile(f) else android.net.Uri.parse(audioUriString)
                    }
                    else -> android.net.Uri.parse(audioUriString)
                }
                val audioSource = mediaSourceFactory.createMediaSource(androidx.media3.common.MediaItem.fromUri(audioUri))
                val mergedSource = androidx.media3.exoplayer.source.MergingMediaSource(videoSource, audioSource)
                exoPlayer.setMediaSource(mergedSource)
            }

            exoPlayer.prepare()
        } catch (e: Exception) {
            android.util.Log.e("DefaultMediaEngine", "Error preparing media source: ${e.localizedMessage}", e)
        }
    }

    override fun setPlaybackSpeed(speed: Float) {
        exoPlayer.setPlaybackSpeed(speed)
    }

    override fun setVolume(volume: Float) {
        exoPlayer.volume = volume
    }

    override fun release() {
        exoPlayer.release()
    }

    override fun getDiagnostics(): MediaDiagnostics {
        val currentTracks = exoPlayer.currentTracks
        val videoList = mutableListOf<VideoDiagnostics>()
        val audioList = mutableListOf<AudioDiagnostics>()
        val subList = mutableListOf<SubtitleDiagnostics>()

        for (group in currentTracks.groups) {
            val trackGroup = group.mediaTrackGroup
            for (i in 0 until group.length) {
                val format = group.getTrackFormat(i)
                when (group.type) {
                    androidx.media3.common.C.TRACK_TYPE_VIDEO -> {
                        videoList.add(
                            VideoDiagnostics(
                                id = format.id ?: "N/A",
                                codec = format.sampleMimeType?.substringAfter("/") ?: "unknown",
                                mimeType = format.sampleMimeType ?: "video/unknown",
                                codecString = format.codecs ?: "N/A",
                                width = format.width,
                                height = format.height,
                                frameRate = format.frameRate,
                                bitrate = format.bitrate,
                                isDefault = (format.selectionFlags and androidx.media3.common.C.SELECTION_FLAG_DEFAULT) != 0
                            )
                        )
                    }
                    androidx.media3.common.C.TRACK_TYPE_AUDIO -> {
                        audioList.add(
                            AudioDiagnostics(
                                id = format.id ?: "N/A",
                                codec = format.sampleMimeType?.substringAfter("/") ?: "unknown",
                                mimeType = format.sampleMimeType ?: "audio/unknown",
                                codecString = format.codecs ?: "N/A",
                                language = format.language ?: "und",
                                channels = format.channelCount,
                                sampleRate = format.sampleRate,
                                bitrate = format.bitrate,
                                isDefault = (format.selectionFlags and androidx.media3.common.C.SELECTION_FLAG_DEFAULT) != 0,
                                isForced = (format.selectionFlags and androidx.media3.common.C.SELECTION_FLAG_FORCED) != 0,
                                title = format.label ?: "N/A"
                            )
                        )
                    }
                    androidx.media3.common.C.TRACK_TYPE_TEXT -> {
                        subList.add(
                            SubtitleDiagnostics(
                                id = format.id ?: "N/A",
                                codec = format.sampleMimeType?.substringAfter("/") ?: "unknown",
                                mimeType = format.sampleMimeType ?: "text/unknown",
                                language = format.language ?: "und",
                                isDefault = (format.selectionFlags and androidx.media3.common.C.SELECTION_FLAG_DEFAULT) != 0,
                                isForced = (format.selectionFlags and androidx.media3.common.C.SELECTION_FLAG_FORCED) != 0,
                                title = format.label ?: "N/A"
                            )
                        )
                    }
                }
            }
        }

        val containerFmt = if (videoList.isNotEmpty()) {
            when {
                videoList.any { it.mimeType.contains("matroska") || it.mimeType.contains("webm") } -> "Matroska / WebM"
                videoList.any { it.mimeType.contains("mp4") } -> "MP4"
                videoList.any { it.mimeType.contains("avc") || it.mimeType.contains("hevc") } -> "MPEG-TS/MP4"
                else -> "Generic Container"
            }
        } else "Unknown"
        
        val timeline = exoPlayer.currentTimeline
        var hasChapters = false
        if (!timeline.isEmpty) {
            val window = androidx.media3.common.Timeline.Window()
            timeline.getWindow(0, window)
            hasChapters = window.firstPeriodIndex != window.lastPeriodIndex
        }

        val metadataMap = mutableMapOf<String, String>()
        val mediaMetadata = exoPlayer.mediaMetadata
        mediaMetadata.title?.let { metadataMap["title"] = it.toString() }
        mediaMetadata.artist?.let { metadataMap["artist"] = it.toString() }
        mediaMetadata.albumTitle?.let { metadataMap["album"] = it.toString() }

        var localFileSizeBytes = 0L
        if (exoPlayer.currentMediaItem != null) {
            val uri = exoPlayer.currentMediaItem?.localConfiguration?.uri
            if (uri != null && uri.scheme == "file") {
                val file = java.io.File(uri.path ?: "")
                if (file.exists()) {
                    localFileSizeBytes = file.length()
                }
            } else if (uri != null && uri.scheme == "content") {
                try {
                    context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                        localFileSizeBytes = pfd.statSize
                    }
                } catch (e: Exception) {
                    // Ignore
                }
            }
        }

        return MediaDiagnostics(
            container = ContainerDiagnostics(
                format = containerFmt,
                durationMs = exoPlayer.duration.coerceAtLeast(0L),
                fileSizeBytes = localFileSizeBytes,
                hasChapters = hasChapters,
                metadata = metadataMap
            ),
            videoTracks = videoList,
            audioTracks = audioList,
            subtitleTracks = subList
        )
    }

    override suspend fun formatPlaybackErrorLog(error: PlaybackException): String {
        val errorCodeName = error.errorCodeName
        val cause = error.cause ?: error
        val exceptionName = cause.javaClass.simpleName
        val causeMsg = cause.message ?: "Unknown Exception"
        
        val sb = StringBuilder()
        sb.appendLine("# PLAYBACK ANALYSIS")
        sb.appendLine()
        sb.appendLine("Result: FAILED")
        sb.appendLine()
        sb.appendLine("Player:")
        sb.appendLine("Media3 / ExoPlayer")
        sb.appendLine()
        sb.appendLine("Failure:")
        sb.appendLine(exceptionName)
        
        val uri = exoPlayer.currentMediaItem?.localConfiguration?.uri
        var probeInfo: com.example.media.probe.MediaProbeInfo? = null
        if (uri != null) {
            val result = com.example.media.probe.MediaProbeEngine.probeMedia(context, uri)
            probeInfo = result.getOrNull()
        }
        
        val video = probeInfo?.primaryVideo
        if (video != null) {
            sb.appendLine()
            sb.appendLine("Video:")
            sb.appendLine(video.codec.uppercase())
            if (!video.profile.isNullOrBlank()) {
                sb.appendLine("Profile:")
                sb.appendLine(video.profile)
            }
            if (!video.pixelFormat.isNullOrBlank()) {
                sb.appendLine("Pixel Format:")
                sb.appendLine(video.pixelFormat)
            }
            
            sb.appendLine()
            sb.appendLine("Device Decoder:")
            val ev = video.decoderEvaluation
            if (ev != null && ev.deviceDecoderName != null) {
                sb.appendLine(ev.deviceDecoderName)
            } else {
                sb.appendLine("None Found")
            }
            
            sb.appendLine()
            sb.appendLine("Analysis:")
            if (exceptionName.contains("DecoderInitializationException") || exceptionName.contains("MediaCodec")) {
                if (ev == null || !ev.isSupported) {
                    sb.appendLine("The requested video format or profile is not supported by")
                    sb.appendLine("the available device decoders.")
                } else {
                    sb.appendLine("The decoder failed to initialize despite claiming support.")
                    sb.appendLine("This may be a device-specific codec quirk or resource exhaustion.")
                }
            } else {
                sb.appendLine("Playback failed due to $exceptionName.")
                sb.appendLine("Reason: $causeMsg")
            }
            
            sb.appendLine()
            sb.appendLine("Recommended action:")
            if (exceptionName.contains("DecoderInitializationException") || exceptionName.contains("MediaCodec")) {
                sb.appendLine("Remux will NOT fix codec incompatibility.")
                sb.appendLine("Transcoding may be required.")
            } else if (causeMsg.contains("extractor") || causeMsg.contains("parser")) {
                sb.appendLine("Container format may be corrupted or unsupported.")
                sb.appendLine("Remuxing may fix the issue.")
            } else {
                sb.appendLine("Try software decoding or transcoding.")
            }
        } else {
            // Fallback if no probe
            sb.appendLine()
            sb.appendLine("Analysis:")
            sb.appendLine("Failed to probe media or no video stream found.")
            sb.appendLine("Reason: $causeMsg")
        }
        
        return sb.toString().trimEnd()
    }

override fun formatSuccessLog(): String {
        val diagnostics = getDiagnostics()
        val video = diagnostics.videoTracks.firstOrNull()
        val audio = diagnostics.audioTracks.firstOrNull()
        val sub = diagnostics.subtitleTracks.firstOrNull()

        val sb = StringBuilder()
        sb.appendLine("[MEDIA]")
        sb.appendLine("container=${diagnostics.container.format}")

        if (video != null) {
            sb.appendLine("\n[VIDEO]")
            sb.appendLine("codec=${video.codec}")
            val videoDec = decoderManager.findVideoDecoder(video.mimeType, video.width, video.height)
            if (videoDec.decoderName != null) {
                sb.appendLine("mode=${videoDec.sourceType.name.lowercase()}")
            }
        }

        if (audio != null) {
            sb.appendLine("\n[AUDIO]")
            sb.appendLine("codec=${audio.codec}")
            sb.appendLine("language=${audio.language}")
            sb.appendLine("channels=${audio.channels}")
            sb.appendLine("sampleRate=${audio.sampleRate}")
            val audioDec = decoderManager.findAudioDecoder(audio.mimeType, audio.channels, audio.sampleRate)
            if (audioDec.decoderName != null) {
                val audioMode = if (audioDec.sourceType == DecoderSourceType.EXTENSION) "software" else audioDec.sourceType.name.lowercase()
                sb.appendLine("mode=$audioMode")
                sb.appendLine("decoder=${audioDec.decoderName}")
            }
        }

        if (sub != null) {
            sb.appendLine("\n[SUBTITLE]")
            sb.appendLine("codec=${sub.codec}")
        }

        return sb.toString().trimEnd()
    }
}
