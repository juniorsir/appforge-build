import re
with open("app/src/main/java/com/example/ui/VideoDownloaderScreen.kt", "r", encoding="utf-8", errors="ignore") as f:
    lines = f.readlines()
for i, line in enumerate(lines):
    if i > 8647 and ("Play" in line or "Pause" in line or "play" in line or "pause" in line):
        print(f"Line {i}: {line.strip()}")
