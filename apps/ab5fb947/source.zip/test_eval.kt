import com.example.media.probe.*

fun main() {
    val playableMkv = MediaProbeInfo(
        pathOrUri = "file:///storage/emulated/0/Movies/playable.mkv",
        format = "matroska,webm",
        durationMs = 60000,
        sizeBytes = 15000000,
        overallBitrate = 2000000,
        streamCount = 2,
        videoStreams = listOf(
            VideoStreamInfo(
                index = 0, codec = "h264", profile = "High", level = "4.1", width = 1920, height = 1080, frameRate = 30f,
                decoderEvaluation = DecoderEvaluation(
                    mimeType = "video/avc",
                    deviceDecoderName = "OMX.qcom.video.decoder.avc",
                    type = "HARDWARE",
                    isSupported = true,
                    isProfileLevelSupported = true,
                    isResolutionSupported = true
                )
            )
        ),
        audioStreams = listOf(
            AudioStreamInfo(
                index = 1, codec = "aac", channels = 2, sampleRate = 48000,
                decoderEvaluation = DecoderEvaluation(
                    mimeType = "audio/mp4a-latm",
                    deviceDecoderName = "OMX.google.aac.decoder",
                    type = "SOFTWARE",
                    isSupported = true
                )
            )
        )
    )

    val failingMkv = MediaProbeInfo(
        pathOrUri = "content://media/external/video/media/105",
        format = "matroska,webm",
        durationMs = 125000,
        sizeBytes = 25000000,
        overallBitrate = 1600000,
        streamCount = 2,
        videoStreams = listOf(
            VideoStreamInfo(
                index = 0, codec = "av1", profile = "Main", width = 1920, height = 1080, frameRate = 30f,
                decoderEvaluation = DecoderEvaluation(
                    mimeType = "video/av01",
                    isSupported = false
                )
            )
        ),
        audioStreams = listOf(
            AudioStreamInfo(
                index = 1, codec = "opus", channels = 2, sampleRate = 48000,
                decoderEvaluation = DecoderEvaluation(
                    mimeType = "audio/opus",
                    deviceDecoderName = "OMX.google.opus.decoder",
                    type = "SOFTWARE",
                    isSupported = true
                )
            )
        )
    )

    println("Playable MKV result:")
    println(playableMkv.toFormattedReport())
    println("\nFailing MKV result:")
    println(failingMkv.toFormattedReport())
}
