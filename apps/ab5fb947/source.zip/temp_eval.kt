

data class DecoderEvaluation(
    val mimeType: String,
    val deviceDecoderName: String? = null,
    val type: String? = null,
    val isSupported: Boolean = false,
    val isProfileLevelSupported: Boolean? = null,
    val isResolutionSupported: Boolean? = null,
    val isHardware: Boolean = false
)

data class VideoStreamInfo(
    val index: Int = 0,
    val codec: String = "unknown",
    val codecLongName: String? = null,
    val codecTag: String? = null,
    val profile: String? = null,
    val level: String? = null,
    val width: Int = 0,
    val height: Int = 0,
    val frameRate: Float = 0f,
    val averageFrameRate: Float = 0f,
    val bitrate: Long = 0L,
    val durationMs: Long = 0L,
    val pixelFormat: String? = null,
    val colorSpace: String? = null,
    val transferCharacteristics: String? = null,
    val colorPrimaries: String? = null,
    val bitDepth: Int = 8,
    val isDefault: Boolean = false,
    val isForced: Boolean = false,
    val language: String = "und",
    val rotation: Int = 0,
    var decoderEvaluation: DecoderEvaluation? = null
)

data class AudioStreamInfo(
    val index: Int = 0,
    val codec: String = "unknown",
    val codecLongName: String? = null,
    val codecTag: String? = null,
    val profile: String? = null,
    val sampleRate: Int = 0,
    val channels: Int = 0,
    val channelLayout: String? = null,
    val sampleFormat: String? = null,
    val bitrate: Long = 0L,
    val durationMs: Long = 0L,
    val language: String = "und",
    val title: String? = null,
    val isDefault: Boolean = false,
    val isForced: Boolean = false,
    var decoderEvaluation: DecoderEvaluation? = null
)

data class SubtitleStreamInfo(
    val index: Int = 0,
    val codec: String = "unknown",
    val language: String = "und",
    val title: String? = null,
    val isDefault: Boolean = false,
    val isForced: Boolean = false
)

data class OtherStreamInfo(
    val index: Int = 0,
    val type: String = "unknown",
    val codec: String = "unknown"
)

data class MediaProbeInfo(
    val pathOrUri: String,
    val format: String = "unknown",
    val formatLongName: String? = null,
    val durationMs: Long = 0L,
    val sizeBytes: Long = 0L,
    val overallBitrate: Long = 0L,
    val streamCount: Int = 0,
    val videoStreams: List<VideoStreamInfo> = emptyList(),
    val audioStreams: List<AudioStreamInfo> = emptyList(),
    val subtitleStreams: List<SubtitleStreamInfo> = emptyList(),
    val otherStreams: List<OtherStreamInfo> = emptyList(),
    val metadataTags: Map<String, String> = emptyMap(),
    val rawProperties: String? = null
) {
    val primaryVideo: VideoStreamInfo?
        get() = videoStreams.firstOrNull { it.isDefault } ?: videoStreams.firstOrNull()
    val primaryAudio: AudioStreamInfo?
        get() = audioStreams.firstOrNull { it.isDefault } ?: audioStreams.firstOrNull()
    val isVideo: Boolean
        get() = videoStreams.isNotEmpty()
    val isAudioOnly: Boolean
        get() = videoStreams.isEmpty() && audioStreams.isNotEmpty()

    private fun formatDuration(durationMs: Long): String {
        if (durationMs <= 0) return "N/A"
        val totalSeconds = durationMs / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format("%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format("%02d:%02d", minutes, seconds)
        }
    }

    private fun formatSize(bytes: Long): String {
        if (bytes <= 0) return "N/A"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1.0 -> String.format("%.2f GB", gb)
            mb >= 1.0 -> String.format("%.2f MB", mb)
            kb >= 1.0 -> String.format("%.2f KB", kb)
            else -> "$bytes bytes"
        }
    }
    
    private fun formatBitrate(bitrate: Long): String {
        return if (bitrate > 0) "${bitrate / 1000} kbps" else "N/A"
    }

    fun toFormattedReport(): String {
        val sb = StringBuilder()
        sb.appendLine("# MEDIA CODEC REPORT\n")
        
        sb.appendLine("FILE")
        val fileName = pathOrUri.substringAfterLast('/').substringAfterLast('%')
        sb.appendLine("Name: $fileName")
        sb.appendLine("Size: ${formatSize(sizeBytes)}")
        sb.appendLine("Duration: ${formatDuration(durationMs)}")
        
        sb.appendLine("\nCONTAINER")
        sb.appendLine("Format: $format")
        if (!formatLongName.isNullOrBlank()) {
            sb.appendLine("Format name: $formatLongName")
        }
        sb.appendLine("Bitrate: ${formatBitrate(overallBitrate)}")
        sb.appendLine("Streams: $streamCount")
        
        if (metadataTags.isNotEmpty()) {
            sb.appendLine("\nMETADATA")
            metadataTags.forEach { (k, v) ->
                sb.appendLine("$k: $v")
            }
        }
        
        for (v in videoStreams) {
            sb.appendLine("\nVIDEO #${v.index}")
            sb.appendLine("Codec: ${v.codec.uppercase()}")
            if (!v.codecLongName.isNullOrBlank() && v.codecLongName != v.codec) {
                sb.appendLine("Codec name: ${v.codecLongName}")
            }
            if (!v.codecTag.isNullOrBlank()) sb.appendLine("Codec Tag: ${v.codecTag}")
            if (!v.profile.isNullOrBlank()) sb.appendLine("Profile: ${v.profile}")
            if (!v.level.isNullOrBlank()) sb.appendLine("Level: ${v.level}")
            
            val ev = v.decoderEvaluation
            if (ev != null) {
                sb.appendLine("\n--- ANDROID DECODER CAPABILITY ---")
                sb.appendLine("Device Decoder: ${ev.deviceDecoderName ?: "None Found"}")
                if (ev.type != null) sb.appendLine("Type: ${ev.type}")
                sb.appendLine("Overall Supported: ${if (ev.isSupported) "YES" else "NO"}")
                if (ev.isProfileLevelSupported != null) sb.appendLine("Profile/Level Supported: ${if (ev.isProfileLevelSupported) "YES" else "NO"}")
                if (ev.isResolutionSupported != null) sb.appendLine("Resolution/FPS Supported: ${if (ev.isResolutionSupported) "YES" else "NO"}")
                sb.appendLine("----------------------------------\n")
            }

            sb.appendLine("Resolution: ${v.width}x${v.height}")
            if (!v.pixelFormat.isNullOrBlank()) sb.appendLine("Pixel Format: ${v.pixelFormat}")
            if (v.frameRate > 0f) sb.appendLine("Frame Rate: ${v.frameRate}")
            if (v.averageFrameRate > 0f && v.averageFrameRate != v.frameRate) sb.appendLine("Avg Frame Rate: ${v.averageFrameRate}")
            if (v.bitrate > 0) sb.appendLine("Bitrate: ${formatBitrate(v.bitrate)}")
            if (v.durationMs > 0) sb.appendLine("Duration: ${formatDuration(v.durationMs)}")
            if (!v.colorSpace.isNullOrBlank()) sb.appendLine("Color Space: ${v.colorSpace}")
            if (!v.colorPrimaries.isNullOrBlank()) sb.appendLine("Color Primaries: ${v.colorPrimaries}")
            if (!v.transferCharacteristics.isNullOrBlank()) sb.appendLine("Transfer Char: ${v.transferCharacteristics}")
            if (v.language != "und") sb.appendLine("Language: ${v.language}")
            if (v.isDefault) sb.appendLine("Default: Yes")
            if (v.isForced) sb.appendLine("Forced: Yes")
        }
        
        for (a in audioStreams) {
            sb.appendLine("\nAUDIO #${a.index}")
            sb.appendLine("Codec: ${a.codec.uppercase()}")
            if (!a.codecLongName.isNullOrBlank() && a.codecLongName != a.codec) {
                sb.appendLine("Codec name: ${a.codecLongName}")
            }
            if (!a.codecTag.isNullOrBlank()) sb.appendLine("Codec Tag: ${a.codecTag}")
            if (!a.profile.isNullOrBlank()) sb.appendLine("Profile: ${a.profile}")
            
            val ea = a.decoderEvaluation
            if (ea != null) {
                sb.appendLine("\n--- ANDROID DECODER CAPABILITY ---")
                sb.appendLine("Device Decoder: ${ea.deviceDecoderName ?: "None Found"}")
                if (ea.type != null) sb.appendLine("Type: ${ea.type}")
                sb.appendLine("Supported: ${if (ea.isSupported) "YES" else "NO"}")
                sb.appendLine("----------------------------------\n")
            }

            sb.appendLine("Channels: ${a.channels}")
            if (!a.channelLayout.isNullOrBlank()) sb.appendLine("Layout: ${a.channelLayout}")
            sb.appendLine("Sample Rate: ${a.sampleRate} Hz")
            if (!a.sampleFormat.isNullOrBlank()) sb.appendLine("Sample Format: ${a.sampleFormat}")
            if (a.bitrate > 0) sb.appendLine("Bitrate: ${formatBitrate(a.bitrate)}")
            if (a.durationMs > 0) sb.appendLine("Duration: ${formatDuration(a.durationMs)}")
            if (a.language != "und") sb.appendLine("Language: ${a.language}")
            if (a.isDefault) sb.appendLine("Default: Yes")
            if (a.isForced) sb.appendLine("Forced: Yes")
        }
        
        for (s in subtitleStreams) {
            sb.appendLine("\nSUBTITLE #${s.index}")
            sb.appendLine("Codec: ${s.codec}")
            if (s.language != "und") sb.appendLine("Language: ${s.language}")
            if (!s.title.isNullOrBlank()) sb.appendLine("Title: ${s.title}")
            if (s.isDefault) sb.appendLine("Default: Yes")
            if (s.isForced) sb.appendLine("Forced: Yes")
        }
        
        for (o in otherStreams) {
            sb.appendLine("\n${o.type.uppercase()} #${o.index}")
            sb.appendLine("Codec: ${o.codec}")
        }
        
        return sb.toString().trimEnd()
    }
}
import com.example.media.probe.*

fun main() {
    val playableMkv = MediaProbeInfo(
        pathOrUri = "file:///storage/emulated/0/Movies/playable.mkv",
        format = "matroska,webm",
        durationMs = 60000,
        sizeBytes = 15000000,
        overallBitrate = 2000000,
        streamCount = 2,
        videoStreams = listOf(
            VideoStreamInfo(
                index = 0, codec = "h264", profile = "High", level = "4.1", width = 1920, height = 1080, frameRate = 30f,
                decoderEvaluation = DecoderEvaluation(
                    mimeType = "video/avc",
                    deviceDecoderName = "OMX.qcom.video.decoder.avc",
                    type = "HARDWARE",
                    isSupported = true,
                    isProfileLevelSupported = true,
                    isResolutionSupported = true
                )
            )
        ),
        audioStreams = listOf(
            AudioStreamInfo(
                index = 1, codec = "aac", channels = 2, sampleRate = 48000,
                decoderEvaluation = DecoderEvaluation(
                    mimeType = "audio/mp4a-latm",
                    deviceDecoderName = "OMX.google.aac.decoder",
                    type = "SOFTWARE",
                    isSupported = true
                )
            )
        )
    )

    val failingMkv = MediaProbeInfo(
        pathOrUri = "content://media/external/video/media/105",
        format = "matroska,webm",
        durationMs = 125000,
        sizeBytes = 25000000,
        overallBitrate = 1600000,
        streamCount = 2,
        videoStreams = listOf(
            VideoStreamInfo(
                index = 0, codec = "av1", profile = "Main", width = 1920, height = 1080, frameRate = 30f,
                decoderEvaluation = DecoderEvaluation(
                    mimeType = "video/av01",
                    isSupported = false
                )
            )
        ),
        audioStreams = listOf(
            AudioStreamInfo(
                index = 1, codec = "opus", channels = 2, sampleRate = 48000,
                decoderEvaluation = DecoderEvaluation(
                    mimeType = "audio/opus",
                    deviceDecoderName = "OMX.google.opus.decoder",
                    type = "SOFTWARE",
                    isSupported = true
                )
            )
        )
    )

    println("Playable MKV result:")
    println(playableMkv.toFormattedReport())
    println("\nFailing MKV result:")
    println(failingMkv.toFormattedReport())
}
