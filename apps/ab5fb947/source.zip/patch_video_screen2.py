import re
with open("app/src/main/java/com/example/ui/VideoDownloaderScreen.kt", "r") as f:
    content = f.read()

if "import kotlinx.coroutines.launch" not in content:
    content = "import kotlinx.coroutines.launch\n" + content

with open("app/src/main/java/com/example/ui/VideoDownloaderScreen.kt", "w") as f:
    f.write(content)
