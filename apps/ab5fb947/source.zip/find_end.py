with open("app/src/main/java/com/example/ui/VideoDownloaderScreen.kt", "r", encoding="utf-8", errors="ignore") as f:
    lines = f.readlines()
for i in range(10183, min(10300, len(lines))):
    if "modifier = Modifier.fillMaxSize()" in lines[i]:
        print(f"Found modifier at {i}")
        for j in range(i-2, i+5):
            print(lines[j].strip())
