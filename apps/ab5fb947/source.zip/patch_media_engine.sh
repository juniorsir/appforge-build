sed -i 's/fun formatPlaybackErrorLog(error: PlaybackException): String/suspend fun formatPlaybackErrorLog(error: PlaybackException): String/' app/src/main/java/com/example/media/MediaEngine.kt
