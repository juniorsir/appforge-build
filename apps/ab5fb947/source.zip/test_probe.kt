import com.example.media.probe.MediaProbeInfo
import com.example.media.probe.VideoStreamInfo
import com.example.media.probe.AudioStreamInfo
import com.example.media.probe.SubtitleStreamInfo
import com.example.media.probe.OtherStreamInfo

fun main() {
    val failingInfo = MediaProbeInfo(
        pathOrUri = "content://media/external/video/media/105",
        format = "matroska,webm",
        formatLongName = "Matroska / WebM",
        durationMs = 125000,
        sizeBytes = 25000000,
        overallBitrate = 1600000,
        streamCount = 2,
        videoStreams = listOf(
            VideoStreamInfo(
                index = 0,
                codec = "av1",
                codecLongName = "AOMedia Video 1",
                profile = "Main",
                width = 1920,
                height = 1080,
                frameRate = 30f,
                averageFrameRate = 30f,
                bitrate = 1450000,
                pixelFormat = "yuv420p10le",
                colorSpace = "bt709",
                colorPrimaries = "bt709",
                transferCharacteristics = "bt709",
                isDefault = true
            )
        ),
        audioStreams = listOf(
            AudioStreamInfo(
                index = 1,
                codec = "opus",
                codecLongName = "Opus (Opus Interactive Audio Codec)",
                sampleRate = 48000,
                channels = 2,
                channelLayout = "stereo",
                sampleFormat = "fltp",
                bitrate = 128000,
                isDefault = true,
                language = "en"
            )
        )
    )

    val workingInfo = MediaProbeInfo(
        pathOrUri = "file:///storage/emulated/0/Movies/test.mp4",
        format = "mov,mp4,m4a,3gp,3g2,mj2",
        formatLongName = "QuickTime / MOV",
        durationMs = 60000,
        sizeBytes = 15000000,
        overallBitrate = 2000000,
        streamCount = 2,
        videoStreams = listOf(
            VideoStreamInfo(
                index = 0,
                codec = "h264",
                codecLongName = "H.264 / AVC / MPEG-4 AVC / MPEG-4 part 10",
                profile = "High",
                level = "4.0",
                width = 1920,
                height = 1080,
                frameRate = 60f,
                averageFrameRate = 60f,
                bitrate = 1800000,
                pixelFormat = "yuv420p",
                isDefault = true
            )
        ),
        audioStreams = listOf(
            AudioStreamInfo(
                index = 1,
                codec = "aac",
                codecLongName = "Advanced Audio Coding",
                sampleRate = 48000,
                channels = 2,
                channelLayout = "stereo",
                sampleFormat = "fltp",
                bitrate = 192000,
                isDefault = true,
                language = "en"
            )
        )
    )

    println("--- FAILING MKV ---")
    println(failingInfo.toFormattedReport())
    println("\n--- WORKING MP4 ---")
    println(workingInfo.toFormattedReport())
}
