import re

with open("app/src/main/java/com/example/media/MediaEngine.kt", "r") as f:
    content = f.read()

new_method = """
    override suspend fun formatPlaybackErrorLog(error: PlaybackException): String {
        val errorCodeName = error.errorCodeName
        val cause = error.cause ?: error
        val exceptionName = cause.javaClass.simpleName
        val causeMsg = cause.message ?: "Unknown Exception"
        
        val sb = StringBuilder()
        sb.appendLine("# PLAYBACK ANALYSIS")
        sb.appendLine()
        sb.appendLine("Result: FAILED")
        sb.appendLine()
        sb.appendLine("Player:")
        sb.appendLine("Media3 / ExoPlayer")
        sb.appendLine()
        sb.appendLine("Failure:")
        sb.appendLine(exceptionName)
        
        val uri = exoPlayer.currentMediaItem?.localConfiguration?.uri
        var probeInfo: com.example.media.probe.MediaProbeInfo? = null
        if (uri != null) {
            val result = com.example.media.probe.MediaProbeEngine.probeMedia(context, uri)
            probeInfo = result.getOrNull()
        }
        
        val video = probeInfo?.primaryVideo
        if (video != null) {
            sb.appendLine()
            sb.appendLine("Video:")
            sb.appendLine(video.codec.uppercase())
            if (!video.profile.isNullOrBlank()) {
                sb.appendLine("Profile:")
                sb.appendLine(video.profile)
            }
            if (!video.pixelFormat.isNullOrBlank()) {
                sb.appendLine("Pixel Format:")
                sb.appendLine(video.pixelFormat)
            }
            
            sb.appendLine()
            sb.appendLine("Device Decoder:")
            val ev = video.decoderEvaluation
            if (ev != null && ev.deviceDecoderName != null) {
                sb.appendLine(ev.deviceDecoderName)
            } else {
                sb.appendLine("None Found")
            }
            
            sb.appendLine()
            sb.appendLine("Analysis:")
            if (exceptionName.contains("DecoderInitializationException") || exceptionName.contains("MediaCodec")) {
                if (ev == null || !ev.isSupported) {
                    sb.appendLine("The requested video format or profile is not supported by")
                    sb.appendLine("the available device decoders.")
                } else {
                    sb.appendLine("The decoder failed to initialize despite claiming support.")
                    sb.appendLine("This may be a device-specific codec quirk or resource exhaustion.")
                }
            } else {
                sb.appendLine("Playback failed due to $exceptionName.")
                sb.appendLine("Reason: $causeMsg")
            }
            
            sb.appendLine()
            sb.appendLine("Recommended action:")
            if (exceptionName.contains("DecoderInitializationException") || exceptionName.contains("MediaCodec")) {
                sb.appendLine("Remux will NOT fix codec incompatibility.")
                sb.appendLine("Transcoding may be required.")
            } else if (causeMsg.contains("extractor") || causeMsg.contains("parser")) {
                sb.appendLine("Container format may be corrupted or unsupported.")
                sb.appendLine("Remuxing may fix the issue.")
            } else {
                sb.appendLine("Try software decoding or transcoding.")
            }
        } else {
            // Fallback if no probe
            sb.appendLine()
            sb.appendLine("Analysis:")
            sb.appendLine("Failed to probe media or no video stream found.")
            sb.appendLine("Reason: $causeMsg")
        }
        
        return sb.toString().trimEnd()
    }
"""

# Replace from `override suspend fun formatPlaybackErrorLog` to the end of the method
start_idx = content.find("override suspend fun formatPlaybackErrorLog")
if start_idx != -1:
    # Find matching brace
    brace_count = 0
    end_idx = -1
    for i in range(start_idx, len(content)):
        if content[i] == '{':
            brace_count += 1
        elif content[i] == '}':
            brace_count -= 1
            if brace_count == 0:
                end_idx = i + 1
                break
    
    if end_idx != -1:
        content = content[:start_idx] + new_method.strip() + "\n\n" + content[end_idx:].lstrip()

with open("app/src/main/java/com/example/media/MediaEngine.kt", "w") as f:
    f.write(content)

