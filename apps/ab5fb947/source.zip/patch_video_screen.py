import re

with open("app/src/main/java/com/example/ui/VideoDownloaderScreen.kt", "r") as f:
    content = f.read()

# Add rememberCoroutineScope
if "val playbackScope = rememberCoroutineScope()" not in content:
    content = content.replace(
        "    DisposableEffect(mediaEngine) {",
        "    val playbackScope = rememberCoroutineScope()\n    DisposableEffect(mediaEngine) {"
    )

# Fix the catch block in the LaunchedEffect (lines ~9069)
old_catch = """        } catch (e: Exception) {
            playerError = mediaEngine.formatPlaybackErrorLog(androidx.media3.common.PlaybackException(e.message, e, androidx.media3.common.PlaybackException.ERROR_CODE_UNSPECIFIED))
            showExternalPlayerAlert = true
        }"""
new_catch = """        } catch (e: Exception) {
            playbackScope.launch {
                playerError = mediaEngine.formatPlaybackErrorLog(androidx.media3.common.PlaybackException(e.message, e, androidx.media3.common.PlaybackException.ERROR_CODE_UNSPECIFIED))
                showExternalPlayerAlert = true
            }
        }"""
content = content.replace(old_catch, new_catch)

# Fix the onPlayerError (lines ~9243)
old_error_catch = """                } catch (e: Exception) {
                    playerError = mediaEngine.formatPlaybackErrorLog(error)
                    showExternalPlayerAlert = true
                }"""
new_error_catch = """                } catch (e: Exception) {
                    playbackScope.launch {
                        playerError = mediaEngine.formatPlaybackErrorLog(error)
                        showExternalPlayerAlert = true
                    }
                }"""
content = content.replace(old_error_catch, new_error_catch)

with open("app/src/main/java/com/example/ui/VideoDownloaderScreen.kt", "w") as f:
    f.write(content)
