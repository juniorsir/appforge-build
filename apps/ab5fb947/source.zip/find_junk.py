import sys

with open("app/src/main/java/com/example/ui/VideoDownloaderScreen.kt", "rb") as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if i > 10300:
        try:
            line.decode('utf-8')
        except:
            print(f"Junk starts at line {i+1}")
            break
