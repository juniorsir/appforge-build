with open("app/src/main/java/com/example/ui/VideoDownloaderScreen.kt", "r", encoding="utf-8", errors="ignore") as f:
    lines = f.readlines()
print("Total lines:", len(lines))
for i in range(len(lines)-20, len(lines)):
    print(f"{i+1}: {lines[i].rstrip()}")
