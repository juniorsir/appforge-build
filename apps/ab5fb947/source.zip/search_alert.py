import sys
with open("app/src/main/java/com/example/ui/VideoDownloaderScreen.kt", "r", encoding="utf-8", errors="ignore") as f:
    lines = f.readlines()
for i, line in enumerate(lines):
    if "showExternalPlayerAlert" in line:
        print(f"Line {i+1}: {line.strip()}")
        for j in range(i+1, min(i+20, len(lines))):
            if "AlertDialog" in lines[j]:
                print(f"  -> Found AlertDialog at {j+1}: {lines[j].strip()}")
