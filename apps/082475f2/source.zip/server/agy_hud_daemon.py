#!/usr/bin/env python3
"""
Termux-First Dual-Window Agy HUD Companion Daemon (agy_hud_daemon.py)

Connects to KaVach / AeroShare locally on http://127.0.0.1:8080 (with Bearer token from
~/.aura_token) over both RFC 6455 WebSocket (instant HUD_COMMAND push) and /api/hud/poll
fallback. Manages an `agy` CLI session (auto-detecting `--input-format stream-json
--output-format stream-json` with automatic fallback to `agy --continue`), streams live
checklist/step/tool/question telemetry into POST /api/hud/state, extracts compact 3-6 zone
low-poly screen wireframes only when screenWatch mode is active, and auto-collapses the HUD
to its bottom-right pill on completion.

Usage in Termux:
    python agy_hud_daemon.py
    python agy_hud_daemon.py --url http://127.0.0.1:8080 --mode auto
    python agy_hud_daemon.py --self-test
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import queue
import re
import signal
import socket
import struct
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from typing import Any, Dict, List, Optional, Tuple

DEFAULT_HTTP_URL = os.environ.get("AURA_HTTP_URL", "http://127.0.0.1:8080").rstrip("/")
TOKEN_CANDIDATES = [
    os.path.expanduser("~/.aura_token"),
    os.path.join(os.path.dirname(os.path.abspath(__file__)), ".aura_token"),
]
BOUNDS_RE = re.compile(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]")
SCREEN_TOOL_KEYWORDS = (
    "ui_tree",
    "ui_action",
    "tap",
    "click",
    "swipe",
    "drag",
    "screen",
    "screenshot",
    "inspect",
    "accessibility",
    "scroll",
)


def load_auth_token(explicit_token: Optional[str] = None) -> str:
    if explicit_token:
        return explicit_token.strip()
    for env_key in ("AURA_API_TOKEN", "AERO_TOKEN"):
        val = os.environ.get(env_key, "").strip()
        if val:
            return val
    for path in TOKEN_CANDIDATES:
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    val = f.read().strip()
                    if val:
                        return val
            except OSError:
                pass
    return ""


class KavachHudClient:
    """Zero-dependency HTTP + RFC 6455 WebSocket client for KaVach /api/hud/* endpoints."""

    def __init__(self, base_url: str, token: str, timeout: float = 5.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token.strip()
        self.timeout = timeout

    def _headers(self, json_body: bool = True) -> Dict[str, str]:
        headers = {
            "User-Agent": "AgyHudDaemon/1.0",
            "Accept": "application/json",
        }
        if json_body:
            headers["Content-Type"] = "application/json"
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
            headers["X-API-Key"] = self.token
        return headers

    def request_json(
        self,
        method: str,
        path: str,
        payload: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        url = f"{self.base_url}{path}"
        data = json.dumps(payload).encode("utf-8") if payload is not None else None
        req = urllib.request.Request(
            url=url,
            data=data,
            headers=self._headers(json_body=payload is not None),
            method=method.upper(),
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                raw = resp.read().decode("utf-8", errors="replace").strip()
                return json.loads(raw) if raw else {"success": True}
        except urllib.error.HTTPError as e:
            body = ""
            try:
                body = e.read().decode("utf-8", errors="replace")
                parsed = json.loads(body)
                if isinstance(parsed, dict):
                    parsed.setdefault("httpStatus", e.code)
                    return parsed
            except Exception:
                pass
            return {"success": False, "httpStatus": e.code, "error": body or str(e)}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def push_hud_state(self, state_payload: Dict[str, Any]) -> Dict[str, Any]:
        return self.request_json("POST", "/api/hud/state", state_payload)

    def send_hud_command(self, cmd_payload: Dict[str, Any]) -> Dict[str, Any]:
        return self.request_json("POST", "/api/hud/command", cmd_payload)

    def poll_hud_commands(self) -> Dict[str, Any]:
        return self.request_json("GET", "/api/hud/poll")

    def hide_hud(self) -> Dict[str, Any]:
        return self.request_json("POST", "/api/hud/hide", {})

    def fetch_ui_tree(self) -> Dict[str, Any]:
        return self.request_json("GET", "/api/ui/tree")


class StdlibWebSocketListener:
    """
    Lightweight pure-stdlib RFC 6455 WebSocket client so the daemon runs in Termux
    without needing `pip install websockets`. Delivers real-time `HUD_COMMAND` frames
    and automatically reconnects on drop.
    """

    def __init__(
        self,
        base_http_url: str,
        token: str,
        on_message,
        stop_event: threading.Event,
    ) -> None:
        self.base_http_url = base_http_url.rstrip("/")
        self.token = token
        self.on_message = on_message
        self.stop_event = stop_event
        self.connected = False
        self._sock: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        self._thread = threading.Thread(target=self._run_loop, name="agy-ws-listener", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self.connected = False
        sock = self._sock
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass

    def _connect_and_read(self) -> None:
        parsed = urllib.parse.urlparse(self.base_http_url)
        host = parsed.hostname or "127.0.0.1"
        port = parsed.port or (443 if parsed.scheme == "https" else 8080)
        ws_path = "/ws"
        if self.token:
            ws_path = f"/ws?token={urllib.parse.quote(self.token)}"

        sock = socket.create_connection((host, port), timeout=5.0)
        self._sock = sock
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        headers = [
            f"GET {ws_path} HTTP/1.1",
            f"Host: {host}:{port}",
            "Upgrade: websocket",
            "Connection: Upgrade",
            f"Sec-WebSocket-Key: {key}",
            "Sec-WebSocket-Version: 13",
        ]
        if self.token:
            headers.append(f"Authorization: Bearer {self.token}")
            headers.append(f"X-API-Key: {self.token}")
        req_bytes = ("\r\n".join(headers) + "\r\n\r\n").encode("utf-8")
        sock.sendall(req_bytes)

        # Read HTTP 101 response headers
        resp_buf = b""
        while b"\r\n\r\n" not in resp_buf and len(resp_buf) < 8192:
            chunk = sock.recv(1024)
            if not chunk:
                raise ConnectionError("WebSocket closed during handshake")
            resp_buf += chunk
        status_line = resp_buf.split(b"\r\n", 1)[0].decode("utf-8", errors="replace")
        if "101" not in status_line:
            raise ConnectionError(f"WebSocket handshake rejected: {status_line}")

        expected_accept = base64.b64encode(
            hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode("utf-8")).digest()
        ).decode("ascii")
        if expected_accept.encode("ascii") not in resp_buf:
            raise ConnectionError("Invalid Sec-WebSocket-Accept")

        sock.settimeout(2.0)
        self.connected = True
        leftover = resp_buf.split(b"\r\n\r\n", 1)[1]

        def read_exact(n: int) -> bytes:
            nonlocal leftover
            while len(leftover) < n:
                if self.stop_event.is_set():
                    raise ConnectionAbortedError("Stopping")
                try:
                    data = sock.recv(max(4096, n - len(leftover)))
                except socket.timeout:
                    continue
                if not data:
                    raise ConnectionError("Socket EOF")
                leftover += data
            out = leftover[:n]
            leftover = leftover[n:]
            return out

        while not self.stop_event.is_set():
            hdr = read_exact(2)
            b0, b1 = hdr[0], hdr[1]
            opcode = b0 & 0x0F
            masked = (b1 & 0x80) != 0
            length = b1 & 0x7F
            if length == 126:
                length = struct.unpack("!H", read_exact(2))[0]
            elif length == 127:
                length = struct.unpack("!Q", read_exact(8))[0]
            mask_key = read_exact(4) if masked else b""
            payload = read_exact(length) if length > 0 else b""
            if masked and payload:
                payload = bytes(b ^ mask_key[i % 4] for i, b in enumerate(payload))

            if opcode == 0x8:  # Close
                break
            elif opcode == 0x9:  # Ping -> send masked Pong
                self._send_ws_frame(sock, 0xA, payload)
            elif opcode == 0x1:  # Text frame
                try:
                    msg = json.loads(payload.decode("utf-8", errors="replace"))
                    if isinstance(msg, dict):
                        self.on_message(msg)
                except Exception:
                    pass

    @staticmethod
    def _send_ws_frame(sock: socket.socket, opcode: int, payload: bytes) -> None:
        mask = os.urandom(4)
        masked_payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        header = bytearray([0x80 | (opcode & 0x0F)])
        length = len(payload)
        if length <= 125:
            header.append(0x80 | length)
        elif length <= 65535:
            header.append(0x80 | 126)
            header.extend(struct.pack("!H", length))
        else:
            header.append(0x80 | 127)
            header.extend(struct.pack("!Q", length))
        header.extend(mask)
        sock.sendall(bytes(header) + masked_payload)

    def _run_loop(self) -> None:
        backoff = 1.0
        while not self.stop_event.is_set():
            try:
                self._connect_and_read()
                backoff = 1.0
            except Exception:
                self.connected = False
            finally:
                if self._sock is not None:
                    try:
                        self._sock.close()
                    except OSError:
                        pass
                    self._sock = None
            if not self.stop_event.is_set():
                self.stop_event.wait(backoff)
                backoff = min(backoff * 1.5, 6.0)


def parse_bounds(bounds_str: str) -> Optional[Tuple[int, int, int, int]]:
    m = BOUNDS_RE.search(bounds_str or "")
    if not m:
        return None
    x1, y1, x2, y2 = (int(m.group(i)) for i in range(1, 5))
    if x2 <= x1 or y2 <= y1:
        return None
    return x1, y1, x2, y2


def extract_wireframe_from_ui_tree(
    tree_response: Dict[str, Any],
    action_vector: Optional[Dict[str, Any]] = None,
    label: str = "Watching Screen",
    max_zones: int = 6,
) -> Dict[str, Any]:
    """
    Extracts ONLY the 3-6 most relevant bounding-box zones from /api/ui/tree
    (skipping clutter and self-excluding any agy_hud_ nodes) for the low-poly
    miniature wireframe canvas.
    """
    nodes_root = tree_response.get("tree") or tree_response.get("nodes") or tree_response.get("uiTree") or []
    if isinstance(nodes_root, dict):
        nodes_root = [nodes_root]

    candidates: List[Tuple[float, Dict[str, Any]]] = []
    max_x, max_y = 1080, 2400

    def walk(node: Dict[str, Any], depth: int = 0) -> None:
        nonlocal max_x, max_y
        if not isinstance(node, dict):
            return
        view_id = str(node.get("viewId") or node.get("viewIdResourceName") or "")
        desc = str(node.get("contentDescription") or "")
        text = str(node.get("text") or "")
        if "agy_hud_" in view_id.lower() or "agy_hud_" in desc.lower():
            return

        b = parse_bounds(str(node.get("bounds") or node.get("boundsInScreen") or ""))
        if b is not None:
            x1, y1, x2, y2 = b
            max_x = max(max_x, x2)
            max_y = max(max_y, y2)
            w, h = x2 - x1, y2 - y1
            area = w * h
            is_clickable = bool(node.get("isClickable"))
            is_editable = bool(node.get("isEditable"))
            is_focused = bool(node.get("isFocused"))
            cls = str(node.get("className") or "").split(".")[-1].lower()
            tag = (text or desc or view_id.split("/")[-1]).strip()

            # Score meaningful interactive/structural elements; ignore tiny icons or full-screen wrappers
            if w >= 40 and h >= 32 and area < (max_x * max_y * 0.85):
                score = 0.0
                role = "panel"
                if is_focused:
                    score += 5.0
                    role = "target"
                if is_editable or "edittext" in cls:
                    score += 4.0
                    role = "input"
                elif is_clickable or "button" in cls:
                    score += 3.0
                    role = "button"
                elif y1 < 260 and tag:
                    score += 1.8
                    role = "header"
                elif tag:
                    score += 1.2
                    role = "card"

                if tag:
                    score += 1.0
                if action_vector:
                    vx = float(action_vector.get("x1", -1))
                    vy = float(action_vector.get("y1", -1))
                    if x1 <= vx <= x2 and y1 <= vy <= y2:
                        score += 8.0
                        role = "target"

                if score >= 2.0:
                    candidates.append(
                        (
                            score,
                            {
                                "x1": x1,
                                "y1": y1,
                                "x2": x2,
                                "y2": y2,
                                "role": role,
                                "tag": tag[:18],
                            },
                        )
                    )

        for child in node.get("children") or []:
            walk(child, depth + 1)

    for root in nodes_root:
        walk(root, 0)

    candidates.sort(key=lambda item: item[0], reverse=True)
    selected: List[Dict[str, Any]] = []
    for _, zone in candidates:
        if len(selected) >= max_zones:
            break
        # Deduplicate near-identical overlapping rectangles
        duplicate = False
        for existing in selected:
            if (
                abs(existing["x1"] - zone["x1"]) < 24
                and abs(existing["y1"] - zone["y1"]) < 24
                and abs(existing["x2"] - zone["x2"]) < 24
                and abs(existing["y2"] - zone["y2"]) < 24
            ):
                duplicate = True
                break
        if not duplicate:
            selected.append(zone)

    payload: Dict[str, Any] = {
        "active": True,
        "label": label,
        "screenWidth": max_x,
        "screenHeight": max_y,
        "zones": selected,
    }
    if action_vector:
        payload["actionVector"] = action_vector
    return payload


class HudStateTracker:
    """Maintains structured Agy HUD state and maps streaming agy events into /api/hud/state."""

    def __init__(self, auto_collapse_seconds: int = 4) -> None:
        self.auto_collapse_seconds = auto_collapse_seconds
        self.state = "IDLE"
        self.title = "Agy Ready"
        self.current_action = ""
        self.next_action = ""
        self.question = ""
        self.tasks: List[Dict[str, str]] = []
        self.screen_watch: Dict[str, Any] = {
            "active": False,
            "label": "",
            "screenWidth": 1080,
            "screenHeight": 2400,
            "zones": [],
        }
        self._lock = threading.Lock()

    def begin_prompt(self, prompt_text: str) -> Dict[str, Any]:
        with self._lock:
            self.state = "WORKING"
            self.title = prompt_text.strip()[:64] or "Running Task"
            self.current_action = "Analyzing request..."
            self.next_action = "Planning execution steps"
            self.question = ""
            self.tasks = [
                {"id": "step_1", "label": "Understand & plan task", "status": "doing"},
            ]
            self.screen_watch = {
                "active": False,
                "label": "",
                "screenWidth": 1080,
                "screenHeight": 2400,
                "zones": [],
            }
            return self.to_payload_locked()

    def apply_agy_event(self, event: Dict[str, Any]) -> Tuple[Dict[str, Any], bool]:
        """
        Applies a parsed `agy` JSON event to HUD state.
        Returns `(hud_payload, screen_watch_active)`.
        """
        with self._lock:
            evt_type = str(event.get("type") or event.get("event") or "").lower()

            # 1. Step / Checklist updates (update_steps / steps / tasks)
            steps = event.get("steps") or event.get("tasks") or event.get("checklist")
            if isinstance(steps, list):
                parsed_tasks: List[Dict[str, str]] = []
                doing_label = ""
                next_label = ""
                for idx, item in enumerate(steps):
                    if isinstance(item, dict):
                        status_raw = str(item.get("status") or item.get("state") or "pending").lower()
                        status = self._normalize_task_status(status_raw)
                        label = str(item.get("label") or item.get("title") or item.get("description") or f"Step {idx + 1}").strip()
                        tid = str(item.get("id") or f"step_{idx + 1}")
                        parsed_tasks.append({"id": tid, "label": label, "status": status})
                        if status == "doing" and not doing_label:
                            doing_label = label
                        elif status == "pending" and not next_label:
                            next_label = label
                    elif isinstance(item, str):
                        parsed_tasks.append({"id": f"step_{idx + 1}", "label": item.strip(), "status": "pending"})
                if parsed_tasks:
                    self.tasks = parsed_tasks
                    if doing_label:
                        self.current_action = doing_label
                    if next_label:
                        self.next_action = next_label
                    self.state = "WORKING"

            # 2. Active Tool Call inspection
            tool_name = str(
                event.get("tool")
                or event.get("tool_name")
                or event.get("name")
                or (event.get("tool_use") or {}).get("name", "")
            ).strip()
            tool_args = (
                event.get("arguments")
                or event.get("args")
                or event.get("input")
                or (event.get("tool_use") or {}).get("input")
                or {}
            )
            if isinstance(tool_args, str):
                try:
                    tool_args = json.loads(tool_args)
                except Exception:
                    tool_args = {"raw": tool_args}

            if tool_name or evt_type in ("tool_use", "tool_call", "function_call"):
                self.state = "WORKING"
                display_tool = tool_name or "tool"
                self.current_action = f"Running {display_tool}"
                if self._is_screen_tool(display_tool, tool_args):
                    action_vec = self._extract_action_vector(display_tool, tool_args)
                    self.screen_watch["active"] = True
                    self.screen_watch["label"] = f"Tool: {display_tool}"
                    if action_vec:
                        self.screen_watch["actionVector"] = action_vec
                else:
                    self.screen_watch["active"] = False
                    self.screen_watch.pop("actionVector", None)

            # 3. Direct question / NEEDS_INPUT escalation
            if evt_type in ("needs_input", "question", "ask_user", "input_required") or event.get("needs_input"):
                q = str(event.get("question") or event.get("text") or event.get("message") or "Agy needs your input").strip()
                self.state = "NEEDS_INPUT"
                self.question = q
                self.current_action = "Waiting for your reply..."
                self.screen_watch["active"] = False

            # 4. Turn / Task Completion
            elif evt_type in ("result", "done", "complete", "completed", "turn_complete", "final"):
                summary = str(event.get("summary") or event.get("text") or event.get("result") or "Task completed").strip()
                self.state = "DONE"
                self.current_action = summary[:80]
                self.next_action = ""
                self.question = ""
                self.screen_watch["active"] = False
                self.screen_watch.pop("actionVector", None)
                for t in self.tasks:
                    if t["status"] in ("doing", "pending"):
                        t["status"] = "done"

            # 5. Plain text delta / status updates
            elif evt_type in ("status", "assistant", "message", "text", "delta"):
                txt = str(event.get("text") or event.get("content") or event.get("message") or "").strip()
                if txt:
                    if txt.endswith("?") and len(txt) < 160 and event.get("awaiting_reply"):
                        self.state = "NEEDS_INPUT"
                        self.question = txt
                    else:
                        self.state = "WORKING"
                        self.current_action = txt.splitlines()[0][:80]

            return self.to_payload_locked(), bool(self.screen_watch.get("active"))

    def update_wireframe(self, wireframe_payload: Dict[str, Any]) -> Dict[str, Any]:
        with self._lock:
            self.screen_watch = wireframe_payload
            return self.to_payload_locked()

    def mark_done(self, summary: str = "Completed") -> Dict[str, Any]:
        with self._lock:
            self.state = "DONE"
            self.current_action = summary[:80]
            self.next_action = ""
            self.question = ""
            self.screen_watch["active"] = False
            self.screen_watch.pop("actionVector", None)
            for t in self.tasks:
                if t["status"] in ("doing", "pending"):
                    t["status"] = "done"
            return self.to_payload_locked()

    def mark_stopped(self) -> Dict[str, Any]:
        with self._lock:
            self.state = "IDLE"
            self.current_action = "Stopped by user"
            self.next_action = ""
            self.question = ""
            self.screen_watch["active"] = False
            self.screen_watch.pop("actionVector", None)
            return self.to_payload_locked()

    def to_payload(self) -> Dict[str, Any]:
        with self._lock:
            return self.to_payload_locked()

    def to_payload_locked(self) -> Dict[str, Any]:
        return {
            "state": self.state,
            "title": self.title,
            "currentAction": self.current_action,
            "nextAction": self.next_action,
            "question": self.question,
            "autoCollapseSeconds": self.auto_collapse_seconds,
            "tasks": list(self.tasks),
            "screenWatch": dict(self.screen_watch),
        }

    @staticmethod
    def _normalize_task_status(raw: str) -> str:
        if raw in ("done", "completed", "complete", "success", "x"):
            return "done"
        if raw in ("doing", "in_progress", "active", "running", "working"):
            return "doing"
        if raw in ("needs_input", "blocked", "question", "waiting"):
            return "needs_input"
        return "pending"

    @staticmethod
    def _is_screen_tool(tool_name: str, tool_args: Dict[str, Any]) -> bool:
        haystack = f"{tool_name} {json.dumps(tool_args, default=str)}".lower()
        return any(kw in haystack for kw in SCREEN_TOOL_KEYWORDS)

    @staticmethod
    def _extract_action_vector(tool_name: str, tool_args: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        if not isinstance(tool_args, dict):
            return None
        action_name = str(tool_args.get("action") or tool_name).upper()
        if all(k in tool_args for k in ("x1", "y1", "x2", "y2")):
            return {
                "type": "DRAG" if "DRAG" in action_name else "SWIPE",
                "x1": float(tool_args["x1"]),
                "y1": float(tool_args["y1"]),
                "x2": float(tool_args["x2"]),
                "y2": float(tool_args["y2"]),
            }
        if "x" in tool_args and "y" in tool_args:
            return {
                "type": "TAP",
                "x1": float(tool_args["x"]),
                "y1": float(tool_args["y"]),
                "x2": float(tool_args["x"]),
                "y2": float(tool_args["y"]),
            }
        return None


class AgySessionRunner:
    """
    Manages the `agy` CLI process with auto-detection of `--input-format stream-json
    --output-format stream-json` and automatic fallback to `agy --continue`.
    """

    def __init__(
        self,
        agy_bin: str,
        mode: str,
        on_event,
        on_turn_finished,
    ) -> None:
        self.agy_bin = agy_bin
        self.requested_mode = mode  # auto | stream | continue
        self.resolved_mode = self._detect_mode()
        self.on_event = on_event
        self.on_turn_finished = on_turn_finished

        self._proc: Optional[subprocess.Popen] = None
        self._proc_lock = threading.Lock()
        self._has_started_conversation = False
        self._stream_reader_thread: Optional[threading.Thread] = None

    def _detect_mode(self) -> str:
        if self.requested_mode in ("stream", "continue"):
            return self.requested_mode
        try:
            res = subprocess.run(
                [self.agy_bin, "--help"],
                capture_output=True,
                text=True,
                timeout=3.0,
                check=False,
            )
            help_text = (res.stdout or "") + "\n" + (res.stderr or "")
            if "--input-format" in help_text and "stream-json" in help_text:
                return "stream"
        except Exception:
            pass
        return "continue"

    def send_prompt(self, prompt_text: str) -> None:
        if self.resolved_mode == "stream":
            if self._send_prompt_stream_json(prompt_text):
                return
            # Automatic runtime fallback to --continue if stream-json subprocess exits immediately
            self.resolved_mode = "continue"
        self._run_prompt_continue(prompt_text)

    def stop_active(self) -> None:
        with self._proc_lock:
            proc = self._proc
        if proc is not None and proc.poll() is None:
            try:
                proc.send_signal(signal.SIGINT)
                try:
                    proc.wait(timeout=1.5)
                except subprocess.TimeoutExpired:
                    proc.terminate()
            except Exception:
                pass

    def _ensure_stream_process(self) -> Optional[subprocess.Popen]:
        with self._proc_lock:
            if self._proc is not None and self._proc.poll() is None:
                return self._proc
            try:
                proc = subprocess.Popen(
                    [
                        self.agy_bin,
                        "--input-format",
                        "stream-json",
                        "--output-format",
                        "stream-json",
                    ],
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1,
                )
                self._proc = proc
                self._stream_reader_thread = threading.Thread(
                    target=self._read_stream_stdout,
                    args=(proc,),
                    name="agy-stream-stdout",
                    daemon=True,
                )
                self._stream_reader_thread.start()
                return proc
            except Exception:
                return None

    def _send_prompt_stream_json(self, prompt_text: str) -> bool:
        proc = self._ensure_stream_process()
        if proc is None or proc.stdin is None:
            return False
        try:
            msg = json.dumps(
                {
                    "type": "user",
                    "message": {
                        "role": "user",
                        "content": prompt_text,
                    },
                }
            )
            proc.stdin.write(msg + "\n")
            proc.stdin.flush()
            return True
        except Exception:
            return False

    def _read_stream_stdout(self, proc: subprocess.Popen) -> None:
        assert proc.stdout is not None
        for raw_line in proc.stdout:
            line = raw_line.strip()
            if not line:
                continue
            evt = self._parse_output_line(line)
            self.on_event(evt)
        # Process exited
        self.on_turn_finished("Stream session closed")

    def _run_prompt_continue(self, prompt_text: str) -> None:
        cmd = [self.agy_bin]
        if self._has_started_conversation:
            cmd.append("--continue")
        cmd.append(prompt_text)

        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
        except FileNotFoundError:
            self.on_event(
                {
                    "type": "done",
                    "summary": f"'{self.agy_bin}' binary not found in PATH",
                }
            )
            self.on_turn_finished(f"'{self.agy_bin}' not found")
            return
        except Exception as e:
            self.on_event({"type": "done", "summary": f"Launch error: {e}"})
            self.on_turn_finished(str(e))
            return

        with self._proc_lock:
            self._proc = proc
        self._has_started_conversation = True

        last_line = "Task completed"
        assert proc.stdout is not None
        for raw_line in proc.stdout:
            line = raw_line.strip()
            if not line:
                continue
            last_line = line
            evt = self._parse_output_line(line)
            self.on_event(evt)
        proc.wait()
        self.on_turn_finished(last_line[:80])

    @staticmethod
    def _parse_output_line(line: str) -> Dict[str, Any]:
        if line.startswith("{") and line.endswith("}"):
            try:
                parsed = json.loads(line)
                if isinstance(parsed, dict):
                    return parsed
            except Exception:
                pass
        return {"type": "status", "text": line}


class AgyHudDaemon:
    """Orchestrates WS + poll command intake, AgySessionRunner, and throttled wireframe sampling."""

    def __init__(
        self,
        base_url: str,
        token: str,
        agy_bin: str = "agy",
        mode: str = "auto",
        poll_interval: float = 0.75,
        auto_collapse_seconds: int = 4,
    ) -> None:
        self.client = KavachHudClient(base_url, token)
        self.tracker = HudStateTracker(auto_collapse_seconds=auto_collapse_seconds)
        self.poll_interval = poll_interval
        self.stop_event = threading.Event()
        self.command_queue: "queue.Queue[Dict[str, Any]]" = queue.Queue()
        self._seen_cmd_ids: List[str] = []
        self._seen_lock = threading.Lock()
        self._screen_watch_active = False
        self._last_hud_push_ts = 0.0

        self.runner = AgySessionRunner(
            agy_bin=agy_bin,
            mode=mode,
            on_event=self._handle_agy_event,
            on_turn_finished=self._handle_turn_finished,
        )
        self.ws_listener = StdlibWebSocketListener(
            base_http_url=base_url,
            token=token,
            on_message=self._handle_ws_message,
            stop_event=self.stop_event,
        )

    def _enqueue_unique_command(self, cmd: Dict[str, Any]) -> bool:
        if cmd.get("type") != "HUD_COMMAND":
            return False
        cmd_id = str(cmd.get("id") or f"{cmd.get('timestamp')}:{cmd.get('action')}:{cmd.get('text')}")
        with self._seen_lock:
            if cmd_id in self._seen_cmd_ids:
                return False
            self._seen_cmd_ids.append(cmd_id)
            if len(self._seen_cmd_ids) > 256:
                self._seen_cmd_ids = self._seen_cmd_ids[-128:]
        self.command_queue.put(cmd)
        return True

    def _handle_ws_message(self, msg: Dict[str, Any]) -> None:
        self._enqueue_unique_command(msg)

    def _handle_agy_event(self, evt: Dict[str, Any]) -> None:
        payload, sw_active = self.tracker.apply_agy_event(evt)
        self._screen_watch_active = sw_active
        self.client.push_hud_state(payload)
        self._last_hud_push_ts = time.time()

    def _handle_turn_finished(self, summary: str) -> None:
        self._screen_watch_active = False
        if self.tracker.state not in ("DONE", "IDLE"):
            payload = self.tracker.mark_done(summary)
            self.client.push_hud_state(payload)

    def _poll_loop(self) -> None:
        while not self.stop_event.is_set():
            # Poll less aggressively when WS is live, faster when WS is disconnected
            wait_s = self.poll_interval * 2.5 if self.ws_listener.connected else self.poll_interval
            res = self.client.poll_hud_commands()
            if res.get("success") and isinstance(res.get("commands"), list):
                for cmd in res["commands"]:
                    if isinstance(cmd, dict):
                        self._enqueue_unique_command(cmd)
            self.stop_event.wait(wait_s)

    def _screen_watch_loop(self) -> None:
        """Throttled /api/ui/tree sampler active ONLY while screenWatch mode is enabled."""
        while not self.stop_event.is_set():
            if self._screen_watch_active:
                tree_res = self.client.fetch_ui_tree()
                if tree_res.get("success", True) and (
                    tree_res.get("tree") or tree_res.get("nodes") or tree_res.get("uiTree")
                ):
                    current_vec = self.tracker.screen_watch.get("actionVector")
                    label = self.tracker.screen_watch.get("label") or "Screen Watch"
                    wf = extract_wireframe_from_ui_tree(tree_res, action_vector=current_vec, label=label)
                    payload = self.tracker.update_wireframe(wf)
                    self.client.push_hud_state(payload)
            self.stop_event.wait(1.2)

    def _worker_loop(self) -> None:
        while not self.stop_event.is_set():
            try:
                cmd = self.command_queue.get(timeout=0.5)
            except queue.Empty:
                continue
            action = str(cmd.get("action") or "PROMPT").upper()
            text = str(cmd.get("text") or "").strip()
            if action == "STOP":
                self.runner.stop_active()
                self._screen_watch_active = False
                self.client.push_hud_state(self.tracker.mark_stopped())
            elif text:
                payload = self.tracker.begin_prompt(text)
                self.client.push_hud_state(payload)
                self.runner.send_prompt(text)

    def run(self) -> None:
        print(
            f"[AgyHudDaemon] Connected target={self.client.base_url} | agy_mode={self.runner.resolved_mode}",
            flush=True,
        )
        # Initialize HUD to compact ready pill
        self.client.push_hud_state(self.tracker.to_payload())

        self.ws_listener.start()
        poll_thread = threading.Thread(target=self._poll_loop, name="agy-hud-poll", daemon=True)
        screen_thread = threading.Thread(target=self._screen_watch_loop, name="agy-screen-watch", daemon=True)
        worker_thread = threading.Thread(target=self._worker_loop, name="agy-worker", daemon=True)
        poll_thread.start()
        screen_thread.start()
        worker_thread.start()

        try:
            while not self.stop_event.is_set():
                time.sleep(0.5)
        except KeyboardInterrupt:
            print("\n[AgyHudDaemon] Shutting down HUD...", flush=True)
        finally:
            self.stop_event.set()
            self.ws_listener.stop()
            self.runner.stop_active()
            self.client.hide_hud()


def run_self_test() -> int:
    """
    Runs a complete local mock HTTP + RFC 6455 WebSocket integration test verifying:
    - Bearer auth enforcement & /api/hud/* JSON schemas
    - Real-time WebSocket HUD_COMMAND delivery + /api/hud/poll fallback deduplication
    - Checkbox step transitions (`done`, `doing`, `pending`, `needs_input`)
    - Compact 3-6 zone low-poly wireframe extraction + self-exclusion of `agy_hud_` nodes
    - Automatic collapse-to-pill payload on completion
    """
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

    state_history: List[Dict[str, Any]] = []
    poll_queue: List[Dict[str, Any]] = []
    ws_clients: List[socket.socket] = []
    test_token = "aura_test_token_12345"

    class MockKavachHandler(BaseHTTPRequestHandler):
        def log_message(self, format: str, *args: Any) -> None:
            return

        def _send_json(self, code: int, obj: Dict[str, Any]) -> None:
            raw = json.dumps(obj).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def _check_auth(self) -> bool:
            auth = self.headers.get("Authorization", "")
            parsed = urllib.parse.urlparse(self.path)
            q_tok = urllib.parse.parse_qs(parsed.query).get("token", [""])[0]
            return auth == f"Bearer {test_token}" or q_tok == test_token

        def do_GET(self) -> None:
            if not self._check_auth():
                self._send_json(401, {"success": False, "error": "UNAUTHORIZED_DEVICE"})
                return
            path = urllib.parse.urlparse(self.path).path
            if path == "/ws" and self.headers.get("Upgrade", "").lower() == "websocket":
                key = self.headers.get("Sec-WebSocket-Key", "").strip()
                accept = base64.b64encode(
                    hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode("utf-8")).digest()
                ).decode("ascii")
                resp = (
                    "HTTP/1.1 101 Switching Protocols\r\n"
                    "Upgrade: websocket\r\n"
                    "Connection: Upgrade\r\n"
                    f"Sec-WebSocket-Accept: {accept}\r\n\r\n"
                ).encode("utf-8")
                self.connection.sendall(resp)
                ws_clients.append(self.connection)
                # Keep socket open until test completes
                try:
                    self.connection.settimeout(3.0)
                    self.connection.recv(1024)
                except Exception:
                    pass
                return
            elif path == "/api/hud/poll":
                drained = list(poll_queue)
                poll_queue.clear()
                self._send_json(200, {"success": True, "count": len(drained), "commands": drained})
            elif path == "/api/ui/tree":
                self._send_json(
                    200,
                    {
                        "success": True,
                        "tree": {
                            "className": "android.widget.FrameLayout",
                            "bounds": "[0,0][1080,2400]",
                            "children": [
                                {
                                    "viewId": "com.example:id/agy_hud_window2",
                                    "contentDescription": "agy_hud_root",
                                    "text": "Should Be Filtered",
                                    "isClickable": True,
                                    "bounds": "[600,1900][1060,2350]",
                                },
                                {
                                    "className": "android.widget.EditText",
                                    "text": "Search settings",
                                    "isEditable": True,
                                    "isFocused": True,
                                    "bounds": "[60,180][1020,310]",
                                },
                                {
                                    "className": "android.widget.Button",
                                    "text": "Connect",
                                    "isClickable": True,
                                    "bounds": "[720,420][1000,520]",
                                },
                                {
                                    "className": "android.widget.TextView",
                                    "text": "Network",
                                    "isClickable": True,
                                    "bounds": "[60,600][520,720]",
                                },
                            ],
                        },
                    },
                )
            else:
                self._send_json(404, {"success": False})

        def do_POST(self) -> None:
            if not self._check_auth():
                self._send_json(401, {"success": False, "error": "UNAUTHORIZED_DEVICE"})
                return
            length = int(self.headers.get("Content-Length", "0"))
            body = json.loads(self.rfile.read(length).decode("utf-8") or "{}")
            path = urllib.parse.urlparse(self.path).path
            if path == "/api/hud/state":
                state_history.append(body)
                self._send_json(200, {"success": True, "state": body.get("state")})
            elif path == "/api/hud/command":
                cmd = {
                    "id": f"cmd_{uuid.uuid4().hex[:6]}",
                    "type": "HUD_COMMAND",
                    "text": body.get("text", ""),
                    "action": body.get("action", "PROMPT"),
                    "timestamp": int(time.time() * 1000),
                }
                poll_queue.append(cmd)
                # Push unmasked server WS text frame to any connected listener
                raw_frame = json.dumps(cmd).encode("utf-8")
                hdr = bytearray([0x81])
                if len(raw_frame) <= 125:
                    hdr.append(len(raw_frame))
                else:
                    hdr.append(126)
                    hdr.extend(struct.pack("!H", len(raw_frame)))
                for sock in list(ws_clients):
                    try:
                        sock.sendall(bytes(hdr) + raw_frame)
                    except Exception:
                        pass
                self._send_json(200, {"success": True, "command": cmd})
            elif path == "/api/hud/hide":
                self._send_json(200, {"success": True, "hudVisible": False})
            else:
                self._send_json(404, {"success": False})

    server = ThreadingHTTPServer(("127.0.0.1", 0), MockKavachHandler)
    port = server.server_address[1]
    srv_thread = threading.Thread(target=server.serve_forever, daemon=True)
    srv_thread.start()

    base_url = f"http://127.0.0.1:{port}"
    client = KavachHudClient(base_url, test_token)
    tracker = HudStateTracker(auto_collapse_seconds=4)

    # 1. Verify WebSocket real-time HUD_COMMAND delivery + poll deduplication
    received_ws: List[Dict[str, Any]] = []
    stop_evt = threading.Event()
    ws = StdlibWebSocketListener(base_url, test_token, received_ws.append, stop_evt)
    ws.start()
    time.sleep(0.25)
    assert ws.connected, "WebSocket failed to connect to mock KaVach server"

    cmd_res = client.send_hud_command({"action": "PROMPT", "text": "Open Wi-Fi settings"})
    assert cmd_res.get("success") is True
    time.sleep(0.2)
    assert len(received_ws) == 1 and received_ws[0]["text"] == "Open Wi-Fi settings", (
        f"Expected WS HUD_COMMAND delivery, got: {received_ws}"
    )

    poll_res = client.poll_hud_commands()
    assert poll_res.get("success") is True and poll_res.get("count") == 1

    # 2. Verify checkbox updates + screenWatch wireframe extraction + agy_hud_ self-exclusion
    client.push_hud_state(tracker.begin_prompt("Open Wi-Fi settings"))
    payload, sw_active = tracker.apply_agy_event(
        {
            "type": "update_steps",
            "steps": [
                {"id": "s1", "label": "Inspect screen", "status": "done"},
                {"id": "s2", "label": "Tap Connect button", "status": "doing"},
                {"id": "s3", "label": "Verify status", "status": "pending"},
            ],
        }
    )
    assert payload["tasks"][0]["status"] == "done"
    assert payload["tasks"][1]["status"] == "doing"
    assert not sw_active
    client.push_hud_state(payload)

    payload, sw_active = tracker.apply_agy_event(
        {
            "type": "tool_use",
            "name": "ui_action",
            "input": {"action": "TAP", "x": 860, "y": 470},
        }
    )
    assert sw_active is True
    assert payload["screenWatch"]["actionVector"]["type"] == "TAP"

    tree = client.fetch_ui_tree()
    wf = extract_wireframe_from_ui_tree(tree, action_vector=payload["screenWatch"]["actionVector"])
    assert wf["active"] is True
    assert 1 <= len(wf["zones"]) <= 6
    assert all("Should Be Filtered" not in z["tag"] for z in wf["zones"]), "HUD node leaked into wireframe!"
    assert any(z["role"] == "target" and z["tag"] == "Connect" for z in wf["zones"])
    client.push_hud_state(tracker.update_wireframe(wf))

    # 3. Verify NEEDS_INPUT escalation & DONE auto-collapse payload
    payload, sw_active = tracker.apply_agy_event({"type": "needs_input", "question": "Confirm Wi-Fi SSID?"})
    assert payload["state"] == "NEEDS_INPUT" and payload["question"] == "Confirm Wi-Fi SSID?" and not sw_active
    client.push_hud_state(payload)

    done_payload = tracker.mark_done("Connected to Wi-Fi")
    assert done_payload["state"] == "DONE"
    assert done_payload["autoCollapseSeconds"] == 4
    assert done_payload["screenWatch"]["active"] is False
    assert all(t["status"] == "done" for t in done_payload["tasks"])
    client.push_hud_state(done_payload)

    hide_res = client.hide_hud()
    assert hide_res.get("success") is True

    stop_evt.set()
    ws.stop()
    server.shutdown()
    server.server_close()

    print(
        f"SELF-TEST PASSED: {len(state_history)} HUD states verified, WS + poll delivery OK, "
        f"wireframe extracted {len(wf['zones'])} clean zones (agy_hud_ excluded)."
    )
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Termux-First Dual-Window Agy HUD Daemon")
    parser.add_argument("--url", default=DEFAULT_HTTP_URL, help="KaVach HTTP base URL (default: http://127.0.0.1:8080)")
    parser.add_argument("--token", default=None, help="Bearer token (defaults to ~/.aura_token)")
    parser.add_argument("--agy-bin", default="agy", help="Path or command name for agy CLI")
    parser.add_argument(
        "--mode",
        choices=("auto", "stream", "continue"),
        default="auto",
        help="Session mode: auto-detect stream-json with fallback to --continue",
    )
    parser.add_argument("--poll-interval", type=float, default=0.75, help="Fallback /api/hud/poll interval in seconds")
    parser.add_argument("--auto-collapse", type=int, default=4, help="Auto-collapse delay in seconds after DONE")
    parser.add_argument("--self-test", action="store_true", help="Run built-in mock HTTP/WS integration test")
    args = parser.parse_args()

    if args.self_test:
        return run_self_test()

    token = load_auth_token(args.token)
    if not token:
        print("[AgyHudDaemon] Warning: No ~/.aura_token found. Run `python send_cmd.py login` first if STRICT auth is enabled.", file=sys.stderr)

    daemon = AgyHudDaemon(
        base_url=args.url,
        token=token,
        agy_bin=args.agy_bin,
        mode=args.mode,
        poll_interval=args.poll_interval,
        auto_collapse_seconds=args.auto_collapse,
    )
    daemon.run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
