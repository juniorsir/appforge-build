package com.kavach.ui.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Compact low-poly miniature screen schematic (~96dp max dimension) for Agy HUD Window 2.
 * Collapses completely to 0dp height (GONE) when screenWatch.active == false.
 * Renders only the 3-6 selective key zones and animated tap/drag vectors.
 */
class MiniScreenWireframeView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var watchState: AgyHudOverlayManager.ScreenWatchState =
        AgyHudOverlayManager.ScreenWatchState()
    private var animPhase: Float = 0f
    private var isAnimating: Boolean = false

    private val density = context.resources.displayMetrics.density
    private val maxDimensionPx = (96f * density).toInt()
    private val minWidthPx = (48f * density).toInt()

    private val frameRect = RectF()
    private val zoneRect = RectF()
    private val arrowPath = Path()

    private val bezelFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#FFF8FAFC")
    }

    private val bezelStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f * density
        color = Color.parseColor("#FFCBD5E1")
    }

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 0.6f * density
        color = Color.parseColor("#FFE2E8F0")
    }

    private val zoneFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val zoneStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.1f * density
    }

    private val tagTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0F172A")
        textSize = 7.5f * density
        isFakeBoldText = true
    }

    private val vectorLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.8f * density
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#0095F6")
        pathEffect = DashPathEffect(floatArrayOf(4f * density, 2.5f * density), 0f)
    }

    private val vectorArrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#D97706")
    }

    private val pulseRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * density
        color = Color.parseColor("#0095F6")
    }

    private val pulseCorePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#D97706")
    }

    private val frameTickRunnable = object : Runnable {
        override fun run() {
            if (!isAnimating || visibility != VISIBLE || !isAttachedToWindow) {
                isAnimating = false
                return
            }
            animPhase = (animPhase + 0.045f) % 1f
            invalidate()
            postDelayed(this, 33L)
        }
    }

    init {
        tag = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}wireframe_view"
        contentDescription = "${AgyHudOverlayManager.HUD_NODE_TAG_PREFIX}wireframe_view"
        visibility = GONE
    }

    fun updateScreenWatch(state: AgyHudOverlayManager.ScreenWatchState, wireframeVisible: Boolean) {
        watchState = state
        val shouldShow = state.active && wireframeVisible
        val targetVisibility = if (shouldShow) VISIBLE else GONE
        if (visibility != targetVisibility) {
            visibility = targetVisibility
        }
        requestLayout()
        invalidate()
        syncAnimationState()
    }

    private fun syncAnimationState() {
        val needsAnim = visibility == VISIBLE && isAttachedToWindow && watchState.active && watchState.actionVector != null
        if (needsAnim && !isAnimating) {
            isAnimating = true
            removeCallbacks(frameTickRunnable)
            post(frameTickRunnable)
        } else if (!needsAnim && isAnimating) {
            isAnimating = false
            removeCallbacks(frameTickRunnable)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        syncAnimationState()
    }

    override fun onDetachedFromWindow() {
        isAnimating = false
        removeCallbacks(frameTickRunnable)
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        if (visibility == GONE || !watchState.active) {
            setMeasuredDimension(0, 0)
            return
        }
        val sw = watchState.screenWidth.coerceAtLeast(100).toFloat()
        val sh = watchState.screenHeight.coerceAtLeast(100).toFloat()
        val aspect = (sw / sh).coerceIn(0.38f, 2.2f)

        val targetW: Int
        val targetH: Int
        if (aspect <= 1f) {
            targetH = maxDimensionPx
            targetW = max(minWidthPx, (maxDimensionPx * aspect).toInt())
        } else {
            targetW = maxDimensionPx
            targetH = max(minWidthPx, (maxDimensionPx / aspect).toInt())
        }
        setMeasuredDimension(
            resolveSize(targetW, widthMeasureSpec),
            resolveSize(targetH, heightMeasureSpec)
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!watchState.active || width <= 4 || height <= 4) return

        val pad = 2f * density
        frameRect.set(pad, pad, width - pad, height - pad)
        val bezelRadius = 10f * density

        // Crisp frosted miniature frame
        bezelStrokePaint.shader = LinearGradient(
            frameRect.left,
            frameRect.top,
            frameRect.right,
            frameRect.bottom,
            intArrayOf(
                Color.parseColor("#FFCBD5E1"),
                Color.parseColor("#FF94A3B8")
            ),
            null,
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(frameRect, bezelRadius, bezelRadius, bezelFillPaint)
        canvas.drawRoundRect(frameRect, bezelRadius, bezelRadius, bezelStrokePaint)

        // Subtle low-poly schematic guide lines (3x3 crosshair grid)
        val innerLeft = frameRect.left + 3f * density
        val innerTop = frameRect.top + 3f * density
        val innerW = (frameRect.width() - 6f * density).coerceAtLeast(1f)
        val innerH = (frameRect.height() - 6f * density).coerceAtLeast(1f)
        for (i in 1..2) {
            val gx = innerLeft + innerW * (i / 3f)
            val gy = innerTop + innerH * (i / 3f)
            canvas.drawLine(gx, innerTop, gx, innerTop + innerH, gridPaint)
            canvas.drawLine(innerLeft, gy, innerLeft + innerW, gy, gridPaint)
        }

        val sw = watchState.screenWidth.coerceAtLeast(1).toFloat()
        val sh = watchState.screenHeight.coerceAtLeast(1).toFloat()

        fun mapX(px: Float): Float = innerLeft + (px / sw).coerceIn(0f, 1f) * innerW
        fun mapY(py: Float): Float = innerTop + (py / sh).coerceAtLeast(0f).coerceAtMost(1f) * innerH

        // Draw ONLY the selective key zones (capped to 8 max for ultra-clean low-poly clarity)
        for (zone in watchState.zones.take(8)) {
            val left = mapX(min(zone.x1, zone.x2))
            val top = mapY(min(zone.y1, zone.y2))
            val right = max(left + 3f * density, mapX(max(zone.x1, zone.x2)))
            val bottom = max(top + 3f * density, mapY(max(zone.y1, zone.y2)))
            zoneRect.set(left, top, right, bottom)

            val roleLower = zone.role.lowercase()
            val (strokeCol, fillCol) = when {
                roleLower.contains("target") || roleLower.contains("focus") || roleLower.contains("cta") ->
                    Color.parseColor("#D97706") to Color.parseColor("#2EE69A12")
                roleLower.contains("button") || roleLower.contains("input") || roleLower.contains("action") ->
                    Color.parseColor("#0095F6") to Color.parseColor("#240095F6")
                else ->
                    Color.parseColor("#94A3B8") to Color.parseColor("#1A64748B")
            }

            zoneFillPaint.color = fillCol
            zoneStrokePaint.color = strokeCol
            val zRadius = 3f * density
            canvas.drawRoundRect(zoneRect, zRadius, zRadius, zoneFillPaint)
            canvas.drawRoundRect(zoneRect, zRadius, zRadius, zoneStrokePaint)

            // Draw miniature label tag if zone is large enough
            val cleanTag = zone.tag.trim()
            if (cleanTag.isNotEmpty() && zoneRect.height() >= 10f * density && zoneRect.width() >= 18f * density) {
                val shortTag = if (cleanTag.length > 7) cleanTag.take(6) + "…" else cleanTag
                canvas.drawText(
                    shortTag,
                    zoneRect.left + 2f * density,
                    zoneRect.top + min(zoneRect.height() - 2f * density, 8.5f * density),
                    tagTextPaint
                )
            }
        }

        // Draw animated tap / drag action vector
        watchState.actionVector?.let { vec ->
            val sx = mapX(vec.x1)
            val sy = mapY(vec.y1)
            val typeUpper = vec.type.uppercase()
            if (typeUpper == "SWIPE" || typeUpper == "DRAG") {
                val ex = mapX(vec.x2)
                val ey = mapY(vec.y2)
                canvas.drawLine(sx, sy, ex, ey, vectorLinePaint)

                // Arrowhead at destination
                val angle = atan2((ey - sy).toDouble(), (ex - sx).toDouble())
                val headLen = 5.5f * density
                arrowPath.reset()
                arrowPath.moveTo(ex, ey)
                arrowPath.lineTo(
                    (ex - headLen * cos(angle - 0.5)).toFloat(),
                    (ey - headLen * sin(angle - 0.5)).toFloat()
                )
                arrowPath.lineTo(
                    (ex - headLen * cos(angle + 0.5)).toFloat(),
                    (ey - headLen * sin(angle + 0.5)).toFloat()
                )
                arrowPath.close()
                canvas.drawPath(arrowPath, vectorArrowPaint)

                // Traveling pulse bead along vector
                val bx = sx + (ex - sx) * animPhase
                val by = sy + (ey - sy) * animPhase
                pulseCorePaint.color = Color.parseColor("#38BDF8")
                canvas.drawCircle(bx, by, 2.8f * density, pulseCorePaint)
                pulseRingPaint.alpha = ((1f - animPhase) * 200f).toInt().coerceIn(30, 220)
                canvas.drawCircle(bx, by, (3.2f + animPhase * 3.5f) * density, pulseRingPaint)
            } else {
                // TAP / CLICK / LONG_PRESS pulsing target reticle
                val ringRadius = (2.5f + animPhase * 7.5f) * density
                pulseRingPaint.color = Color.parseColor("#38BDF8")
                pulseRingPaint.alpha = ((1f - animPhase) * 230f).toInt().coerceIn(20, 230)
                canvas.drawCircle(sx, sy, ringRadius, pulseRingPaint)
                pulseCorePaint.color = Color.parseColor("#F59E0B")
                canvas.drawCircle(sx, sy, 2.6f * density, pulseCorePaint)
            }
        }
    }
}
