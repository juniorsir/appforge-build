package com.kavach.ui.overlay

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Termux-First Dual-Window Agy HUD Overlay Manager.
 *
 * Manages two coordinated Dark Obsidian Liquid Glass overlays integrated with FloatingOverlayManager:
 * 1. Window 1 (`agy_input`): Floating interactive command/prompt input bar with dynamic Termux-safe
 *    `FLAG_NOT_FOCUSABLE` keyboard handoff (Termux keeps IME focus until user taps EditText, and
 *    regains focus immediately on Send, Stop, outside touch, or collapse).
 * 2. Window 2 (`agy_hud`): Draggable live Task & Screen HUD with Expanded mode (status dot, opacity
 *    cycle 90%/65%/35%, wireframe toggle, ghost touch-through toggle, live CheckBox task list,
 *    MiniScreenWireframeView) and Collapsed mode (`✓ Agy • Done | 💬 Ask / Task` pill).
 *
 * All views are tagged with `agy_hud_` for self-exclusion in AccessibilityRepositoryImpl, and
 * bounding boxes are exposed for temporary `FLAG_NOT_TOUCHABLE` collision pass-through.
 */
class AgyHudOverlayManager(
    private val context: Context,
    private val floatingOverlayManager: FloatingOverlayManager,
    private val onCommandBroadcast: ((JSONObject) -> Unit)? = null
) {
    companion object {
        private const val TAG = "AgyHudOverlayManager"
        const val HUD_NODE_TAG_PREFIX = "agy_hud_"
        private const val MAX_QUEUED_COMMANDS = 64

        val OPACITY_LEVELS = floatArrayOf(0.90f, 0.65f, 0.35f)

        // Frosted Crisp Light Glass Palette (unified with main app Crisp Light Mode)
        private val COLOR_OBSIDIAN_GLASS = Color.parseColor("#F2FFFFFF")
        private val COLOR_PILL_INPUT_BG = Color.parseColor("#FFF1F5F9")
        private val COLOR_INNER_CAPSULE = Color.parseColor("#FFF1F5F9")
        private val COLOR_HAIRLINE = Color.parseColor("#FFE2E8F0")
        private val COLOR_CYAN = Color.parseColor("#0095F6")
        private val COLOR_VIOLET = Color.parseColor("#4F46E5")
        private val COLOR_EMERALD = Color.parseColor("#16A34A")
        private val COLOR_AMBER = Color.parseColor("#D97706")
        private val COLOR_CORAL = Color.parseColor("#E11D48")
        private val COLOR_TEXT_PRIMARY = Color.parseColor("#0F172A")
        private val COLOR_TEXT_SECONDARY = Color.parseColor("#64748B")
    }

    data class AgyHudTask(
        val id: String,
        val label: String,
        val status: String = "pending" // done | doing | pending | needs_input
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("id", id)
            put("label", label)
            put("status", status)
        }
    }

    data class WireframeZone(
        val x1: Float,
        val y1: Float,
        val x2: Float,
        val y2: Float,
        val role: String = "panel",
        val tag: String = ""
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("x1", x1.toDouble())
            put("y1", y1.toDouble())
            put("x2", x2.toDouble())
            put("y2", y2.toDouble())
            put("role", role)
            put("tag", tag)
        }
    }

    data class WireframeActionVector(
        val type: String = "TAP", // TAP | CLICK | SWIPE | DRAG
        val x1: Float,
        val y1: Float,
        val x2: Float = x1,
        val y2: Float = y1
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("type", type)
            put("x1", x1.toDouble())
            put("y1", y1.toDouble())
            put("x2", x2.toDouble())
            put("y2", y2.toDouble())
        }
    }

    data class ScreenWatchState(
        val active: Boolean = false,
        val label: String = "",
        val screenWidth: Int = 1080,
        val screenHeight: Int = 2400,
        val zones: List<WireframeZone> = emptyList(),
        val actionVector: WireframeActionVector? = null
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("active", active)
            put("label", label)
            put("screenWidth", screenWidth)
            put("screenHeight", screenHeight)
            put("zones", JSONArray().apply { zones.forEach { put(it.toJson()) } })
            if (actionVector != null) put("actionVector", actionVector.toJson())
        }
    }

    data class AgyHudState(
        val state: String = "IDLE", // IDLE | WORKING | NEEDS_INPUT | DONE
        val title: String = "Agy Ready",
        val currentAction: String = "",
        val nextAction: String = "",
        val question: String = "",
        val autoCollapseSeconds: Int = 4,
        val tasks: List<AgyHudTask> = emptyList(),
        val screenWatch: ScreenWatchState = ScreenWatchState()
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("state", state)
            put("title", title)
            put("currentAction", currentAction)
            put("nextAction", nextAction)
            put("question", question)
            put("autoCollapseSeconds", autoCollapseSeconds)
            put("tasks", JSONArray().apply { tasks.forEach { put(it.toJson()) } })
            put("screenWatch", screenWatch.toJson())
        }
    }

    data class HudCommand(
        val id: String = "cmd_${UUID.randomUUID().toString().take(8)}",
        val type: String = "HUD_COMMAND",
        val text: String,
        val action: String = "PROMPT", // PROMPT | STOP
        val timestamp: Long = System.currentTimeMillis()
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("id", id)
            put("type", type)
            put("text", text)
            put("action", action)
            put("timestamp", timestamp)
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val windowManager: WindowManager? by lazy {
        context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
    }
    private val inputMethodManager: InputMethodManager? by lazy {
        context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
    }

    private val commandQueue = ConcurrentLinkedQueue<HudCommand>()

    private val _isHudVisible = MutableStateFlow(false)
    val isHudVisible: StateFlow<Boolean> = _isHudVisible.asStateFlow()

    private val _isInputVisible = MutableStateFlow(false)
    val isInputVisible: StateFlow<Boolean> = _isInputVisible.asStateFlow()

    private val _hudState = MutableStateFlow(AgyHudState())
    val hudState: StateFlow<AgyHudState> = _hudState.asStateFlow()

    private val _isCollapsedFlow = MutableStateFlow(true)
    val isCollapsedFlow: StateFlow<Boolean> = _isCollapsedFlow.asStateFlow()

    private val _opacityFlow = MutableStateFlow(OPACITY_LEVELS[0])
    val opacityFlow: StateFlow<Float> = _opacityFlow.asStateFlow()

    private val _ghostPassThroughFlow = MutableStateFlow(false)
    val ghostPassThroughFlow: StateFlow<Boolean> = _ghostPassThroughFlow.asStateFlow()

    private val _wireframeEnabledFlow = MutableStateFlow(true)
    val wireframeEnabledFlow: StateFlow<Boolean> = _wireframeEnabledFlow.asStateFlow()

    @Volatile
    private var isCollapsed: Boolean = true
        set(value) {
            field = value
            _isCollapsedFlow.value = value
        }
    @Volatile
    private var opacityIndex: Int = 0
        set(value) {
            field = value
            _opacityFlow.value = OPACITY_LEVELS[value.coerceIn(0, OPACITY_LEVELS.lastIndex)]
        }
    @Volatile
    private var wireframeEnabled: Boolean = true
        set(value) {
            field = value
            _wireframeEnabledFlow.value = value
        }
    @Volatile
    private var ghostPassThrough: Boolean = false
        set(value) {
            field = value
            _ghostPassThroughFlow.value = value
        }
    @Volatile
    private var isInputFocused: Boolean = false
    @Volatile
    private var temporaryPassThroughActive: Boolean = false

    // Window 2 (agy_hud) references
    private var hudRootView: FrameLayout? = null
    private var hudParams: WindowManager.LayoutParams? = null
    private var hudExpandedContainer: LinearLayout? = null
    private var hudCollapsedPill: LinearLayout? = null
    private var statusDotView: View? = null
    private var statusBadgeText: TextView? = null
    private var titleText: TextView? = null
    private var questionBannerText: TextView? = null
    private var currentActionText: TextView? = null
    private var nextActionText: TextView? = null
    private var taskListContainer: LinearLayout? = null
    private var taskScrollView: ScrollView? = null
    private var wireframeContainer: LinearLayout? = null
    private var wireframeLabelText: TextView? = null
    private var wireframeView: MiniScreenWireframeView? = null
    private var opacityBtn: TextView? = null
    private var wireframeBtn: TextView? = null
    private var ghostBtn: TextView? = null
    private var collapsedStatusText: TextView? = null

    // Tiny ghost restore pill (only visible while ghost mode is ON so user can exit ghost mode)
    private var ghostRestoreView: View? = null
    private var ghostRestoreParams: WindowManager.LayoutParams? = null

    // Window 1 (agy_input) references
    private var inputRootView: LinearLayout? = null
    private var inputParams: WindowManager.LayoutParams? = null
    private var inputEditText: EditText? = null
    private var pasteClearBtn: TextView? = null

    // Scheduled tasks
    private var autoCollapseRunnable: Runnable? = null
    private var passThroughRestoreRunnable: Runnable? = null
    private var pulseRunnable: Runnable? = null
    private var pulseToggle: Boolean = false

    fun hasOverlayPermission(): Boolean = floatingOverlayManager.hasPermission()

    fun getOverlayPermissionIntent(): Intent? = floatingOverlayManager.getPermissionIntent()

    fun parseHudStateFromJson(json: JSONObject): AgyHudState {
        val current = _hudState.value
        val state = json.optString("state", current.state).uppercase().trim()
            .let { if (it in listOf("IDLE", "WORKING", "NEEDS_INPUT", "DONE")) it else "WORKING" }
        val title = if (json.has("title")) json.optString("title", "") else current.title
        val currentAction = if (json.has("currentAction")) json.optString("currentAction", "") else current.currentAction
        val nextAction = if (json.has("nextAction")) json.optString("nextAction", "") else current.nextAction
        val question = if (json.has("question")) json.optString("question", "") else if (state != "NEEDS_INPUT") "" else current.question
        val autoCollapse = json.optInt("autoCollapseSeconds", current.autoCollapseSeconds).coerceIn(0, 120)

        val tasks = if (json.has("tasks")) {
            val arr = json.optJSONArray("tasks") ?: JSONArray()
            val list = mutableListOf<AgyHudTask>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                list.add(
                    AgyHudTask(
                        id = obj.optString("id", "t_$i"),
                        label = obj.optString("label", "").trim(),
                        status = obj.optString("status", "pending").lowercase().trim()
                    )
                )
            }
            list
        } else {
            current.tasks
        }

        val screenWatch = if (json.has("screenWatch")) {
            val swObj = json.optJSONObject("screenWatch")
            if (swObj != null) {
                val zonesArr = swObj.optJSONArray("zones") ?: JSONArray()
                val zones = mutableListOf<WireframeZone>()
                for (i in 0 until zonesArr.length()) {
                    val z = zonesArr.optJSONObject(i) ?: continue
                    zones.add(
                        WireframeZone(
                            x1 = z.optDouble("x1", 0.0).toFloat(),
                            y1 = z.optDouble("y1", 0.0).toFloat(),
                            x2 = z.optDouble("x2", 0.0).toFloat(),
                            y2 = z.optDouble("y2", 0.0).toFloat(),
                            role = z.optString("role", "panel"),
                            tag = z.optString("tag", "")
                        )
                    )
                }
                val avObj = swObj.optJSONObject("actionVector")
                val actionVec = if (avObj != null) {
                    WireframeActionVector(
                        type = avObj.optString("type", "TAP").uppercase(),
                        x1 = avObj.optDouble("x1", 0.0).toFloat(),
                        y1 = avObj.optDouble("y1", 0.0).toFloat(),
                        x2 = avObj.optDouble("x2", avObj.optDouble("x1", 0.0)).toFloat(),
                        y2 = avObj.optDouble("y2", avObj.optDouble("y1", 0.0)).toFloat()
                    )
                } else null

                ScreenWatchState(
                    active = swObj.optBoolean("active", false),
                    label = swObj.optString("label", ""),
                    screenWidth = swObj.optInt("screenWidth", context.resources.displayMetrics.widthPixels.coerceAtLeast(360)),
                    screenHeight = swObj.optInt("screenHeight", context.resources.displayMetrics.heightPixels.coerceAtLeast(640)),
                    zones = zones,
                    actionVector = actionVec
                )
            } else {
                ScreenWatchState(active = false)
            }
        } else {
            current.screenWatch
        }

        return AgyHudState(
            state = state,
            title = title.ifBlank { "Agy HUD" },
            currentAction = currentAction,
            nextAction = nextAction,
            question = question,
            autoCollapseSeconds = autoCollapse,
            tasks = tasks,
            screenWatch = screenWatch
        )
    }

    /**
     * Handles POST /api/hud/state. Updates in-memory state immediately and renders Window 2 / Window 1.
     */
    fun updateState(json: JSONObject): JSONObject {
        val nextState = parseHudStateFromJson(json)
        _hudState.value = nextState

        val hasPerm = hasOverlayPermission()
        when (nextState.state) {
            "WORKING" -> {
                isCollapsed = false
            }
            "NEEDS_INPUT" -> {
                isCollapsed = false
                if (!hasPerm) _isInputVisible.value = true
            }
            "DONE", "IDLE" -> {
                if (nextState.autoCollapseSeconds <= 0) {
                    isCollapsed = true
                    if (!hasPerm) _isInputVisible.value = false
                }
            }
        }

        if (hasPerm) {
            runOnMain {
                ensureHudWindowAttached()
                when (nextState.state) {
                    "WORKING" -> {
                        cancelAutoCollapse()
                        isCollapsed = false
                    }
                    "NEEDS_INPUT" -> {
                        cancelAutoCollapse()
                        isCollapsed = false
                        showInputWindowInternal(requestKeyboardFocus = true)
                    }
                    "DONE", "IDLE" -> {
                        if (nextState.autoCollapseSeconds > 0) {
                            scheduleAutoCollapse(nextState.autoCollapseSeconds)
                        } else {
                            isCollapsed = true
                            hideInputWindowInternal()
                        }
                    }
                }
                renderHudWindow()
                syncPulseAnimation()
            }
        } else if ((nextState.state == "DONE" || nextState.state == "IDLE") && nextState.autoCollapseSeconds > 0) {
            runOnMain { scheduleAutoCollapse(nextState.autoCollapseSeconds) }
        }

        return JSONObject().apply {
            put("success", true)
            put("overlayRendered", hasPerm)
            if (!hasPerm) {
                put("permissionRequired", true)
                put("warning", "SYSTEM_ALERT_WINDOW not granted; HUD state stored in memory only.")
            }
            put("state", nextState.state)
            put("hudVisible", _isHudVisible.value)
            put("inputVisible", _isInputVisible.value)
            put("collapsed", isCollapsed)
            put("taskCount", nextState.tasks.size)
            put("screenWatchActive", nextState.screenWatch.active)
        }
    }

    /**
     * Shows the compact HUD pill (or expands it) directly from the in-app Settings toggle.
     */
    fun showCompactPill(): Boolean {
        if (!hasOverlayPermission()) return false
        runOnMain {
            isCollapsed = true
            ensureHudWindowAttached()
            renderHudWindow()
        }
        return true
    }

    /**
     * Handles POST /api/hud/command:
     * - action = PROMPT / STOP: enqueues command + broadcasts HUD_COMMAND via WebSocket
     * - action = OPEN_INPUT / CLOSE_INPUT / EXPAND / COLLAPSE / TOGGLE_GHOST / CYCLE_OPACITY
     */
    fun handleRemoteCommand(json: JSONObject): JSONObject {
        val action = json.optString("action", "PROMPT").uppercase().trim()
        val text = json.optString("text", json.optString("prompt", "")).trim()
        val result = JSONObject()

        when (action) {
            "OPEN_INPUT" -> {
                val autoFocus = json.optBoolean("focus", true)
                if (!hasOverlayPermission()) {
                    _isInputVisible.value = true
                    return result.put("success", true).put("action", action)
                        .put("inputVisible", true).put("sandboxOnly", true)
                }
                runOnMain {
                    ensureHudWindowAttached()
                    showInputWindowInternal(requestKeyboardFocus = autoFocus)
                    renderHudWindow()
                }
                result.put("success", true).put("action", action).put("inputVisible", true)
            }
            "CLOSE_INPUT" -> {
                runOnMain { hideInputWindowInternal() }
                _isInputVisible.value = false
                result.put("success", true).put("action", action).put("inputVisible", false)
            }
            "EXPAND" -> {
                cancelAutoCollapse()
                isCollapsed = false
                if (hasOverlayPermission()) {
                    runOnMain {
                        ensureHudWindowAttached()
                        renderHudWindow()
                    }
                }
                result.put("success", true).put("action", action).put("collapsed", false)
            }
            "COLLAPSE" -> {
                isCollapsed = true
                runOnMain {
                    hideInputWindowInternal()
                    if (hudRootView != null) renderHudWindow()
                }
                result.put("success", true).put("action", action).put("collapsed", true)
            }
            "TOGGLE_GHOST" -> {
                val enabled = if (json.has("enabled")) json.optBoolean("enabled") else !ghostPassThrough
                runOnMain { setGhostModeInternal(enabled) }
                result.put("success", true).put("action", action).put("ghostPassThrough", enabled)
            }
            "TOGGLE_WIREFRAME" -> {
                val enabled = if (json.has("enabled")) json.optBoolean("enabled") else !wireframeEnabled
                wireframeEnabled = enabled
                runOnMain { if (hudRootView != null) renderHudWindow() }
                result.put("success", true).put("action", action).put("wireframeEnabled", enabled)
            }
            "CYCLE_OPACITY" -> {
                runOnMain { cycleOpacityInternal() }
                result.put("success", true).put("action", action)
                    .put("opacity", OPACITY_LEVELS[opacityIndex].toDouble())
            }
            "STOP" -> {
                val cmd = enqueueAndBroadcastCommand(text = text.ifBlank { "STOP" }, action = "STOP")
                result.put("success", true).put("command", cmd.toJson())
            }
            else -> {
                if (text.isEmpty()) {
                    return result.put("success", false).put("error", "Missing 'text' for PROMPT command")
                }
                val cmd = enqueueAndBroadcastCommand(text = text, action = "PROMPT")
                result.put("success", true).put("command", cmd.toJson())
            }
        }
        return result
    }

    /**
     * Enqueues a HUD_COMMAND into the thread-safe queue for GET /api/hud/poll and immediately
     * pushes it to connected WebSocket clients.
     */
    fun enqueueAndBroadcastCommand(text: String, action: String = "PROMPT"): HudCommand {
        val normalizedAction = if (action.equals("STOP", ignoreCase = true)) "STOP" else "PROMPT"
        val cmd = HudCommand(text = text, action = normalizedAction)
        while (commandQueue.size >= MAX_QUEUED_COMMANDS) {
            commandQueue.poll()
        }
        commandQueue.offer(cmd)
        try {
            onCommandBroadcast?.invoke(cmd.toJson())
        } catch (e: Exception) {
            Log.w(TAG, "Failed broadcasting HUD_COMMAND: ${e.message}")
        }
        return cmd
    }

    /**
     * Handles GET /api/hud/poll: atomically drains all pending commands typed in Window 1.
     */
    fun pollCommands(): JSONObject {
        val drained = JSONArray()
        while (true) {
            val next = commandQueue.poll() ?: break
            drained.put(next.toJson())
        }
        return JSONObject().apply {
            put("success", true)
            put("count", drained.length())
            put("commands", drained)
            put("hudVisible", _isHudVisible.value)
            put("inputVisible", _isInputVisible.value)
            put("collapsed", isCollapsed)
            put("state", _hudState.value.state)
            put("ghostPassThrough", ghostPassThrough)
            put("opacity", OPACITY_LEVELS[opacityIndex].toDouble())
        }
    }

    /**
     * Handles POST /api/hud/hide: dismisses both HUD windows cleanly and cancels timers.
     */
    fun hideAll(): JSONObject {
        runOnMain {
            cancelAutoCollapse()
            stopPulseAnimation()
            passThroughRestoreRunnable?.let { mainHandler.removeCallbacks(it) }
            temporaryPassThroughActive = false
            ghostPassThrough = false
            hideGhostRestorePillInternal()
            hideInputWindowInternal()
            hudRootView?.let { view ->
                try {
                    windowManager?.removeView(view)
                } catch (e: Exception) {
                    Log.w(TAG, "Error removing agy_hud: ${e.message}")
                }
            }
            hudRootView = null
            hudParams = null
            _isHudVisible.value = false
        }
        return JSONObject().apply {
            put("success", true)
            put("hudVisible", false)
            put("inputVisible", false)
        }
    }

    // -------------------------------------------------------------------------
    // Touch Collision Pass-Through Helpers (called by DeviceBridgeManager)
    // -------------------------------------------------------------------------

    fun getOverlayBounds(): List<Rect> {
        val rects = mutableListOf<Rect>()
        val screenW = context.resources.displayMetrics.widthPixels.coerceAtLeast(1080)
        val screenH = context.resources.displayMetrics.heightPixels.coerceAtLeast(1920)

        fun collectRect(view: View?, params: WindowManager.LayoutParams?) {
            if (view == null || params == null) return
            val loc = IntArray(2)
            view.getLocationOnScreen(loc)
            val w = view.width.takeIf { it > 0 } ?: (260 * density()).toInt()
            val h = view.height.takeIf { it > 0 } ?: (96 * density()).toInt()
            val left = if (loc[0] != 0 || loc[1] != 0) {
                loc[0]
            } else if ((params.gravity and Gravity.END) == Gravity.END || (params.gravity and Gravity.RIGHT) == Gravity.RIGHT) {
                (screenW - params.x - w).coerceAtLeast(0)
            } else {
                params.x.coerceAtLeast(0)
            }
            val top = if (loc[0] != 0 || loc[1] != 0) {
                loc[1]
            } else if ((params.gravity and Gravity.BOTTOM) == Gravity.BOTTOM) {
                (screenH - params.y - h).coerceAtLeast(0)
            } else {
                params.y.coerceAtLeast(0)
            }
            rects.add(Rect(left, top, left + w, top + h))
        }

        collectRect(hudRootView, hudParams)
        collectRect(inputRootView, inputParams)
        collectRect(ghostRestoreView, ghostRestoreParams)
        return rects
    }

    fun coordinatesOverlapRects(
        x1: Float,
        y1: Float,
        x2: Float = x1,
        y2: Float = y1,
        rects: List<Rect>
    ): Boolean {
        if (rects.isEmpty()) return false
        val segRect = Rect(
            min(x1, x2).toInt(),
            min(y1, y2).toInt(),
            max(x1, x2).toInt() + 1,
            max(y1, y2).toInt() + 1
        )
        return rects.any { r ->
            r.contains(x1.toInt(), y1.toInt()) ||
                r.contains(x2.toInt(), y2.toInt()) ||
                Rect.intersects(r, segRect)
        }
    }

    /**
     * Checks if a gesture (TAP/SWIPE/DRAG) overlaps agy_hud or agy_input; if so, temporarily
     * applies FLAG_NOT_TOUCHABLE for ~durationMs (default 300ms) so touch passes directly underneath.
     */
    fun temporarilyPassThroughIfColliding(
        x1: Float,
        y1: Float,
        x2: Float = x1,
        y2: Float = y1,
        durationMs: Long = 300L
    ): Boolean {
        if (!_isHudVisible.value && !_isInputVisible.value) return false
        val bounds = getOverlayBounds()
        if (!coordinatesOverlapRects(x1, y1, x2, y2, bounds)) return false

        val safeDuration = durationMs.coerceIn(250L, 2500L)
        val latch = CountDownLatch(1)
        val applyTask = Runnable {
            try {
                temporaryPassThroughActive = true
                applyTouchableFlagsInternal(touchable = false)
                passThroughRestoreRunnable?.let { mainHandler.removeCallbacks(it) }
                val restore = Runnable {
                    temporaryPassThroughActive = false
                    if (!ghostPassThrough) {
                        applyTouchableFlagsInternal(touchable = true)
                    }
                }
                passThroughRestoreRunnable = restore
                mainHandler.postDelayed(restore, safeDuration)
            } finally {
                latch.countDown()
            }
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            applyTask.run()
        } else {
            mainHandler.post(applyTask)
            try {
                latch.await(150L, TimeUnit.MILLISECONDS)
            } catch (_: InterruptedException) {}
        }
        return true
    }

    // -------------------------------------------------------------------------
    // Window 2: Live Task & Screen HUD (`agy_hud`)
    // -------------------------------------------------------------------------

    private fun ensureHudWindowAttached() {
        if (hudRootView != null) {
            _isHudVisible.value = true
            return
        }
        val wm = windowManager ?: return
        val d = density()

        val root = FrameLayout(context)
        val expanded = buildExpandedHudCard(d)
        val collapsed = buildCollapsedHudPill(d)
        root.addView(expanded)
        root.addView(collapsed)
        tagTreeForSelfExclusion(root, "window2")

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            x = (14 * d).toInt()
            y = (28 * d).toInt()
        }

        hudRootView = root
        hudParams = params
        hudExpandedContainer = expanded
        hudCollapsedPill = collapsed

        attachBottomRightDragListener(expanded, params) { hudRootView }
        attachBottomRightDragListener(collapsed, params) { hudRootView }

        try {
            wm.addView(root, params)
            _isHudVisible.value = true
        } catch (e: Exception) {
            Log.e(TAG, "Failed adding agy_hud window: ${e.message}")
            hudRootView = null
            hudParams = null
            _isHudVisible.value = false
        }
    }

    private fun buildExpandedHudCard(d: Float): LinearLayout {
        val cardWidthPx = min((276 * d).toInt(), (context.resources.displayMetrics.widthPixels * 0.84f).toInt())
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(cardWidthPx, ViewGroup.LayoutParams.WRAP_CONTENT)
            setPadding((14 * d).toInt(), (11 * d).toInt(), (14 * d).toInt(), (12 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = COLOR_OBSIDIAN_GLASS,
                strokeColor = COLOR_CYAN,
                radiusDp = 28f
            )
            elevation = 10f * d
        }

        // Draggable Header Bar
        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val dot = View(context).apply {
            val sz = (9 * d).toInt()
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginEnd = (7 * d).toInt() }
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(COLOR_CYAN)
            }
        }
        statusDotView = dot

        val badge = TextView(context).apply {
            text = "AGY • IDLE"
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(COLOR_CYAN)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        statusBadgeText = badge

        fun headerControlChip(symbol: String, desc: String, onClick: () -> Unit): TextView {
            return TextView(context).apply {
                text = symbol
                textSize = 11.5f
                gravity = Gravity.CENTER
                setTextColor(COLOR_TEXT_PRIMARY)
                val sz = (26 * d).toInt()
                layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginStart = (4 * d).toInt() }
                background = createLiquidGlassDrawable(
                    fillColor = COLOR_INNER_CAPSULE,
                    strokeColor = Color.parseColor("#4438BDF8"),
                    radiusDp = 999f,
                    strokeDp = 0.8f
                )
                contentDescription = "${HUD_NODE_TAG_PREFIX}$desc"
                setOnClickListener { onClick() }
            }
        }

        val opBtn = headerControlChip("◐", "opacity_btn") { cycleOpacityInternal() }
        opacityBtn = opBtn
        val wfBtn = headerControlChip("👁", "wireframe_toggle_btn") {
            wireframeEnabled = !wireframeEnabled
            renderHudWindow()
        }
        wireframeBtn = wfBtn
        val ghBtn = headerControlChip("👻", "ghost_toggle_btn") {
            setGhostModeInternal(!ghostPassThrough)
        }
        ghostBtn = ghBtn
        val chatBtn = headerControlChip("💬", "open_input_btn") {
            if (_isInputVisible.value) {
                hideInputWindowInternal()
            } else {
                showInputWindowInternal(requestKeyboardFocus = true)
            }
        }
        val collapseBtn = headerControlChip("─", "collapse_btn") {
            isCollapsed = true
            hideInputWindowInternal()
            renderHudWindow()
        }

        header.addView(dot)
        header.addView(badge)
        header.addView(opBtn)
        header.addView(wfBtn)
        header.addView(ghBtn)
        header.addView(chatBtn)
        header.addView(collapseBtn)
        container.addView(header)

        // Task Title
        val titleTv = TextView(context).apply {
            text = "Agy Ready"
            textSize = 13f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_TEXT_PRIMARY)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (6 * d).toInt() }
        }
        titleText = titleTv
        container.addView(titleTv)

        // Pulsing Question Prompt Banner (visible on NEEDS_INPUT)
        val questionTv = TextView(context).apply {
            textSize = 11f
            setTextColor(COLOR_AMBER)
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setPadding((10 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#2EF59E0B"),
                strokeColor = COLOR_AMBER,
                radiusDp = 16f,
                strokeDp = 1f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (6 * d).toInt() }
            visibility = View.GONE
            setOnClickListener { showInputWindowInternal(requestKeyboardFocus = true) }
        }
        questionBannerText = questionTv
        container.addView(questionTv)

        // Doing Now + Will Do Next lines
        val doingTv = TextView(context).apply {
            textSize = 10.5f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_CYAN)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (5 * d).toInt() }
            visibility = View.GONE
        }
        currentActionText = doingTv
        container.addView(doingTv)

        val nextTv = TextView(context).apply {
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_TEXT_SECONDARY)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (2 * d).toInt() }
            visibility = View.GONE
        }
        nextActionText = nextTv
        container.addView(nextTv)

        // CheckBox Task List Container inside compact ScrollView
        val tasksLayout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        taskListContainer = tasksLayout

        val scroll = ScrollView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (6 * d).toInt() }
            isVerticalScrollBarEnabled = false
            addView(tasksLayout)
            visibility = View.GONE
        }
        taskScrollView = scroll
        container.addView(scroll)

        // Mini Low-Poly Screen Wireframe Section (collapses to 0dp / GONE when screenWatch.active == false)
        val wfBox = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((8 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (6 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = COLOR_INNER_CAPSULE,
                strokeColor = Color.parseColor("#55A855F7"),
                radiusDp = 18f,
                strokeDp = 0.9f
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (7 * d).toInt() }
            visibility = View.GONE
        }

        val wfView = MiniScreenWireframeView(context)
        wireframeView = wfView

        val wfCaption = TextView(context).apply {
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_TEXT_SECONDARY)
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            ).apply { marginStart = (10 * d).toInt() }
        }
        wireframeLabelText = wfCaption

        wfBox.addView(wfView)
        wfBox.addView(wfCaption)
        wireframeContainer = wfBox
        container.addView(wfBox)

        return container
    }

    private fun buildCollapsedHudPill(d: Float): LinearLayout {
        val pill = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((12 * d).toInt(), (7 * d).toInt(), (8 * d).toInt(), (7 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = COLOR_OBSIDIAN_GLASS,
                strokeColor = COLOR_CYAN,
                radiusDp = 999f,
                strokeDp = 1.2f
            )
            elevation = 10f * d
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val statusTv = TextView(context).apply {
            text = "✓ Agy • Done"
            textSize = 11.5f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_TEXT_PRIMARY)
            setPadding(0, (2 * d).toInt(), (8 * d).toInt(), (2 * d).toInt())
            contentDescription = "${HUD_NODE_TAG_PREFIX}collapsed_expand_btn"
            setOnClickListener {
                cancelAutoCollapse()
                isCollapsed = false
                renderHudWindow()
            }
        }
        collapsedStatusText = statusTv

        val divider = View(context).apply {
            layoutParams = LinearLayout.LayoutParams((1 * d).toInt(), (16 * d).toInt()).apply {
                marginEnd = (8 * d).toInt()
            }
            setBackgroundColor(Color.parseColor("#33FFFFFF"))
        }

        val askBtn = TextView(context).apply {
            text = "💬 Ask / Task"
            textSize = 11f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_CYAN)
            setPadding((10 * d).toInt(), (4 * d).toInt(), (10 * d).toInt(), (4 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = Color.parseColor("#2438BDF8"),
                strokeColor = Color.parseColor("#6638BDF8"),
                radiusDp = 999f,
                strokeDp = 0.9f
            )
            contentDescription = "${HUD_NODE_TAG_PREFIX}collapsed_ask_btn"
            setOnClickListener {
                cancelAutoCollapse()
                showInputWindowInternal(requestKeyboardFocus = true)
            }
        }

        pill.addView(statusTv)
        pill.addView(divider)
        pill.addView(askBtn)
        return pill
    }

    private fun renderHudWindow() {
        val state = _hudState.value
        val d = density()
        val alphaVal = OPACITY_LEVELS[opacityIndex]
        val accentColor = when (state.state) {
            "WORKING" -> COLOR_CYAN
            "NEEDS_INPUT" -> COLOR_AMBER
            "DONE" -> COLOR_EMERALD
            else -> COLOR_VIOLET
        }

        hudRootView?.alpha = if (ghostPassThrough) (alphaVal * 0.45f).coerceAtLeast(0.22f) else alphaVal
        inputRootView?.alpha = if (ghostPassThrough) (alphaVal * 0.45f).coerceAtLeast(0.22f) else alphaVal

        hudExpandedContainer?.visibility = if (isCollapsed) View.GONE else View.VISIBLE
        hudCollapsedPill?.visibility = if (isCollapsed) View.VISIBLE else View.GONE

        val rimColor = when (state.state) {
            "NEEDS_INPUT" -> COLOR_AMBER
            else -> COLOR_HAIRLINE
        }
        hudExpandedContainer?.background = createLiquidGlassDrawable(
            fillColor = COLOR_OBSIDIAN_GLASS,
            strokeColor = rimColor,
            radiusDp = 24f,
            strokeDp = if (state.state == "NEEDS_INPUT") 1.5f else 1.0f
        )
        hudCollapsedPill?.background = createLiquidGlassDrawable(
            fillColor = COLOR_OBSIDIAN_GLASS,
            strokeColor = rimColor,
            radiusDp = 999f,
            strokeDp = 1.0f
        )

        // Update Collapsed Pill Label
        val pillPrefix = when (state.state) {
            "WORKING" -> "● Agy • Working"
            "NEEDS_INPUT" -> "? Agy • Reply"
            "DONE" -> "✓ Agy • Done"
            else -> "○ Agy • Ready"
        }
        collapsedStatusText?.text = pillPrefix
        collapsedStatusText?.setTextColor(if (state.state == "NEEDS_INPUT") COLOR_AMBER else COLOR_TEXT_PRIMARY)

        // Update Expanded Header
        statusDotView?.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(accentColor)
        }
        statusBadgeText?.text = "AGY • ${state.state}"
        statusBadgeText?.setTextColor(accentColor)

        val opacityPct = (alphaVal * 100).toInt()
        opacityBtn?.text = if (opacityPct == 90) "◐" else if (opacityPct == 65) "◑" else "○"
        wireframeBtn?.alpha = if (wireframeEnabled) 1f else 0.45f
        ghostBtn?.setTextColor(if (ghostPassThrough) COLOR_AMBER else COLOR_TEXT_PRIMARY)

        // Title
        titleText?.text = state.title

        // Question Banner
        if (state.question.isNotBlank()) {
            questionBannerText?.visibility = View.VISIBLE
            questionBannerText?.text = "? ${state.question}"
        } else {
            questionBannerText?.visibility = View.GONE
        }

        // Doing Now & Next Action lines
        if (state.currentAction.isNotBlank()) {
            currentActionText?.visibility = View.VISIBLE
            currentActionText?.text = "▶ ${state.currentAction}"
        } else {
            currentActionText?.visibility = View.GONE
        }

        if (state.nextAction.isNotBlank()) {
            nextActionText?.visibility = View.VISIBLE
            nextActionText?.text = "↳ Next: ${state.nextAction}"
        } else {
            nextActionText?.visibility = View.GONE
        }

        // CheckBox Task List
        val listHost = taskListContainer
        if (listHost != null) {
            listHost.removeAllViews()
            if (state.tasks.isEmpty()) {
                taskScrollView?.visibility = View.GONE
            } else {
                taskScrollView?.visibility = View.VISIBLE
                val maxListHeightPx = (118 * d).toInt()
                taskScrollView?.layoutParams = (taskScrollView?.layoutParams as? LinearLayout.LayoutParams)?.apply {
                    height = if (state.tasks.size > 4) maxListHeightPx else ViewGroup.LayoutParams.WRAP_CONTENT
                }
                for (task in state.tasks) {
                    val (marker, color) = when (task.status) {
                        "done" -> "[x]" to COLOR_EMERALD
                        "doing" -> "[▶]" to COLOR_CYAN
                        "needs_input" -> "[?]" to COLOR_AMBER
                        else -> "[ ]" to COLOR_TEXT_SECONDARY
                    }
                    val row = LinearLayout(context).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding((6 * d).toInt(), (3 * d).toInt(), (6 * d).toInt(), (3 * d).toInt())
                        if (task.status == "doing" || task.status == "needs_input") {
                            background = createLiquidGlassDrawable(
                                fillColor = Color.argb(30, Color.red(color), Color.green(color), Color.blue(color)),
                                strokeColor = Color.argb(90, Color.red(color), Color.green(color), Color.blue(color)),
                                radiusDp = 10f,
                                strokeDp = 0.7f
                            )
                        }
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { bottomMargin = (3 * d).toInt() }
                    }
                    val boxTv = TextView(context).apply {
                        text = marker
                        textSize = 10.5f
                        typeface = Typeface.MONOSPACE
                        setTypeface(typeface, Typeface.BOLD)
                        setTextColor(color)
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { marginEnd = (6 * d).toInt() }
                    }
                    val labelTv = TextView(context).apply {
                        text = task.label
                        textSize = 11f
                        setTextColor(if (task.status == "done") COLOR_TEXT_SECONDARY else COLOR_TEXT_PRIMARY)
                        maxLines = 2
                        ellipsize = TextUtils.TruncateAt.END
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    }
                    row.addView(boxTv)
                    row.addView(labelTv)
                    tagTreeForSelfExclusion(row, "task_${task.id}")
                    listHost.addView(row)
                }
            }
        }

        // Low-Poly Mini Screen Wireframe (ONLY visible when screenWatch.active == true && wireframeEnabled)
        val showWireframe = state.screenWatch.active && wireframeEnabled
        wireframeView?.updateScreenWatch(state.screenWatch, wireframeEnabled)
        wireframeContainer?.visibility = if (showWireframe) View.VISIBLE else View.GONE
        if (showWireframe) {
            val zoneCount = state.screenWatch.zones.size
            val vecDesc = state.screenWatch.actionVector?.let { " • ${it.type}" } ?: ""
            val lbl = state.screenWatch.label.ifBlank { "Screen Watch" }
            wireframeLabelText?.text = "$lbl\n$zoneCount zones$vecDesc"
        }

        hudRootView?.let { root ->
            hudParams?.let { params ->
                try {
                    windowManager?.updateViewLayout(root, params)
                } catch (_: Exception) {}
            }
        }
    }

    // -------------------------------------------------------------------------
    // Window 1: Message & Command Input (`agy_input`) with Dynamic Focus Handoff
    // -------------------------------------------------------------------------

    private fun showInputWindowInternal(requestKeyboardFocus: Boolean) {
        val wm = windowManager ?: return
        if (inputRootView == null) {
            val d = density()
            val cardWidthPx = min((304 * d).toInt(), (context.resources.displayMetrics.widthPixels * 0.90f).toInt())

            val root = object : LinearLayout(context) {
                override fun onTouchEvent(event: MotionEvent?): Boolean {
                    if (event?.action == MotionEvent.ACTION_OUTSIDE) {
                        releaseInputFocusToTermux()
                        return true
                    }
                    return super.onTouchEvent(event)
                }
            }.apply {
                orientation = LinearLayout.VERTICAL
                setPadding((10 * d).toInt(), (8 * d).toInt(), (10 * d).toInt(), (9 * d).toInt())
                background = createLiquidGlassDrawable(
                    fillColor = COLOR_OBSIDIAN_GLASS,
                    strokeColor = COLOR_VIOLET,
                    radiusDp = 26f,
                    strokeDp = 1.2f
                )
                elevation = 12f * d
            }

            // Compact top drag handle & close row
            val topBar = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = (6 * d).toInt() }
            }

            val barLabel = TextView(context).apply {
                text = "✦ Message Agy"
                textSize = 10.5f
                typeface = Typeface.MONOSPACE
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(COLOR_CYAN)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }

            val pasteClear = TextView(context).apply {
                text = "Paste"
                textSize = 10f
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(COLOR_TEXT_SECONDARY)
                setPadding((8 * d).toInt(), (3 * d).toInt(), (8 * d).toInt(), (3 * d).toInt())
                background = createLiquidGlassDrawable(
                    fillColor = COLOR_INNER_CAPSULE,
                    strokeColor = Color.parseColor("#33FFFFFF"),
                    radiusDp = 999f,
                    strokeDp = 0.7f
                )
                contentDescription = "${HUD_NODE_TAG_PREFIX}paste_clear_btn"
                setOnClickListener {
                    val et = inputEditText ?: return@setOnClickListener
                    if (et.text.isNullOrEmpty()) {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                        val clip = cm?.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString()?.trim().orEmpty()
                        if (clip.isNotEmpty()) {
                            et.setText(clip)
                            et.setSelection(clip.length)
                        }
                    } else {
                        et.setText("")
                    }
                    updatePasteClearLabel()
                }
            }
            pasteClearBtn = pasteClear

            val closeBtn = TextView(context).apply {
                text = "✕"
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(COLOR_TEXT_SECONDARY)
                val sz = (24 * d).toInt()
                layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginStart = (6 * d).toInt() }
                background = createLiquidGlassDrawable(
                    fillColor = COLOR_INNER_CAPSULE,
                    strokeColor = Color.parseColor("#33FFFFFF"),
                    radiusDp = 999f,
                    strokeDp = 0.7f
                )
                contentDescription = "${HUD_NODE_TAG_PREFIX}close_input_btn"
                setOnClickListener { hideInputWindowInternal() }
            }

            topBar.addView(barLabel)
            topBar.addView(pasteClear)
            topBar.addView(closeBtn)
            root.addView(topBar)

            // Full-Pill Input Row: EditText + Send + Stop
            val inputRow = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }

            val editText = EditText(context).apply {
                hint = "Ask Agy or assign task..."
                setHintTextColor(Color.parseColor("#8094A3B8"))
                setTextColor(COLOR_TEXT_PRIMARY)
                textSize = 12.5f
                isSingleLine = true
                imeOptions = EditorInfo.IME_ACTION_SEND
                setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
                background = createLiquidGlassDrawable(
                    fillColor = COLOR_PILL_INPUT_BG,
                    strokeColor = Color.parseColor("#6638BDF8"),
                    radiusDp = 999f,
                    strokeDp = 1f
                )
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                contentDescription = "${HUD_NODE_TAG_PREFIX}prompt_input"

                setOnTouchListener { _, ev ->
                    if (ev.action == MotionEvent.ACTION_UP || ev.action == MotionEvent.ACTION_DOWN) {
                        acquireInputFocusFromTermux()
                    }
                    false
                }

                setOnEditorActionListener { _, actionId, event ->
                    if (actionId == EditorInfo.IME_ACTION_SEND ||
                        (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
                    ) {
                        submitPromptFromInput()
                        true
                    } else {
                        false
                    }
                }

                addTextChangedListener(object : android.text.TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                        updatePasteClearLabel()
                    }
                    override fun afterTextChanged(s: android.text.Editable?) {}
                })
            }
            inputEditText = editText

            val sendBtn = TextView(context).apply {
                text = "Send"
                textSize = 11.5f
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (8 * d).toInt())
                background = createLiquidGlassDrawable(
                    fillColor = COLOR_CYAN,
                    strokeColor = COLOR_CYAN,
                    radiusDp = 999f,
                    strokeDp = 0.8f
                )
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginStart = (6 * d).toInt() }
                contentDescription = "${HUD_NODE_TAG_PREFIX}send_btn"
                setOnClickListener { submitPromptFromInput() }
            }

            val stopBtn = TextView(context).apply {
                text = "■"
                textSize = 12f
                setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
                setTextColor(COLOR_CORAL)
                gravity = Gravity.CENTER
                val sz = (34 * d).toInt()
                layoutParams = LinearLayout.LayoutParams(sz, sz).apply { marginStart = (5 * d).toInt() }
                background = createLiquidGlassDrawable(
                    fillColor = Color.parseColor("#2EE11D48"),
                    strokeColor = COLOR_CORAL,
                    radiusDp = 999f,
                    strokeDp = 1f
                )
                contentDescription = "${HUD_NODE_TAG_PREFIX}stop_btn"
                setOnClickListener {
                    enqueueAndBroadcastCommand(text = "STOP", action = "STOP")
                    releaseInputFocusToTermux()
                }
            }

            inputRow.addView(editText)
            inputRow.addView(sendBtn)
            inputRow.addView(stopBtn)
            root.addView(inputRow)
            tagTreeForSelfExclusion(root, "window1")

            // Position anchored BOTTOM_RIGHT just above the HUD pill/card
            val baseHudY = hudParams?.y ?: (28 * d).toInt()
            val params = WindowManager.LayoutParams(
                cardWidthPx,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayWindowType(),
                // Start with FLAG_NOT_FOCUSABLE so Termux keeps keyboard focus until user taps EditText!
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.END
                x = (14 * d).toInt()
                y = baseHudY + (74 * d).toInt()
                softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            }

            inputRootView = root
            inputParams = params
            isInputFocused = false

            attachBottomRightDragListener(topBar, params) { inputRootView }

            try {
                wm.addView(root, params)
                _isInputVisible.value = true
                root.alpha = OPACITY_LEVELS[opacityIndex]
            } catch (e: Exception) {
                Log.e(TAG, "Failed adding agy_input window: ${e.message}")
                inputRootView = null
                inputParams = null
                _isInputVisible.value = false
                return
            }
        }

        if (requestKeyboardFocus) {
            mainHandler.postDelayed({ acquireInputFocusFromTermux() }, 60L)
        }
    }

    private fun acquireInputFocusFromTermux() {
        val root = inputRootView ?: return
        val params = inputParams ?: return
        val et = inputEditText ?: return
        if (!isInputFocused) {
            params.flags = (params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()) or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
            isInputFocused = true
            try {
                windowManager?.updateViewLayout(root, params)
            } catch (e: Exception) {
                Log.w(TAG, "Failed updating focusable layout for agy_input: ${e.message}")
            }
        }
        et.isFocusable = true
        et.isFocusableInTouchMode = true
        et.requestFocus()
        et.post {
            try {
                inputMethodManager?.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
            } catch (_: Exception) {}
        }
    }

    private fun releaseInputFocusToTermux() {
        val root = inputRootView ?: return
        val params = inputParams ?: return
        val et = inputEditText
        try {
            if (et != null) {
                inputMethodManager?.hideSoftInputFromWindow(et.windowToken, 0)
                et.clearFocus()
            }
        } catch (_: Exception) {}

        if (isInputFocused || (params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) == 0) {
            params.flags = params.flags or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
            isInputFocused = false
            try {
                windowManager?.updateViewLayout(root, params)
            } catch (_: Exception) {}
        }
    }

    private fun submitPromptFromInput() {
        val et = inputEditText ?: return
        val text = et.text?.toString()?.trim().orEmpty()
        if (text.isNotEmpty()) {
            enqueueAndBroadcastCommand(text = text, action = "PROMPT")
            et.setText("")
            updatePasteClearLabel()
            isCollapsed = false
            renderHudWindow()
        }
        releaseInputFocusToTermux()
    }

    private fun hideInputWindowInternal() {
        releaseInputFocusToTermux()
        inputRootView?.let { view ->
            try {
                windowManager?.removeView(view)
            } catch (e: Exception) {
                Log.w(TAG, "Error removing agy_input: ${e.message}")
            }
        }
        inputRootView = null
        inputParams = null
        inputEditText = null
        pasteClearBtn = null
        isInputFocused = false
        _isInputVisible.value = false
    }

    private fun updatePasteClearLabel() {
        val isEmpty = inputEditText?.text.isNullOrEmpty()
        pasteClearBtn?.text = if (isEmpty) "Paste" else "Clear"
    }

    // -------------------------------------------------------------------------
    // Ghost Pass-Through, Opacity, Timers & Pulse Helpers
    // -------------------------------------------------------------------------

    private fun cycleOpacityInternal() {
        opacityIndex = (opacityIndex + 1) % OPACITY_LEVELS.size
        renderHudWindow()
    }

    private fun setGhostModeInternal(enabled: Boolean) {
        ghostPassThrough = enabled
        applyTouchableFlagsInternal(touchable = !enabled && !temporaryPassThroughActive)
        if (enabled) {
            showGhostRestorePillInternal()
        } else {
            hideGhostRestorePillInternal()
        }
        renderHudWindow()
    }

    private fun showGhostRestorePillInternal() {
        if (ghostRestoreView != null) return
        val wm = windowManager ?: return
        val d = density()
        val restoreBtn = TextView(context).apply {
            text = "👻 Un-Ghost"
            textSize = 10f
            setTypeface(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(COLOR_AMBER)
            setPadding((10 * d).toInt(), (5 * d).toInt(), (10 * d).toInt(), (5 * d).toInt())
            background = createLiquidGlassDrawable(
                fillColor = COLOR_OBSIDIAN_GLASS,
                strokeColor = COLOR_AMBER,
                radiusDp = 999f,
                strokeDp = 1f
            )
            setOnClickListener { setGhostModeInternal(false) }
        }
        tagTreeForSelfExclusion(restoreBtn, "ghost_restore")
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            x = (14 * d).toInt()
            y = ((hudParams?.y ?: (28 * d).toInt()) + (235 * d).toInt())
        }
        ghostRestoreView = restoreBtn
        ghostRestoreParams = params
        try {
            wm.addView(restoreBtn, params)
        } catch (_: Exception) {
            ghostRestoreView = null
            ghostRestoreParams = null
        }
    }

    private fun hideGhostRestorePillInternal() {
        ghostRestoreView?.let { v ->
            try {
                windowManager?.removeView(v)
            } catch (_: Exception) {}
        }
        ghostRestoreView = null
        ghostRestoreParams = null
    }

    private fun applyTouchableFlagsInternal(touchable: Boolean) {
        fun updateWindow(view: View?, params: WindowManager.LayoutParams?) {
            if (view == null || params == null) return
            params.flags = if (touchable) {
                params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            } else {
                params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            }
            try {
                windowManager?.updateViewLayout(view, params)
            } catch (_: Exception) {}
        }
        updateWindow(hudRootView, hudParams)
        updateWindow(inputRootView, inputParams)
    }

    private fun scheduleAutoCollapse(seconds: Int) {
        cancelAutoCollapse()
        val task = Runnable {
            isCollapsed = true
            hideInputWindowInternal()
            if (hudRootView != null) {
                renderHudWindow()
            }
        }
        autoCollapseRunnable = task
        mainHandler.postDelayed(task, seconds * 1000L)
    }

    private fun cancelAutoCollapse() {
        autoCollapseRunnable?.let { mainHandler.removeCallbacks(it) }
        autoCollapseRunnable = null
    }

    private fun syncPulseAnimation() {
        val state = _hudState.value.state
        val shouldPulse = _isHudVisible.value && (state == "WORKING" || state == "NEEDS_INPUT")
        if (shouldPulse && pulseRunnable == null) {
            val runner = object : Runnable {
                override fun run() {
                    if (!_isHudVisible.value) {
                        stopPulseAnimation()
                        return
                    }
                    pulseToggle = !pulseToggle
                    statusDotView?.alpha = if (pulseToggle) 1.0f else 0.35f
                    if (_hudState.value.state == "NEEDS_INPUT") {
                        questionBannerText?.alpha = if (pulseToggle) 1.0f else 0.72f
                    } else {
                        questionBannerText?.alpha = 1.0f
                    }
                    mainHandler.postDelayed(this, 650L)
                }
            }
            pulseRunnable = runner
            mainHandler.postDelayed(runner, 650L)
        } else if (!shouldPulse) {
            stopPulseAnimation()
        }
    }

    private fun stopPulseAnimation() {
        pulseRunnable?.let { mainHandler.removeCallbacks(it) }
        pulseRunnable = null
        statusDotView?.alpha = 1.0f
        questionBannerText?.alpha = 1.0f
    }

    // -------------------------------------------------------------------------
    // Utility Helpers
    // -------------------------------------------------------------------------

    private fun attachBottomRightDragListener(
        dragHandle: View,
        params: WindowManager.LayoutParams,
        rootProvider: () -> View?
    ) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var moved = false

        dragHandle.setOnTouchListener { _, event ->
            val root = rootProvider() ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    moved = false
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - initialTouchX
                    val dy = event.rawY - initialTouchY
                    if (abs(dx) > 8f || abs(dy) > 8f) {
                        moved = true
                        // Anchored BOTTOM | END: dragging left increases x, dragging up increases y
                        val screenW = context.resources.displayMetrics.widthPixels
                        val screenH = context.resources.displayMetrics.heightPixels
                        params.x = (initialX - dx.toInt()).coerceIn(0, (screenW - 80).coerceAtLeast(0))
                        params.y = (initialY - dy.toInt()).coerceIn(0, (screenH - 80).coerceAtLeast(0))
                        try {
                            windowManager?.updateViewLayout(root, params)
                        } catch (_: Exception) {}
                    }
                    moved
                }
                else -> false
            }
        }
    }

    private fun createLiquidGlassDrawable(
        fillColor: Int,
        strokeColor: Int,
        radiusDp: Float,
        strokeDp: Float = 1.2f
    ): GradientDrawable {
        val d = density()
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusDp * d
            setColor(fillColor)
            setStroke((strokeDp * d).toInt().coerceAtLeast(1), strokeColor)
        }
    }

    private fun tagTreeForSelfExclusion(view: View, suffix: String) {
        val existing = view.contentDescription?.toString()
        if (existing.isNullOrBlank() || !existing.startsWith(HUD_NODE_TAG_PREFIX)) {
            view.contentDescription = "$HUD_NODE_TAG_PREFIX$suffix"
        }
        view.tag = "$HUD_NODE_TAG_PREFIX$suffix"
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                tagTreeForSelfExclusion(view.getChildAt(i), "${suffix}_$i")
            }
        }
    }

    private fun overlayWindowType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    private fun density(): Float = context.resources.displayMetrics.density.coerceAtLeast(1f)

    private fun runOnMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
        } else {
            mainHandler.post(block)
        }
    }
}
