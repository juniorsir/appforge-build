package com.kavach.presentation.dashboard

import android.graphics.Rect
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.kavach.accessibility.AccessibilityRepositoryImpl
import com.kavach.ui.overlay.AgyHudOverlayManager
import com.kavach.ui.theme.CrispAmber
import com.kavach.ui.theme.CrispBg
import com.kavach.ui.theme.CrispBlue
import com.kavach.ui.theme.CrispBorder
import com.kavach.ui.theme.CrispEmerald
import com.kavach.ui.theme.CrispHairline
import com.kavach.ui.theme.CrispIndigo
import com.kavach.ui.theme.CrispInkMuted
import com.kavach.ui.theme.CrispInkPrimary
import com.kavach.ui.theme.CrispInkSecondary
import com.kavach.ui.theme.CrispRose
import com.kavach.ui.theme.CrispSurface
import com.kavach.ui.theme.CrispSurfaceSubtle
import com.kavach.ui.theme.JetBrainsMonoFamily
import com.kavach.ui.theme.LiquidIconOrb
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Full Interactive Agy HUD Test Mode Simulator.
 * Drives the real AgyHudOverlayManager (floating overlay + /api/hud endpoints & command queue)
 * while mirroring live Window 2 (Task + Low-Poly Wireframe / Collapsed Pill) & Window 1 (Prompt)
 * inside a clean Crisp Light Mode sandbox so every feature can be tested without Termux running.
 */
@Composable
fun AgyHudSimulatorDialog(
    hudManager: AgyHudOverlayManager,
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val hudState by hudManager.hudState.collectAsState()
    val isHudVisible by hudManager.isHudVisible.collectAsState()
    val isInputVisible by hudManager.isInputVisible.collectAsState()
    val isCollapsed by hudManager.isCollapsedFlow.collectAsState()
    val opacity by hudManager.opacityFlow.collectAsState()
    val ghostPassThrough by hudManager.ghostPassThroughFlow.collectAsState()
    val wireframeEnabled by hudManager.wireframeEnabledFlow.collectAsState()

    var isAutoPlaying by remember { mutableStateOf(false) }
    var activeFlowStep by remember { mutableStateOf("Ready to simulate Agy lifecycle") }
    var autoPlayJob by remember { mutableStateOf<Job?>(null) }
    var simulatedTurnJob by remember { mutableStateOf<Job?>(null) }
    var sandboxPrompt by remember { mutableStateOf("") }
    var hasOverlayPerm by remember { mutableStateOf(hudManager.hasOverlayPermission()) }

    val echoLogs = remember { mutableStateListOf<String>() }
    val timeFmt = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }

    fun addLog(msg: String) {
        val ts = timeFmt.format(Date())
        echoLogs.add(0, "[$ts] $msg")
        if (echoLogs.size > 30) echoLogs.removeAt(echoLogs.lastIndex)
    }

    fun pushStatePayload(label: String, json: JSONObject) {
        hasOverlayPerm = hudManager.hasOverlayPermission()
        val res = hudManager.updateState(json)
        activeFlowStep = label
        val overlayTag = if (res.optBoolean("overlayRendered")) "real HUD + sandbox" else "sandbox preview"
        addLog("STATE -> ${json.optString("state")} ($overlayTag)")
    }

    fun runSimulatedPromptTurn(promptText: String) {
        simulatedTurnJob?.cancel()
        simulatedTurnJob = scope.launch {
            pushStatePayload(
                "Simulating prompt: $promptText",
                buildWorkingPayload(promptText)
            )
            delay(1600L)
            pushStatePayload(
                "Screen Watch: Inspecting UI & targeting button",
                buildTapWatchPayload(promptText)
            )
            delay(1900L)
            pushStatePayload(
                "Task Complete — auto-collapsing in 4s",
                buildDonePayload("Finished: ${promptText.take(36)}")
            )
        }
    }

    // Live command echo loop: drains real HUD_COMMAND items submitted via Window 1 or Simulator bar
    LaunchedEffect(hudManager) {
        addLog("Simulator ready. Tap 'Play Full Flow' or type a prompt below.")
        while (isActive) {
            val pollRes = hudManager.pollCommands()
            val count = pollRes.optInt("count", 0)
            if (count > 0) {
                val arr = pollRes.optJSONArray("commands") ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val cmd = arr.optJSONObject(i) ?: continue
                    val action = cmd.optString("action", "PROMPT")
                    val text = cmd.optString("text", "")
                    addLog("HUD_COMMAND [$action]: \"$text\"")
                    if (action == "STOP") {
                        autoPlayJob?.cancel()
                        simulatedTurnJob?.cancel()
                        isAutoPlaying = false
                        pushStatePayload("Stopped by user", buildIdlePayload("Stopped by user"))
                    } else if (text.isNotBlank()) {
                        autoPlayJob?.cancel()
                        isAutoPlaying = false
                        runSimulatedPromptTurn(text)
                    }
                }
            }
            delay(300L)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            autoPlayJob?.cancel()
            simulatedTurnJob?.cancel()
        }
    }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = CrispSurface,
            shape = RoundedCornerShape(28.dp),
            border = BorderStroke(1.dp, CrispHairline),
            shadowElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .heightIn(max = 780.dp)
                .testTag("agy_hud_simulator_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        LiquidIconOrb(
                            icon = Icons.Rounded.AutoAwesome,
                            tint = CrispBlue,
                            size = 38.dp,
                            iconSize = 20.dp
                        )
                        Column {
                            Text(
                                text = "Agy HUD Simulator",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = CrispInkPrimary
                            )
                            Text(
                                text = activeFlowStep,
                                style = MaterialTheme.typography.labelSmall,
                                color = CrispInkSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    IconButton(
                        onClick = onDismissRequest,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(CrispSurfaceSubtle)
                            .testTag("close_hud_simulator_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Close Simulator",
                            tint = CrispInkSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Real Overlay Permission Banner
                if (!hasOverlayPerm) {
                    Surface(
                        color = CrispAmber.copy(alpha = 0.08f),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, CrispAmber.copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Sandbox live. Grant overlay permission to float over Termux.",
                                style = MaterialTheme.typography.labelSmall,
                                color = CrispAmber,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(Modifier.width(8.dp))
                            Surface(
                                color = CrispAmber,
                                shape = RoundedCornerShape(50),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .clickable {
                                        hudManager.getOverlayPermissionIntent()?.let { intent ->
                                            try {
                                                context.startActivity(intent)
                                            } catch (_: Exception) {}
                                        }
                                    }
                            ) {
                                Text(
                                    text = "Grant",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }
                }

                // 1. Live Synchronized HUD Sandbox Preview
                Surface(
                    color = CrispBg,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, CrispHairline),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("simulator_live_preview_box")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "LIVE DUAL-WINDOW PREVIEW",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    letterSpacing = 0.8.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                ),
                                color = CrispInkMuted
                            )
                            Text(
                                text = "${(opacity * 100).toInt()}% • ${if (ghostPassThrough) "Ghost ON" else if (isHudVisible) "Floating" else "Sandbox"}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = JetBrainsMonoFamily,
                                    fontSize = 10.sp
                                ),
                                color = CrispInkSecondary
                            )
                        }

                        // Synchronized Window 2 Preview (Expanded Card or Collapsed Pill)
                        SandboxWindow2Preview(
                            state = hudState,
                            isCollapsed = isCollapsed,
                            opacity = opacity,
                            ghostPassThrough = ghostPassThrough,
                            wireframeEnabled = wireframeEnabled,
                            onCycleOpacity = {
                                hudManager.handleRemoteCommand(JSONObject().put("action", "CYCLE_OPACITY"))
                                addLog("OPACITY -> ${(hudManager.opacityFlow.value * 100).toInt()}%")
                            },
                            onToggleWireframe = {
                                hudManager.handleRemoteCommand(JSONObject().put("action", "TOGGLE_WIREFRAME"))
                            },
                            onToggleGhost = {
                                hudManager.handleRemoteCommand(JSONObject().put("action", "TOGGLE_GHOST"))
                                addLog("GHOST PASS-THROUGH -> ${!ghostPassThrough}")
                            },
                            onToggleInput = {
                                val nextAction = if (isInputVisible) "CLOSE_INPUT" else "OPEN_INPUT"
                                hudManager.handleRemoteCommand(JSONObject().put("action", nextAction))
                            },
                            onToggleCollapse = {
                                val nextAction = if (isCollapsed) "EXPAND" else "COLLAPSE"
                                hudManager.handleRemoteCommand(JSONObject().put("action", nextAction))
                            }
                        )

                        // Synchronized Window 1 Preview (Prompt + Send + Stop)
                        AnimatedVisibility(
                            visible = isInputVisible || !isCollapsed,
                            enter = fadeIn() + expandVertically(),
                            exit = fadeOut() + shrinkVertically()
                        ) {
                            Surface(
                                color = CrispSurface,
                                shape = RoundedCornerShape(20.dp),
                                border = BorderStroke(1.dp, CrispBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    OutlinedTextField(
                                        value = sandboxPrompt,
                                        onValueChange = { sandboxPrompt = it },
                                        singleLine = true,
                                        placeholder = {
                                            Text(
                                                text = "Type test prompt for Agy...",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = CrispInkMuted
                                            )
                                        },
                                        textStyle = MaterialTheme.typography.bodySmall.copy(color = CrispInkPrimary),
                                        shape = RoundedCornerShape(50),
                                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                                        keyboardActions = KeyboardActions(
                                            onSend = {
                                                val txt = sandboxPrompt.trim()
                                                if (txt.isNotEmpty()) {
                                                    hudManager.enqueueAndBroadcastCommand(txt, "PROMPT")
                                                    sandboxPrompt = ""
                                                }
                                            }
                                        ),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = CrispBlue,
                                            unfocusedBorderColor = CrispHairline,
                                            focusedContainerColor = CrispSurfaceSubtle,
                                            unfocusedContainerColor = CrispSurfaceSubtle
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("simulator_prompt_input")
                                    )

                                    Surface(
                                        color = CrispBlue,
                                        shape = CircleShape,
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .clickable {
                                                val txt = sandboxPrompt.trim().ifEmpty { "Check Wi-Fi & open Termux" }
                                                hudManager.enqueueAndBroadcastCommand(txt, "PROMPT")
                                                sandboxPrompt = ""
                                            }
                                            .testTag("simulator_send_button")
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Rounded.Send,
                                                contentDescription = "Send Test Prompt",
                                                tint = Color.White,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }

                                    Surface(
                                        color = CrispRose.copy(alpha = 0.12f),
                                        shape = CircleShape,
                                        border = BorderStroke(1.dp, CrispRose.copy(alpha = 0.3f)),
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .clickable {
                                                hudManager.enqueueAndBroadcastCommand("STOP", "STOP")
                                            }
                                            .testTag("simulator_stop_button")
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Rounded.Stop,
                                                contentDescription = "Stop Agy",
                                                tint = CrispRose,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 2. One-Tap Auto-Play Full Flow CTA
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            if (isAutoPlaying) {
                                autoPlayJob?.cancel()
                                isAutoPlaying = false
                                activeFlowStep = "Auto-play stopped"
                                addLog("DEMO stopped")
                            } else {
                                simulatedTurnJob?.cancel()
                                isAutoPlaying = true
                                autoPlayJob = scope.launch {
                                    try {
                                        pushStatePayload("Step 1/5: WORKING (Task Checklist)", buildWorkingPayload("Deploy Termux Script"))
                                        delay(2200L)
                                        pushStatePayload("Step 2/5: SCREEN WATCH (TAP Reticle)", buildTapWatchPayload("Deploy Termux Script"))
                                        delay(2600L)
                                        pushStatePayload("Step 3/5: SCREEN WATCH (SWIPE Vector)", buildSwipeWatchPayload("Deploy Termux Script"))
                                        delay(2600L)
                                        pushStatePayload("Step 4/5: NEEDS_INPUT (Auto-Opens Window 1)", buildNeedsInputPayload())
                                        delay(2600L)
                                        pushStatePayload("Step 5/5: DONE (Auto-Collapses in 4s)", buildDonePayload("All tasks verified & deployed"))
                                        delay(4300L)
                                        activeFlowStep = "Completed — Collapsed to bottom-right pill"
                                        addLog("Auto-collapsed to compact bottom-right pill")
                                    } finally {
                                        isAutoPlaying = false
                                    }
                                }
                            }
                        },
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isAutoPlaying) CrispRose else CrispBlue,
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("simulator_autoplay_button")
                    ) {
                        Icon(
                            imageVector = if (isAutoPlaying) Icons.Rounded.Stop else Icons.Rounded.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = if (isAutoPlaying) "Stop Demo" else "Play Full Flow",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Surface(
                        color = CrispSurfaceSubtle,
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, CrispHairline),
                        modifier = Modifier
                            .height(44.dp)
                            .clip(RoundedCornerShape(50))
                            .clickable {
                                autoPlayJob?.cancel()
                                simulatedTurnJob?.cancel()
                                isAutoPlaying = false
                                hudManager.hideAll()
                                activeFlowStep = "HUD hidden cleanly"
                                addLog("POST /api/hud/hide -> dismissed both windows")
                            }
                            .testTag("simulator_hide_button")
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        ) {
                            Text(
                                text = "Hide",
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                                color = CrispInkSecondary
                            )
                        }
                    }
                }

                // 3. Manual State & Overlay Triggers
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "MANUAL STATE TRIGGERS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            letterSpacing = 0.8.sp,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        ),
                        color = CrispInkMuted
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SimChip("Working", CrispBlue, "sim_trigger_working") {
                            pushStatePayload("Manual: WORKING", buildWorkingPayload("Run Diagnostics"))
                        }
                        SimChip("Tap Watch", CrispBlue, "sim_trigger_tap") {
                            pushStatePayload("Manual: Screen Watch TAP", buildTapWatchPayload("Tap Connect"))
                        }
                        SimChip("Swipe Watch", CrispIndigo, "sim_trigger_swipe") {
                            pushStatePayload("Manual: Screen Watch SWIPE", buildSwipeWatchPayload("Scroll Settings"))
                        }
                        SimChip("Needs Input", CrispAmber, "sim_trigger_input") {
                            pushStatePayload("Manual: NEEDS_INPUT", buildNeedsInputPayload())
                        }
                        SimChip("Done (4s)", CrispEmerald, "sim_trigger_done") {
                            pushStatePayload("Manual: DONE (4s collapse)", buildDonePayload("Checks passed"))
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SimChip("Expand", CrispInkPrimary, "sim_cmd_expand") {
                            hudManager.handleRemoteCommand(JSONObject().put("action", "EXPAND"))
                            addLog("CMD -> EXPAND")
                        }
                        SimChip("Collapse", CrispInkPrimary, "sim_cmd_collapse") {
                            hudManager.handleRemoteCommand(JSONObject().put("action", "COLLAPSE"))
                            addLog("CMD -> COLLAPSE")
                        }
                        SimChip("Open Input", CrispBlue, "sim_cmd_open_input") {
                            hudManager.handleRemoteCommand(JSONObject().put("action", "OPEN_INPUT"))
                            addLog("CMD -> OPEN_INPUT")
                        }
                        SimChip("Opacity ${(opacity * 100).toInt()}%", CrispInkPrimary, "sim_cmd_opacity") {
                            hudManager.handleRemoteCommand(JSONObject().put("action", "CYCLE_OPACITY"))
                            addLog("CMD -> CYCLE_OPACITY (${(hudManager.opacityFlow.value * 100).toInt()}%)")
                        }
                        SimChip(if (ghostPassThrough) "Un-Ghost" else "Ghost Mode", CrispAmber, "sim_cmd_ghost") {
                            hudManager.handleRemoteCommand(JSONObject().put("action", "TOGGLE_GHOST"))
                            addLog("CMD -> TOGGLE_GHOST")
                        }
                    }
                }

                // 4. Safety Hooks Verification
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = CrispSurfaceSubtle,
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, CrispHairline),
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(50))
                            .clickable {
                                val repo = AccessibilityRepositoryImpl()
                                val hudExcluded = repo.isAgyHudIdentifier("com.kavach:id/agy_hud_window2", "agy_hud_root")
                                val termuxKept = !repo.isAgyHudIdentifier("com.termux:id/terminal_view", "Terminal")
                                val status = if (hudExcluded && termuxKept) "PASS" else "FAIL"
                                addLog("SAFETY [$status] Self-Exclusion: agy_hud_ filtered, Termux visible")
                            }
                            .testTag("sim_test_self_exclusion")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Shield,
                                contentDescription = null,
                                tint = CrispEmerald,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(Modifier.width(5.dp))
                            Text(
                                text = "Self-Exclusion",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                color = CrispInkPrimary,
                                maxLines = 1
                            )
                        }
                    }

                    Surface(
                        color = CrispSurfaceSubtle,
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, CrispHairline),
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(50))
                            .clickable {
                                val sampleRects = hudManager.getOverlayBounds().ifEmpty {
                                    listOf(Rect(640, 1800, 1060, 2320))
                                }
                                val hit = hudManager.coordinatesOverlapRects(820f, 2000f, 820f, 2000f, sampleRects)
                                val miss = !hudManager.coordinatesOverlapRects(120f, 240f, 120f, 240f, sampleRects)
                                val applied = hudManager.temporarilyPassThroughIfColliding(820f, 2000f)
                                val status = if (hit && miss) "PASS" else "FAIL"
                                addLog("SAFETY [$status] Touch Pass-Through: overlap=$hit, liveApplied=$applied (300ms)")
                            }
                            .testTag("sim_test_touch_passthrough")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.TouchApp,
                                contentDescription = null,
                                tint = CrispBlue,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(Modifier.width(5.dp))
                            Text(
                                text = "Touch Pass-Thru",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                color = CrispInkPrimary,
                                maxLines = 1
                            )
                        }
                    }
                }

                HorizontalDivider(color = CrispHairline)

                // 5. Live HUD_COMMAND & Telemetry Echo Console
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "LIVE COMMAND ECHO & TELEMETRY",
                            style = MaterialTheme.typography.labelSmall.copy(
                                letterSpacing = 0.8.sp,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            ),
                            color = CrispInkMuted
                        )
                        Text(
                            text = "Clear",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                            color = CrispBlue,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .clickable { echoLogs.clear() }
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Surface(
                        color = CrispSurfaceSubtle,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, CrispHairline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            if (echoLogs.isEmpty()) {
                                Text(
                                    text = "No events yet.",
                                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                                    color = CrispInkMuted
                                )
                            } else {
                                echoLogs.take(6).forEach { line ->
                                    Text(
                                        text = line,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontFamily = JetBrainsMonoFamily,
                                            fontSize = 10.sp,
                                            lineHeight = 14.sp
                                        ),
                                        color = when {
                                            line.contains("HUD_COMMAND") -> CrispBlue
                                            line.contains("PASS") -> CrispEmerald
                                            line.contains("NEEDS_INPUT") -> CrispAmber
                                            else -> CrispInkSecondary
                                        },
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SandboxWindow2Preview(
    state: AgyHudOverlayManager.AgyHudState,
    isCollapsed: Boolean,
    opacity: Float,
    ghostPassThrough: Boolean,
    wireframeEnabled: Boolean,
    onCycleOpacity: () -> Unit,
    onToggleWireframe: () -> Unit,
    onToggleGhost: () -> Unit,
    onToggleInput: () -> Unit,
    onToggleCollapse: () -> Unit
) {
    val accent = when (state.state) {
        "WORKING" -> CrispBlue
        "NEEDS_INPUT" -> CrispAmber
        "DONE" -> CrispEmerald
        else -> CrispIndigo
    }
    val visualAlpha = if (ghostPassThrough) (opacity * 0.5f).coerceAtLeast(0.35f) else opacity

    if (isCollapsed) {
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.CenterEnd
        ) {
            Surface(
                color = CrispSurface,
                shape = RoundedCornerShape(50),
                shadowElevation = 2.dp,
                border = BorderStroke(1.dp, if (state.state == "NEEDS_INPUT") CrispAmber else CrispBorder),
                modifier = Modifier.alpha(visualAlpha)
            ) {
                Row(
                    modifier = Modifier.padding(start = 12.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val label = when (state.state) {
                        "WORKING" -> "● Agy • Working"
                        "NEEDS_INPUT" -> "? Agy • Reply"
                        "DONE" -> "✓ Agy • Done"
                        else -> "○ Agy • Ready"
                    }
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = if (state.state == "NEEDS_INPUT") CrispAmber else CrispInkPrimary,
                        modifier = Modifier.clickable(onClick = onToggleCollapse)
                    )
                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(14.dp)
                            .background(CrispHairline)
                    )
                    Surface(
                        color = CrispBlue.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(50),
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .clickable(onClick = onToggleInput)
                    ) {
                        Text(
                            text = "💬 Ask / Task",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = CrispBlue,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    } else {
        Surface(
            color = CrispSurface,
            shape = RoundedCornerShape(22.dp),
            shadowElevation = 2.dp,
            border = BorderStroke(1.dp, if (state.state == "NEEDS_INPUT") CrispAmber else CrispBorder),
            modifier = Modifier
                .fillMaxWidth()
                .alpha(visualAlpha)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(accent)
                        )
                        Text(
                            text = "AGY • ${state.state}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = JetBrainsMonoFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            ),
                            color = accent
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        MiniHudChip("◐", onCycleOpacity)
                        MiniHudChip("👁", onToggleWireframe)
                        MiniHudChip("👻", onToggleGhost)
                        MiniHudChip("💬", onToggleInput)
                        MiniHudChip("─", onToggleCollapse)
                    }
                }

                Text(
                    text = state.title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = CrispInkPrimary
                )

                if (state.question.isNotBlank()) {
                    Surface(
                        color = CrispAmber.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, CrispAmber.copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "? ${state.question}",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = CrispAmber,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }

                if (state.currentAction.isNotBlank()) {
                    Text(
                        text = "▶ ${state.currentAction}",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                        color = CrispBlue
                    )
                }
                if (state.nextAction.isNotBlank()) {
                    Text(
                        text = "↳ Next: ${state.nextAction}",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                        color = CrispInkSecondary
                    )
                }

                // Live CheckBox Task List
                state.tasks.forEach { task ->
                    val (marker, color) = when (task.status) {
                        "done" -> "[x]" to CrispEmerald
                        "doing" -> "[▶]" to CrispBlue
                        "needs_input" -> "[?]" to CrispAmber
                        else -> "[ ]" to CrispInkMuted
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = marker,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = JetBrainsMonoFamily,
                                fontWeight = FontWeight.Bold
                            ),
                            color = color
                        )
                        Text(
                            text = task.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (task.status == "done") CrispInkSecondary else CrispInkPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Miniature Low-Poly Wireframe Canvas (collapses to 0dp when screenWatch.active == false)
                AnimatedVisibility(
                    visible = state.screenWatch.active && wireframeEnabled,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Surface(
                        color = CrispSurfaceSubtle,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, CrispHairline),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            SandboxWireframeCanvas(watch = state.screenWatch)
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = state.screenWatch.label.ifBlank { "Screen Watch" },
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = CrispInkPrimary
                                )
                                Text(
                                    text = "${state.screenWatch.zones.size} key zones${state.screenWatch.actionVector?.let { " • ${it.type}" } ?: ""}",
                                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                                    color = CrispInkSecondary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SandboxWireframeCanvas(watch: AgyHudOverlayManager.ScreenWatchState) {
    val infinite = rememberInfiniteTransition(label = "wf_anim")
    val phase by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wf_phase"
    )
    Canvas(
        modifier = Modifier
            .size(width = 48.dp, height = 88.dp)
    ) {
        val pad = 2.dp.toPx()
        val w = (size.width - pad * 2).coerceAtLeast(1f)
        val h = (size.height - pad * 2).coerceAtLeast(1f)
        drawRoundRect(
            color = Color(0xFFFFFFFF),
            topLeft = Offset(pad, pad),
            size = Size(w, h),
            cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
        )
        drawRoundRect(
            color = Color(0xFFCBD5E1),
            topLeft = Offset(pad, pad),
            size = Size(w, h),
            cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx()),
            style = Stroke(width = 1.2.dp.toPx())
        )

        val sw = watch.screenWidth.coerceAtLeast(1).toFloat()
        val sh = watch.screenHeight.coerceAtLeast(1).toFloat()
        val inset = 4.dp.toPx()
        val iw = (w - inset * 2).coerceAtLeast(1f)
        val ih = (h - inset * 2).coerceAtLeast(1f)
        fun mx(x: Float) = pad + inset + (x / sw).coerceIn(0f, 1f) * iw
        fun my(y: Float) = pad + inset + (y / sh).coerceIn(0f, 1f) * ih

        watch.zones.take(6).forEach { z ->
            val l = mx(min(z.x1, z.x2))
            val t = my(min(z.y1, z.y2))
            val r = max(l + 4.dp.toPx(), mx(max(z.x1, z.x2)))
            val b = max(t + 4.dp.toPx(), my(max(z.y1, z.y2)))
            val isTarget = z.role.contains("target", true) || z.role.contains("focus", true)
            val isAction = z.role.contains("button", true) || z.role.contains("input", true)
            val stroke = when {
                isTarget -> CrispAmber
                isAction -> CrispBlue
                else -> Color(0xFF94A3B8)
            }
            drawRoundRect(
                color = stroke.copy(alpha = 0.16f),
                topLeft = Offset(l, t),
                size = Size(r - l, b - t),
                cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
            )
            drawRoundRect(
                color = stroke,
                topLeft = Offset(l, t),
                size = Size(r - l, b - t),
                cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx()),
                style = Stroke(width = 1.dp.toPx())
            )
        }

        watch.actionVector?.let { vec ->
            val sx = mx(vec.x1)
            val sy = my(vec.y1)
            if (vec.type.equals("SWIPE", true) || vec.type.equals("DRAG", true)) {
                val ex = mx(vec.x2)
                val ey = my(vec.y2)
                drawLine(
                    color = CrispBlue,
                    start = Offset(sx, sy),
                    end = Offset(ex, ey),
                    strokeWidth = 1.6.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 4f), 0f)
                )
                val angle = atan2((ey - sy).toDouble(), (ex - sx).toDouble())
                val head = 5.dp.toPx()
                val arrow = Path().apply {
                    moveTo(ex, ey)
                    lineTo((ex - head * cos(angle - 0.5)).toFloat(), (ey - head * sin(angle - 0.5)).toFloat())
                    lineTo((ex - head * cos(angle + 0.5)).toFloat(), (ey - head * sin(angle + 0.5)).toFloat())
                    close()
                }
                drawPath(arrow, color = CrispAmber)
                val bx = sx + (ex - sx) * phase
                val by = sy + (ey - sy) * phase
                drawCircle(color = CrispBlue, radius = 3.dp.toPx(), center = Offset(bx, by))
            } else {
                drawCircle(
                    color = CrispBlue.copy(alpha = (1f - phase).coerceIn(0.15f, 0.9f)),
                    radius = (3f + phase * 8f).dp.toPx(),
                    center = Offset(sx, sy),
                    style = Stroke(width = 1.4.dp.toPx())
                )
                drawCircle(color = CrispAmber, radius = 2.6.dp.toPx(), center = Offset(sx, sy))
            }
        }
    }
}

@Composable
private fun MiniHudChip(symbol: String, onClick: () -> Unit) {
    Surface(
        color = CrispSurfaceSubtle,
        shape = CircleShape,
        border = BorderStroke(0.8.dp, CrispHairline),
        modifier = Modifier
            .size(26.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(text = symbol, fontSize = 11.sp, color = CrispInkPrimary)
        }
    }
}

@Composable
private fun SimChip(label: String, tint: Color, tag: String, onClick: () -> Unit) {
    Surface(
        color = CrispSurfaceSubtle,
        shape = RoundedCornerShape(50),
        border = BorderStroke(1.dp, CrispHairline),
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .testTag(tag)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
            color = tint,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
        )
    }
}

private fun buildIdlePayload(note: String): JSONObject = JSONObject().apply {
    put("state", "IDLE")
    put("title", "Agy Ready")
    put("currentAction", note)
    put("nextAction", "")
    put("question", "")
    put("autoCollapseSeconds", 3)
    put("tasks", JSONArray())
    put("screenWatch", JSONObject().put("active", false))
}

private fun buildWorkingPayload(title: String): JSONObject = JSONObject().apply {
    put("state", "WORKING")
    put("title", title)
    put("currentAction", "Inspecting active Termux environment")
    put("nextAction", "Check device bridge & screen targets")
    put("question", "")
    put("autoCollapseSeconds", 4)
    put("tasks", JSONArray().apply {
        put(JSONObject().put("id", "s1").put("label", "Load ~/.aura_token & verify bridge").put("status", "done"))
        put(JSONObject().put("id", "s2").put("label", "Inspect UI hierarchy safely").put("status", "doing"))
        put(JSONObject().put("id", "s3").put("label", "Execute target screen action").put("status", "pending"))
        put(JSONObject().put("id", "s4").put("label", "Confirm result & summarize").put("status", "pending"))
    })
    put("screenWatch", JSONObject().put("active", false))
}

private fun buildTapWatchPayload(title: String): JSONObject = JSONObject().apply {
    put("state", "WORKING")
    put("title", title)
    put("currentAction", "Tapping Connect CTA (pass-through safe)")
    put("nextAction", "Scroll list to verify status")
    put("question", "")
    put("autoCollapseSeconds", 4)
    put("tasks", JSONArray().apply {
        put(JSONObject().put("id", "s1").put("label", "Load ~/.aura_token & verify bridge").put("status", "done"))
        put(JSONObject().put("id", "s2").put("label", "Inspect UI hierarchy safely").put("status", "done"))
        put(JSONObject().put("id", "s3").put("label", "Tap Connect button").put("status", "doing"))
        put(JSONObject().put("id", "s4").put("label", "Confirm result & summarize").put("status", "pending"))
    })
    put("screenWatch", JSONObject().apply {
        put("active", true)
        put("label", "Settings • Tap Target")
        put("screenWidth", 1080)
        put("screenHeight", 2400)
        put("zones", JSONArray().apply {
            put(JSONObject().put("x1", 60).put("y1", 160).put("x2", 1020).put("y2", 320).put("role", "header").put("tag", "Header"))
            put(JSONObject().put("x1", 80).put("y1", 460).put("x2", 1000).put("y2", 620).put("role", "input").put("tag", "Search"))
            put(JSONObject().put("x1", 660).put("y1", 920).put("x2", 1000).put("y2", 1090).put("role", "target").put("tag", "Connect"))
            put(JSONObject().put("x1", 80).put("y1", 1220).put("x2", 1000).put("y2", 1740).put("role", "panel").put("tag", "List"))
        })
        put("actionVector", JSONObject().put("type", "TAP").put("x1", 830).put("y1", 1005).put("x2", 830).put("y2", 1005))
    })
}

private fun buildSwipeWatchPayload(title: String): JSONObject = JSONObject().apply {
    put("state", "WORKING")
    put("title", title)
    put("currentAction", "Swiping up to check logs")
    put("nextAction", "Ask user for confirmation")
    put("question", "")
    put("autoCollapseSeconds", 4)
    put("tasks", JSONArray().apply {
        put(JSONObject().put("id", "s1").put("label", "Load ~/.aura_token & verify bridge").put("status", "done"))
        put(JSONObject().put("id", "s2").put("label", "Inspect UI hierarchy safely").put("status", "done"))
        put(JSONObject().put("id", "s3").put("label", "Swipe feed & capture result").put("status", "doing"))
        put(JSONObject().put("id", "s4").put("label", "Confirm result & summarize").put("status", "pending"))
    })
    put("screenWatch", JSONObject().apply {
        put("active", true)
        put("label", "Feed • Swipe Up")
        put("screenWidth", 1080)
        put("screenHeight", 2400)
        put("zones", JSONArray().apply {
            put(JSONObject().put("x1", 60).put("y1", 180).put("x2", 1020).put("y2", 340).put("role", "header").put("tag", "Logs"))
            put(JSONObject().put("x1", 80).put("y1", 460).put("x2", 1000).put("y2", 1180).put("role", "panel").put("tag", "Card 1"))
            put(JSONObject().put("x1", 80).put("y1", 1260).put("x2", 1000).put("y2", 1980).put("role", "button").put("tag", "Card 2"))
        })
        put("actionVector", JSONObject().put("type", "SWIPE").put("x1", 540).put("y1", 1820).put("x2", 540).put("y2", 620))
    })
}

private fun buildNeedsInputPayload(): JSONObject = JSONObject().apply {
    put("state", "NEEDS_INPUT")
    put("title", "Confirmation Needed")
    put("currentAction", "Waiting for your reply in Window 1...")
    put("nextAction", "Apply changes & finish")
    put("question", "Should I restart the Termux relay now?")
    put("autoCollapseSeconds", 4)
    put("tasks", JSONArray().apply {
        put(JSONObject().put("id", "s1").put("label", "Inspect UI hierarchy safely").put("status", "done"))
        put(JSONObject().put("id", "s2").put("label", "Await user confirmation").put("status", "needs_input"))
        put(JSONObject().put("id", "s3").put("label", "Apply changes & summarize").put("status", "pending"))
    })
    put("screenWatch", JSONObject().put("active", false))
}

private fun buildDonePayload(summary: String): JSONObject = JSONObject().apply {
    put("state", "DONE")
    put("title", "Task Completed")
    put("currentAction", summary)
    put("nextAction", "")
    put("question", "")
    put("autoCollapseSeconds", 4)
    put("tasks", JSONArray().apply {
        put(JSONObject().put("id", "s1").put("label", "Load ~/.aura_token & verify bridge").put("status", "done"))
        put(JSONObject().put("id", "s2").put("label", "Inspect UI hierarchy safely").put("status", "done"))
        put(JSONObject().put("id", "s3").put("label", "Execute target screen action").put("status", "done"))
        put(JSONObject().put("id", "s4").put("label", "Confirm result & summarize").put("status", "done"))
    })
    put("screenWatch", JSONObject().put("active", false))
}
