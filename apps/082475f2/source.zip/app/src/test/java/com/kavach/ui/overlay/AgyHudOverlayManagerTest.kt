package com.kavach.ui.overlay

import android.content.Context
import android.graphics.Rect
import androidx.test.core.app.ApplicationProvider
import com.kavach.accessibility.AccessibilityRepositoryImpl
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class AgyHudOverlayManagerTest {

    private lateinit var context: Context
    private lateinit var floatingOverlayManager: FloatingOverlayManager
    private lateinit var hudManager: AgyHudOverlayManager
    private val broadcastedCommands = mutableListOf<JSONObject>()

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        floatingOverlayManager = FloatingOverlayManager(context)
        broadcastedCommands.clear()
        hudManager = AgyHudOverlayManager(
            context = context,
            floatingOverlayManager = floatingOverlayManager,
            onCommandBroadcast = { cmd -> broadcastedCommands.add(cmd) }
        )
    }

    @Test
    fun `updateState parses tasks, question, autoCollapseSeconds, and screenWatch wireframe`() {
        val payload = JSONObject().apply {
            put("state", "WORKING")
            put("title", "Configure Termux Bridge")
            put("currentAction", "Tapping Connect button")
            put("nextAction", "Verify WebSocket live")
            put("autoCollapseSeconds", 5)
            put("tasks", JSONArray().apply {
                put(JSONObject().put("id", "t1").put("label", "Inspect screen").put("status", "done"))
                put(JSONObject().put("id", "t2").put("label", "Tap Connect").put("status", "doing"))
                put(JSONObject().put("id", "t3").put("label", "Verify reply").put("status", "pending"))
            })
            put("screenWatch", JSONObject().apply {
                put("active", true)
                put("label", "Settings Screen")
                put("screenWidth", 1080)
                put("screenHeight", 2400)
                put("zones", JSONArray().apply {
                    put(
                        JSONObject()
                            .put("x1", 700).put("y1", 400)
                            .put("x2", 1000).put("y2", 520)
                            .put("role", "target").put("tag", "Connect")
                    )
                })
                put(
                    "actionVector",
                    JSONObject()
                        .put("type", "TAP")
                        .put("x1", 850).put("y1", 460)
                        .put("x2", 850).put("y2", 460)
                )
            })
        }

        val res = hudManager.updateState(payload)
        assertTrue(res.optBoolean("success"))
        assertEquals("WORKING", res.optString("state"))
        assertEquals(3, res.optInt("taskCount"))
        assertTrue(res.optBoolean("screenWatchActive"))

        val stored = hudManager.hudState.value
        assertEquals("Configure Termux Bridge", stored.title)
        assertEquals(5, stored.autoCollapseSeconds)
        assertEquals("done", stored.tasks[0].status)
        assertEquals("doing", stored.tasks[1].status)
        assertEquals("pending", stored.tasks[2].status)
        assertTrue(stored.screenWatch.active)
        assertEquals(1, stored.screenWatch.zones.size)
        assertNotNull(stored.screenWatch.actionVector)
        assertEquals("TAP", stored.screenWatch.actionVector?.type)
    }

    @Test
    fun `remote PROMPT and STOP commands broadcast over WS callback and drain via poll`() {
        val promptRes = hudManager.handleRemoteCommand(
            JSONObject().put("action", "PROMPT").put("text", "List files in Termux")
        )
        assertTrue(promptRes.optBoolean("success"))

        val stopRes = hudManager.handleRemoteCommand(
            JSONObject().put("action", "STOP")
        )
        assertTrue(stopRes.optBoolean("success"))

        assertEquals(2, broadcastedCommands.size)
        assertEquals("HUD_COMMAND", broadcastedCommands[0].optString("type"))
        assertEquals("PROMPT", broadcastedCommands[0].optString("action"))
        assertEquals("List files in Termux", broadcastedCommands[0].optString("text"))
        assertEquals("STOP", broadcastedCommands[1].optString("action"))

        val poll1 = hudManager.pollCommands()
        assertTrue(poll1.optBoolean("success"))
        assertEquals(2, poll1.optInt("count"))
        val cmds = poll1.getJSONArray("commands")
        assertEquals("PROMPT", cmds.getJSONObject(0).optString("action"))
        assertEquals("STOP", cmds.getJSONObject(1).optString("action"))

        // Second poll should be empty (atomic drain)
        val poll2 = hudManager.pollCommands()
        assertEquals(0, poll2.optInt("count"))
    }

    @Test
    fun `accessibility repository self-excludes agy_hud_ prefixed nodes`() {
        val repo = AccessibilityRepositoryImpl()
        assertTrue(repo.isAgyHudIdentifier("com.kavach:id/agy_hud_window2", null))
        assertTrue(repo.isAgyHudIdentifier(null, "agy_hud_prompt_input"))
        assertTrue(repo.isAgyHudIdentifier("AGY_HUD_WIREFRAME", null))
        assertFalse(repo.isAgyHudIdentifier("com.termux:id/terminal_view", "Terminal"))
    }

    @Test
    fun `touch collision overlap detects TAP and SWIPE intersecting overlay bounds`() {
        val hudRect = listOf(Rect(650, 1800, 1050, 2320))
        // TAP inside HUD
        assertTrue(hudManager.coordinatesOverlapRects(800f, 2000f, 800f, 2000f, hudRect))
        // TAP outside HUD
        assertFalse(hudManager.coordinatesOverlapRects(200f, 400f, 200f, 400f, hudRect))
        // SWIPE crossing through HUD
        assertTrue(hudManager.coordinatesOverlapRects(500f, 2100f, 950f, 2100f, hudRect))
        // SWIPE completely above HUD
        assertFalse(hudManager.coordinatesOverlapRects(100f, 500f, 900f, 500f, hudRect))
    }

    @Test
    fun `mini wireframe view collapses to 0dp when screenWatch is inactive`() {
        val wf = MiniScreenWireframeView(context)
        wf.updateScreenWatch(
            AgyHudOverlayManager.ScreenWatchState(active = false),
            wireframeVisible = true
        )
        assertEquals(android.view.View.GONE, wf.visibility)
        wf.measure(
            android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.AT_MOST),
            android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.AT_MOST)
        )
        assertEquals(0, wf.measuredHeight)
        assertEquals(0, wf.measuredWidth)

        wf.updateScreenWatch(
            AgyHudOverlayManager.ScreenWatchState(
                active = true,
                screenWidth = 1080,
                screenHeight = 2400
            ),
            wireframeVisible = true
        )
        assertEquals(android.view.View.VISIBLE, wf.visibility)
        wf.measure(
            android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.AT_MOST),
            android.view.View.MeasureSpec.makeMeasureSpec(400, android.view.View.MeasureSpec.AT_MOST)
        )
        assertTrue(wf.measuredHeight > 0)
        assertTrue(wf.measuredWidth > 0)
    }
}
