# Nexora Vertical Shorts & Sovereign Reels Architecture Plan

Upgrade Nexora into a vertical short-form Reels platform backed by **Firebase Authentication** and the **Akash Sovereign User Vault** (`https://akashbox.duckdns.org`), combining zero-delay adjacent video pre-buffering, row-level authenticated interactions, a Saved & Liked Reels profile vault, and strict Zero Emoji text sanitization.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> **Confirmed Product & Privacy Decisions**
> 1. **Navigation Architecture**: Existing application tabs (`Home`, `Explore`, `Reels`, `Messages`, `Library`, `Profile`) are preserved, with **Reels** (`NavTab.LIVE`) serving as the dedicated full-screen vertical short-video destination.
> 2. **Authentication Gate**: Users must sign in with **Firebase Authentication** before accessing the Reels feed and sovereign user vault interactions.
> 3. **No Watch History Tracking**: Per your explicit selection, watch completion telemetry (`POST /_/u/history`) is disabled and will not be transmitted.
> 4. **Zero Emoji Enforcement**: All rendered usernames, creator handles, titles, and descriptions pass through a strict client-side Unicode emoji stripping filter.

> [!NOTE]
> **Firebase Authentication Provider Provisioning**
> In this Android build environment, automated Firebase provisioning configures **Google Sign-In via Jetpack Credential Manager (`GetSignInWithGoogleOption`)** as the primary cryptographic identity provider issuing Firebase ID tokens (`Authorization: Bearer <firebase_id_token>`). Additional manual providers can be toggled directly in the Firebase Console if desired later.

---

## Overview & Core Concept

Nexora's Reels experience delivers an instant, high-craft vertical video feed strictly curated for short-form media (`media_type == "short"` and `duration <= 120s`) served from the dedicated Akash endpoint (`GET /_/s7a1`). Every authenticated interaction—profile synchronization, liking, bookmarking, and querying per-reel interaction status—is persisted to the Akash Sovereign User Vault using the user's live Firebase ID token alongside the client application token.

---

## User Experience & Visual Design

### 1. Sovereign Authentication Gate
- **Sign-In Stage**: Before entering the Reels feed, unauthenticated users are presented with a pearl-glass **Sovereign Identity Gate** featuring one-tap Google Sign-In powered by Jetpack `CredentialManager`.
- **Automatic Vault Sync**: Immediately upon authentication, the client extracts the user's Firebase ID token and synchronizes their display name, derived handle (`email.split('@')[0]`), and avatar URL with `POST /_/u/sync`.

### 2. Full-Screen Vertical Reels Player & Lookahead Engine
- **Snap-to-Page Vertical Pager**: Full-bleed 9:16 vertical pager (`RESIZE_MODE_ZOOM`) with crisp page-snap physics.
- **Zero-Delay Lookahead Pre-Buffering**:
  - While Reel `[i]` loops seamlessly (`REPEAT_MODE_ONE`), a background `CacheWriter` pre-caches the first **2 MB** of Reel `[i + 1]` into the shared 120 MB `SimpleCache`, and preloads the thumbnail for Reel `[i + 2]`.
  - Swiping to adjacent reels transitions playback immediately with zero buffering spinner, while off-screen players pause immediately to conserve memory and bandwidth.
- **Interactive Gestures**:
  - **Single Tap**: Toggles play/pause with an animated central status indicator.
  - **Double Tap**: Triggers a spring-animated heart burst overlay and dispatches an authenticated Like action (`POST /_/u/like`).

### 3. Instagram-Style Overlay Controls & Zero Emoji Rendering
- **Right Side Action Rail**:
  - **Creator Avatar** with follow badge and profile navigation.
  - **Like Button**: Heart icon displaying live `likes_count`, synced via `GET /_/u/status/{file_code}` and toggled via `POST /_/u/like`.
  - **Save / Bookmark Button**: Bookmark icon with persistent active state toggled via `POST /_/u/saved`.
  - **Comment & Share Controls**: Quick-access comment drawer and native share sheet trigger.
- **Bottom Metadata Overlay**:
  - Bold `@creator_handle` sanitized of all emojis.
  - Video description/title clamped to **2 lines** with an inline **`more` / `less`** expansion toggle.
  - Scrolling **Audio Marquee** badge displaying original sound attribution.

### 4. Profile & Sovereign Saved / Liked Vault
- **Authenticated Profile Header**: Displays the signed-in user's synced handle, display name, avatar, account status badge, and sign-out action.
- **Dedicated Reels Vault Grids**:
  - **Saved Reels Tab**: 3-column vertical thumbnail grid populated directly from `GET /_/u/saved?media_type=short` and updated optimistically when bookmarking reels.
  - **Liked Reels Tab**: 3-column vertical thumbnail grid displaying all short reels where `is_liked == true`.
  - Tapping any tile in the Saved or Liked grids launches the full-screen vertical Reels player at that reel.

---

## Key Product Decisions & Trade-Offs

| Area | Decision | Rationale |
| :--- | :--- | :--- |
| **Feed Endpoint Isolation** | Exclusively query `GET /_/s7a1` and enforce `media_type == "short"` & `duration <= 120s` | Prevents long-form catalog items from appearing in the vertical Reels pager and ensures rapid segment pre-buffering. |
| **Optimistic UI + Sovereign Reconciliation** | Update Like (`is_liked`, `likes_count`) and Save (`is_saved`) states immediately on tap, then reconcile with server response | Keeps double-tap heart animations and bookmark toggles instantaneous at 60fps while guaranteeing Row-Level Security accuracy. |
| **Per-Reel Status Hydration** | Query `GET /_/u/status/{file_code}` when a Reel becomes the active page | Ensures accurate `is_liked`, `is_saved`, and `likes_count` state per reel without blocking initial feed rendering. |
| **Privacy-First Telemetry** | Omit `POST /_/u/history` calls | Honors user preference not to record watch history in the Sovereign User Vault. |

---

## Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────────┐
│                        Presentation Layer (Compose)                        │
│                                                                            │
│  ┌──────────────────────┐  ┌──────────────────────┐  ┌──────────────────┐  │
│  │ Sovereign Auth Gate  │  │  Vertical Reels Feed │  │  Profile Vault   │  │
│  │ (CredentialManager)  │  │  + Right/Bottom HUD  │  │ (Saved & Liked)  │  │
│  └──────────┬───────────┘  └──────────┬───────────┘  └────────┬─────────┘  │
└─────────────┼─────────────────────────┼───────────────────────┼────────────┘
              │                         │                       │
              ▼                         ▼                       ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                   State & Domain Layer (NexoraViewModel)                   │
│                                                                            │
│  • Firebase Auth State Listener & ID Token Provider                        │
│  • Zero Emoji Sanitizer Regex Engine                                       │
│  • Optimistic Like / Save State & Active Reel Status Hydration             │
│  • ExoPlayer 2MB Lookahead Pre-Buffer Coordinator                          │
└───────────────────────────┬───────────────────────────────────┬────────────┘
                            │                                   │
                            ▼                                   ▼
┌───────────────────────────────────────┐   ┌────────────────────────────────┐
│       Firebase Authentication         │   │  Akash Sovereign Backend API   │
│                                       │   │  (https://akashbox.duckdns.org)│
│  • Google Sign-In (GetSignInWithGoogle│   │  • GET  /_/s7a1 (Shorts Feed)  │
│    Option / GetGoogleIdOption)        │   │  • POST /_/u/sync              │
│  • Issues Bearer ID Token             │   │  • POST /_/u/like              │
│                                       │   │  • POST /_/u/saved             │
│                                       │   │  • GET  /_/u/saved?media_type= │
│                                       │   │  • GET  /_/u/status/{code}     │
└───────────────────────────────────────┘   └────────────────────────────────┘
```

### Data & Security Pipeline
1. **Header Injection**: Every request to `https://akashbox.duckdns.org` attaches `x-app-token: akash_sec_client_03e804cabbbcface799a4522ca673dd166b8e76813f84389`. When a Firebase user is signed in, a fresh token from `firebaseUser.getIdToken(false)` is attached as `Authorization: Bearer <firebase_id_token>`.
2. **Zero Emoji Regex Sanitization**: All incoming strings (`title`, `author`, `creator_handle`, user profile names) and outgoing display strings are stripped of emojis and pictographs via a centralized Unicode regex sanitizer covering `[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]` before entering UI state.
3. **Media Pre-Buffering Pipeline**: `ReelsLookaheadCacheManager` uses a singleton `SimpleCache` and `CacheDataSource.Factory` to stream the active reel while asynchronously caching the first `2 * 1024 * 1024` bytes of `clips[activeIndex + 1]` and warming the image cache for `clips[activeIndex + 2]`.
