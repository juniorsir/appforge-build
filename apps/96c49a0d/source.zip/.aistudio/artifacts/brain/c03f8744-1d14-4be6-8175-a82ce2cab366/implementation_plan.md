# Audio-Video Synchronization (`audio = video`) Plan

## Goal
Ensure strict, frame-accurate audio and video synchronization across all video playback surfaces (Home feed inline previews and fullscreen Shorts viewer) during startup, active playback, buffering recovery, seeking, looping, and quality switches.

## Root Causes Identified
1. **Redundant Surface Re-binding on Recomposition**: `AndroidView.update` in `AkashInlineClipExoPlayer.kt` calls `exoPlayer.setVideoTextureView(textureView)` on every Compose recomposition, which interrupts the hardware video surface pipeline while the audio renderer continues advancing.
2. **Audio Running Ahead of First Video Frame**: AAC audio decodes almost instantaneously while 1080p hardware video decoding takes longer to render its first frame, causing audio to play over the poster thumbnail before video frames appear and introducing startup clock offset.
3. **Under-Buffered Startup Threshold**: `DefaultLoadControl` currently uses `bufferForPlaybackMs = 450`, allowing playback to enter `STATE_READY` as soon as tiny audio packets arrive before a full video keyframe GOP is ready.
4. **Quality Switch & Seek Transitions**: Switching stream quality (`loadedMediaUri != directStreamUrl`) or scrubbing does not re-lock the first-frame render gate, allowing audio to play before the video decoder locks onto the target keyframe.

## Proposed Changes

### 1. Hardware Clock Master & Renderer Synchronization (`AkashInlineClipExoPlayer.kt`)
- Configure `DefaultRenderersFactory(context)` with:
  - `setEnableDecoderFallback(true)` to prevent codec stalls on high-profile 1080p streams.
  - `setAllowedJoiningTimeMs(5_000L)` so video and audio renderers join tightly onto the shared media clock.
- Configure `AudioAttributes` with `C.USAGE_MEDIA` and `C.CONTENT_TYPE_MOVIE` on `ExoPlayer.Builder` so Android's `AudioTrack` uses movie-mode hardware timestamp synchronization (`AudioTimestamp` master clock).
- Update `DefaultLoadControl` buffering thresholds (`bufferForPlaybackMs = 1_200`, `bufferForPlaybackAfterRebufferMs = 2_200`) so both audio and video sample queues have complete keyframes before playback resumes.

### 2. First-Frame & Buffering A/V Lock (`AkashInlineClipExoPlayer.kt`)
- Hold audible output (`exoPlayer.volume = 0f`) while `!hasRenderedFirstFrame` or `isBuffering` is true, unmuting (`1f` when not muted) only when `onRenderedFirstFrame` has fired and `playbackState == Player.STATE_READY`.
- On initial startup (`targetStartPositionMs == 0L`), if the audio clock advanced slightly while waiting for the hardware video decoder to render the very first frame (`onRenderedFirstFrame`), snap `exoPlayer.seekTo(0L)` so audio and video begin locked together from `0:00`.
- Reset `hasRenderedFirstFrame = false` whenever switching quality streams (`loadedMediaUri != directStreamUrl`) so audio waits for the new video stream's first frame at `previousPositionMs` before unmuting.

### 3. Single-Bind Video Surface Pipeline (`AkashInlineClipExoPlayer.kt`)
- Track the bound `ExoPlayer` instance on the `TextureView` tag inside `AndroidView` and only call `exoPlayer.setVideoTextureView(textureView)` when the player instance or surface actually changes, preventing recompositions from disrupting video frame delivery.
- Add `onPositionDiscontinuity` handling in `Player.Listener` to keep progress and renderer states synchronized across user seeks and loop boundaries.

## Verification Plan
- Run `compile_applet` to verify zero compilation or type errors across the project.
