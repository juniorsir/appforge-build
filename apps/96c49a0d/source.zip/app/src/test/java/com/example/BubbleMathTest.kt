package com.example

import com.example.nexora.animation.BubbleMath
import com.example.nexora.animation.ClickOrigin
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BubbleMathTest {

    @Test
    fun `computeStageBubbleGeometry places pivot at origin at p=0 and converges to identity at p=1`() {
        // Button clicked in top header at (320, 48), while stage container starts at (0, 96) with size (1080, 1800)
        val originX = 320f
        val originY = 48f
        val containerLeft = 0f
        val containerTop = 96f
        val containerWidth = 1080f
        val containerHeight = 1800f

        val geom = BubbleMath.computeStageBubbleGeometry(
            originX = originX,
            originY = originY,
            containerLeft = containerLeft,
            containerTop = containerTop,
            containerWidth = containerWidth,
            containerHeight = containerHeight
        )

        // At p = 0, effective origin in screen space must equal (originX, originY)
        assertEquals(originX, geom.effectiveOriginScreenXAt(containerLeft, 0f), 0.001f)
        assertEquals(originY, geom.effectiveOriginScreenYAt(containerTop, 0f), 0.001f)
        assertEquals(0.055f, geom.scaleAt(0f), 0.0001f)

        // At p = 1, translation offset converges to (0, 0) and scale converges to 1.0f
        assertEquals(0f, geom.translationXAt(1f), 0.0001f)
        assertEquals(0f, geom.translationYAt(1f), 0.0001f)
        assertEquals(1.0f, geom.scaleAt(1f), 0.0001f)
        assertTrue(geom.maxRadius > 1000f)
    }

    @Test
    fun `computeModalBubbleGeometry translates modal center by delta to clicked button at p=0`() {
        val viewportWidth = 1080f
        val viewportHeight = 2400f
        val originX = 920f
        val originY = 72f

        val modalGeom = BubbleMath.computeModalBubbleGeometry(
            originX = originX,
            originY = originY,
            viewportWidth = viewportWidth,
            viewportHeight = viewportHeight
        )

        val expectedDeltaX = originX - (viewportWidth / 2f)
        val expectedDeltaY = originY - (viewportHeight / 2f)

        assertEquals(expectedDeltaX, modalGeom.deltaX, 0.001f)
        assertEquals(expectedDeltaY, modalGeom.deltaY, 0.001f)
        assertEquals(expectedDeltaX, modalGeom.translationXAt(0f), 0.001f)
        assertEquals(expectedDeltaY, modalGeom.translationYAt(0f), 0.001f)
        assertEquals(0f, modalGeom.translationXAt(1f), 0.001f)
        assertEquals(0f, modalGeom.translationYAt(1f), 0.001f)
        assertEquals(1.0f, modalGeom.scaleAt(1f), 0.001f)
    }

    @Test
    fun `concentricInnerRadius enforces R_inner = max(R_outer - P, 8dp)`() {
        // RadiusOuterXL = 28.dp with 8.dp padding -> RadiusInnerXL = 20.dp
        assertEquals(20f, BubbleMath.concentricInnerRadius(28f, 8f), 0.001f)
        // RadiusOuterLG = 24.dp with 8.dp padding -> RadiusInnerLG = 16.dp
        assertEquals(16f, BubbleMath.concentricInnerRadius(24f, 8f), 0.001f)
        // RadiusOuterMD = 20.dp with 8.dp padding -> RadiusInnerMD = 12.dp
        assertEquals(12f, BubbleMath.concentricInnerRadius(20f, 8f), 0.001f)
        // Enforces minimum 8.dp bound
        assertEquals(8f, BubbleMath.concentricInnerRadius(12f, 10f), 0.001f)
    }

    @Test
    fun `computeVideoCardGeometry enforces exact mathematical proportions and avatar clamping`() {
        val cardGeom = BubbleMath.computeVideoCardGeometry(360f)
        // r = min(0.055 * 360, 24) = 19.8
        assertEquals(19.8f, cardGeom.outerCornerRadiusDp, 0.01f)
        assertEquals(10f, cardGeom.outerPaddingDp, 0.01f)
        // r_thumb = max(19.8 - 4, 12) = 15.8
        assertEquals(15.8f, cardGeom.innerThumbnailCornerRadiusDp, 0.01f)
        // H_t = 0.64 * 360 = 230.4
        assertEquals(230.4f, cardGeom.thumbnailHeightDp, 0.01f)
        // D_a = clamp(34, 0.115 * 360 = 41.4, 44) = 41.4
        assertEquals(41.4f, cardGeom.avatarDiameterDp, 0.01f)

        val normalized = ClickOrigin.fromRootCoordinates(10f, 2390f, 1000f, 2400f, 123L)
        assertEquals(0.05f, normalized.u, 0.001f)
        assertEquals(0.95f, normalized.v, 0.001f)
    }
}
