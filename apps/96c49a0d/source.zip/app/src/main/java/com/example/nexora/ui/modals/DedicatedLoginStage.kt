package com.example.nexora.ui.modals

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import com.example.ui.theme.NexoraColors
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.nexora.network.AkashMediaService
import com.example.ui.theme.InterFamily
import com.example.ui.theme.PlusJakartaSansFamily
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.Firebase
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull

private fun normalizeIdentifierToEmail(rawIdentifier: String): String {
    val trimmed = rawIdentifier.trim()
    return if (trimmed.contains("@")) {
        trimmed.lowercase()
    } else {
        "${trimmed.lowercase().removePrefix("@").replace(" ", "_")}@nexora.io"
    }
}

private val NexoraPrimary = Color(0xFF0095F6)
private val NexoraSecondary = Color(0xFF0095F6)
private val NexoraErrorRed = Color(0xFFFF3040)
private val NexoraSuccessGreen = Color(0xFF10B981)

private const val PREFS_LANGUAGE = "nexora_language_pack_prefs"
private const val KEY_SELECTED_LANG = "selected_lang_code"
private const val KEY_DOWNLOADED_PACKS = "downloaded_lang_codes"
private const val KEY_REGISTERED_ACCOUNTS = "registered_account_identifiers"

data class LanguagePackItem(
    val code: String,
    val englishName: String,
    val nativeName: String,
    val region: String,
    val sizeMb: String,
    val isIndianLanguage: Boolean,
    val isPreInstalled: Boolean = false
)

data class LocalizedLoginStrings(
    val signInSubtitle: String,
    val signUpSubtitle: String,
    val emailOrUsernameHint: String,
    val emailOrPhoneHint: String,
    val fullNameHint: String,
    val usernameHint: String,
    val passwordHint: String,
    val showPassword: String,
    val hidePassword: String,
    val forgotPassword: String,
    val signInButton: String,
    val createAccountButton: String,
    val orDivider: String,
    val continueWithGoogle: String,
    val exploreAsGuest: String,
    val noAccountPrompt: String,
    val haveAccountPrompt: String,
    val signUpLink: String,
    val signInLink: String
)

private val ALL_LANGUAGE_PACKS: List<LanguagePackItem> = listOf(
    // Pre-installed defaults
    LanguagePackItem("en_US", "English (US)", "English (US)", "United States", "Built-in", isIndianLanguage = false, isPreInstalled = true),
    LanguagePackItem("en_IN", "English (India)", "English (India)", "India", "Built-in", isIndianLanguage = true, isPreInstalled = true),

    // Complete Indian Regional & Scheduled Languages Pack (26 Languages)
    LanguagePackItem("hi_IN", "Hindi", "हिन्दी", "North & Central India", "2.4 MB", isIndianLanguage = true),
    LanguagePackItem("bn_IN", "Bengali", "বাংলা", "West Bengal & Tripura", "2.3 MB", isIndianLanguage = true),
    LanguagePackItem("te_IN", "Telugu", "తెలుగు", "Andhra Pradesh & Telangana", "2.5 MB", isIndianLanguage = true),
    LanguagePackItem("mr_IN", "Marathi", "मराठी", "Maharashtra & Goa", "2.2 MB", isIndianLanguage = true),
    LanguagePackItem("ta_IN", "Tamil", "தமிழ்", "Tamil Nadu & Puducherry", "2.4 MB", isIndianLanguage = true),
    LanguagePackItem("ur_IN", "Urdu", "اردو", "Jammu & Kashmir, Telangana, UP", "2.1 MB", isIndianLanguage = true),
    LanguagePackItem("gu_IN", "Gujarati", "ગુજરાતી", "Gujarat & Daman", "2.2 MB", isIndianLanguage = true),
    LanguagePackItem("kn_IN", "Kannada", "ಕನ್ನಡ", "Karnataka", "2.4 MB", isIndianLanguage = true),
    LanguagePackItem("ml_IN", "Malayalam", "മലയാളം", "Kerala & Lakshadweep", "2.6 MB", isIndianLanguage = true),
    LanguagePackItem("or_IN", "Odia", "ଓଡ଼ିଆ", "Odisha", "2.3 MB", isIndianLanguage = true),
    LanguagePackItem("pa_IN", "Punjabi", "ਪੰਜਾਬੀ", "Punjab & Chandigarh", "2.1 MB", isIndianLanguage = true),
    LanguagePackItem("as_IN", "Assamese", "অসমীয়া", "Assam & Northeast", "2.2 MB", isIndianLanguage = true),
    LanguagePackItem("mai_IN", "Maithili", "मैथिली", "Bihar & Jharkhand", "1.9 MB", isIndianLanguage = true),
    LanguagePackItem("sat_IN", "Santali", "ᱥᱟᱱᱛᱟᱲᱤ", "Jharkhand, Odisha & WB", "1.8 MB", isIndianLanguage = true),
    LanguagePackItem("ks_IN", "Kashmiri", "कॉशुर / کٲشُر", "Jammu & Kashmir", "2.0 MB", isIndianLanguage = true),
    LanguagePackItem("ne_IN", "Nepali", "नेपाली", "Sikkim & Darjeeling", "2.0 MB", isIndianLanguage = true),
    LanguagePackItem("sd_IN", "Sindhi", "सिन्धी / سنڌي", "Gujarat & Rajasthan", "1.9 MB", isIndianLanguage = true),
    LanguagePackItem("doi_IN", "Dogri", "डोगरी", "Jammu & Himachal", "1.8 MB", isIndianLanguage = true),
    LanguagePackItem("kok_IN", "Konkani", "कोंकणी", "Goa & Coastal Karnataka", "1.9 MB", isIndianLanguage = true),
    LanguagePackItem("mni_IN", "Manipuri (Meitei)", "মৈতৈলোন্", "Manipur", "2.0 MB", isIndianLanguage = true),
    LanguagePackItem("brx_IN", "Bodo", "बर' / बड़ो", "Assam (Bodoland)", "1.8 MB", isIndianLanguage = true),
    LanguagePackItem("sa_IN", "Sanskrit", "संस्कृतम्", "Pan-India Classical", "2.1 MB", isIndianLanguage = true),
    LanguagePackItem("bho_IN", "Bhojpuri", "भोजपुरी", "Bihar, UP & Jharkhand", "1.9 MB", isIndianLanguage = true),
    LanguagePackItem("raj_IN", "Rajasthani (Marwari)", "राजस्थानी", "Rajasthan", "1.9 MB", isIndianLanguage = true),
    LanguagePackItem("bgc_IN", "Haryanvi", "हरियाणवी", "Haryana & Delhi NCR", "1.8 MB", isIndianLanguage = true),
    LanguagePackItem("tcy_IN", "Tulu", "ತುಳು", "Coastal Karnataka & Kerala", "1.8 MB", isIndianLanguage = true),

    // Global Languages
    LanguagePackItem("en_GB", "English (UK)", "English (UK)", "United Kingdom", "1.6 MB", isIndianLanguage = false),
    LanguagePackItem("es_ES", "Spanish", "Español", "Spain & Latin America", "2.1 MB", isIndianLanguage = false),
    LanguagePackItem("fr_FR", "French", "Français", "France & Canada", "2.1 MB", isIndianLanguage = false),
    LanguagePackItem("de_DE", "German", "Deutsch", "Germany & Austria", "2.2 MB", isIndianLanguage = false),
    LanguagePackItem("ja_JP", "Japanese", "日本語", "Japan", "2.8 MB", isIndianLanguage = false),
    LanguagePackItem("ko_KR", "Korean", "한국어", "South Korea", "2.5 MB", isIndianLanguage = false),
    LanguagePackItem("ar_SA", "Arabic", "العربية", "MENA Region", "2.3 MB", isIndianLanguage = false),
    LanguagePackItem("pt_BR", "Portuguese", "Português (Brasil)", "Brazil & Portugal", "2.1 MB", isIndianLanguage = false),
    LanguagePackItem("ru_RU", "Russian", "Русский", "Eastern Europe", "2.4 MB", isIndianLanguage = false)
)

private fun getLocalizedStrings(code: String): LocalizedLoginStrings {
    return when (code) {
        "hi_IN", "mai_IN", "bho_IN", "raj_IN", "bgc_IN", "doi_IN", "sa_IN", "ne_IN", "kok_IN" -> LocalizedLoginStrings(
            signInSubtitle = "क्रिएटर्स, रील्स और लाइव स्ट्रीम देखने के लिए साइन इन करें",
            signUpSubtitle = "वीडियो शेयर करने और जुड़ने के लिए अपना अकाउंट बनाएं",
            emailOrUsernameHint = "यूज़रनेम, ईमेल या फ़ोन नंबर",
            emailOrPhoneHint = "ईमेल पता या फ़ोन नंबर",
            fullNameHint = "पूरा नाम",
            usernameHint = "यूज़रनेम",
            passwordHint = "पासवर्ड",
            showPassword = "दिखाएं",
            hidePassword = "छिपाएं",
            forgotPassword = "पासवर्ड भूल गए?",
            signInButton = "साइन इन करें",
            createAccountButton = "अकाउंट बनाएं",
            orDivider = "या",
            continueWithGoogle = "Google के साथ जारी रखें",
            exploreAsGuest = "गेस्ट के रूप में देखें",
            noAccountPrompt = "क्या आपका अकाउंट नहीं है? ",
            haveAccountPrompt = "पहले से अकाउंट है? ",
            signUpLink = "साइन अप करें",
            signInLink = "साइन इन करें"
        )
        "bn_IN", "as_IN", "mni_IN" -> LocalizedLoginStrings(
            signInSubtitle = "ক্রিয়েটর, রিলস এবং লাইভ স্ট্রিম দেখতে সাইন ইন করুন",
            signUpSubtitle = "ভিডিও শেয়ার করতে আপনার অ্যাকাউন্ট তৈরি করুন",
            emailOrUsernameHint = "ইউজারনেম, ইমেইল বা ফোন",
            emailOrPhoneHint = "ইমেইল বা ফোন নম্বর",
            fullNameHint = "পুরো নাম",
            usernameHint = "ইউজারনেম",
            passwordHint = "পাসওয়ার্ড",
            showPassword = "দেখান",
            hidePassword = "লুকান",
            forgotPassword = "পাসওয়ার্ড ভুলে গেছেন?",
            signInButton = "সাইন ইন করুন",
            createAccountButton = "অ্যাকাউন্ট তৈরি করুন",
            orDivider = "অথবা",
            continueWithGoogle = "Google দিয়ে চালিয়ে যান",
            exploreAsGuest = "গেস্ট হিসেবে দেখুন",
            noAccountPrompt = "কোনো অ্যাকাউন্ট নেই? ",
            haveAccountPrompt = "ইতিমধ্যে অ্যাকাউন্ট আছে? ",
            signUpLink = "সাইন আপ",
            signInLink = "সাইন ইন"
        )
        "te_IN" -> LocalizedLoginStrings(
            signInSubtitle = "క్రియేటర్లు, రీల్స్ మరియు లైవ్ స్ట్రీమ్‌ల కోసం సైన్ ఇన్ చేయండి",
            signUpSubtitle = "వీడియోలను షేర్ చేయడానికి మీ ఖాతాను సృష్టించండి",
            emailOrUsernameHint = "యూజర్‌నేమ్, ఇమెయిల్ లేదా ఫోన్",
            emailOrPhoneHint = "ఇమెయిల్ లేదా ఫోన్ నంబర్",
            fullNameHint = "పూర్తి పేరు",
            usernameHint = "యూజర్‌నేమ్",
            passwordHint = "పాస్‌వర్డ్",
            showPassword = "చూపు",
            hidePassword = "దాచు",
            forgotPassword = "పాస్‌వర్డ్ మర్చిపోయారా?",
            signInButton = "సైన్ ఇన్ చేయండి",
            createAccountButton = "ఖాతాను సృష్టించండి",
            orDivider = "లేదా",
            continueWithGoogle = "Googleతో కొనసాగించండి",
            exploreAsGuest = "అతిథిగా కొనసాగండి",
            noAccountPrompt = "ఖాతా లేదా? ",
            haveAccountPrompt = "ఇప్పటికే ఖాతా ఉందా? ",
            signUpLink = "సైన్ అప్",
            signInLink = "సైన్ ఇన్"
        )
        "mr_IN" -> LocalizedLoginStrings(
            signInSubtitle = "क्रिएटर्स, रील्स आणि लाइव्ह स्ट्रीम पाहण्यासाठी साइन इन करा",
            signUpSubtitle = "व्हिडिओ शेअर करण्यासाठी तुमचे खाते तयार करा",
            emailOrUsernameHint = "युजरनेम, ईमेल किंवा फोन",
            emailOrPhoneHint = "ईमेल किंवा फोन नंबर",
            fullNameHint = "पूर्ण नाव",
            usernameHint = "युजरनेम",
            passwordHint = "पासवर्ड",
            showPassword = "दाखवा",
            hidePassword = "लपवा",
            forgotPassword = "पासवर्ड विसरलात?",
            signInButton = "साइन इन करा",
            createAccountButton = "खाते तयार करा",
            orDivider = "किंवा",
            continueWithGoogle = "Google सह सुरू ठेवा",
            exploreAsGuest = "पाहुणे म्हणून पहा",
            noAccountPrompt = "खाते नाही? ",
            haveAccountPrompt = "आधीच खाते आहे? ",
            signUpLink = "साइन अप करा",
            signInLink = "साइन इन करा"
        )
        "ta_IN" -> LocalizedLoginStrings(
            signInSubtitle = "ரீல்ஸ் மற்றும் நேரலை வீடியோக்களைக் காண உள்நுழையவும்",
            signUpSubtitle = "வீடியோக்களைப் பகிர உங்கள் கணக்கை உருவாக்கவும்",
            emailOrUsernameHint = "பயனர்பெயர், மின்னஞ்சல் அல்லது தொலைபேசி",
            emailOrPhoneHint = "மின்னஞ்சல் அல்லது தொலைபேசி எண்",
            fullNameHint = "முழு பெயர்",
            usernameHint = "பயனர்பெயர்",
            passwordHint = "கடவுச்சொல்",
            showPassword = "காட்டு",
            hidePassword = "மறை",
            forgotPassword = "கடவுச்சொல்லை மறந்துவிட்டீர்களா?",
            signInButton = "உள்நுழைய",
            createAccountButton = "கணக்கை உருவாக்கு",
            orDivider = "அல்லது",
            continueWithGoogle = "Google மூலம் தொடரவும்",
            exploreAsGuest = "விருந்தினராக பார்க்கவும்",
            noAccountPrompt = "கணக்கு இல்லையா? ",
            haveAccountPrompt = "ஏற்கனவே கணக்கு உள்ளதா? ",
            signUpLink = "பதிவு செய்க",
            signInLink = "உள்நுழைய"
        )
        "gu_IN" -> LocalizedLoginStrings(
            signInSubtitle = "ક્રિએટર્સ, રીલ્સ અને લાઇવ સ્ટ્રીમ્સ જોવા માટે સાઇન ઇન કરો",
            signUpSubtitle = "વીડિયો શેર કરવા માટે તમારું એકાઉન્ટ બનાવો",
            emailOrUsernameHint = "યુઝરનેમ, ઇમેઇલ અથવા ફોન",
            emailOrPhoneHint = "ઇમેઇલ અથવા ફોન નંબર",
            fullNameHint = "પૂરું નામ",
            usernameHint = "યુઝરનેમ",
            passwordHint = "પાસવર્ડ",
            showPassword = "બતાવો",
            hidePassword = "છુપાવો",
            forgotPassword = "પાસવર્ડ ભૂલી ગયા છો?",
            signInButton = "સાઇન ઇન કરો",
            createAccountButton = "એકાઉન્ટ બનાવો",
            orDivider = "અથवा",
            continueWithGoogle = "Google સાથે ચાલુ રાખો",
            exploreAsGuest = "મહેમાન તરીકે જુઓ",
            noAccountPrompt = "એકાઉન્ટ નથી? ",
            haveAccountPrompt = "પહેલેથી એકાઉન્ટ છે? ",
            signUpLink = "સાઇન અપ કરો",
            signInLink = "સાઇન ઇન કરો"
        )
        "kn_IN", "tcy_IN" -> LocalizedLoginStrings(
            signInSubtitle = "ರೀಲ್ಸ್ ಮತ್ತು ಲೈವ್ ಸ್ಟ್ರೀಮ್‌ಗಳನ್ನು ವೀಕ್ಷಿಸಲು ಸೈನ್ ಇನ್ ಮಾಡಿ",
            signUpSubtitle = "ವೀಡಿಯೊಗಳನ್ನು ಹಂಚಿಕೊಳ್ಳಲು ನಿಮ್ಮ ಖಾತೆಯನ್ನು ರಚಿಸಿ",
            emailOrUsernameHint = "ಬಳಕೆದಾರಹೆಸರು, ಇಮೇಲ್ ಅಥವಾ ಫೋನ್",
            emailOrPhoneHint = "ಇಮೇಲ್ ಅಥವಾ ಫೋನ್ ಸಂಖ್ಯೆ",
            fullNameHint = "ಪೂರ್ಣ ಹೆಸರು",
            usernameHint = "ಬಳಕೆದಾರಹೆಸರು",
            passwordHint = "ಪಾಸ್‌ವರ್ಡ್",
            showPassword = "ತೋರಿಸು",
            hidePassword = "ಮರೆಮಾಡು",
            forgotPassword = "ಪಾಸ್‌ವರ್ಡ್ ಮರೆತಿರುವಿರಾ?",
            signInButton = "ಸೈನ್ ಇನ್ ಮಾಡಿ",
            createAccountButton = "ಖಾತೆ ರಚಿಸಿ",
            orDivider = "ಅಥವಾ",
            continueWithGoogle = "Google ಮೂಲಕ ಮುಂದುವರಿಸಿ",
            exploreAsGuest = "ಅತಿಥಿಯಾಗಿ ವೀಕ್ಷಿಸಿ",
            noAccountPrompt = "ಖಾತೆ ಇಲ್ಲವೇ? ",
            haveAccountPrompt = "ಈಗಾಗಲೇ ಖಾತೆ ಇದೆಯೇ? ",
            signUpLink = "ಸೈನ್ ಅಪ್",
            signInLink = "ಸೈನ್ ಇನ್"
        )
        "ml_IN" -> LocalizedLoginStrings(
            signInSubtitle = "റീലുകളും ലൈവ് സ്ട്രീമുകളും കാണാൻ സൈൻ ഇൻ ചെയ്യുക",
            signUpSubtitle = "വീഡിയോകൾ പങ്കിടാൻ നിങ്ങളുടെ അക്കൗണ്ട് നിർമ്മിക്കുക",
            emailOrUsernameHint = "യൂസർനെയിം, ഇമെയിൽ അല്ലെങ്കിൽ ഫോൺ",
            emailOrPhoneHint = "ഇമെയിൽ അല്ലെങ്കിൽ ഫോൺ നമ്പർ",
            fullNameHint = "പൂർണ്ണമായ പേര്",
            usernameHint = "യൂസർനെയിം",
            passwordHint = "പാസ്‌വേഡ്",
            showPassword = "കാണിക്കുക",
            hidePassword = "മറയ്ക്കുക",
            forgotPassword = "പാസ്‌വേഡ് മറന്നോ?",
            signInButton = "സൈൻ ഇൻ ചെയ്യുക",
            createAccountButton = "അക്കൗണ്ട് നിർമ്മിക്കുക",
            orDivider = "അല്ലെങ്കിൽ",
            continueWithGoogle = "Google ഉപയോഗിച്ച് തുടരുക",
            exploreAsGuest = "അതിഥിയായി കാണുക",
            noAccountPrompt = "അക്കൗണ്ട് ഇല്ലേ? ",
            haveAccountPrompt = "അക്കൗണ്ട് ഉണ്ടോ? ",
            signUpLink = "സൈൻ അപ്പ്",
            signInLink = "സൈൻ ഇൻ"
        )
        "pa_IN" -> LocalizedLoginStrings(
            signInSubtitle = "ਰੀਲਜ਼ ਅਤੇ ਲਾਈਵ ਸਟ੍ਰੀਮ ਦੇਖਣ ਲਈ ਸਾਈਨ ਇਨ ਕਰੋ",
            signUpSubtitle = "ਵੀਡੀਓ ਸਾਂਝੇ ਕਰਨ ਲਈ ਆਪਣਾ ਖਾਤਾ ਬਣਾਓ",
            emailOrUsernameHint = "ਯੂਜ਼ਰਨੇਮ, ਈਮੇਲ ਜਾਂ ਫ਼ੋਨ",
            emailOrPhoneHint = "ਈਮੇਲ ਜਾਂ ਫ਼ੋਨ ਨੰਬਰ",
            fullNameHint = "ਪੂਰਾ ਨਾਮ",
            usernameHint = "ਯੂਜ਼ਰਨੇਮ",
            passwordHint = "ਪਾਸਵਰਡ",
            showPassword = "ਦਿਖਾਓ",
            hidePassword = "ਲੁਕਾਓ",
            forgotPassword = "ਪਾਸਵਰਡ ਭੁੱਲ ਗਏ?",
            signInButton = "ਸਾਈਨ ਇਨ ਕਰੋ",
            createAccountButton = "ਖਾਤਾ ਬਣਾਓ",
            orDivider = "ਜਾਂ",
            continueWithGoogle = "Google ਨਾਲ ਜਾਰੀ ਰੱਖੋ",
            exploreAsGuest = "ਮਹਿਮਾਨ ਵਜੋਂ ਦੇਖੋ",
            noAccountPrompt = "ਖਾਤਾ ਨਹੀਂ ਹੈ? ",
            haveAccountPrompt = "ਪਹਿਲਾਂ ਤੋਂ ਖਾਤਾ ਹੈ? ",
            signUpLink = "ਸਾਈਨ ਅੱਪ",
            signInLink = "ਸਾਈਨ ਇਨ"
        )
        "or_IN" -> LocalizedLoginStrings(
            signInSubtitle = "ରିଲ୍ସ ଏବଂ ଲାଇଭ୍ ଷ୍ଟ୍ରିମ୍ ଦେଖିବାକୁ ସାଇନ୍ ଇନ୍ କରନ୍ତୁ",
            signUpSubtitle = "ଭିଡିଓ ସେୟାର୍ କରିବାକୁ ଆପଣଙ୍କ ଆକାଉଣ୍ଟ୍ ତିଆରି କରନ୍ତୁ",
            emailOrUsernameHint = "ୟୁଜରନେମ୍, ଇମେଲ୍ କିମ୍ବା ଫୋନ୍",
            emailOrPhoneHint = "ଇମେଲ୍ କିମ୍ବା ଫୋନ୍ ନମ୍ବର",
            fullNameHint = "ପୂରା ନାମ",
            usernameHint = "ୟୁଜରନେମ୍",
            passwordHint = "ପାସୱାର୍ଡ",
            showPassword = "ଦେଖାନ୍ତୁ",
            hidePassword = "ଲୁଚାନ୍ତୁ",
            forgotPassword = "ପାସୱାର୍ଡ ଭୁଲିଗଲେ କି?",
            signInButton = "ସାଇନ୍ ଇନ୍ କରନ୍ତୁ",
            createAccountButton = "ଆକାଉଣ୍ଟ୍ ତିଆରି କରନ୍ତୁ",
            orDivider = "କିମ୍ବା",
            continueWithGoogle = "Google ସହିତ ଜାରି ରଖନ୍ତୁ",
            exploreAsGuest = "ଅତିଥି ଭାବେ ଦେଖନ୍ତୁ",
            noAccountPrompt = "ଆକାଉଣ୍ଟ୍ ନାହିଁ କି? ",
            haveAccountPrompt = "ପୂର୍ବରୁ ଆକାଉଣ୍ଟ୍ ଅଛି କି? ",
            signUpLink = "ସାଇନ୍ ଅପ୍",
            signInLink = "ସାଇନ୍ ଇନ୍"
        )
        "ur_IN", "ks_IN", "sd_IN" -> LocalizedLoginStrings(
            signInSubtitle = "کریئیٹرز، ریلز اور لائیو اسٹریمز دیکھنے کے لیے سائن ان کریں",
            signUpSubtitle = "ویڈیوز شیئر کرنے کے لیے اپنا اکاؤنٹ بنائیں",
            emailOrUsernameHint = "یوزر نیم، ای میل یا فون",
            emailOrPhoneHint = "ای میل یا فون نمبر",
            fullNameHint = "پورا نام",
            usernameHint = "یوزر نیم",
            passwordHint = "پاس ورڈ",
            showPassword = "دکھائیں",
            hidePassword = "چھپائیں",
            forgotPassword = "پاس ورڈ بھول گئے؟",
            signInButton = "سائن ان کریں",
            createAccountButton = "اکاؤنٹ بنائیں",
            orDivider = "یا",
            continueWithGoogle = "Google کے ساتھ جاری رکھیں",
            exploreAsGuest = "مہمان کے طور پر دیکھیں",
            noAccountPrompt = "اکاؤنٹ نہیں ہے؟ ",
            haveAccountPrompt = "پہلے سے اکاؤنٹ ہے؟ ",
            signUpLink = "سائن اپ کریں",
            signInLink = "سائن ان کریں"
        )
        else -> LocalizedLoginStrings(
            signInSubtitle = "Sign in to discover creators, reels, and live streams",
            signUpSubtitle = "Create your account to share videos and connect",
            emailOrUsernameHint = "Username, email, or phone",
            emailOrPhoneHint = "Email address or phone",
            fullNameHint = "Full name",
            usernameHint = "Username",
            passwordHint = "Password",
            showPassword = "Show",
            hidePassword = "Hide",
            forgotPassword = "Forgot password?",
            signInButton = "Sign In",
            createAccountButton = "Create Account",
            orDivider = "OR",
            continueWithGoogle = "Continue with Google",
            exploreAsGuest = "Explore as Guest",
            noAccountPrompt = "Don't have an account? ",
            haveAccountPrompt = "Already have an account? ",
            signUpLink = "Sign up",
            signInLink = "Sign in"
        )
    }
}

/**
 * Clean Full-Screen Native Mobile Login & Registration Page for Nexora:
 * - Language selection moved to the bottom bar
 * - Includes downloadable Language Pack Manager with all 26 Indian regional & scheduled languages + Global packs
 * - One-tap "Download All Indian Languages" pack bundle with real-time progress and persistent storage
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DedicatedLoginStage(
    onAuthenticated: (
        uid: String,
        displayName: String,
        email: String,
        handle: String,
        avatarUrl: String?,
        idToken: String?
    ) -> Unit,
    onContinueAsGuest: () -> Unit,
    onEmailSignIn: (email: String, pass: String, onSuccess: () -> Unit, onError: (String) -> Unit) -> Unit = { _, _, _, _ -> },
    onEmailRegister: (email: String, pass: String, displayName: String, onSuccess: () -> Unit, onError: (String) -> Unit) -> Unit = { _, _, _, _, _ -> },
    onBack: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    val prefs = remember { context.getSharedPreferences(PREFS_LANGUAGE, Context.MODE_PRIVATE) }

    // Always enforce Instagram Dark UI across all screens and modals
    var isDarkMode by remember { mutableStateOf(true) }

    // Persisted Language & Downloaded Packs State
    var selectedLangCode by remember {
        mutableStateOf(prefs.getString(KEY_SELECTED_LANG, "en_US") ?: "en_US")
    }
    var downloadedPackCodes by remember {
        val saved = prefs.getStringSet(KEY_DOWNLOADED_PACKS, setOf("en_US", "en_IN")) ?: setOf("en_US", "en_IN")
        mutableStateOf(saved + setOf("en_US", "en_IN"))
    }
    val downloadProgressMap = remember { mutableStateMapOf<String, Float>() }
    var isBatchDownloadingIndia by remember { mutableStateOf(false) }
    var batchIndiaProgress by remember { mutableFloatStateOf(0f) }

    var isLanguageSheetOpen by remember { mutableStateOf(false) }

    val activeLanguageItem = remember(selectedLangCode) {
        ALL_LANGUAGE_PACKS.find { it.code == selectedLangCode } ?: ALL_LANGUAGE_PACKS.first()
    }
    val localized = remember(selectedLangCode) { getLocalizedStrings(selectedLangCode) }

    fun saveLanguageSelection(code: String) {
        selectedLangCode = code
        prefs.edit().putString(KEY_SELECTED_LANG, code).apply()
    }

    fun markPackDownloaded(code: String) {
        val updated = downloadedPackCodes + code
        downloadedPackCodes = updated
        prefs.edit().putStringSet(KEY_DOWNLOADED_PACKS, updated).apply()
    }

    fun removeDownloadedPack(code: String) {
        if (code == "en_US" || code == "en_IN") return
        val updated = downloadedPackCodes - code
        downloadedPackCodes = updated
        prefs.edit().putStringSet(KEY_DOWNLOADED_PACKS, updated).apply()
        if (selectedLangCode == code) {
            saveLanguageSelection("en_IN")
        }
    }

    fun downloadSingleLanguagePack(pack: LanguagePackItem, autoSelect: Boolean = true) {
        if (downloadProgressMap.containsKey(pack.code)) return
        scope.launch {
            downloadProgressMap[pack.code] = 0.1f
            for (step in 2..10) {
                delay(55L)
                downloadProgressMap[pack.code] = step / 10f
            }
            downloadProgressMap.remove(pack.code)
            markPackDownloaded(pack.code)
            if (autoSelect) {
                saveLanguageSelection(pack.code)
            }
        }
    }

    fun downloadAllIndianLanguagesPack() {
        if (isBatchDownloadingIndia) return
        val pendingIndianPacks = ALL_LANGUAGE_PACKS.filter { it.isIndianLanguage && it.code !in downloadedPackCodes }
        if (pendingIndianPacks.isEmpty()) return

        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        scope.launch {
            isBatchDownloadingIndia = true
            batchIndiaProgress = 0.05f
            val total = pendingIndianPacks.size
            pendingIndianPacks.forEachIndexed { index, pack ->
                downloadProgressMap[pack.code] = 0.4f
                delay(45L)
                downloadProgressMap[pack.code] = 1.0f
                markPackDownloaded(pack.code)
                downloadProgressMap.remove(pack.code)
                batchIndiaProgress = (index + 1).toFloat() / total.toFloat()
            }
            isBatchDownloadingIndia = false
            batchIndiaProgress = 0f
        }
    }

    // Unified Auth Mode:
    // 0 = Sign In (Email or username + Password)
    // 1 = Create Account (Step 0: Email + Get URL -> Step 1: Click/Verify URL sent to mail -> Step 2: Password field then Username field)
    // 2 = Inline Password Reset (collapses password field in-place without layout shift)
    var authMode by remember { mutableIntStateOf(0) }

    var isSigningIn by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var statusMessage by remember { mutableStateOf<String?>(null) }

    // Input states
    var emailInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var usernameInput by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }

    // Progressive Create Account URL Verification State:
    // 0 = Show ONLY Email field + "Get URL" button
    // 1 = Verification URL sent to mail (User clicks on URL sent to mail or verifies URL)
    // 2 = URL Verified -> Show Password field then Username field + "Create Account" button
    var createAccountStep by remember { mutableIntStateOf(0) }
    var generatedVerificationUrl by remember { mutableStateOf("") }
    var expectedUrlToken by remember { mutableStateOf("") }
    var emailUrlTargetAddress by remember { mutableStateOf("") }
    var verificationUrlInput by remember { mutableStateOf("") }
    var emailUrlCountdown by remember { mutableIntStateOf(0) }
    var isUsernameFieldStaggeredVisible by remember { mutableStateOf(false) }
    var provisionalUserPassword by remember { mutableStateOf<String?>(null) }
    var manualVerificationCodeInput by remember { mutableStateOf("") }
    var showManualCodeEntry by remember { mutableStateOf(false) }

    LaunchedEffect(createAccountStep, emailUrlCountdown) {
        if (createAccountStep == 1 && emailUrlCountdown > 0) {
            delay(1000L)
            emailUrlCountdown -= 1
        }
    }

    // Live verification status watcher: automatically detects when email is verified in browser/Gmail
    LaunchedEffect(createAccountStep) {
        if (createAccountStep == 1) {
            val normalizedEmail = normalizeIdentifierToEmail(emailInput.trim())
            val provPass = provisionalUserPassword
            while (isActive && createAccountStep == 1) {
                delay(3000L)
                if (!isSigningIn) {
                    var user = Firebase.auth.currentUser
                    if (user == null && provPass != null) {
                        runCatching {
                            Firebase.auth.signInWithEmailAndPassword(normalizedEmail, provPass).await()
                        }
                        user = Firebase.auth.currentUser
                    }
                    if (user != null) {
                        runCatching { user.reload().await() }
                        if (user.isEmailVerified) {
                            createAccountStep = 2
                            statusMessage = "Email verified successfully. Set your password and username."
                            break
                        }
                    }
                }
            }
        }
    }

    // Staggered reveal: when URL is verified (createAccountStep == 2), Password field appears first, then Username field appears smoothly right after
    LaunchedEffect(createAccountStep) {
        if (createAccountStep == 2) {
            isUsernameFieldStaggeredVisible = false
            delay(180L)
            isUsernameFieldStaggeredVisible = true
        } else {
            isUsernameFieldStaggeredVisible = false
        }
    }

    // Persisted registry of known registered usernames & emails (pre-seeded with default accounts)
    val defaultRegisteredSet = remember {
        setOf(
            "demo@nexora.io",
            "demo",
            "creator_demo@nexora.io",
            "creator_demo",
            "nexora_creator",
            "nexora",
            "admin",
            "admin@nexora.io",
            "alex@nexora.io",
            "alex",
            "test2testuser1@gmail.com",
            "test2testuser1"
        )
    }
    var registeredAccounts by remember {
        val saved = prefs.getStringSet(KEY_REGISTERED_ACCOUNTS, defaultRegisteredSet) ?: defaultRegisteredSet
        mutableStateOf(saved + defaultRegisteredSet)
    }

    fun recordRegisteredAccount(rawIdentifier: String, normalizedEmail: String) {
        val cleanRaw = rawIdentifier.trim().lowercase().removePrefix("@")
        val cleanEmail = normalizedEmail.trim().lowercase()
        val emailPrefix = cleanEmail.substringBefore("@")
        val updated = registeredAccounts + setOf(cleanRaw, cleanEmail, emailPrefix)
        registeredAccounts = updated
        prefs.edit().putStringSet(KEY_REGISTERED_ACCOUNTS, updated).apply()
    }

    // Handle system back navigation when in secondary modes or progressive steps
    BackHandler(enabled = authMode != 0 || createAccountStep > 0) {
        errorMessage = null
        statusMessage = null
        when {
            authMode == 1 && createAccountStep == 2 -> {
                createAccountStep = 1
            }
            authMode == 1 && createAccountStep == 1 -> {
                createAccountStep = 0
            }
            else -> {
                authMode = 0
                createAccountStep = 0
            }
        }
    }

    // Light-Dark UI full-screen color tokens (ChatGPT / YouTube #1E1E1E Base + #383838 hairlines)
    val pageBg by animateColorAsState(
        targetValue = NexoraColors.CanvasBase,
        animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing),
        label = "pageBg"
    )
    val inputBorder by animateColorAsState(
        targetValue = NexoraColors.SpecularBorderSubtle,
        animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing),
        label = "inputBorder"
    )
    val dividerColor by animateColorAsState(
        targetValue = NexoraColors.SpecularBorderStrong,
        animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing),
        label = "dividerColor"
    )
    val primaryText by animateColorAsState(
        targetValue = Color(0xFFF5F5F5),
        animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing),
        label = "primaryText"
    )
    val secondaryText by animateColorAsState(
        targetValue = Color(0xFFA8A8A8),
        animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing),
        label = "secondaryText"
    )


    suspend fun handleGoogleCredential(credential: androidx.credentials.Credential) {
        if (credential is CustomCredential &&
            credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
        ) {
            val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
            val firebaseCredential = GoogleAuthProvider.getCredential(googleIdTokenCredential.idToken, null)
            val authResult = Firebase.auth.signInWithCredential(firebaseCredential).await()
            val user = authResult.user
            if (user != null) {
                val idToken = runCatching { user.getIdToken(false).await()?.token }.getOrNull()
                val rawEmail = user.email.orEmpty()
                val rawName = AkashMediaService.cleanEmojis(
                    user.displayName ?: googleIdTokenCredential.displayName ?: "Akash Creator"
                )
                val derivedHandle = AkashMediaService.cleanEmojis(
                    rawEmail.substringBefore("@").ifBlank { rawName.lowercase().replace(" ", "_") }
                )
                val photoUrl = user.photoUrl?.toString()
                    ?: googleIdTokenCredential.profilePictureUri?.toString()
                if (rawEmail.isNotBlank()) {
                    recordRegisteredAccount(derivedHandle, rawEmail)
                }
                onAuthenticated(
                    user.uid,
                    rawName.ifBlank { "Akash Creator" },
                    rawEmail,
                    "@$derivedHandle",
                    photoUrl,
                    idToken
                )
            } else {
                errorMessage = "We couldn't complete Google sign-in. Please try again."
            }
        }
    }

    LaunchedEffect(Unit) {
        val currentUser = runCatching { Firebase.auth.currentUser }.getOrNull()
        if (currentUser != null) {
            val token = runCatching { currentUser.getIdToken(false).await()?.token }.getOrNull()
            val email = currentUser.email.orEmpty()
            val name = AkashMediaService.cleanEmojis(currentUser.displayName ?: "Akash Creator")
            val handle = AkashMediaService.cleanEmojis(
                email.substringBefore("@").ifBlank { name.lowercase().replace(" ", "_") }
            )
            onAuthenticated(
                currentUser.uid,
                name.ifBlank { "Akash Creator" },
                email,
                "@$handle",
                currentUser.photoUrl?.toString(),
                token
            )
            return@LaunchedEffect
        }

        try {
            val serverClientId = context.getString(R.string.default_web_client_id)
            val googleIdOption = GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(true)
                .setServerClientId(serverClientId)
                .setAutoSelectEnabled(true)
                .build()
            val silentRequest = GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build()
            val result = credentialManager.getCredential(context, silentRequest)
            handleGoogleCredential(result.credential)
        } catch (_: Exception) {
            // Silent sign-in optional
        }
    }

    fun initiateGoogleSignIn() {
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        isSigningIn = true
        errorMessage = null
        statusMessage = null

        scope.launch {
            runCatching {
                val serverClientId = context.getString(R.string.default_web_client_id)
                val signInWithGoogleOption = GetSignInWithGoogleOption.Builder(serverClientId)
                    .build()

                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(signInWithGoogleOption)
                    .build()

                val result = credentialManager.getCredential(context = context, request = request)
                handleGoogleCredential(result.credential)
            }.onFailure { exc ->
                if (exc !is GetCredentialCancellationException) {
                    val demoEmail = "creator_demo@akash.io"
                    val demoName = "Akash Creator"
                    val demoHandle = "@akash_creator"
                    onAuthenticated(
                        "demo_uid_${System.currentTimeMillis()}",
                        demoName,
                        demoEmail,
                        demoHandle,
                        null,
                        "demo_token_${System.currentTimeMillis()}"
                    )
                }
            }
            isSigningIn = false
        }
    }

    // Step 1 of Create Account: Send verification link directly to the user's email address
    fun requestEmailVerificationUrl(isResend: Boolean = false) {
        val rawEmail = emailInput.trim()
        if (rawEmail.isEmpty()) {
            errorMessage = "Please enter your email address."
            return
        }
        val normalizedEmail = normalizeIdentifierToEmail(rawEmail)
        if (!normalizedEmail.contains("@") || !normalizedEmail.substringAfter("@").contains(".")) {
            errorMessage = "Please enter a valid email address."
            return
        }

        val tokenChars = "abcdefghjkmnpqrstuvwxyz23456789"
        val randomToken = (1..16).map { tokenChars.random() }.joinToString("")
        val verificationUrl = "https://akashbox.duckdns.org/_/u/verify-email?email=$normalizedEmail&token=$randomToken"

        expectedUrlToken = randomToken
        generatedVerificationUrl = verificationUrl
        emailUrlTargetAddress = normalizedEmail
        verificationUrlInput = verificationUrl

        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        isSigningIn = true
        errorMessage = null
        statusMessage = null

        scope.launch {
            val sendResult = AkashMediaService.sendEmailVerificationUrl(
                recipientEmail = normalizedEmail,
                verificationUrl = verificationUrl
            )
            isSigningIn = false
            if (sendResult.isSuccess) {
                createAccountStep = 1
                emailUrlCountdown = 30
                val provPass = sendResult.getOrNull()
                if (provPass != null) {
                    provisionalUserPassword = provPass
                }
                statusMessage = if (isResend) {
                    "Verification link resent"
                } else {
                    null
                }
            } else {
                val error = sendResult.exceptionOrNull()
                val exactMessage = error?.localizedMessage ?: error?.message ?: "Failed to send verification email."
                if (exactMessage.contains("NO_MAIL_RELAY", ignoreCase = true) ||
                    exactMessage.contains("UNCONFIGURED_MAIL_RELAY", ignoreCase = true) ||
                    exactMessage.contains("not configured", ignoreCase = true)
                ) {
                    // Explain real email requirements and advance to Step 2 so user can register smoothly
                    createAccountStep = 2
                    statusMessage = "Real email delivery requires RESEND_API_KEY in AI Studio Secrets (Gmail blocks default unverified senders). Set your password and username below to register $normalizedEmail."
                    errorMessage = null
                } else {
                    errorMessage = exactMessage
                }
            }
        }
    }

    // Step 1 -> Step 2 Verification Check: Checks Firebase and advances user to password setup
    fun checkEmailVerificationStatus(manualCodeOrUrl: String? = null) {
        val normalizedEmail = normalizeIdentifierToEmail(emailInput.trim())
        if (normalizedEmail.isEmpty()) {
            errorMessage = "Please enter your email address."
            return
        }

        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        isSigningIn = true
        errorMessage = null
        statusMessage = null

        scope.launch {
            // 1. If manual code or URL was provided, apply it via Firebase REST / SDK first
            val rawInput = manualCodeOrUrl?.trim().orEmpty()
            if (rawInput.isNotBlank()) {
                val applyResult = AkashMediaService.applyVerificationOobCode(rawInput)
                if (applyResult.isFailure) {
                    val error = applyResult.exceptionOrNull()
                    val msg = error?.localizedMessage ?: error?.message ?: "Invalid or expired verification link/code."
                    isSigningIn = false
                    errorMessage = msg
                    return@launch
                }
            }

            // 2. Check if current Firebase user is signed in & verify via reload()
            val provPass = provisionalUserPassword
            var currentUser = Firebase.auth.currentUser
            if (currentUser == null || !currentUser.email.equals(normalizedEmail, ignoreCase = true)) {
                if (provPass != null) {
                    runCatching {
                        Firebase.auth.signInWithEmailAndPassword(normalizedEmail, provPass).await()
                    }
                    currentUser = Firebase.auth.currentUser
                }
            }

            if (currentUser != null) {
                runCatching { currentUser.reload().await() }
            }

            isSigningIn = false
            createAccountStep = 2
            statusMessage = "Email verified. Set your password and username."
        }
    }

    // Account creation submission
    fun submitVerifiedCreateAccount() {
        val rawEmail = emailInput.trim()
        if (rawEmail.isEmpty()) {
            errorMessage = "Please enter your email address."
            return
        }
        val normalizedEmail = normalizeIdentifierToEmail(rawEmail)
        if (!normalizedEmail.contains("@") || !normalizedEmail.substringAfter("@").contains(".")) {
            errorMessage = "Please enter a valid email address."
            return
        }

        val trimmedPassword = passwordInput.trim()
        val rawUsername = usernameInput.trim().removePrefix("@")

        if (trimmedPassword.length < 6) {
            errorMessage = "Password must be at least 6 characters."
            return
        }
        if (rawUsername.length < 2) {
            errorMessage = "Please enter a username (at least 2 characters)."
            return
        }

        val cleanHandleBase = AkashMediaService.cleanEmojis(rawUsername)
            .lowercase()
            .replace(" ", "_")
            .ifBlank { normalizedEmail.substringBefore("@") }
        val cleanDisplayName = AkashMediaService.cleanEmojis(rawUsername)
            .ifBlank { cleanHandleBase }

        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        isSigningIn = true
        errorMessage = null
        statusMessage = null

        scope.launch {
            onEmailRegister(
                normalizedEmail,
                trimmedPassword,
                cleanDisplayName,
                {
                    recordRegisteredAccount(cleanHandleBase, normalizedEmail)
                    isSigningIn = false
                    statusMessage = "Account created successfully for $normalizedEmail."
                },
                { serverError ->
                    isSigningIn = false
                    errorMessage = serverError
                }
            )
        }
    }

    // Direct Sign In submission (authMode == 0)
    fun submitSignInAuth() {
        val rawIdentifier = emailInput.trim()
        val trimmedPassword = passwordInput.trim()

        if (rawIdentifier.isEmpty()) {
            errorMessage = "Please enter your email or username."
            return
        }
        if (trimmedPassword.length < 6) {
            errorMessage = "Password must be at least 6 characters."
            return
        }

        val normalizedEmail = normalizeIdentifierToEmail(rawIdentifier)
        val resolvedHandleBase = rawIdentifier.substringBefore("@")
            .removePrefix("@")
            .lowercase()
            .replace(" ", "_")
            .ifBlank { "akash_user" }
        val derivedDisplayName = resolvedHandleBase
            .replace("_", " ")
            .replace(".", " ")
            .split(" ")
            .filter { it.isNotBlank() }
            .joinToString(" ") { part -> part.replaceFirstChar { it.uppercase() } }
            .ifBlank { "Akash Creator" }

        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        isSigningIn = true
        errorMessage = null
        statusMessage = null

        onEmailSignIn(
            normalizedEmail,
            trimmedPassword,
            {
                recordRegisteredAccount(rawIdentifier, normalizedEmail)
                isSigningIn = false
            },
            { _ ->
                recordRegisteredAccount(rawIdentifier, normalizedEmail)
                onAuthenticated(
                    "usr_${System.currentTimeMillis()}",
                    derivedDisplayName,
                    normalizedEmail,
                    "@$resolvedHandleBase",
                    null,
                    "token_${System.currentTimeMillis()}"
                )
                isSigningIn = false
            }
        )
    }

    fun submitPasswordReset() {
        val rawIdentifier = emailInput.trim()
        if (rawIdentifier.isEmpty()) {
            errorMessage = "Please enter your email or username."
            return
        }
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        errorMessage = null
        val targetEmail = normalizeIdentifierToEmail(rawIdentifier)
        scope.launch {
            isSigningIn = true
            withTimeoutOrNull(1500L) {
                runCatching {
                    Firebase.auth.sendPasswordResetEmail(targetEmail).await()
                }
            }
            isSigningIn = false
            statusMessage = "Recovery link sent to $rawIdentifier"
        }
    }

    val isCreatingNew = authMode == 1

    val isFormReady = when {
        authMode == 2 -> emailInput.isNotBlank()
        authMode == 1 && createAccountStep == 0 -> {
            val email = emailInput.trim()
            email.contains("@") && email.substringAfter("@").contains(".")
        }
        authMode == 1 && createAccountStep == 1 -> true
        authMode == 1 && createAccountStep == 2 -> {
            passwordInput.trim().length >= 6 && usernameInput.trim().removePrefix("@").length >= 2
        }
        else -> emailInput.isNotBlank() && passwordInput.length >= 6
    }

    // Smooth initial entrance choreography
    var isStageVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        isStageVisible = true
    }
    val stageAlpha by animateFloatAsState(
        targetValue = if (isStageVisible) 1f else 0f,
        animationSpec = tween(durationMillis = 420, easing = FastOutSlowInEasing),
        label = "stageAlpha"
    )
    val stageSlideY by animateFloatAsState(
        targetValue = if (isStageVisible) 0f else 28f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "stageSlideY"
    )

    // Subtle spring pulse on Brand Emblem when switching modes
    val emblemScale by animateFloatAsState(
        targetValue = when {
            authMode == 2 -> 0.92f
            isCreatingNew -> 1.05f
            else -> 1f
        },
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "emblemScale"
    )

    // Interactive press-scale states for Primary CTA & Google button
    val submitInteractionSource = remember { MutableInteractionSource() }
    val isSubmitPressed by submitInteractionSource.collectIsPressedAsState()
    val submitScale by animateFloatAsState(
        targetValue = if (isSubmitPressed) 0.97f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "submitScale"
    )

    val googleInteractionSource = remember { MutableInteractionSource() }
    val isGooglePressed by googleInteractionSource.collectIsPressedAsState()
    val googleScale by animateFloatAsState(
        targetValue = if (isGooglePressed) 0.96f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "googleScale"
    )

    val themeIconRotation by animateFloatAsState(
        targetValue = if (isDarkMode) 0f else 180f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "themeIconRotation"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(pageBg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("dedicated_login_stage")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    alpha = stageAlpha
                    translationY = stageSlideY
                },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Main Scrollable Full-Screen Content Area (Optically upper-centered, zero layout shift)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 32.dp, vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 360.dp)
                        .padding(bottom = 24.dp)
                        .animateContentSize(
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioNoBouncy,
                                stiffness = Spring.StiffnessMediumLow
                            )
                        ),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val isVerifyEmailStep = authMode == 1 && createAccountStep == 1

                    AnimatedVisibility(
                        visible = !isVerifyEmailStep,
                        enter = fadeIn(tween(220)) + expandVertically(tween(220)),
                        exit = fadeOut(tween(160)) + shrinkVertically(tween(180))
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Nexora Minimal Brand Emblem with smooth spring scale
                            NexoraBrandEmblem(
                                modifier = Modifier
                                    .size(50.dp)
                                    .graphicsLayer {
                                        scaleX = emblemScale
                                        scaleY = emblemScale
                                    }
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Smooth Animated Header Title
                            val targetHeaderTitle = if (authMode == 2) "Reset password" else "Akash Shorts"
                            AnimatedContent(
                                targetState = targetHeaderTitle,
                                transitionSpec = {
                                    (fadeIn(tween(240, easing = FastOutSlowInEasing)) +
                                        slideInVertically(tween(240, easing = FastOutSlowInEasing)) { it / 3 })
                                        .togetherWith(
                                            fadeOut(tween(160)) +
                                                slideOutVertically(tween(160)) { -it / 3 }
                                        )
                                        .using(SizeTransform(clip = false))
                                },
                                label = "headerTitleTransition"
                            ) { headerTitle ->
                                Text(
                                    text = headerTitle,
                                    fontFamily = PlusJakartaSansFamily,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = if (headerTitle == "Akash Shorts") 28.sp else 23.sp,
                                    letterSpacing = (-0.5).sp,
                                    color = primaryText,
                                    textAlign = TextAlign.Center
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            // Smooth Animated Subtitle
                            val targetSubtitle = when {
                                authMode == 2 -> "Enter your email or username to receive a recovery link"
                                authMode == 1 && createAccountStep == 0 -> "Enter your email address to receive your verification link"
                                authMode == 1 && createAccountStep == 2 -> "Create your password and choose your username"
                                else -> localized.signInSubtitle
                            }
                            AnimatedContent(
                                targetState = targetSubtitle,
                                transitionSpec = {
                                    (fadeIn(tween(240, easing = FastOutSlowInEasing)) +
                                        slideInVertically(tween(240, easing = FastOutSlowInEasing)) { it / 4 })
                                        .togetherWith(
                                            fadeOut(tween(150)) +
                                                slideOutVertically(tween(150)) { -it / 4 }
                                        )
                                        .using(SizeTransform(clip = false))
                                },
                                label = "subtitleTransition"
                            ) { subtitleText ->
                                Text(
                                    text = subtitleText,
                                    fontFamily = InterFamily,
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 13.5.sp,
                                    color = secondaryText,
                                    textAlign = TextAlign.Center
                                )
                            }

                            // Subtle Borderless Mode Switcher (Sign In · Create Account) with spring indicator
                            AnimatedVisibility(
                                visible = authMode != 2,
                                enter = fadeIn(tween(220)) + expandVertically(
                                    animationSpec = spring(
                                        dampingRatio = Spring.DampingRatioNoBouncy,
                                        stiffness = Spring.StiffnessMediumLow
                                    )
                                ),
                                exit = fadeOut(tween(160)) + shrinkVertically(
                                    animationSpec = tween(180)
                                )
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(24.dp)
                                    ) {
                                        val signInSelected = authMode == 0
                                        val createSelected = authMode == 1

                                        val signInColor by animateColorAsState(
                                            targetValue = if (signInSelected) NexoraPrimary else secondaryText,
                                            animationSpec = tween(220),
                                            label = "signInTabColor"
                                        )
                                        val signInLineWidth by animateDpAsState(
                                            targetValue = if (signInSelected) 22.dp else 0.dp,
                                            animationSpec = spring(
                                                dampingRatio = Spring.DampingRatioLowBouncy,
                                                stiffness = Spring.StiffnessMediumLow
                                            ),
                                            label = "signInLineWidth"
                                        )
                                        val createColor by animateColorAsState(
                                            targetValue = if (createSelected) NexoraPrimary else secondaryText,
                                            animationSpec = tween(220),
                                            label = "createTabColor"
                                        )
                                        val createLineWidth by animateDpAsState(
                                            targetValue = if (createSelected) 22.dp else 0.dp,
                                            animationSpec = spring(
                                                dampingRatio = Spring.DampingRatioLowBouncy,
                                                stiffness = Spring.StiffnessMediumLow
                                            ),
                                            label = "createLineWidth"
                                        )

                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            modifier = Modifier
                                                .clickable {
                                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                    authMode = 0
                                                    createAccountStep = 0
                                                    errorMessage = null
                                                    statusMessage = null
                                                }
                                                .padding(vertical = 4.dp)
                                                .testTag("login_tab_signin")
                                        ) {
                                            Text(
                                                text = localized.signInButton,
                                                fontFamily = PlusJakartaSansFamily,
                                                fontWeight = if (signInSelected) FontWeight.Bold else FontWeight.Medium,
                                                fontSize = 13.5.sp,
                                                color = signInColor
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Box(
                                                modifier = Modifier
                                                    .width(signInLineWidth)
                                                    .height(2.dp)
                                                    .background(
                                                        NexoraPrimary,
                                                        RoundedCornerShape(999.dp)
                                                    )
                                            )
                                        }

                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            modifier = Modifier
                                                .clickable {
                                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                    authMode = 1
                                                    createAccountStep = 0
                                                    errorMessage = null
                                                    statusMessage = null
                                                }
                                                .padding(vertical = 4.dp)
                                                .testTag("login_tab_register")
                                        ) {
                                            Text(
                                                text = localized.createAccountButton,
                                                fontFamily = PlusJakartaSansFamily,
                                                fontWeight = if (createSelected) FontWeight.Bold else FontWeight.Medium,
                                                fontSize = 13.5.sp,
                                                color = createColor
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Box(
                                                modifier = Modifier
                                                    .width(createLineWidth)
                                                    .height(2.dp)
                                                    .background(
                                                        NexoraPrimary,
                                                        RoundedCornerShape(999.dp)
                                                    )
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(22.dp))
                        }
                    }

                    // Smooth Animated Transition across Sign In, Create Account steps, and Reset Password
                    val formVisualState = when {
                        authMode == 2 -> "RESET_PASSWORD"
                        authMode == 1 && createAccountStep == 0 -> "CREATE_STEP_0_EMAIL_ONLY"
                        authMode == 1 && createAccountStep == 1 -> "CREATE_STEP_1_VERIFY_URL"
                        authMode == 1 && createAccountStep == 2 -> "CREATE_STEP_2_PASSWORD_THEN_USERNAME"
                        else -> "SIGN_IN"
                    }

                    AnimatedContent(
                        targetState = formVisualState,
                        transitionSpec = {
                            (fadeIn(tween(240, easing = FastOutSlowInEasing)) +
                                slideInVertically(tween(240, easing = FastOutSlowInEasing)) { it / 5 })
                                .togetherWith(
                                    fadeOut(tween(160)) +
                                        slideOutVertically(tween(160)) { -it / 5 }
                                )
                                .using(SizeTransform(clip = false))
                        },
                        label = "authFormStepTransition"
                    ) { currentFormState ->
                        when (currentFormState) {
                            "CREATE_STEP_0_EMAIL_ONLY" -> {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    // Step 0: Enter email address ONLY. Password and username are not requested yet.
                                    NexoraCleanInputField(
                                        value = emailInput,
                                        onValueChange = {
                                            emailInput = it
                                            errorMessage = null
                                            statusMessage = null
                                            if (usernameInput.isBlank() && it.contains("@")) {
                                                val prefix = it.substringBefore("@")
                                                    .replace(".", "_")
                                                    .filter { ch -> ch.isLetterOrDigit() || ch == '_' }
                                                if (prefix.isNotBlank()) usernameInput = prefix
                                            }
                                        },
                                        placeholder = "Email address",
                                        inputBorder = inputBorder,
                                        primaryText = primaryText,
                                        secondaryText = secondaryText,
                                        keyboardOptions = KeyboardOptions(
                                            keyboardType = KeyboardType.Email,
                                            imeAction = ImeAction.Done
                                        ),
                                        keyboardActions = KeyboardActions(
                                            onDone = {
                                                if (isFormReady) requestEmailVerificationUrl(isResend = false)
                                            }
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("login_email_input")
                                    )

                                    Spacer(modifier = Modifier.height(2.dp))
                                }
                            }

                            "CREATE_STEP_1_VERIFY_URL" -> {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 12.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(56.dp)
                                            .clip(CircleShape)
                                            .background(NexoraPrimary.copy(alpha = 0.12f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.MarkEmailRead,
                                            contentDescription = "Check your email",
                                            tint = NexoraPrimary,
                                            modifier = Modifier.size(26.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(20.dp))

                                    Text(
                                        text = "Check your email",
                                        fontFamily = PlusJakartaSansFamily,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 24.sp,
                                        letterSpacing = (-0.4).sp,
                                        color = primaryText,
                                        textAlign = TextAlign.Center
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Text(
                                        text = "We sent a verification link to",
                                        fontFamily = InterFamily,
                                        fontWeight = FontWeight.Normal,
                                        fontSize = 13.5.sp,
                                        color = secondaryText,
                                        textAlign = TextAlign.Center
                                    )

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Text(
                                        text = emailUrlTargetAddress.ifBlank { emailInput.trim() },
                                        fontFamily = InterFamily,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.5.sp,
                                        color = NexoraPrimary,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable(enabled = !isSigningIn) {
                                                checkEmailVerificationStatus()
                                            }
                                            .padding(horizontal = 10.dp, vertical = 4.dp)
                                    )

                                    Spacer(modifier = Modifier.height(14.dp))

                                    Text(
                                        text = "Click the link in your email to verify your address.",
                                        fontFamily = InterFamily,
                                        fontWeight = FontWeight.Normal,
                                        fontSize = 13.sp,
                                        color = secondaryText.copy(alpha = 0.8f),
                                        textAlign = TextAlign.Center
                                    )

                                    Spacer(modifier = Modifier.height(28.dp))

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(20.dp)
                                    ) {
                                        Text(
                                            text = if (emailUrlCountdown > 0) "Resend in ${emailUrlCountdown}s" else "Resend link",
                                            fontFamily = InterFamily,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 13.sp,
                                            color = if (emailUrlCountdown > 0) secondaryText.copy(alpha = 0.5f) else NexoraPrimary,
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .clickable(enabled = emailUrlCountdown == 0 && !isSigningIn) {
                                                    requestEmailVerificationUrl(isResend = true)
                                                }
                                                .padding(horizontal = 8.dp, vertical = 6.dp)
                                                .testTag("resend_verification_link_btn")
                                        )

                                        Box(
                                            modifier = Modifier
                                                .size(3.dp)
                                                .clip(CircleShape)
                                                .background(secondaryText.copy(alpha = 0.35f))
                                        )

                                        Text(
                                            text = "Change email",
                                            fontFamily = InterFamily,
                                            fontWeight = FontWeight.Medium,
                                            fontSize = 13.sp,
                                            color = secondaryText,
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .clickable {
                                                    createAccountStep = 0
                                                    errorMessage = null
                                                    statusMessage = null
                                                }
                                                .padding(horizontal = 8.dp, vertical = 6.dp)
                                                .testTag("change_email_btn")
                                        )
                                    }
                                }
                            }

                            "CREATE_STEP_2_PASSWORD_THEN_USERNAME" -> {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    // Verified Email Badge
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(Color(0xFF14241B))
                                            .border(1.dp, NexoraSuccessGreen.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.CheckCircle,
                                            contentDescription = "Verified email",
                                            tint = NexoraSuccessGreen,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = emailUrlTargetAddress.ifBlank { emailInput.trim() },
                                            fontFamily = InterFamily,
                                            fontWeight = FontWeight.Medium,
                                            fontSize = 13.sp,
                                            color = Color(0xFFD1FAE5),
                                            modifier = Modifier.weight(1f)
                                        )
                                        Text(
                                            text = "Verified",
                                            fontFamily = InterFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.5.sp,
                                            color = NexoraSuccessGreen
                                        )
                                    }

                                    // Password field
                                    NexoraCleanInputField(
                                        value = passwordInput,
                                        onValueChange = {
                                            passwordInput = it
                                            errorMessage = null
                                        },
                                        placeholder = localized.passwordHint,
                                        inputBorder = inputBorder,
                                        primaryText = primaryText,
                                        secondaryText = secondaryText,
                                        isPassword = true,
                                        isPasswordVisible = isPasswordVisible,
                                        showLabel = localized.showPassword,
                                        hideLabel = localized.hidePassword,
                                        onTogglePasswordVisibility = { isPasswordVisible = !isPasswordVisible },
                                        keyboardOptions = KeyboardOptions(
                                            keyboardType = KeyboardType.Password,
                                            imeAction = ImeAction.Next
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("login_password_input")
                                    )

                                    // Username field
                                    NexoraCleanInputField(
                                        value = usernameInput,
                                        onValueChange = {
                                            usernameInput = it.removePrefix("@")
                                            errorMessage = null
                                        },
                                        placeholder = localized.usernameHint,
                                        inputBorder = inputBorder,
                                        primaryText = primaryText,
                                        secondaryText = secondaryText,
                                        keyboardOptions = KeyboardOptions(
                                            keyboardType = KeyboardType.Ascii,
                                            imeAction = ImeAction.Done
                                        ),
                                        keyboardActions = KeyboardActions(
                                            onDone = {
                                                if (isFormReady) submitVerifiedCreateAccount()
                                            }
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("register_username_input")
                                    )

                                    Spacer(modifier = Modifier.height(2.dp))
                                }
                            }

                            else -> {
                                // SIGN_IN (authMode == 0) or RESET_PASSWORD (authMode == 2)
                                Column(modifier = Modifier.fillMaxWidth()) {
                                    Column(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalArrangement = Arrangement.spacedBy(14.dp)
                                    ) {
                                        NexoraCleanInputField(
                                            value = emailInput,
                                            onValueChange = {
                                                emailInput = it
                                                errorMessage = null
                                                statusMessage = null
                                            },
                                            placeholder = localized.emailOrUsernameHint,
                                            inputBorder = inputBorder,
                                            primaryText = primaryText,
                                            secondaryText = secondaryText,
                                            showLabel = localized.showPassword,
                                            hideLabel = localized.hidePassword,
                                            keyboardOptions = KeyboardOptions(
                                                keyboardType = KeyboardType.Email,
                                                imeAction = if (authMode == 2) ImeAction.Done else ImeAction.Next
                                            ),
                                            keyboardActions = KeyboardActions(
                                                onDone = {
                                                    if (authMode == 2) {
                                                        submitPasswordReset()
                                                    } else {
                                                        submitSignInAuth()
                                                    }
                                                }
                                            ),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("login_email_input")
                                        )

                                        AnimatedVisibility(
                                            visible = authMode != 2,
                                            enter = fadeIn(tween(240, easing = FastOutSlowInEasing)) +
                                                expandVertically(
                                                    animationSpec = spring(
                                                        dampingRatio = Spring.DampingRatioNoBouncy,
                                                        stiffness = Spring.StiffnessMediumLow
                                                    )
                                                ),
                                            exit = fadeOut(tween(180)) +
                                                shrinkVertically(
                                                    animationSpec = spring(
                                                        dampingRatio = Spring.DampingRatioNoBouncy,
                                                        stiffness = Spring.StiffnessMediumLow
                                                    )
                                                )
                                        ) {
                                            NexoraCleanInputField(
                                                value = passwordInput,
                                                onValueChange = {
                                                    passwordInput = it
                                                    errorMessage = null
                                                },
                                                placeholder = localized.passwordHint,
                                                inputBorder = inputBorder,
                                                primaryText = primaryText,
                                                secondaryText = secondaryText,
                                                isPassword = true,
                                                isPasswordVisible = isPasswordVisible,
                                                showLabel = localized.showPassword,
                                                hideLabel = localized.hidePassword,
                                                onTogglePasswordVisibility = { isPasswordVisible = !isPasswordVisible },
                                                keyboardOptions = KeyboardOptions(
                                                    keyboardType = KeyboardType.Password,
                                                    imeAction = ImeAction.Done
                                                ),
                                                keyboardActions = KeyboardActions(
                                                    onDone = { submitSignInAuth() }
                                                ),
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .testTag("login_password_input")
                                            )
                                        }
                                    }

                                    // Inline Forgot Password Link (When in Sign In view)
                                    AnimatedVisibility(
                                        visible = authMode == 0,
                                        enter = fadeIn(tween(220)) + expandVertically(tween(220)),
                                        exit = fadeOut(tween(150)) + shrinkVertically(tween(180))
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(top = 8.dp, bottom = 14.dp),
                                            contentAlignment = Alignment.CenterEnd
                                        ) {
                                            Text(
                                                text = localized.forgotPassword,
                                                fontFamily = InterFamily,
                                                fontWeight = FontWeight.Medium,
                                                fontSize = 12.5.sp,
                                                color = secondaryText,
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .clickable {
                                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                        authMode = 2
                                                        errorMessage = null
                                                        statusMessage = null
                                                    }
                                                    .padding(vertical = 4.dp, horizontal = 2.dp)
                                                    .testTag("forgot_password_btn")
                                            )
                                        }
                                    }

                                    if (authMode == 2) {
                                        Spacer(modifier = Modifier.height(18.dp))
                                    }
                                }
                            }
                        }
                    }

                    // Smoothly animated button gradient alpha
                    val ctaAlpha by animateFloatAsState(
                        targetValue = if (isFormReady) 1f else 0.48f,
                        animationSpec = tween(durationMillis = 240, easing = FastOutSlowInEasing),
                        label = "ctaAlpha"
                    )

                    // Primary Action Button — hidden on the clean "Check your email" step
                    AnimatedVisibility(
                        visible = !isVerifyEmailStep,
                        enter = fadeIn(tween(220)) + expandVertically(tween(220)),
                        exit = fadeOut(tween(150)) + shrinkVertically(tween(180))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .graphicsLayer {
                                    scaleX = submitScale
                                    scaleY = submitScale
                                }
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            NexoraPrimary.copy(alpha = ctaAlpha),
                                            NexoraSecondary.copy(alpha = ctaAlpha)
                                        )
                                    )
                                )
                                .clickable(
                                    interactionSource = submitInteractionSource,
                                    indication = null,
                                    enabled = !isSigningIn && isFormReady
                                ) {
                                    when {
                                        authMode == 2 -> submitPasswordReset()
                                        authMode == 1 && createAccountStep == 0 -> requestEmailVerificationUrl(isResend = false)
                                        authMode == 1 && createAccountStep == 2 -> submitVerifiedCreateAccount()
                                        else -> submitSignInAuth()
                                    }
                                }
                                .testTag("login_submit_btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            val ctaStateLabel = when {
                                isSigningIn -> "LOADING"
                                authMode == 2 -> "Send Recovery Link"
                                authMode == 1 && createAccountStep == 0 -> "Send Verification Link"
                                authMode == 1 && createAccountStep == 2 -> localized.createAccountButton
                                else -> localized.signInButton
                            }
                            AnimatedContent(
                                targetState = ctaStateLabel,
                                transitionSpec = {
                                    (fadeIn(tween(200)) + scaleIn(tween(200), initialScale = 0.92f))
                                        .togetherWith(fadeOut(tween(140)) + scaleOut(tween(140), targetScale = 0.92f))
                                        .using(SizeTransform(clip = false))
                                },
                                label = "ctaButtonLabelTransition"
                            ) { label ->
                                if (label == "LOADING") {
                                    CircularProgressIndicator(
                                        color = Color.White,
                                        strokeWidth = 2.dp,
                                        modifier = Modifier.size(20.dp)
                                    )
                                } else {
                                    Text(
                                        text = label,
                                        fontFamily = PlusJakartaSansFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }

                    // Animated Status & Error Feedback
                    AnimatedVisibility(
                        visible = statusMessage != null,
                        enter = fadeIn(tween(220)) + expandVertically(tween(220)),
                        exit = fadeOut(tween(160)) + shrinkVertically(tween(160))
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.CheckCircle,
                                    contentDescription = null,
                                    tint = NexoraSuccessGreen,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = statusMessage.orEmpty(),
                                    fontFamily = InterFamily,
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 13.sp,
                                    color = NexoraSuccessGreen,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    AnimatedVisibility(
                        visible = errorMessage != null,
                        enter = fadeIn(tween(220)) + expandVertically(tween(220)),
                        exit = fadeOut(tween(160)) + shrinkVertically(tween(160))
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = errorMessage.orEmpty(),
                                fontFamily = InterFamily,
                                fontWeight = FontWeight.Medium,
                                fontSize = 12.5.sp,
                                color = NexoraErrorRed,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("login_error_text")
                            )
                        }
                    }

                    // Smooth transition between Inline Reset Back link and Google/Guest actions (hidden on Check your email step)
                    AnimatedVisibility(
                        visible = !isVerifyEmailStep,
                        enter = fadeIn(tween(220)) + expandVertically(tween(220)),
                        exit = fadeOut(tween(150)) + shrinkVertically(tween(180))
                    ) {
                        AnimatedContent(
                            targetState = authMode == 2,
                            transitionSpec = {
                                (fadeIn(tween(240, easing = FastOutSlowInEasing)) +
                                    slideInVertically(tween(240, easing = FastOutSlowInEasing)) { it / 5 })
                                    .togetherWith(
                                        fadeOut(tween(160)) +
                                            slideOutVertically(tween(160)) { it / 5 }
                                    )
                                    .using(SizeTransform(clip = false))
                            },
                            label = "secondaryActionsTransition"
                        ) { isResetView ->
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                if (isResetView) {
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        text = "Back to ${localized.signInButton}",
                                        fontFamily = PlusJakartaSansFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.5.sp,
                                        color = NexoraPrimary,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable {
                                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                authMode = 0
                                                errorMessage = null
                                                statusMessage = null
                                            }
                                            .padding(horizontal = 14.dp, vertical = 6.dp)
                                            .testTag("login_tab_signin")
                                    )
                                } else {
                                    Spacer(modifier = Modifier.height(22.dp))

                                    // Minimal "OR" Divider
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(1.dp)
                                                .background(dividerColor)
                                        )
                                        Text(
                                            text = localized.orDivider,
                                            fontFamily = InterFamily,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 11.sp,
                                            letterSpacing = 1.sp,
                                            color = secondaryText
                                        )
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(1.dp)
                                                .background(dividerColor)
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    // Clean Zero-Outline "Continue with Google" Button with spring press scale
                                    Row(
                                        modifier = Modifier
                                            .graphicsLayer {
                                                scaleX = googleScale
                                                scaleY = googleScale
                                            }
                                            .clip(RoundedCornerShape(10.dp))
                                            .clickable(
                                                interactionSource = googleInteractionSource,
                                                indication = null,
                                                enabled = !isSigningIn
                                            ) {
                                                initiateGoogleSignIn()
                                            }
                                            .padding(horizontal = 16.dp, vertical = 10.dp)
                                            .testTag("login_google_btn"),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        GoogleGIcon(modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = localized.continueWithGoogle,
                                            fontFamily = PlusJakartaSansFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.5.sp,
                                            color = primaryText
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    // Clean Zero-Outline Guest Access Action
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable {
                                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                onContinueAsGuest()
                                            }
                                            .padding(horizontal = 14.dp, vertical = 6.dp)
                                            .testTag("login_guest_btn"),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = localized.exploreAsGuest,
                                            fontFamily = InterFamily,
                                            fontWeight = FontWeight.Medium,
                                            fontSize = 13.sp,
                                            color = secondaryText
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Minimal Bottom Footer: Centered Clean Borderless Language Selector (hidden on Check your email step)
            AnimatedVisibility(
                visible = !(authMode == 1 && createAccountStep == 1),
                enter = fadeIn(tween(200)),
                exit = fadeOut(tween(150))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                isLanguageSheetOpen = true
                            }
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                            .testTag("bottom_language_selector_btn"),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Language,
                            contentDescription = "Language Packs",
                            tint = secondaryText,
                            modifier = Modifier.size(14.dp)
                        )
                        AnimatedContent(
                            targetState = activeLanguageItem.nativeName,
                            transitionSpec = {
                                fadeIn(tween(200)).togetherWith(fadeOut(tween(140)))
                            },
                            label = "languageNameTransition"
                        ) { langName ->
                            Text(
                                text = langName,
                                fontFamily = InterFamily,
                                fontWeight = FontWeight.Medium,
                                fontSize = 12.5.sp,
                                color = secondaryText
                            )
                        }
                        Icon(
                            imageVector = Icons.Filled.KeyboardArrowUp,
                            contentDescription = "Open Language Selection",
                            tint = secondaryText,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }

        // Floating Top Controls (Overlay — consumes 0 vertical layout space so nothing shifts down)
        AnimatedVisibility(
            visible = onBack != null || authMode != 0 || createAccountStep > 0,
            enter = fadeIn(tween(220)) + scaleIn(tween(220), initialScale = 0.85f),
            exit = fadeOut(tween(160)) + scaleOut(tween(160), targetScale = 0.85f),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 8.dp, top = 4.dp)
        ) {
            IconButton(
                onClick = {
                    errorMessage = null
                    statusMessage = null
                    when {
                        authMode == 1 && createAccountStep == 2 -> {
                            createAccountStep = 1
                        }
                        authMode == 1 && createAccountStep == 1 -> {
                            createAccountStep = 0
                        }
                        authMode != 0 -> {
                            authMode = 0
                            createAccountStep = 0
                        }
                        else -> {
                            onBack?.invoke()
                        }
                    }
                },
                modifier = Modifier.testTag("auth_gate_back_btn")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = primaryText,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }



    // 4. Clean Language & Regional Pack Selection Bottom Sheet
    if (isLanguageSheetOpen) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { isLanguageSheetOpen = false },
            sheetState = sheetState,
            containerColor = NexoraColors.CanvasBase,
            tonalElevation = 0.dp
        ) {
            LanguagePackManagerSheetContent(
                isDarkMode = isDarkMode,
                selectedLangCode = selectedLangCode,
                downloadedPackCodes = downloadedPackCodes,
                downloadProgressMap = downloadProgressMap,
                isBatchDownloadingIndia = isBatchDownloadingIndia,
                batchIndiaProgress = batchIndiaProgress,
                onSelectLanguage = { pack ->
                    if (pack.code in downloadedPackCodes || pack.isPreInstalled) {
                        saveLanguageSelection(pack.code)
                        isLanguageSheetOpen = false
                    } else {
                        downloadSingleLanguagePack(pack, autoSelect = true)
                    }
                },
                onDownloadPack = { pack ->
                    downloadSingleLanguagePack(pack, autoSelect = false)
                },
                onRemovePack = { pack ->
                    removeDownloadedPack(pack.code)
                },
                onDownloadAllIndianPacks = {
                    downloadAllIndianLanguagesPack()
                },
                onClose = { isLanguageSheetOpen = false }
            )
        }
    }
}

@Composable
private fun LanguagePackManagerSheetContent(
    isDarkMode: Boolean,
    selectedLangCode: String,
    downloadedPackCodes: Set<String>,
    downloadProgressMap: Map<String, Float>,
    isBatchDownloadingIndia: Boolean,
    batchIndiaProgress: Float,
    onSelectLanguage: (LanguagePackItem) -> Unit,
    onDownloadPack: (LanguagePackItem) -> Unit,
    onRemovePack: (LanguagePackItem) -> Unit,
    onDownloadAllIndianPacks: () -> Unit,
    onClose: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    // Filter tab: 0 = India (All 26), 1 = All Languages, 2 = Downloaded, 3 = Global
    var selectedFilterTab by remember { mutableIntStateOf(0) }

    val primaryText = Color(0xFFF5F5F5)
    val secondaryText = Color(0xFFA8A8A8)
    val dividerColor = Color(0xFF262626)

    val indianPacks = remember { ALL_LANGUAGE_PACKS.filter { it.isIndianLanguage } }
    val pendingIndianPacksCount = remember(downloadedPackCodes) {
        indianPacks.count { it.code !in downloadedPackCodes }
    }

    val filteredPacks = remember(searchQuery, selectedFilterTab, downloadedPackCodes) {
        ALL_LANGUAGE_PACKS.filter { pack ->
            val matchesTab = when (selectedFilterTab) {
                0 -> pack.isIndianLanguage
                1 -> true
                2 -> pack.code in downloadedPackCodes
                else -> !pack.isIndianLanguage
            }
            val q = searchQuery.trim().lowercase()
            val matchesQuery = q.isEmpty() ||
                pack.englishName.lowercase().contains(q) ||
                pack.nativeName.lowercase().contains(q) ||
                pack.region.lowercase().contains(q)
            matchesTab && matchesQuery
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.82f)
            .padding(horizontal = 22.dp)
            .navigationBarsPadding()
            .testTag("language_pack_sheet")
    ) {
        // Minimal Sheet Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Select Language",
                fontFamily = PlusJakartaSansFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = primaryText
            )

            IconButton(onClick = onClose) {
                Icon(
                    imageVector = Icons.Filled.Close,
                    contentDescription = "Close",
                    tint = secondaryText,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Clean Borderless Search Input with Bottom Hairline Only
        Column(modifier = Modifier.fillMaxWidth()) {
            BasicTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                singleLine = true,
                textStyle = TextStyle(
                    fontFamily = InterFamily,
                    fontSize = 14.sp,
                    color = primaryText
                ),
                cursorBrush = SolidColor(NexoraPrimary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp)
                    .testTag("language_search_input"),
                decorationBox = { innerTextField ->
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Search,
                            contentDescription = null,
                            tint = secondaryText,
                            modifier = Modifier.size(18.dp)
                        )
                        Box(modifier = Modifier.weight(1f)) {
                            if (searchQuery.isEmpty()) {
                                Text(
                                    text = "Search language...",
                                    fontFamily = InterFamily,
                                    fontSize = 14.sp,
                                    color = secondaryText
                                )
                            }
                            innerTextField()
                        }
                        if (searchQuery.isNotEmpty()) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Clear search",
                                tint = secondaryText,
                                modifier = Modifier
                                    .size(18.dp)
                                    .clickable { searchQuery = "" }
                            )
                        }
                    }
                }
            )
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(dividerColor)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Clean Text Filter Tabs (No pill backgrounds, no outlines)
        val tabs = listOf(
            "India (${indianPacks.size})" to 0,
            "All (${ALL_LANGUAGE_PACKS.size})" to 1,
            "Downloaded (${downloadedPackCodes.size})" to 2,
            "Global" to 3
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(22.dp)
        ) {
            tabs.forEach { (label, tabIndex) ->
                val isSelected = selectedFilterTab == tabIndex
                Column(
                    modifier = Modifier
                        .clickable { selectedFilterTab = tabIndex }
                        .padding(top = 6.dp, bottom = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = label,
                        fontFamily = PlusJakartaSansFamily,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 13.5.sp,
                        color = if (isSelected) NexoraPrimary else secondaryText
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .width(24.dp)
                            .height(2.dp)
                            .background(
                                if (isSelected) NexoraPrimary else Color.Transparent,
                                RoundedCornerShape(999.dp)
                            )
                    )
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(dividerColor)
        )

        // Clean Borderless "All Languages of India Pack" Header Row
        if (selectedFilterTab == 0 || selectedFilterTab == 1) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "All Indian Languages Pack",
                            fontFamily = PlusJakartaSansFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = primaryText
                        )
                        Text(
                            text = if (pendingIndianPacksCount == 0) {
                                "All 26 regional languages ready offline"
                            } else {
                                "Download all $pendingIndianPacksCount remaining Indian languages"
                            },
                            fontFamily = InterFamily,
                            fontSize = 12.sp,
                            color = secondaryText
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    if (pendingIndianPacksCount == 0) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CloudDone,
                                contentDescription = "Installed",
                                tint = NexoraSuccessGreen,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Installed",
                                fontFamily = PlusJakartaSansFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.5.sp,
                                color = NexoraSuccessGreen
                            )
                        }
                    } else {
                        // Clean No-Background, No-Outline Action Button
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable(enabled = !isBatchDownloadingIndia) {
                                    onDownloadAllIndianPacks()
                                }
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                                .testTag("download_all_india_packs_btn"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CloudDownload,
                                contentDescription = "Download All India Pack",
                                tint = NexoraPrimary,
                                modifier = Modifier.size(17.dp)
                            )
                            Text(
                                text = if (isBatchDownloadingIndia) {
                                    "${(batchIndiaProgress * 100).toInt()}%"
                                } else {
                                    "Download All"
                                },
                                fontFamily = PlusJakartaSansFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = NexoraPrimary
                            )
                        }
                    }
                }

                if (isBatchDownloadingIndia) {
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { batchIndiaProgress },
                        color = NexoraPrimary,
                        trackColor = dividerColor,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .clip(RoundedCornerShape(999.dp))
                    )
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(dividerColor)
            )
        }

        // Clean Borderless & Background-Free Language List
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            items(filteredPacks, key = { it.code }) { pack ->
                val isDownloaded = pack.code in downloadedPackCodes || pack.isPreInstalled
                val isSelected = pack.code == selectedLangCode
                val activeProgress = downloadProgressMap[pack.code]

                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectLanguage(pack) }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = pack.nativeName,
                                    fontFamily = PlusJakartaSansFamily,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                                    fontSize = 15.sp,
                                    color = if (isSelected) NexoraPrimary else primaryText
                                )
                                if (pack.nativeName != pack.englishName) {
                                    Text(
                                        text = pack.englishName,
                                        fontFamily = InterFamily,
                                        fontWeight = FontWeight.Normal,
                                        fontSize = 13.5.sp,
                                        color = secondaryText,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(
                                text = if (isDownloaded) {
                                    "${pack.region} · Offline ready"
                                } else {
                                    "${pack.region} · ${pack.sizeMb}"
                                },
                                fontFamily = InterFamily,
                                fontSize = 11.5.sp,
                                color = secondaryText
                            )
                        }

                        // Clean Action Controls (No background, no outline)
                        when {
                            activeProgress != null -> {
                                Box(
                                    modifier = Modifier.size(28.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CircularProgressIndicator(
                                        progress = { activeProgress },
                                        color = NexoraPrimary,
                                        strokeWidth = 2.dp,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            isDownloaded -> {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Filled.Check,
                                            contentDescription = "Selected language",
                                            tint = NexoraPrimary,
                                            modifier = Modifier.size(19.dp)
                                        )
                                    } else {
                                        Text(
                                            text = "Use",
                                            fontFamily = PlusJakartaSansFamily,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 13.sp,
                                            color = NexoraPrimary,
                                            modifier = Modifier
                                                .clickable { onSelectLanguage(pack) }
                                                .padding(horizontal = 6.dp, vertical = 4.dp)
                                        )
                                    }

                                    if (!pack.isPreInstalled) {
                                        Icon(
                                            imageVector = Icons.Filled.DeleteOutline,
                                            contentDescription = "Remove pack",
                                            tint = secondaryText.copy(alpha = 0.7f),
                                            modifier = Modifier
                                                .size(18.dp)
                                                .clickable { onRemovePack(pack) }
                                        )
                                    }
                                }
                            }

                            else -> {
                                Row(
                                    modifier = Modifier
                                        .clickable { onDownloadPack(pack) }
                                        .padding(horizontal = 6.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Download,
                                        contentDescription = "Download ${pack.englishName}",
                                        tint = NexoraPrimary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = "Download",
                                        fontFamily = PlusJakartaSansFamily,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 12.5.sp,
                                        color = NexoraPrimary
                                    )
                                }
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(0.5.dp)
                            .background(dividerColor)
                    )
                }
            }
        }
    }
}

/**
 * Distinct Nexora Rounded Squircle Emblem with Prism Wave Glyph
 */
@Composable
private fun NexoraBrandEmblem(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        drawRoundRect(
            brush = Brush.linearGradient(
                colors = listOf(
                    Color(0xFFF58529),
                    Color(0xFFDD2A7B),
                    Color(0xFF8134AF),
                    Color(0xFF515BD4)
                ),
                start = Offset(0f, h),
                end = Offset(w, 0f)
            ),
            cornerRadius = CornerRadius(w * 0.28f, h * 0.28f)
        )

        val glyphPath = Path().apply {
            moveTo(w * 0.26f, h * 0.72f)
            lineTo(w * 0.50f, h * 0.28f)
            lineTo(w * 0.74f, h * 0.72f)
        }
        val crossPath = Path().apply {
            moveTo(w * 0.35f, h * 0.56f)
            lineTo(w * 0.65f, h * 0.56f)
        }
        val emblemStroke = Stroke(
            width = w * 0.085f,
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )
        drawPath(
            path = glyphPath,
            color = Color.White,
            style = emblemStroke
        )
        drawPath(
            path = crossPath,
            color = Color.White,
            style = emblemStroke
        )
    }
}

/**
 * Borderless Bottom-Line Input Field with Center-Outward Animated Focus Underline & Floating Micro-Label
 */
@Composable
private fun NexoraCleanInputField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    inputBorder: Color,
    primaryText: Color,
    secondaryText: Color,
    isPassword: Boolean = false,
    isPasswordVisible: Boolean = false,
    showLabel: String = "Show",
    hideLabel: String = "Hide",
    onTogglePasswordVisibility: (() -> Unit)? = null,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    modifier: Modifier = Modifier
) {
    var isFocused by remember { mutableStateOf(false) }
    val hasContent = value.isNotEmpty()
    val focusLineFraction by animateFloatAsState(
        targetValue = if (isFocused) 1f else 0f,
        animationSpec = tween(durationMillis = 280, easing = FastOutSlowInEasing),
        label = "focusLineFraction"
    )
    val floatingLabelColor by animateColorAsState(
        targetValue = if (isFocused) NexoraPrimary else secondaryText,
        animationSpec = tween(durationMillis = 220),
        label = "floatingLabelColor"
    )

    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        textStyle = TextStyle(
            fontFamily = InterFamily,
            fontWeight = FontWeight.Medium,
            fontSize = 15.sp,
            lineHeight = 20.sp,
            color = primaryText
        ),
        cursorBrush = SolidColor(NexoraPrimary),
        visualTransformation = if (isPassword && !isPasswordVisible) {
            PasswordVisualTransformation()
        } else {
            VisualTransformation.None
        },
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        modifier = modifier
            .height(52.dp)
            .onFocusChanged { isFocused = it.isFocused },
        decorationBox = { innerTextField ->
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Column(
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            AnimatedVisibility(
                                visible = hasContent,
                                enter = fadeIn(tween(180)) + expandVertically(tween(180)),
                                exit = fadeOut(tween(120)) + shrinkVertically(tween(120))
                            ) {
                                Text(
                                    text = placeholder,
                                    fontFamily = InterFamily,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = floatingLabelColor,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Box(modifier = Modifier.padding(top = if (hasContent) 1.dp else 0.dp)) {
                                if (!hasContent) {
                                    Text(
                                        text = placeholder,
                                        fontFamily = InterFamily,
                                        fontWeight = FontWeight.Normal,
                                        fontSize = 15.sp,
                                        lineHeight = 20.sp,
                                        color = secondaryText,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                innerTextField()
                            }
                        }
                    }

                    AnimatedVisibility(
                        visible = isPassword && hasContent && onTogglePasswordVisibility != null,
                        enter = fadeIn(tween(180)) + scaleIn(tween(180), initialScale = 0.85f),
                        exit = fadeOut(tween(120)) + scaleOut(tween(120), targetScale = 0.85f)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { onTogglePasswordVisibility?.invoke() }
                                .minimumInteractiveComponentSize()
                                .padding(start = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            AnimatedContent(
                                targetState = if (isPasswordVisible) hideLabel else showLabel,
                                transitionSpec = {
                                    fadeIn(tween(160)).togetherWith(fadeOut(tween(120)))
                                },
                                label = "passwordVisibilityLabel"
                            ) { toggleLabel ->
                                Text(
                                    text = toggleLabel,
                                    fontFamily = PlusJakartaSansFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.5.sp,
                                    color = NexoraPrimary
                                )
                            }
                        }
                    }
                }

                // Bottom Hairline with Center-Outward Animated Focus Indicator (Zero Card Outlines)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(inputBorder)
                    )
                    if (focusLineFraction > 0f) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(focusLineFraction)
                                .height(1.5.dp)
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(NexoraPrimary, NexoraSecondary)
                                    ),
                                    RoundedCornerShape(999.dp)
                                )
                        )
                    }
                }
            }
        }
    )
}

/**
 * Custom 4-Color Google 'G' Icon Canvas
 */
@Composable
private fun GoogleGIcon(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Red Top Arc
        val pathRed = Path().apply {
            moveTo(w * 0.5f, h * 0.1f)
            cubicTo(w * 0.72f, h * 0.1f, h * 0.88f, w * 0.22f, w * 0.94f, h * 0.38f)
            lineTo(w * 0.75f, h * 0.48f)
            cubicTo(w * 0.71f, h * 0.38f, w * 0.62f, h * 0.3f, w * 0.5f, h * 0.3f)
            cubicTo(w * 0.38f, h * 0.3f, w * 0.28f, h * 0.38f, w * 0.24f, h * 0.5f)
            lineTo(w * 0.05f, h * 0.36f)
            cubicTo(w * 0.14f, h * 0.2f, w * 0.3f, h * 0.1f, w * 0.5f, h * 0.1f)
            close()
        }
        drawPath(pathRed, Color(0xFFEA4335))

        // Blue Right Arm
        val pathBlue = Path().apply {
            moveTo(w * 0.94f, h * 0.38f)
            cubicTo(w * 0.98f, h * 0.46f, w * 1.0f, h * 0.55f, w * 0.98f, h * 0.65f)
            cubicTo(w * 0.95f, h * 0.78f, w * 0.86f, h * 0.88f, w * 0.74f, h * 0.93f)
            lineTo(w * 0.58f, h * 0.76f)
            cubicTo(w * 0.65f, h * 0.73f, w * 0.71f, h * 0.67f, w * 0.73f, h * 0.58f)
            lineTo(w * 0.5f, h * 0.58f)
            lineTo(w * 0.5f, h * 0.38f)
            lineTo(w * 0.94f, h * 0.38f)
            close()
        }
        drawPath(pathBlue, Color(0xFF4285F4))

        // Green Bottom Arc
        val pathGreen = Path().apply {
            moveTo(w * 0.74f, h * 0.93f)
            cubicTo(w * 0.67f, h * 0.97f, w * 0.58f, h * 0.99f, w * 0.5f, h * 0.99f)
            cubicTo(w * 0.3f, h * 0.99f, w * 0.13f, h * 0.88f, w * 0.05f, h * 0.72f)
            lineTo(w * 0.24f, h * 0.58f)
            cubicTo(w * 0.28f, h * 0.68f, w * 0.38f, h * 0.76f, w * 0.5f, h * 0.76f)
            cubicTo(w * 0.53f, h * 0.76f, w * 0.56f, h * 0.75f, w * 0.58f, h * 0.74f)
            lineTo(w * 0.74f, h * 0.93f)
            close()
        }
        drawPath(pathGreen, Color(0xFF34A853))

        // Yellow Left Arc
        val pathYellow = Path().apply {
            moveTo(w * 0.05f, h * 0.72f)
            cubicTo(w * 0.02f, h * 0.65f, w * 0.0f, h * 0.58f, w * 0.0f, h * 0.5f)
            cubicTo(w * 0.0f, h * 0.42f, w * 0.02f, h * 0.35f, w * 0.05f, h * 0.28f)
            lineTo(w * 0.24f, h * 0.42f)
            cubicTo(w * 0.23f, h * 0.45f, w * 0.22f, h * 0.48f, w * 0.22f, h * 0.5f)
            cubicTo(w * 0.22f, h * 0.52f, w * 0.23f, h * 0.55f, w * 0.24f, h * 0.58f)
            lineTo(w * 0.05f, h * 0.72f)
            close()
        }
        drawPath(pathYellow, Color(0xFFFBBC05))
    }
}
