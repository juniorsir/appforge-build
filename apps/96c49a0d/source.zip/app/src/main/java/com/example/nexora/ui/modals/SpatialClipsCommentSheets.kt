package com.example.nexora.ui.modals

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyHorizontalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nexora.data.VideoComment
import com.example.nexora.data.VideoItem
import com.example.nexora.ui.components.CreatorAvatarBadge
import com.example.ui.theme.NexoraColors
import com.example.ui.theme.NexoraTypography
import com.example.ui.theme.liquidGlassAccent
import com.example.ui.theme.liquidGlassWhitePill
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Identifies comments authored by the current user during this session so top-level comments
 * are always pinned at index 0 for easy discovery by the poster.
 */
internal fun isUserPostedComment(comment: VideoComment): Boolean {
    return comment.id.startsWith("c_") || comment.timestamp.equals("Just now", ignoreCase = true)
}

/**
 * Resolves the parent comment ID if [comment] is a reply to another comment, either via
 * an explicit `[REPLY_TO:parentId]` token or via a leading `@author_handle` mention.
 */
internal fun resolveParentCommentId(
    comment: VideoComment,
    allComments: List<VideoComment>
): String? {
    val explicitMatch = Regex("\\[REPLY_TO:([^\\]]+)\\]").find(comment.text)
    if (explicitMatch != null) {
        val targetId = explicitMatch.groupValues[1]
        if (allComments.any { it.id == targetId && it.id != comment.id }) {
            return targetId
        }
    }

    val cleaned = comment.text.replace(Regex("\\[REPLY_TO:[^\\]]+\\]"), "").trim()
    if (cleaned.startsWith("@")) {
        val mentionToken = cleaned.substringAfter("@").substringBefore(" ").lowercase()
        if (mentionToken.isNotBlank()) {
            val matchedParent = allComments.firstOrNull { candidate ->
                candidate.id != comment.id &&
                    ! candidate.text.contains("[REPLY_TO:") &&
                    (candidate.authorName.lowercase().replace(" ", "_") == mentionToken ||
                        candidate.authorHandle.removePrefix("@").lowercase() == mentionToken)
            }
            if (matchedParent != null) {
                return matchedParent.id
            }
        }
    }
    return null
}

/**
 * Strips internal `[GIF:...]` and `[REPLY_TO:...]` metadata tokens from display text.
 */
internal fun cleanCommentCaptionText(rawText: String): String {
    return rawText
        .replace(Regex("\\[REPLY_TO:[^\\]]+\\]"), "")
        .replace(Regex("\\[GIF:[^\\]]+\\]"), "")
        .trim()
}

/**
 * Dynamically scans all comments in the current short video to find the single most-used emoji
 * and its occurrence count, replacing the static user profile icon in the comment composer.
 */
internal fun computeMostUsedCommentEmoji(comments: List<VideoComment>): Pair<String, Int> {
    return "TOP" to (comments.size.coerceAtLeast(1))
}

@Composable
internal fun SpatialClipCommentsBottomSheet(
    clip: VideoItem,
    commentSortMode: String,
    onSortModeChange: (String) -> Unit,
    commentDraft: String,
    onCommentDraftChange: (String) -> Unit,
    replyingToAuthor: String?,
    onReplyingToAuthorChange: (String?) -> Unit,
    isGifPickerOpen: Boolean,
    onGifPickerOpenChange: (Boolean) -> Unit,
    gifSearchQuery: String,
    onGifSearchQueryChange: (String) -> Unit,
    onOpenShareSheet: () -> Unit,
    onAddComment: (String) -> Unit,
    onToggleCommentLike: (String) -> Unit,
    sheetNestedScrollBlocker: NestedScrollConnection,
    onDeleteComment: (String) -> Unit = {}
) {

    // Track which top-level parent comment ID is being replied to
    var replyingToParentId by remember(clip.id) { mutableStateOf<String?>(null) }
    val collapsedReplyThreads = remember(clip.id) { mutableStateMapOf<String, Boolean>() }

    // Clear replyingToParentId if external replyingToAuthor is cleared
    LaunchedEffect(replyingToAuthor) {
        if (replyingToAuthor == null) {
            replyingToParentId = null
        }
    }

    // Separate top-level parent comments from nested replies, and group replies under their parent ID
    val (sortedParentComments, repliesByParentId) = remember(clip.comments, commentSortMode) {
        val parentMap = mutableMapOf<String, MutableList<VideoComment>>()
        val topLevel = mutableListOf<VideoComment>()

        for (comment in clip.comments) {
            val parentId = resolveParentCommentId(comment, clip.comments)
            if (parentId != null) {
                parentMap.getOrPut(parentId) { mutableListOf() }.add(comment)
            } else {
                topLevel.add(comment)
            }
        }

        // Chronological order for replies under a parent (oldest reply first, newest reply at bottom of thread)
        val orderedRepliesMap = parentMap.mapValues { (_, list) -> list.reversed() }

        // Pin user's own top-level comments at index 0 in both Top and Newest modes
        val (ownTopLevel, otherTopLevel) = topLevel.partition { isUserPostedComment(it) }
        val sortedOthers = if (commentSortMode == "Top") {
            otherTopLevel.sortedByDescending { it.likes }
        } else {
            otherTopLevel
        }

        (ownTopLevel + sortedOthers) to orderedRepliesMap
    }

    val coroutineScope = rememberCoroutineScope()
    val commentListState = rememberLazyListState()
    val gifGridState = rememberLazyGridState()

    var selectedGifCategory by remember { mutableStateOf("Trending") }
    var publicGifs by remember {
        mutableStateOf(PublicGifRepository.curatedPublicGifs)
    }
    var nextTenorPos by remember { mutableStateOf<String?>(null) }
    var nextOffset by remember { mutableIntStateOf(0) }
    var currentPage by remember { mutableIntStateOf(0) }
    var isFetchingPublicGifs by remember { mutableStateOf(false) }
    var isLoadingMoreGifs by remember { mutableStateOf(false) }

    // Reset and load first page whenever search query, category, or picker visibility changes
    LaunchedEffect(gifSearchQuery, selectedGifCategory, isGifPickerOpen) {
        currentPage = 0
        nextTenorPos = null
        nextOffset = 0
        publicGifs = PublicGifRepository.filterCurated(gifSearchQuery, selectedGifCategory)

        if (isGifPickerOpen) {
            isFetchingPublicGifs = true
            runCatching { gifGridState.scrollToItem(0) }
            if (gifSearchQuery.isNotBlank()) {
                delay(220)
            }
            val firstPage = PublicGifRepository.fetchPublicGifPage(
                query = gifSearchQuery,
                category = selectedGifCategory,
                tenorPos = null,
                offset = 0,
                pageIndex = 0
            )
            publicGifs = firstPage.items
            nextTenorPos = firstPage.nextTenorPos
            nextOffset = firstPage.nextOffset
            currentPage = 1
            isFetchingPublicGifs = false
        }
    }

    // Detect when user scrolls near the end of the 2-row grid to trigger infinite pagination
    val shouldLoadMore by remember {
        derivedStateOf {
            val layoutInfo = gifGridState.layoutInfo
            val totalItems = layoutInfo.totalItemsCount
            val lastVisible = layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            totalItems > 0 && lastVisible >= (totalItems - 6).coerceAtLeast(1)
        }
    }

    suspend fun loadNextInfiniteGifBatch() {
        if (isLoadingMoreGifs || isFetchingPublicGifs) return
        isLoadingMoreGifs = true
        val pageResult = PublicGifRepository.fetchPublicGifPage(
            query = gifSearchQuery,
            category = selectedGifCategory,
            tenorPos = nextTenorPos,
            offset = nextOffset,
            pageIndex = currentPage
        )
        val existingIds = publicGifs.asSequence().map { it.id }.toHashSet()
        val uniqueNew = pageResult.items.filterNot { it.id in existingIds }
        if (uniqueNew.isNotEmpty()) {
            publicGifs = publicGifs + uniqueNew
        }
        nextTenorPos = pageResult.nextTenorPos
        nextOffset = pageResult.nextOffset
        currentPage += 1
        isLoadingMoreGifs = false
    }

    LaunchedEffect(shouldLoadMore, isGifPickerOpen) {
        if (isGifPickerOpen && shouldLoadMore) {
            loadNextInfiniteGifBatch()
        }
    }

    // Helper to submit either a top-level comment or a nested reply under its parent comment
    fun submitCommentOrReply(rawContent: String) {
        val activeParentId = replyingToParentId ?: if (replyingToAuthor != null) {
            sortedParentComments.firstOrNull {
                it.authorName.equals(replyingToAuthor, ignoreCase = true)
            }?.id
        } else {
            null
        }

        val payload = if (activeParentId != null) {
            "[REPLY_TO:$activeParentId]$rawContent"
        } else {
            rawContent
        }

        onAddComment(payload)
        onCommentDraftChange("")
        onReplyingToAuthorChange(null)
        replyingToParentId = null

        if (activeParentId != null) {
            collapsedReplyThreads[activeParentId] = false
            val parentIdx = sortedParentComments.indexOfFirst { it.id == activeParentId }
            if (parentIdx >= 0) {
                coroutineScope.launch {
                    runCatching { commentListState.animateScrollToItem(parentIdx) }
                }
            }
        } else {
            coroutineScope.launch {
                runCatching { commentListState.animateScrollToItem(0) }
            }
        }
    }

    val topSheetShape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(520.dp)
            .shadow(
                elevation = 24.dp,
                shape = topSheetShape,
                ambientColor = NexoraColors.AmbientShadowTint,
                spotColor = NexoraColors.AmbientShadowTint
            )
            .clip(topSheetShape)
            .background(NexoraColors.CanvasBase)
            .border(
                width = 1.4.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        NexoraColors.SpecularBorderStrong,
                        NexoraColors.Sky300.copy(alpha = 0.65f),
                        NexoraColors.Lavender300.copy(alpha = 0.65f)
                    )
                ),
                shape = topSheetShape
            )
            .nestedScroll(sheetNestedScrollBlocker)
            .pointerInput(Unit) {
                detectVerticalDragGestures { change, _ ->
                    change.consume()
                }
            }
            .clickable(enabled = false) {}
            .windowInsetsPadding(WindowInsets.navigationBars)
            .testTag("clip_comments_drawer")
    ) {
        // Top Iridescent Drag Handle Pill
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp, bottom = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .width(44.dp)
                    .height(4.5.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                NexoraColors.Sky400.copy(alpha = 0.70f),
                                NexoraColors.Lavender400.copy(alpha = 0.85f),
                                NexoraColors.ElectricIndigo.copy(alpha = 0.70f)
                            )
                        )
                    )
            )
        }

        // Frosted Liquid Glass Header:
        // Adapts dynamically between Comments Header and Full-Window Infinite GIF Studio Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            if (isGifPickerOpen) {
                Row(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .liquidGlassWhitePill(999.dp)
                        .clickable { onGifPickerOpenChange(false) }
                        .padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to comments",
                        tint = NexoraColors.InkAccent,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "Comments",
                        style = NexoraTypography.BadgeMicro.copy(
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = NexoraColors.InkAccent
                        )
                    )
                }

                Row(
                    modifier = Modifier.align(Alignment.Center),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "GIF Studio",
                        style = NexoraTypography.CardTitle.copy(
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = NexoraColors.InkPrimary
                        )
                    )
                    Box(
                        modifier = Modifier
                            .liquidGlassAccent(999.dp)
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${publicGifs.size}+ ∞ GIFs",
                            style = NexoraTypography.BadgeMicro.copy(
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = NexoraColors.InkAccent
                            )
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .size(32.dp)
                        .liquidGlassWhitePill(999.dp)
                        .clickable { onGifPickerOpenChange(false) },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Close GIF Picker",
                        tint = NexoraColors.InkAccent,
                        modifier = Modifier.size(15.dp)
                    )
                }
            } else {
                Row(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .clip(RoundedCornerShape(999.dp))
                        .background(NexoraColors.Pearl200.copy(alpha = 0.85f))
                        .border(
                            width = 1.dp,
                            color = NexoraColors.SpecularBorderStrong,
                            shape = RoundedCornerShape(999.dp)
                        )
                        .padding(2.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf("Top", "Newest").forEach { mode ->
                        val isSelected = commentSortMode == mode
                        Box(
                            modifier = Modifier
                                .then(
                                    if (isSelected) Modifier.liquidGlassAccent(999.dp)
                                    else Modifier.clip(RoundedCornerShape(999.dp))
                                )
                                .clickable { onSortModeChange(mode) }
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = mode,
                                style = NexoraTypography.BadgeMicro.copy(
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold,
                                    color = if (isSelected) NexoraColors.InkAccent else NexoraColors.InkMuted
                                )
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.align(Alignment.Center),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Comments",
                        style = NexoraTypography.CardTitle.copy(
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = NexoraColors.InkPrimary
                        )
                    )
                    Box(
                        modifier = Modifier
                            .liquidGlassAccent(999.dp)
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${clip.comments.size}",
                            style = NexoraTypography.BadgeMicro.copy(
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = NexoraColors.InkAccent
                            )
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .size(32.dp)
                        .liquidGlassWhitePill(999.dp)
                        .clickable { onOpenShareSheet() },
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.size(17.dp)) {
                        val w = size.width
                        val h = size.height
                        val planePath = Path().apply {
                            moveTo(w * 0.10f, h * 0.42f)
                            lineTo(w * 0.90f, h * 0.14f)
                            lineTo(w * 0.58f, h * 0.88f)
                            lineTo(w * 0.44f, h * 0.54f)
                            close()
                        }
                        drawPath(
                            path = planePath,
                            color = NexoraColors.InkAccent,
                            style = Stroke(width = 1.7.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                        )
                        drawLine(
                            color = NexoraColors.ElectricIndigo,
                            start = Offset(w * 0.44f, h * 0.54f),
                            end = Offset(w * 0.90f, h * 0.14f),
                            strokeWidth = 1.5.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }
                }
            }
        }

        HorizontalDivider(
            color = NexoraColors.Pearl300.copy(alpha = 0.85f),
            thickness = 1.dp
        )

        // Main Full-Size Comment Section Window (weight = 1f):
        // Shows either the Full-Window 2-Row Infinite Public GIF Browser or the Threaded Comment List
        if (isGifPickerOpen) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                NexoraColors.Pearl100.copy(alpha = 0.95f),
                                NexoraColors.Sky100.copy(alpha = 0.50f),
                                NexoraColors.Lavender100.copy(alpha = 0.68f)
                            )
                        )
                    )
                    .nestedScroll(sheetNestedScrollBlocker)
                    .padding(top = 10.dp, bottom = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .height(38.dp)
                            .liquidGlassWhitePill(14.dp)
                            .padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Search,
                            contentDescription = "Search Infinite GIFs",
                            tint = NexoraColors.ElectricIndigo,
                            modifier = Modifier.size(16.dp)
                        )
                        BasicTextField(
                            value = gifSearchQuery,
                            onValueChange = { onGifSearchQueryChange(it) },
                            singleLine = true,
                            textStyle = NexoraTypography.BadgeMicro.copy(
                                fontSize = 12.5.sp,
                                color = NexoraColors.InkPrimary,
                                fontWeight = FontWeight.Medium
                            ),
                            cursorBrush = SolidColor(NexoraColors.ElectricIndigo),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("clip_gif_search_input"),
                            decorationBox = { inner ->
                                if (gifSearchQuery.isEmpty()) {
                                    Text(
                                        text = "Search infinite Tenor & GIPHY GIFs...",
                                        style = NexoraTypography.BadgeMicro.copy(
                                            fontSize = 12.sp,
                                            color = NexoraColors.InkMuted
                                        ),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                inner()
                            }
                        )

                        if (gifSearchQuery.isNotEmpty()) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Clear search",
                                tint = NexoraColors.InkMuted,
                                modifier = Modifier
                                    .size(15.dp)
                                    .clickable { onGifSearchQueryChange("") }
                            )
                        }

                        Box(
                            modifier = Modifier
                                .liquidGlassAccent(999.dp)
                                .padding(horizontal = 7.dp, vertical = 2.5.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(5.5.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isFetchingPublicGifs || isLoadingMoreGifs) NexoraColors.Sky400
                                            else NexoraColors.EmeraldLive
                                        )
                                )
                                Text(
                                    text = if (isFetchingPublicGifs || isLoadingMoreGifs) "STREAMING" else "∞ INFINITE",
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = NexoraColors.InkAccent
                                    )
                                )
                            }
                        }
                    }
                }

                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("clip_gif_category_row"),
                    contentPadding = PaddingValues(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    items(PublicGifRepository.categories, key = { it }) { category ->
                        val isSelected = selectedGifCategory == category && gifSearchQuery.isBlank()
                        Box(
                            modifier = Modifier
                                .then(
                                    if (isSelected) Modifier.liquidGlassAccent(999.dp)
                                    else Modifier.liquidGlassWhitePill(999.dp)
                                )
                                .clickable {
                                    selectedGifCategory = category
                                    onGifSearchQueryChange("")
                                }
                                .padding(horizontal = 12.dp, vertical = 5.dp)
                                .testTag("clip_gif_category_${category.lowercase().replace(" ", "_")}")
                        ) {
                            Text(
                                text = category,
                                style = NexoraTypography.BadgeMicro.copy(
                                    fontSize = 10.5.sp,
                                    fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold,
                                    color = if (isSelected) NexoraColors.InkAccent else NexoraColors.InkSecondary
                                )
                            )
                        }
                    }
                }

                LazyHorizontalGrid(
                    rows = GridCells.Fixed(2),
                    state = gifGridState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .nestedScroll(sheetNestedScrollBlocker)
                        .testTag("clip_gif_picker_row"),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(publicGifs, key = { it.id }) { gif ->
                        AnimatedCommentGifCard(
                            sticker = gif,
                            modifier = Modifier
                                .width(172.dp)
                                .fillMaxHeight()
                                .clickable {
                                    val prefix = if (commentDraft.isNotBlank()) "${commentDraft.trim()} " else ""
                                    submitCommentOrReply("$prefix${gif.toToken()}")
                                    onGifPickerOpenChange(false)
                                    onGifSearchQueryChange("")
                                }
                                .testTag("clip_gif_option_${gif.id}")
                        )
                    }

                    item(key = "infinite_gif_loader_card") {
                        Box(
                            modifier = Modifier
                                .width(136.dp)
                                .fillMaxHeight()
                                .liquidGlassWhitePill(16.dp)
                                .clickable {
                                    coroutineScope.launch {
                                        loadNextInfiniteGifBatch()
                                    }
                                }
                                .padding(12.dp)
                                .testTag("clip_gif_load_more_card"),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .liquidGlassAccent(999.dp)
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = if (isLoadingMoreGifs) "LOADING..." else "∞ MORE",
                                        style = NexoraTypography.BadgeMicro.copy(
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = NexoraColors.ElectricIndigo
                                        )
                                    )
                                }
                                Text(
                                    text = if (isLoadingMoreGifs) "Fetching next GIF batch..." else "Swipe or tap for more GIFs",
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = NexoraColors.InkSecondary
                                    )
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // Scroll-Isolated Threaded Comment List:
            // - User's posted top-level comments sit cleanly at index 0 (no border box)
            // - Replies render directly under their parent comment
            LazyColumn(
                state = commentListState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .nestedScroll(sheetNestedScrollBlocker)
                    .testTag("clip_comments_lazy_list"),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                itemsIndexed(sortedParentComments, key = { _, item -> item.id }) { index, comment ->
                    val childReplies = repliesByParentId[comment.id].orEmpty()
                    val isThreadCollapsed = collapsedReplyThreads[comment.id] == true

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("clip_comment_row_${comment.id}"),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Parent Comment Item (clean borderless layout)
                        CommentThreadItemRow(
                            comment = comment,
                            creatorName = clip.creatorName,
                            showPinnedBadge = index == 0 && !isUserPostedComment(comment) && commentSortMode == "Top",
                            isReply = false,
                            onReplyClick = {
                                replyingToParentId = comment.id
                                onReplyingToAuthorChange(comment.authorName)
                                onCommentDraftChange(com.example.nexora.network.AkashMediaService.cleanEmojis("@${comment.authorName.lowercase().replace(" ", "_")} "))
                            },
                            onToggleLike = { onToggleCommentLike(comment.id) },
                            onDeleteClick = { onDeleteComment(comment.id) }
                        )

                        // Nested Replies directly under Parent Comment
                        if (childReplies.isNotEmpty()) {
                            if (!isThreadCollapsed) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(start = 34.dp)
                                        .testTag("clip_comment_replies_${comment.id}"),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    childReplies.forEach { replyComment ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(IntrinsicSize.Min),
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            // Subtle vertical thread connector bar
                                            Box(
                                                modifier = Modifier
                                                    .width(1.5.dp)
                                                    .fillMaxHeight()
                                                    .clip(RoundedCornerShape(999.dp))
                                                    .background(NexoraColors.Pearl300)
                                            )

                                            Box(modifier = Modifier.weight(1f)) {
                                                CommentThreadItemRow(
                                                    comment = replyComment,
                                                    creatorName = clip.creatorName,
                                                    showPinnedBadge = false,
                                                    isReply = true,
                                                    onReplyClick = {
                                                        // Keep nested under the same parent comment
                                                        replyingToParentId = comment.id
                                                        onReplyingToAuthorChange(replyComment.authorName)
                                                        onCommentDraftChange(
                                                            com.example.nexora.network.AkashMediaService.cleanEmojis(
                                                                "@${replyComment.authorName.lowercase().replace(" ", "_")} "
                                                            )
                                                        )
                                                    },
                                                    onToggleLike = { onToggleCommentLike(replyComment.id) },
                                                    onDeleteClick = { onDeleteComment(replyComment.id) }
                                                )
                                            }
                                        }
                                    }

                                    // Instagram-style "Hide replies" toggle line
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier
                                            .padding(start = 12.dp, top = 2.dp)
                                            .clickable { collapsedReplyThreads[comment.id] = true }
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .width(22.dp)
                                                .height(1.dp)
                                                .background(NexoraColors.InkMuted.copy(alpha = 0.45f))
                                        )
                                        Text(
                                            text = "Hide replies",
                                            style = NexoraTypography.BadgeMicro.copy(
                                                fontSize = 10.5.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = NexoraColors.InkMuted
                                            )
                                        )
                                    }
                                }
                            } else {
                                // Collapsed "View N replies" line under parent comment
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier
                                        .padding(start = 48.dp, top = 2.dp)
                                        .clickable { collapsedReplyThreads[comment.id] = false }
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .width(24.dp)
                                            .height(1.dp)
                                            .background(NexoraColors.InkMuted.copy(alpha = 0.45f))
                                    )
                                    Text(
                                        text = if (childReplies.size == 1) {
                                            "View 1 reply"
                                        } else {
                                            "View ${childReplies.size} replies"
                                        },
                                        style = NexoraTypography.BadgeMicro.copy(
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = NexoraColors.InkMuted
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        HorizontalDivider(
            color = NexoraColors.Pearl300.copy(alpha = 0.85f),
            thickness = 1.dp
        )

        // Replying-To Banner (if active)
        if (replyingToAuthor != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NexoraColors.Lavender100.copy(alpha = 0.85f))
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Replying to $replyingToAuthor",
                    style = NexoraTypography.BadgeMicro.copy(
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NexoraColors.InkAccent
                    )
                )
                Icon(
                    imageVector = Icons.Filled.Close,
                    contentDescription = "Cancel reply",
                    tint = NexoraColors.InkSecondary,
                    modifier = Modifier
                        .size(14.dp)
                        .clickable {
                            replyingToParentId = null
                            onReplyingToAuthorChange(null)
                            onCommentDraftChange("")
                        }
                )
            }
        }

        // Bottom Frosted Liquid Glass Composer:
        // Most-Used Emoji Badge (replaces profile avatar) + Glass Pill Input + Premium Motion-Sticker GIF Icon + Post
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NexoraColors.CanvasBase)
                .padding(start = 14.dp, end = 14.dp, bottom = 12.dp, top = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // User Profile Avatar Badge (Zero-Emoji compliance)
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .testTag("clip_comment_author_avatar"),
                contentAlignment = Alignment.Center
            ) {
                CreatorAvatarBadge(
                    name = "You",
                    seed = 1,
                    size = 36.dp,
                    isSquircle = false,
                    borderWidth = 1.2.dp,
                    showOnlineDot = false
                )
            }

            // Frosted Liquid Glass Composer Input Capsule
            Row(
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .liquidGlassWhitePill(999.dp)
                    .padding(start = 14.dp, end = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                BasicTextField(
                    value = commentDraft,
                    onValueChange = {
                        onCommentDraftChange(com.example.nexora.network.AkashMediaService.cleanEmojis(it))
                    },
                    singleLine = true,
                    textStyle = NexoraTypography.NavPillLabel.copy(
                        fontSize = 13.sp,
                        color = NexoraColors.InkPrimary
                    ),
                    cursorBrush = SolidColor(NexoraColors.ElectricIndigo),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("clip_comment_input"),
                    decorationBox = { inner ->
                        if (commentDraft.isEmpty()) {
                            Text(
                                text = if (replyingToAuthor != null) {
                                    "Reply to $replyingToAuthor..."
                                } else {
                                    "Add a comment for ${clip.creatorName}..."
                                },
                                style = NexoraTypography.NavPillLabel.copy(
                                    fontSize = 13.sp,
                                    color = NexoraColors.InkMuted
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        inner()
                    }
                )

                // Premium 3D Prismatic Motion-Sticker GIF Icon Button
                SculptedGifVectorButton(
                    isActive = isGifPickerOpen,
                    onClick = { onGifPickerOpenChange(!isGifPickerOpen) }
                )

                // Liquid Glass "Post" Pill Button
                val canPost = commentDraft.isNotBlank()
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(
                            if (canPost) {
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        NexoraColors.ElectricIndigo,
                                        NexoraColors.Lavender500
                                    )
                                )
                            } else {
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        NexoraColors.Pearl200,
                                        NexoraColors.Pearl300
                                    )
                                )
                            }
                        )
                        .clickable(enabled = canPost) {
                            if (commentDraft.isNotBlank()) {
                                submitCommentOrReply(commentDraft.trim())
                            }
                        }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                        .testTag("clip_comment_send_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Post",
                        style = NexoraTypography.BadgeMicro.copy(
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (canPost) Color.White else NexoraColors.InkMuted
                        )
                    )
                }
            }
        }
    }
}

/**
 * Renders an individual comment or nested reply row without any artificial border box around it.
 */
@Composable
private fun CommentThreadItemRow(
    comment: VideoComment,
    creatorName: String,
    showPinnedBadge: Boolean,
    isReply: Boolean,
    onReplyClick: () -> Unit,
    onToggleLike: () -> Unit,
    onDeleteClick: (() -> Unit)? = null
) {
    val parsedGif = remember(comment.text) { parseGifFromComment(comment.text) }
    val captionWithoutTokens = remember(comment.text) { cleanCommentCaptionText(comment.text) }

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(if (isReply) 10.dp else 12.dp)
    ) {
        CreatorAvatarBadge(
            name = comment.authorName,
            seed = comment.avatarSeed,
            size = if (isReply) 28.dp else 36.dp,
            isSquircle = false,
            borderWidth = 1.dp,
            showOnlineDot = false
        )

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = comment.authorName,
                    style = NexoraTypography.BadgeMicro.copy(
                        fontSize = if (isReply) 11.5.sp else 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = NexoraColors.InkPrimary
                    )
                )
                if (comment.authorName == creatorName) {
                    Box(
                        modifier = Modifier
                            .liquidGlassAccent(6.dp)
                            .padding(horizontal = 6.dp, vertical = 1.5.dp)
                    ) {
                        Text(
                            text = "Author",
                            style = NexoraTypography.BadgeMicro.copy(
                                fontSize = 9.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = NexoraColors.ElectricIndigo
                            )
                        )
                    }
                }
                Text(
                    text = comment.timestamp,
                    style = NexoraTypography.BadgeMicro.copy(
                        fontSize = 11.sp,
                        color = NexoraColors.InkMuted
                    )
                )
                if (showPinnedBadge) {
                    Box(
                        modifier = Modifier
                            .liquidGlassWhitePill(6.dp)
                            .padding(horizontal = 6.dp, vertical = 1.5.dp)
                    ) {
                        Text(
                            text = "Pinned",
                            style = NexoraTypography.BadgeMicro.copy(
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = NexoraColors.InkSecondary
                            )
                        )
                    }
                }
            }

            if (captionWithoutTokens.isNotEmpty()) {
                val styledCaption = remember(captionWithoutTokens) {
                    buildAnnotatedString {
                        if (captionWithoutTokens.startsWith("@")) {
                            val mentionEnd = captionWithoutTokens.indexOf(' ')
                            if (mentionEnd > 0) {
                                withStyle(
                                    SpanStyle(
                                        color = NexoraColors.ElectricIndigo,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                ) {
                                    append(captionWithoutTokens.substring(0, mentionEnd))
                                }
                                append(captionWithoutTokens.substring(mentionEnd))
                            } else {
                                withStyle(
                                    SpanStyle(
                                        color = NexoraColors.ElectricIndigo,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                ) {
                                    append(captionWithoutTokens)
                                }
                            }
                        } else {
                            append(captionWithoutTokens)
                        }
                    }
                }
                Text(
                    text = styledCaption,
                    style = NexoraTypography.NavPillLabel.copy(
                        fontSize = if (isReply) 13.sp else 13.5.sp,
                        color = NexoraColors.InkSecondary,
                        lineHeight = 18.sp
                    )
                )
            }

            if (parsedGif != null) {
                AnimatedCommentGifCard(
                    sticker = parsedGif,
                    modifier = Modifier
                        .padding(top = 3.dp)
                        .width(if (isReply) 160.dp else 184.dp)
                        .height(if (isReply) 100.dp else 114.dp)
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.padding(top = 2.dp)
            ) {
                Text(
                    text = "Reply",
                    style = NexoraTypography.BadgeMicro.copy(
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NexoraColors.InkMuted
                    ),
                    modifier = Modifier.clickable { onReplyClick() }
                )
                if (comment.isDeletable || isUserPostedComment(comment)) {
                    Text(
                        text = "Delete",
                        style = NexoraTypography.BadgeMicro.copy(
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NexoraColors.LiveRose
                        ),
                        modifier = Modifier
                            .clickable { onDeleteClick?.invoke() }
                            .testTag("delete_comment_${comment.id}")
                    )
                }
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(3.dp),
            modifier = Modifier
                .padding(top = 2.dp)
                .clickable { onToggleLike() }
        ) {
            Icon(
                imageVector = if (comment.isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                contentDescription = "Like Comment",
                tint = if (comment.isLiked) NexoraColors.LiveRose else NexoraColors.InkMuted,
                modifier = Modifier.size(if (isReply) 14.dp else 16.dp)
            )
            if (comment.likes > 0) {
                Text(
                    text = "${comment.likes}",
                    style = NexoraTypography.BadgeMicro.copy(
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (comment.isLiked) NexoraColors.LiveRose else NexoraColors.InkMuted
                    )
                )
            }
        }
    }
}
