package com.example.nexora.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.ThumbDown
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import coil.compose.SubcomposeAsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.media3.ui.AspectRatioFrameLayout
import com.example.nexora.data.VideoComment
import com.example.nexora.data.VideoItem
import com.example.nexora.ui.player.AkashInlineClipExoPlayer
import com.example.ui.theme.NexoraColors
import com.example.ui.theme.NexoraTypography
import com.example.ui.theme.liquidGlassAccent
import com.example.ui.theme.liquidGlassCard
import com.example.ui.theme.liquidGlassDarkOverlay
import com.example.ui.theme.liquidGlassElevatedCapsule
import com.example.ui.theme.liquidGlassWhitePill
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Unified Media-Only Post / Video Card sized dynamically according to the video or post's aspect ratio.
 *
 * Corner Overlay Layout (Frameless icons — zero circles or background pills behind icons):
 * - Bottom-Left: Creator profile icon + @handle (with verified badge)
 * - Bottom-Right: Frameless Mute / Unmute button
 * - Top-Right: Horizontal row of frameless Like, Comment (cmt), Share, and Two-Horizontal-Line (=) More icon
 * - More Menu (=): Music Info, Save, Interested, and Report options
 */
@Composable
fun NexoraVideoCard(
    video: VideoItem,
    isSaved: Boolean,
    onVideoClick: (VideoItem) -> Unit,
    onCreatorClick: (String) -> Unit,
    onToggleSave: (String) -> Unit,
    onShareClick: (VideoItem) -> Unit,
    modifier: Modifier = Modifier,
    resumeProgress: Float? = null,
    onToggleLike: (String) -> Unit = {},
    onDoubleTapLike: (String) -> Unit = onToggleLike,
    onToggleRepost: (String) -> Unit = {},
    onAddComment: (String, String) -> Unit = { _, _ -> },
    onToggleCommentLike: (String, String) -> Unit = { _, _ -> },
    onActionFeedback: (String) -> Unit = {},
    isAutoplayActive: Boolean = false,
    isMuted: Boolean = false,
    onToggleMute: () -> Unit = {}
) {
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()

    val slides = remember(video.carouselSlides, video.visualPreset) {
        video.carouselSlides.ifEmpty { listOf(video.visualPreset) }
    }
    var activeSlideIndex by remember(video.id) { mutableIntStateOf(0) }
    val activePreset = slides.getOrElse(activeSlideIndex) { video.visualPreset }

    // Modal states for More Options (=) and Comments (cmt)
    var isMoreMenuOpen by remember(video.id) { mutableStateOf(false) }
    var isCommentsSheetOpen by remember(video.id) { mutableStateOf(false) }
    var isInterested by remember(video.id) { mutableStateOf<Boolean?>(null) }
    var isReported by remember(video.id) { mutableStateOf(false) }

    // Local optimistic comments list synced with video.comments so comments work across all tabs
    val localAddedComments = remember(video.id) { mutableStateListOf<VideoComment>() }
    val combinedComments = remember(video.comments, localAddedComments.size) {
        val existingIds = video.comments.map { it.id }.toSet()
        localAddedComments.filter { it.id !in existingIds } + video.comments
    }

    // Double-Tap Refractive Heart Burst state
    var burstCenter by remember { mutableStateOf<Offset?>(null) }
    val burstScale = remember { Animatable(0f) }
    val burstAlpha = remember { Animatable(0f) }

    val likeScale by animateFloatAsState(
        targetValue = if (video.isLiked) 1.2f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "like_bounce"
    )

    // Per-card caption expansion state
    var isCaptionExpanded by remember(video.id) { mutableStateOf(false) }

    // Track actual intrinsic aspect ratio of loaded thumbnail so we fit media accurately without cropping
    var intrinsicImageAspectRatio by remember(video.id) { mutableStateOf<Float?>(null) }
    val rawMediaAspectRatio = intrinsicImageAspectRatio ?: video.aspectRatio

    // Prevent stretching the card too tall when media height is high by clamping aspect ratio >= 1.08f
    val effectiveAspectRatio = rawMediaAspectRatio.coerceIn(1.08f, 1.85f)
    val compactLikesText = remember(video.likesCount) { formatCompactLikesCount(video.likesCount) }
    val fullLikesText = remember(video.likesCount) { formatFullLikesCount(video.likesCount) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("video_card_${video.id}"),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(effectiveAspectRatio)
                .clip(RoundedCornerShape(24.dp))
                .background(NexoraColors.Pearl100)
                .border(
                    width = 1.dp,
                    color = Color.White.copy(alpha = 0.28f),
                    shape = RoundedCornerShape(24.dp)
                )
                .pointerInput(video.id, video.isVideoPost) {
                    detectTapGestures(
                        onTap = {
                            if (video.isVideoPost || video.isLiveStream) {
                                onVideoClick(video)
                            }
                        },
                        onDoubleTap = { tapOffset ->
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onDoubleTapLike(video.id)
                            burstCenter = tapOffset
                            scope.launch {
                                burstScale.snapTo(0.2f)
                                burstAlpha.snapTo(1f)
                                launch {
                                    burstScale.animateTo(
                                        targetValue = 1.25f,
                                        animationSpec = spring(
                                            dampingRatio = 0.52f,
                                            stiffness = 460f
                                        )
                                    )
                                    burstScale.animateTo(
                                        targetValue = 1.0f,
                                        animationSpec = tween(160)
                                    )
                                }
                                launch {
                                    delay(420L)
                                    burstAlpha.animateTo(0f, tween(280))
                                }
                            }
                        }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            // 1. Dynamic Aspect-Ratio Media Layer (Autoplay video when centered on screen, or uncropped thumbnail)
            val context = LocalContext.current
            val networkThumbUrl = video.effectiveThumbnailUrl
            if (isAutoplayActive && video.isVideoPost) {
                AkashInlineClipExoPlayer(
                    clip = video,
                    isActivePage = true,
                    isPaused = false,
                    isMuted = isMuted,
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT,
                    modifier = Modifier.fillMaxSize()
                )
            } else if (!networkThumbUrl.isNullOrBlank()) {
                val imageRequest = remember(context, networkThumbUrl) {
                    ImageRequest.Builder(context)
                        .data(networkThumbUrl)
                        .crossfade(180)
                        .memoryCachePolicy(CachePolicy.ENABLED)
                        .diskCachePolicy(CachePolicy.ENABLED)
                        .build()
                }
                // Subtle ambient backdrop so pillarboxed/letterboxed regions of tall or wide media look intentional
                Box(modifier = Modifier.fillMaxSize()) {
                    SpatialVisualCanvas(
                        preset = activePreset,
                        isAnimated = false,
                        playbackPhase = video.previewProgress
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0xCC000000))
                    )
                }

                SubcomposeAsyncImage(
                    model = imageRequest,
                    contentDescription = video.title,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize(),
                    onSuccess = { successState ->
                        val size = successState.painter.intrinsicSize
                        if (size.width > 0f && size.height > 0f && size.width.isFinite() && size.height.isFinite()) {
                            intrinsicImageAspectRatio = size.width / size.height
                        }
                    },
                    loading = {
                        InstagramDarkShimmerBox(modifier = Modifier.fillMaxSize())
                    },
                    error = {
                        SpatialVisualCanvas(
                            preset = activePreset,
                            isAnimated = video.isLiveStream,
                            playbackPhase = (video.previewProgress + activeSlideIndex * 0.22f) % 1.0f
                        )
                    }
                )
            } else {
                SpatialVisualCanvas(
                    preset = activePreset,
                    isAnimated = video.isLiveStream,
                    playbackPhase = (video.previewProgress + activeSlideIndex * 0.22f) % 1.0f
                )
            }

            // 2. Subtle Top & Bottom Gradient Scrims so frameless white icons & handle stay legible
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            0.0f to Color(0x660F172A),
                            0.26f to Color.Transparent,
                            0.72f to Color.Transparent,
                            1.0f to Color(0x880F172A)
                        )
                    )
            )

            // 3. Top-Left Corner: Profile Icon + @Handle (Instagram style)
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(start = 14.dp, top = 12.dp, end = 64.dp)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        onCreatorClick(video.creatorId)
                    }
                    .testTag("avatar_btn_${video.id}"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                CreatorAvatarBadge(
                    name = video.creatorName,
                    seed = video.creatorAvatarSeed,
                    size = 30.dp,
                    borderWidth = 1.2.dp,
                    avatarUrl = video.effectiveCreatorAvatarUrl
                )

                Text(
                    text = video.formattedCreatorHandle,
                    style = NexoraTypography.CreatorSubtitle.copy(
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.5.sp,
                        shadow = Shadow(
                            color = Color(0x990F172A),
                            offset = Offset(0f, 1.5f),
                            blurRadius = 4f
                        )
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                VerifiedBadge(size = 13.dp)

                if (!video.isPhotoPost && video.duration.isNotBlank() && video.duration != "0:00") {
                    Text(
                        text = "• ${video.duration}",
                        style = NexoraTypography.MetaCaption.copy(
                            color = Color.White.copy(alpha = 0.88f),
                            fontSize = 11.5.sp,
                            shadow = Shadow(
                                color = Color(0x990F172A),
                                offset = Offset(0f, 1.5f),
                                blurRadius = 4f
                            )
                        ),
                        maxLines = 1
                    )
                }
            }

            // 4. Top-Right Corner: Two-Horizontal-Line (=) More Button (No background or circle)
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 10.dp, end = 12.dp)
                    .size(36.dp)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        isMoreMenuOpen = true
                    }
                    .semantics { contentDescription = "More options" }
                    .testTag("more_btn_${video.id}"),
                contentAlignment = Alignment.Center
            ) {
                TwoHorizontalLinesIcon(
                    color = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }

            // 5. Multi-Slide Carousel Controls (when post has multiple slides)
            if (slides.size > 1) {
                if (activeSlideIndex > 0) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .padding(start = 8.dp)
                            .size(32.dp)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) {
                                activeSlideIndex = (activeSlideIndex - 1).coerceAtLeast(0)
                            }
                            .testTag("carousel_prev_${video.id}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                            contentDescription = "Previous slide",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                if (activeSlideIndex < slides.lastIndex) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .padding(end = 8.dp)
                            .size(32.dp)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) {
                                activeSlideIndex = (activeSlideIndex + 1).coerceAtMost(slides.lastIndex)
                            }
                            .testTag("carousel_next_${video.id}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Next slide",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                // Minimal slide dots at bottom center
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    slides.forEachIndexed { idx, _ ->
                        val isCurrent = idx == activeSlideIndex
                        Box(
                            modifier = Modifier
                                .size(
                                    width = if (isCurrent) 12.dp else 5.dp,
                                    height = 5.dp
                                )
                                .clip(RoundedCornerShape(999.dp))
                                .background(
                                    if (isCurrent) Color.White else Color.White.copy(alpha = 0.45f)
                                )
                                .clickable { activeSlideIndex = idx }
                        )
                    }
                }
            }

            // 6. Bottom-Left Corner: Frameless Mute / Unmute Button (No background or circle, shown for video posts)
            if (!video.isPhotoPost) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 12.dp, bottom = 8.dp)
                        .size(40.dp)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onToggleMute()
                        }
                        .testTag("mute_btn_${video.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isMuted) {
                            Icons.AutoMirrored.Filled.VolumeOff
                        } else {
                            Icons.AutoMirrored.Filled.VolumeUp
                        },
                        contentDescription = if (isMuted) "Unmute audio" else "Mute audio",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            // 7. Bottom-Right Corner: Frameless Share, Comment (cmt), and Like Buttons
            Row(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 14.dp, bottom = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Share Button (No background or circle)
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onShareClick(video)
                        }
                        .testTag("share_btn_${video.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Share,
                        contentDescription = "Share ${video.title}",
                        tint = Color.White,
                        modifier = Modifier.size(21.dp)
                    )
                }

                // Comment (cmt) Button + Count (No background or circle)
                Row(
                    modifier = Modifier
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            isCommentsSheetOpen = true
                        }
                        .padding(vertical = 4.dp)
                        .testTag("comment_btn_${video.id}"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.ChatBubbleOutline,
                        contentDescription = "Comments",
                        tint = Color.White,
                        modifier = Modifier.size(21.dp)
                    )
                    Text(
                        text = combinedComments.size.toString(),
                        style = NexoraTypography.BadgeMicro.copy(
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            shadow = Shadow(
                                color = Color(0x990F172A),
                                offset = Offset(0f, 1.5f),
                                blurRadius = 4f
                            )
                        )
                    )
                }

                // Like Heart Button (Frameless heart icon)
                Box(
                    modifier = Modifier
                        .graphicsLayer {
                            scaleX = likeScale
                            scaleY = likeScale
                        }
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onToggleLike(video.id)
                        }
                        .padding(vertical = 4.dp, horizontal = 2.dp)
                        .testTag("like_btn_${video.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (video.isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = if (video.isLiked) "Unlike" else "Like",
                        tint = if (video.isLiked) NexoraColors.LiveRose else Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            // 8. Double-Tap Refractive Heart Burst Overlay
            val currentBurst = burstCenter
            if (currentBurst != null && burstAlpha.value > 0.01f) {
                val halfSizePx = with(density) { 36.dp.toPx() }
                Box(
                    modifier = Modifier
                        .offset {
                            IntOffset(
                                (currentBurst.x - halfSizePx).roundToInt(),
                                (currentBurst.y - halfSizePx).roundToInt()
                            )
                        }
                        .size(72.dp)
                        .graphicsLayer {
                            scaleX = burstScale.value
                            scaleY = burstScale.value
                            alpha = burstAlpha.value
                        }
                        .drawBehind {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        NexoraColors.LiveRose.copy(alpha = 0.48f),
                                        NexoraColors.Lavender400.copy(alpha = 0.28f),
                                        Color.Transparent
                                    ),
                                    center = center,
                                    radius = size.maxDimension * 0.72f
                                ),
                                radius = size.maxDimension * 0.72f,
                                center = center
                            )
                        }
                        .liquidGlassElevatedCapsule(999.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Favorite,
                        contentDescription = null,
                        tint = NexoraColors.LiveRose,
                        modifier = Modifier.size(34.dp)
                    )
                }
            }
        }

        // 9. Instagram-Style Post Details Below Media: Single Unified Likes, Views, Caption & Uploaded Time
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Single Total Likes & Views Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "$fullLikesText likes",
                    style = NexoraTypography.CreatorSubtitle.copy(
                        color = NexoraColors.InkPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.5.sp
                    ),
                    modifier = Modifier.testTag("likes_count_${video.id}")
                )
                Text(
                    text = "• ${video.viewsText}",
                    style = NexoraTypography.MetaCaption.copy(
                        color = NexoraColors.InkSecondary,
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.5.sp
                    ),
                    modifier = Modifier.testTag("views_count_${video.id}")
                )
            }

            // Caption (@handle + Title + Expandable Description & Hashtags)
            val hasMoreContent = remember(video) {
                video.description.isNotBlank() || video.hashtags.isNotEmpty() || video.title.length > 40
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        if (hasMoreContent) {
                            isCaptionExpanded = !isCaptionExpanded
                        }
                    }
                    .testTag("caption_area_${video.id}"),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                val annotatedCaption = remember(video) {
                    buildAnnotatedString {
                        withStyle(
                            SpanStyle(
                                color = NexoraColors.InkPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.5.sp
                            )
                        ) {
                            append(video.creatorHandle.removePrefix("@"))
                            append("  ")
                        }
                        withStyle(
                            SpanStyle(
                                color = NexoraColors.InkPrimary,
                                fontWeight = FontWeight.Normal,
                                fontSize = 13.5.sp
                            )
                        ) {
                            append(video.title)
                        }
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = annotatedCaption,
                        style = NexoraTypography.CreatorSubtitle.copy(
                            fontSize = 13.5.sp
                        ),
                        maxLines = if (isCaptionExpanded) 6 else 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (!isCaptionExpanded && hasMoreContent) {
                        Text(
                            text = " ... more",
                            style = NexoraTypography.MetaCaption.copy(
                                color = NexoraColors.InkSecondary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.5.sp
                            ),
                            modifier = Modifier.clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) {
                                isCaptionExpanded = true
                            }
                        )
                    }
                }

                AnimatedVisibility(visible = isCaptionExpanded) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (video.description.isNotBlank()) {
                            Text(
                                text = video.description,
                                style = NexoraTypography.CreatorSubtitle.copy(
                                    color = NexoraColors.InkSecondary,
                                    fontSize = 13.sp
                                )
                            )
                        }
                        if (video.hashtags.isNotEmpty()) {
                            Text(
                                text = video.hashtags.joinToString(" "),
                                style = NexoraTypography.MetaCaption.copy(
                                    color = NexoraColors.InkAccent,
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 12.5.sp
                                )
                            )
                        }
                        Text(
                            text = "less",
                            style = NexoraTypography.MetaCaption.copy(
                                color = NexoraColors.InkSecondary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp
                            ),
                            modifier = Modifier
                                .padding(top = 2.dp)
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null
                                ) {
                                    isCaptionExpanded = false
                                }
                        )
                    }
                }
            }

            // View Comments (hidden if 0 comments)
            if (combinedComments.isNotEmpty()) {
                Text(
                    text = if (combinedComments.size == 1) "View 1 comment" else "View all ${combinedComments.size} comments",
                    style = NexoraTypography.MetaCaption.copy(
                        color = NexoraColors.InkSecondary,
                        fontSize = 12.5.sp
                    ),
                    modifier = Modifier.clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        isCommentsSheetOpen = true
                    }
                )
            }

            // Single, Clean Uploaded Time (Subtle Instagram style timestamp)
            Text(
                text = video.relativeTime,
                style = NexoraTypography.MetaCaption.copy(
                    color = NexoraColors.InkSecondary.copy(alpha = 0.75f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Normal
                ),
                modifier = Modifier
                    .padding(top = 1.dp)
                    .testTag("uploaded_time_${video.id}")
            )
        }
    }

    // 10. Two-Horizontal-Line (=) More Options Modal (Music Info, Save, Interested, Report)
    if (isMoreMenuOpen) {
        PostMoreOptionsDialog(
            video = video,
            isSaved = isSaved,
            interestedState = isInterested,
            isReported = isReported,
            onDismiss = { isMoreMenuOpen = false },
            onToggleSave = {
                onToggleSave(video.id)
                onActionFeedback(if (isSaved) "Removed from Saved" else "Saved to Library")
            },
            onSelectInterested = { interested ->
                isInterested = interested
                val feedbackMsg = if (interested) {
                    "Interested · Showing more posts like this"
                } else {
                    "Not Interested · Tuning your feed"
                }
                onActionFeedback(feedbackMsg)
                isMoreMenuOpen = false
            },
            onSubmitReport = { reason ->
                isReported = true
                onActionFeedback("Reported post ($reason)")
                isMoreMenuOpen = false
            }
        )
    }

    // 11. Post Comments Dialog / Sheet (triggered by cmt icon)
    if (isCommentsSheetOpen) {
        PostCommentsDialog(
            video = video,
            comments = combinedComments,
            onDismiss = { isCommentsSheetOpen = false },
            onSubmitComment = { text ->
                val trimmed = text.trim()
                if (trimmed.isNotEmpty()) {
                    localAddedComments.add(
                        0,
                        VideoComment(
                            id = "c_local_${System.currentTimeMillis()}",
                            authorName = "Aether Visuals",
                            authorHandle = "@aethervisuals",
                            avatarSeed = 1,
                            text = trimmed,
                            timestamp = "Just now",
                            likes = 0,
                            isLiked = false
                        )
                    )
                    onAddComment(video.id, trimmed)
                }
            },
            onToggleCommentLike = { commentId ->
                onToggleCommentLike(video.id, commentId)
            }
        )
    }
}

private fun formatCompactLikesCount(count: Int): String {
    return when {
        count >= 1_000_000 -> String.format("%.1fM", count / 1_000_000f)
        count >= 1_000 -> String.format("%.1fK", count / 1_000f)
        else -> count.toString()
    }
}

private fun formatFullLikesCount(count: Int): String {
    return String.format("%,d", count)
}

/**
 * Custom frameless icon drawing two crisp horizontal lines (`=`) for the top-right More menu button.
 */
@Composable
private fun TwoHorizontalLinesIcon(
    color: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val strokeWidthPx = 2.2.dp.toPx()
        val horizontalInset = size.width * 0.14f
        val topLineY = size.height * 0.36f
        val bottomLineY = size.height * 0.64f

        // Subtle drop shadow for contrast over bright video regions
        val shadowColor = Color(0x660F172A)
        val shadowOffset = 1.dp.toPx()
        drawLine(
            color = shadowColor,
            start = Offset(horizontalInset, topLineY + shadowOffset),
            end = Offset(size.width - horizontalInset, topLineY + shadowOffset),
            strokeWidth = strokeWidthPx,
            cap = StrokeCap.Round
        )
        drawLine(
            color = shadowColor,
            start = Offset(horizontalInset, bottomLineY + shadowOffset),
            end = Offset(size.width - horizontalInset, bottomLineY + shadowOffset),
            strokeWidth = strokeWidthPx,
            cap = StrokeCap.Round
        )

        // Crisp white two horizontal lines
        drawLine(
            color = color,
            start = Offset(horizontalInset, topLineY),
            end = Offset(size.width - horizontalInset, topLineY),
            strokeWidth = strokeWidthPx,
            cap = StrokeCap.Round
        )
        drawLine(
            color = color,
            start = Offset(horizontalInset, bottomLineY),
            end = Offset(size.width - horizontalInset, bottomLineY),
            strokeWidth = strokeWidthPx,
            cap = StrokeCap.Round
        )
    }
}

@Composable
private fun PostMoreOptionsDialog(
    video: VideoItem,
    isSaved: Boolean,
    interestedState: Boolean?,
    isReported: Boolean,
    onDismiss: () -> Unit,
    onToggleSave: () -> Unit,
    onSelectInterested: (Boolean) -> Unit,
    onSubmitReport: (String) -> Unit
) {
    var showMusicDetails by remember { mutableStateOf(false) }
    var showReportReasons by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0x660F172A))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                )
                .padding(horizontal = 20.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {}
                    )
                    .liquidGlassCard(cornerRadius = 28.dp)
                    .padding(18.dp)
                    .testTag("more_options_sheet_${video.id}"),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CreatorAvatarBadge(
                            name = video.creatorName,
                            seed = video.creatorAvatarSeed,
                            size = 28.dp
                        )
                        Text(
                            text = video.creatorHandle,
                            style = NexoraTypography.CardTitle.copy(fontSize = 14.sp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .liquidGlassWhitePill(999.dp)
                            .clickable { onDismiss() }
                            .testTag("more_options_close_${video.id}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Close options",
                            tint = NexoraColors.InkSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // 1. Music Info Option
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(NexoraColors.Pearl200)
                        .clickable { showMusicDetails = !showMusicDetails }
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                        .testTag("more_option_music_${video.id}"),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.MusicNote,
                                contentDescription = "Music Info",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = "Music Info",
                                    style = NexoraTypography.CardTitle.copy(fontSize = 14.sp)
                                )
                                Text(
                                    text = video.musicTrack,
                                    style = NexoraTypography.MetaCaption,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Icon(
                            imageVector = Icons.Filled.GraphicEq,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    AnimatedVisibility(visible = showMusicDetails) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(NexoraColors.Pearl300)
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "Track: ${video.musicTrack}",
                                style = NexoraTypography.CreatorSubtitle.copy(
                                    color = NexoraColors.InkPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                            Text(
                                text = "Codec: 24-bit / 48kHz Spatial Ambisonic Master · ${video.creatorName}",
                                style = NexoraTypography.MetaCaption
                            )
                        }
                    }
                }

                // 2. Save Option
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(if (isSaved) NexoraColors.Pearl300 else NexoraColors.Pearl200)
                        .clickable { onToggleSave() }
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                        .testTag("more_option_save_${video.id}"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = if (isSaved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                            contentDescription = "Save",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = if (isSaved) "Saved in Library" else "Save",
                                style = NexoraTypography.CardTitle.copy(fontSize = 14.sp)
                            )
                            Text(
                                text = if (isSaved) "Tap to remove from Saved Videos" else "Bookmark this post to your Library",
                                style = NexoraTypography.MetaCaption
                            )
                        }
                    }

                    if (isSaved) {
                        Icon(
                            imageVector = Icons.Filled.CheckCircle,
                            contentDescription = "Saved",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // 3. Interested Option
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(NexoraColors.Pearl200)
                        .clickable { onSelectInterested(true) }
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                        .testTag("more_option_interested_${video.id}"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = if (interestedState == true) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
                            contentDescription = "Interested",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = "Interested",
                                style = NexoraTypography.CardTitle.copy(fontSize = 14.sp)
                            )
                            Text(
                                text = "Recommend more posts from ${video.creatorHandle} & ${video.category}",
                                style = NexoraTypography.MetaCaption,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(NexoraColors.Pearl300)
                            .clickable { onSelectInterested(false) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("more_option_not_interested_${video.id}")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.ThumbDown,
                                contentDescription = "Not Interested",
                                tint = NexoraColors.InkSecondary,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "Less",
                                style = NexoraTypography.BadgeMicro.copy(color = NexoraColors.InkSecondary)
                            )
                        }
                    }
                }

                // 4. Report Option
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(NexoraColors.Pearl200)
                        .clickable { showReportReasons = !showReportReasons }
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                        .testTag("more_option_report_${video.id}"),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Flag,
                            contentDescription = "Report",
                            tint = NexoraColors.LiveRose,
                            modifier = Modifier.size(20.dp)
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = if (isReported) "Report Submitted" else "Report",
                                style = NexoraTypography.CardTitle.copy(
                                    fontSize = 14.sp,
                                    color = NexoraColors.LiveRose
                                )
                            )
                            Text(
                                text = "Flag copyright, audio metadata, or community issues",
                                style = NexoraTypography.MetaCaption
                            )
                        }
                    }

                    AnimatedVisibility(visible = showReportReasons) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(
                                "Spam or misleading metadata",
                                "Audio or visual copyright claim",
                                "Inappropriate or harmful content"
                            ).forEach { reason ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color(0x18F43F5E))
                                        .clickable { onSubmitReport(reason) }
                                        .padding(horizontal = 12.dp, vertical = 8.dp)
                                ) {
                                    Text(
                                        text = reason,
                                        style = NexoraTypography.CreatorSubtitle.copy(
                                            color = NexoraColors.LiveRose,
                                            fontWeight = FontWeight.Medium
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PostCommentsDialog(
    video: VideoItem,
    comments: List<VideoComment>,
    onDismiss: () -> Unit,
    onSubmitComment: (String) -> Unit,
    onToggleCommentLike: (String) -> Unit
) {
    var commentDraft by remember { mutableStateOf("") }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0x660F172A))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                )
                .padding(horizontal = 16.dp, vertical = 32.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {}
                    )
                    .liquidGlassCard(cornerRadius = 28.dp)
                    .padding(18.dp)
                    .testTag("comments_sheet_${video.id}"),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Comments (${comments.size})",
                        style = NexoraTypography.CardTitle.copy(fontSize = 15.sp)
                    )

                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .liquidGlassWhitePill(999.dp)
                            .clickable { onDismiss() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Close comments",
                            tint = NexoraColors.InkSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 120.dp, max = 300.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(comments, key = { it.id }) { comment ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(NexoraColors.Pearl200)
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            CreatorAvatarBadge(
                                name = comment.authorName,
                                seed = comment.avatarSeed,
                                size = 28.dp
                            )
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = comment.authorHandle,
                                        style = NexoraTypography.CreatorSubtitle.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = NexoraColors.InkPrimary
                                        )
                                    )
                                    Text(
                                        text = comment.timestamp,
                                        style = NexoraTypography.MetaCaption
                                    )
                                }
                                Text(
                                    text = comment.text,
                                    style = NexoraTypography.CreatorSubtitle.copy(
                                        color = NexoraColors.InkPrimary
                                    )
                                )
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp),
                                modifier = Modifier
                                    .clickable { onToggleCommentLike(comment.id) }
                                    .padding(4.dp)
                            ) {
                                Icon(
                                    imageVector = if (comment.isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                                    contentDescription = "Like comment",
                                    tint = if (comment.isLiked) NexoraColors.LiveRose else NexoraColors.InkSecondary,
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = comment.likes.toString(),
                                    style = NexoraTypography.MetaCaption
                                )
                            }
                        }
                    }
                }

                // Comment Input Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(999.dp))
                        .background(NexoraColors.Pearl300)
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier.weight(1f),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        if (commentDraft.isEmpty()) {
                            Text(
                                text = "Add a comment for ${video.creatorHandle}...",
                                style = NexoraTypography.MetaCaption
                            )
                        }
                        BasicTextField(
                            value = commentDraft,
                            onValueChange = { commentDraft = it },
                            singleLine = true,
                            textStyle = NexoraTypography.CreatorSubtitle.copy(
                                color = NexoraColors.InkPrimary
                            ),
                            cursorBrush = SolidColor(NexoraColors.InkAccent),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("comment_input_${video.id}")
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .liquidGlassAccent(999.dp)
                            .clickable {
                                if (commentDraft.isNotBlank()) {
                                    onSubmitComment(commentDraft)
                                    commentDraft = ""
                                }
                            }
                            .testTag("comment_send_${video.id}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Post comment",
                            tint = NexoraColors.InkAccent,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Vertical 9:16 Shorts / Spatial Clips Card used inside SpatialClipsRail.
 */
@Composable
fun NexoraShortsCard(
    video: VideoItem,
    isSaved: Boolean,
    onVideoClick: (VideoItem) -> Unit,
    onCreatorClick: (String) -> Unit,
    onToggleSave: (String) -> Unit,
    onShareClick: (VideoItem) -> Unit,
    modifier: Modifier = Modifier,
    onToggleLike: (String) -> Unit = {}
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(9f / 16f)
            .clip(RoundedCornerShape(22.dp))
            .border(
                width = 1.dp,
                color = Color.White.copy(alpha = 0.34f),
                shape = RoundedCornerShape(22.dp)
            )
            .clickable { onVideoClick(video) }
            .testTag("shorts_card_${video.id}")
    ) {
        val context = LocalContext.current
        val shortThumbUrl = video.effectiveThumbnailUrl
        if (!shortThumbUrl.isNullOrBlank()) {
            val imageRequest = remember(context, shortThumbUrl) {
                ImageRequest.Builder(context)
                    .data(shortThumbUrl)
                    .crossfade(180)
                    .memoryCachePolicy(CachePolicy.ENABLED)
                    .diskCachePolicy(CachePolicy.ENABLED)
                    .build()
            }
            Box(modifier = Modifier.fillMaxSize()) {
                SpatialVisualCanvas(
                    preset = video.visualPreset,
                    isAnimated = false,
                    playbackPhase = video.previewProgress
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xCC000000))
                )
            }

            SubcomposeAsyncImage(
                model = imageRequest,
                contentDescription = video.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
                loading = {
                    InstagramDarkShimmerBox(modifier = Modifier.fillMaxSize())
                },
                error = {
                    SpatialVisualCanvas(
                        preset = video.visualPreset,
                        isAnimated = false,
                        playbackPhase = video.previewProgress
                    )
                }
            )
        } else {
            SpatialVisualCanvas(
                preset = video.visualPreset,
                isAnimated = false,
                playbackPhase = video.previewProgress
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        0.0f to Color(0x440F172A),
                        0.45f to Color.Transparent,
                        1.0f to Color(0xCC0F172A)
                    )
                )
        )

        // Top-right duration badge
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp)
                .liquidGlassDarkOverlay(999.dp)
                .padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
            Text(
                text = video.duration,
                style = NexoraTypography.BadgeMicro.copy(
                    color = Color.White,
                    fontSize = 9.5.sp,
                    fontWeight = FontWeight.SemiBold
                )
            )
        }

        // Bottom user profile photo, @handle • relative_time & views in Spatial Clips
        Row(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 10.dp)
                .testTag("spatial_clip_creator_info_${video.id}"),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CreatorAvatarBadge(
                name = video.creatorName,
                seed = video.creatorAvatarSeed,
                size = 28.dp,
                borderWidth = 1.4.dp,
                avatarUrl = video.effectiveCreatorAvatarUrl
            )
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(1.dp)
            ) {
                Text(
                    text = "${video.formattedCreatorHandle} • ${video.relativeTime}",
                    style = NexoraTypography.CreatorSubtitle.copy(
                        color = Color.White,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        shadow = Shadow(
                            color = Color(0xCC090D16),
                            offset = Offset(0f, 1.5f),
                            blurRadius = 6f
                        )
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = video.formattedViews,
                    style = NexoraTypography.BadgeMicro.copy(
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        shadow = Shadow(
                            color = Color(0xCC090D16),
                            offset = Offset(0f, 1.5f),
                            blurRadius = 6f
                        )
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

