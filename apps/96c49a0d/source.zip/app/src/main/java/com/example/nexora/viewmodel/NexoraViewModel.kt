package com.example.nexora.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.nexora.animation.ClickOrigin
import com.example.nexora.data.ChatMessage
import com.example.nexora.data.CreatorProfile
import com.example.nexora.data.CuratedCollection
import com.example.nexora.data.DirectChatMessage
import com.example.nexora.data.DirectMessageEntity
import com.example.nexora.data.DirectMessageThread
import com.example.nexora.data.ExploreSortMode
import com.example.nexora.data.FlaggedContentItem
import com.example.nexora.data.LibrarySubTab
import com.example.nexora.data.NavTab
import com.example.nexora.data.NexoraDatabase
import com.example.nexora.data.NexoraRepository
import com.example.nexora.data.NexoraSeedData
import com.example.nexora.data.NotificationItem
import com.example.nexora.data.Playlist
import com.example.nexora.data.ProfileSubTab
import com.example.nexora.data.SpatialPulseSlide
import com.example.nexora.data.SpatialPulseStory
import com.example.nexora.data.UploadedVideoEntity
import com.example.nexora.data.VideoComment
import com.example.nexora.data.VideoItem
import com.example.nexora.data.VisualThemePreset
import com.example.nexora.data.formatCatalogDuration
import com.example.nexora.network.AkashCatalogItem
import com.example.nexora.network.AkashMediaService
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

data class FloatingReactionParticle(
    val id: Long,
    val emoji: String,
    val horizontalFraction: Float
)

data class NexoraUiState(
    val activeTab: NavTab = NavTab.HOME,
    val previousTab: NavTab = NavTab.HOME,
    val navTabOrder: List<NavTab> = listOf(NavTab.HOME, NavTab.EXPLORE, NavTab.LIVE, NavTab.LIBRARY, NavTab.PROFILE),
    val isAuthenticated: Boolean = false,
    val authUserUid: String? = null,
    val authUserEmail: String? = null,
    val authIdToken: String? = null,
    val savedReelsFromVault: List<VideoItem> = emptyList(),
    val isSavedReelsLoading: Boolean = false,
    val selectedCategory: String = "For You",
    val searchQuery: String = "",
    val selectedHashtag: String? = null,
    val exploreSortMode: ExploreSortMode = ExploreSortMode.TRENDING,
    val liveCategoryFilter: String = "All Live",
    val librarySubTab: LibrarySubTab = LibrarySubTab.SAVED_VIDEOS,
    val profileSubTab: ProfileSubTab = ProfileSubTab.OVERVIEW,
    val profileVideosFilter: String = "Latest",
    val lastClickOrigin: ClickOrigin = ClickOrigin(),
    val stageTransitionOrigin: ClickOrigin = ClickOrigin(),
    val modalTransitionOrigin: ClickOrigin = ClickOrigin(),
    val videos: List<VideoItem> = NexoraSeedData.initialVideos,
    val shortVideos: List<VideoItem> = emptyList(),
    val isShortsLoading: Boolean = false,
    val shortsError: String? = null,
    val isCatalogLoading: Boolean = false,
    val catalogError: String? = null,
    val creators: List<CreatorProfile> = NexoraSeedData.creators,
    val collections: List<CuratedCollection> = NexoraSeedData.curatedCollections,
    val activeLiveStream: VideoItem = NexoraSeedData.initialVideos.first { it.isLiveStream },
    val activeCreator: CreatorProfile = NexoraSeedData.creators.first(),
    val ownStudioProfile: CreatorProfile = NexoraSeedData.creators.first(),
    val savedVideoIds: Set<String> = setOf("vid_nordic_glass", "vid_liquid_glass_math"),
    val watchHistoryProgress: Map<String, Float> = mapOf(
        "vid_nordic_glass" to 0.35f,
        "vid_orbital_dyson" to 0.62f,
        "vid_liquid_glass_math" to 0.78f
    ),
    val subscribedCreatorIds: Set<String> = setOf("creator_aether", "creator_kurogane", "creator_lumina"),
    val playlists: List<Playlist> = NexoraSeedData.initialPlaylists,
    val notifications: List<NotificationItem> = NexoraSeedData.initialNotifications,
    val liveChatMessages: List<ChatMessage> = NexoraSeedData.initialLiveChat,
    val liveUptimeSeconds: Int = 8048,
    val floatingReactions: List<FloatingReactionParticle> = emptyList(),
    val moderationQueue: List<FlaggedContentItem> = NexoraSeedData.initialModerationQueue,
    val spatialPulses: List<SpatialPulseStory> = NexoraSeedData.initialSpatialPulses,
    val activePulseStory: SpatialPulseStory? = null,
    val activeClipId: String? = null,
    val directThreads: List<DirectMessageThread> = NexoraSeedData.initialDirectThreads,
    val activeDmCreatorId: String = "creator_kurogane",
    val isChatConversationOpen: Boolean = false,
    val isNotificationsOpen: Boolean = false,
    val isDmModalOpen: Boolean = false,
    val isUploadModalOpen: Boolean = false,
    val isAdminModalOpen: Boolean = false,
    val isPlaylistModalOpen: Boolean = false,
    val isEditProfileModalOpen: Boolean = false,
    val isAccountCentreModalOpen: Boolean = false,
    val isRefreshing: Boolean = false,
    val tabRefreshTrigger: Long = 0L,
    val isGlobalAudioMuted: Boolean = false,
    val isGuestMode: Boolean = false,
    val toastMessage: String? = null
)

class NexoraViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: NexoraRepository =
        NexoraRepository(NexoraDatabase.getInstance(application).nexoraDao())

    private val _uiState = MutableStateFlow(NexoraUiState())
    val uiState: StateFlow<NexoraUiState> = _uiState.asStateFlow()

    init {
        seedInitialDatabaseIfNeeded()
        observePersistentData()
        restoreExistingFirebaseSession()
        fetchShortsFeed()
        startLiveBroadcastTicker()
    }

    private suspend fun resolveCurrentIdToken(): String? {
        val currentUser = runCatching { Firebase.auth.currentUser }.getOrNull()
        if (currentUser != null) {
            val freshToken = runCatching { currentUser.getIdToken(false).await()?.token }.getOrNull()
            if (!freshToken.isNullOrBlank()) {
                _uiState.update { it.copy(authIdToken = freshToken) }
                return freshToken
            }
        }
        return _uiState.value.authIdToken
    }

    private fun restoreExistingFirebaseSession() {
        viewModelScope.launch {
            val user = runCatching { Firebase.auth.currentUser }.getOrNull() ?: return@launch
            val token = runCatching { user.getIdToken(false).await()?.token }.getOrNull()
            val email = user.email.orEmpty()
            val cleanName = AkashMediaService.cleanEmojis(user.displayName ?: "Akash Creator").ifBlank { "Akash Creator" }
            val derivedHandle = AkashMediaService.cleanEmojis(
                email.substringBefore("@").ifBlank { cleanName.lowercase().replace(" ", "_") }
            )
            onFirebaseUserAuthenticated(
                uid = user.uid,
                displayName = cleanName,
                email = email,
                handle = "@$derivedHandle",
                avatarUrl = user.photoUrl?.toString(),
                idToken = token
            )
        }
    }

    fun onFirebaseUserAuthenticated(
        uid: String,
        displayName: String,
        email: String,
        handle: String,
        avatarUrl: String?,
        idToken: String?
    ) {
        val cleanName = AkashMediaService.cleanEmojis(displayName).ifBlank { "Akash Creator" }
        val rawHandle = AkashMediaService.cleanEmojis(handle.ifBlank { email.substringBefore("@") }).removePrefix("@").ifBlank { "creator" }
        val normalizedHandle = "@$rawHandle"

        _uiState.update { state ->
            val updatedOwn = state.ownStudioProfile.copy(
                name = cleanName,
                handle = normalizedHandle,
                avatarUrl = avatarUrl ?: state.ownStudioProfile.avatarUrl
            )
            val updatedCreators = state.creators.map {
                if (it.id == "creator_aether") updatedOwn else it
            }
            val updatedActive = if (state.activeCreator.id == "creator_aether") updatedOwn else state.activeCreator
            state.copy(
                isAuthenticated = true,
                isGuestMode = false,
                authUserUid = uid,
                authUserEmail = email,
                authIdToken = idToken,
                ownStudioProfile = updatedOwn,
                creators = updatedCreators,
                activeCreator = updatedActive,
                toastMessage = "Authenticated as $normalizedHandle"
            )
        }

        viewModelScope.launch {
            val token = idToken ?: resolveCurrentIdToken()
            if (!token.isNullOrBlank()) {
                val syncResult = AkashMediaService.syncUserProfile(
                    firebaseIdToken = token,
                    displayName = cleanName,
                    email = email,
                    avatarUrl = avatarUrl
                )
                syncResult.onSuccess { synced ->
                    if (!synced.handle.isNullOrBlank()) {
                        val assignedHandle = if (synced.handle.startsWith("@")) synced.handle else "@${synced.handle}"
                        _uiState.update { state ->
                            val updatedOwn = state.ownStudioProfile.copy(
                                handle = assignedHandle,
                                name = synced.displayName ?: state.ownStudioProfile.name,
                                avatarUrl = synced.avatarUrl ?: state.ownStudioProfile.avatarUrl
                            )
                            val updatedCreators = state.creators.map {
                                if (it.id == "creator_aether") updatedOwn else it
                            }
                            val updatedActive = if (state.activeCreator.id == "creator_aether") updatedOwn else state.activeCreator
                            state.copy(
                                ownStudioProfile = updatedOwn,
                                creators = updatedCreators,
                                activeCreator = updatedActive,
                                toastMessage = "Universal identity synced: $assignedHandle"
                            )
                        }
                    }
                }
            }
            fetchShortsFeed()
            fetchSavedReelsFromVault()
        }
    }

    fun enableGuestMode() {
        _uiState.update {
            it.copy(
                isGuestMode = true,
                toastMessage = "Exploring Akash Shorts in Guest Mode"
            )
        }
    }

    fun signInWithEmailAndPassword(
        email: String,
        pass: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            runCatching {
                val result = Firebase.auth.signInWithEmailAndPassword(email, pass).await()
                val user = result.user
                if (user != null) {
                    val token = runCatching { user.getIdToken(false).await()?.token }.getOrNull()
                    val cleanName = AkashMediaService.cleanEmojis(user.displayName ?: email.substringBefore("@")).ifBlank { "Akash Creator" }
                    val handle = "@" + email.substringBefore("@")
                    onFirebaseUserAuthenticated(
                        uid = user.uid,
                        displayName = cleanName,
                        email = user.email ?: email,
                        handle = handle,
                        avatarUrl = user.photoUrl?.toString(),
                        idToken = token
                    )
                    onSuccess()
                } else {
                    onError("Sign in failed.")
                }
            }.onFailure { exc ->
                onError(exc.localizedMessage ?: "Failed to sign in.")
            }
        }
    }

    fun registerWithEmailAndPassword(
        email: String,
        pass: String,
        displayName: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            runCatching {
                val cleanUsernameBase = AkashMediaService.cleanEmojis(displayName)
                    .trim()
                    .removePrefix("@")
                    .lowercase()
                    .replace(" ", "_")
                    .ifBlank { email.substringBefore("@").lowercase() }
                val cleanDisplayName = AkashMediaService.cleanEmojis(displayName)
                    .trim()
                    .removePrefix("@")
                    .ifBlank { cleanUsernameBase }
                val handle = "@$cleanUsernameBase"

                val result = Firebase.auth.createUserWithEmailAndPassword(email, pass).await()
                val user = result.user
                if (user != null) {
                    val profileUpdates = com.google.firebase.auth.UserProfileChangeRequest.Builder()
                        .setDisplayName(cleanDisplayName)
                        .build()
                    runCatching { user.updateProfile(profileUpdates).await() }
                    runCatching { user.sendEmailVerification().await() }
                    val token = runCatching { user.getIdToken(false).await()?.token }.getOrNull()
                    onFirebaseUserAuthenticated(
                        uid = user.uid,
                        displayName = cleanDisplayName,
                        email = user.email ?: email,
                        handle = handle,
                        avatarUrl = null,
                        idToken = token
                    )
                    onSuccess()
                } else {
                    onError("Registration failed.")
                }
            }.onFailure { exc ->
                val rawMsg = exc.localizedMessage ?: "Failed to create account."
                val friendlyMsg = when {
                    rawMsg.contains("The email address is already in use", ignoreCase = true) ||
                    rawMsg.contains("EMAIL_EXISTS", ignoreCase = true) ->
                        "This email address is already registered. Please sign in instead."
                    rawMsg.contains("badly formatted", ignoreCase = true) ||
                    rawMsg.contains("INVALID_EMAIL", ignoreCase = true) ->
                        "Please enter a valid email address."
                    rawMsg.contains("Password should be at least", ignoreCase = true) ||
                    rawMsg.contains("WEAK_PASSWORD", ignoreCase = true) ->
                        "Password must be at least 6 characters."
                    else -> rawMsg
                }
                onError(friendlyMsg)
            }
        }
    }

    fun signOutFirebase() {
        runCatching { Firebase.auth.signOut() }
        _uiState.update { state ->
            state.copy(
                isAuthenticated = false,
                isGuestMode = false,
                authUserUid = null,
                authUserEmail = null,
                authIdToken = null,
                activeClipId = null,
                toastMessage = "Signed out of Sovereign Vault"
            )
        }
    }

    fun toggleGlobalAudioMuted() {
        val nextMuted = !_uiState.value.isGlobalAudioMuted
        _uiState.update {
            it.copy(
                isGlobalAudioMuted = nextMuted,
                toastMessage = if (nextMuted) "Audio muted" else "Audio unmuted"
            )
        }
    }

    fun setGlobalAudioMuted(muted: Boolean) {
        if (_uiState.value.isGlobalAudioMuted != muted) {
            _uiState.update {
                it.copy(
                    isGlobalAudioMuted = muted,
                    toastMessage = if (muted) "Audio muted" else "Audio unmuted"
                )
            }
        }
    }

    fun unmuteGlobalAudio() {
        if (_uiState.value.isGlobalAudioMuted) {
            _uiState.update {
                it.copy(
                    isGlobalAudioMuted = false,
                    toastMessage = "Audio unmuted"
                )
            }
        }
    }

    fun fetchSavedReelsFromVault() {
        viewModelScope.launch {
            _uiState.update { it.copy(isSavedReelsLoading = true) }
            val token = resolveCurrentIdToken()
            val result = AkashMediaService.fetchSavedReels(token)
            result.fold(
                onSuccess = { savedResult ->
                    val presets = VisualThemePreset.entries
                    val creatorsList = NexoraSeedData.creators
                    val mappedSaved = savedResult.items.mapIndexed { idx, item ->
                        mapAkashCatalogItemToVideoItem(item, idx, presets, creatorsList)
                    }
                    _uiState.update { state ->
                        val nextSavedIds = state.savedVideoIds + savedResult.fileCodes + mappedSaved.map { it.id }
                        state.copy(
                            savedReelsFromVault = mappedSaved,
                            savedVideoIds = nextSavedIds,
                            isSavedReelsLoading = false
                        )
                    }
                },
                onFailure = {
                    _uiState.update { it.copy(isSavedReelsLoading = false) }
                }
            )
        }
    }

    fun checkReelInteractionStatus(videoId: String) {
        viewModelScope.launch {
            val clip = _uiState.value.shortVideos.find { it.id == videoId }
                ?: _uiState.value.videos.find { it.id == videoId }
                ?: return@launch
            val fileCode = clip.effectiveFileCode
            if (fileCode.isBlank()) return@launch
            val token = resolveCurrentIdToken()
            val statusResult = AkashMediaService.fetchVideoInteractionStatus(token, fileCode)
            statusResult.onSuccess { status ->
                _uiState.update { state ->
                    val updatedShorts = state.shortVideos.map { v ->
                        if (v.id == videoId || v.effectiveFileCode == status.fileCode) {
                            v.copy(
                                isLiked = status.isLiked,
                                likesCount = if (status.totalLikes >= 0) status.totalLikes else v.likesCount
                            )
                        } else v
                    }
                    val updatedVideos = state.videos.map { v ->
                        if (v.id == videoId || v.effectiveFileCode == status.fileCode) {
                            v.copy(
                                isLiked = status.isLiked,
                                likesCount = if (status.totalLikes >= 0) status.totalLikes else v.likesCount
                            )
                        } else v
                    }
                    val nextSaved = if (status.isSaved) {
                        state.savedVideoIds + videoId + status.fileCode
                    } else {
                        state.savedVideoIds
                    }
                    state.copy(
                        shortVideos = updatedShorts,
                        videos = updatedVideos,
                        savedVideoIds = nextSaved
                    )
                }
            }
            loadVideoComments(videoId)
        }
    }

    fun loadVideoComments(videoId: String) {
        viewModelScope.launch {
            val clip = _uiState.value.shortVideos.find { it.id == videoId }
                ?: _uiState.value.videos.find { it.id == videoId }
                ?: return@launch
            val fileCode = clip.effectiveFileCode
            if (fileCode.isBlank()) return@launch
            val token = resolveCurrentIdToken()
            val result = AkashMediaService.fetchComments(fileCode, token)
            result.onSuccess { commentItems ->
                if (commentItems.isNotEmpty()) {
                    val ownHandle = _uiState.value.ownStudioProfile.handle.lowercase()
                    val ownName = _uiState.value.ownStudioProfile.name.lowercase()
                    val mappedComments = commentItems.map { item ->
                        val isOwn = item.authorHandle.lowercase() == ownHandle || item.authorName.lowercase() == ownName
                        VideoComment(
                            id = item.id,
                            authorName = item.authorName,
                            authorHandle = item.authorHandle,
                            avatarSeed = item.authorHandle.hashCode().let { if (it < 0) -it else it } % 6 + 1,
                            text = item.commentText,
                            timestamp = item.createdAt,
                            likes = item.likes,
                            isLiked = item.isLiked,
                            avatarUrl = item.avatarUrl,
                            isDeletable = isOwn
                        )
                    }
                    _uiState.update { state ->
                        val updatedShorts = state.shortVideos.map { v ->
                            if (v.id == videoId || v.effectiveFileCode == fileCode) {
                                v.copy(comments = mappedComments)
                            } else v
                        }
                        val updatedVideos = state.videos.map { v ->
                            if (v.id == videoId || v.effectiveFileCode == fileCode) {
                                v.copy(comments = mappedComments)
                            } else v
                        }
                        state.copy(shortVideos = updatedShorts, videos = updatedVideos)
                    }
                }
            }
        }
    }

    fun fetchShortsFeed(forceRefresh: Boolean = false) {
        viewModelScope.launch {
            _uiState.update { it.copy(isShortsLoading = true, shortsError = null) }
            val token = resolveCurrentIdToken()
            val result = AkashMediaService.fetchShortsFeed(token, forceRefresh = forceRefresh)
            result.fold(
                onSuccess = { shortItems ->
                    val presets = VisualThemePreset.entries
                    val creatorsList = NexoraSeedData.creators
                    val mappedShorts = shortItems
                        .filter { it.mediaType == "short" && (it.duration <= 0.0 || it.duration <= 120.0) }
                        .mapIndexed { idx, item ->
                            mapAkashCatalogItemToVideoItem(item, idx, presets, creatorsList)
                        }
                    _uiState.update { state ->
                        val existingLikedIds = state.shortVideos.filter { it.isLiked }.map { it.id }.toSet() +
                            state.videos.filter { it.isLiked }.map { it.id }.toSet()
                        val hydratedShorts = mappedShorts.map { item ->
                            if (item.id in existingLikedIds) item.copy(isLiked = true) else item
                        }
                        val liveItems = state.videos.filter { it.isLiveStream }
                        val catalogIds = hydratedShorts.map { it.id }.toSet()
                        val customUploaded = state.videos.filter {
                            !it.isLiveStream && it.id.startsWith("vid_custom_") && it.id !in catalogIds
                        }
                        state.copy(
                            shortVideos = hydratedShorts,
                            videos = if (hydratedShorts.isNotEmpty()) customUploaded + hydratedShorts + liveItems else state.videos,
                            isShortsLoading = false,
                            shortsError = null,
                            isCatalogLoading = false,
                            catalogError = null
                        )
                    }
                    if (mappedShorts.isNotEmpty()) {
                        com.example.nexora.ui.player.ReelsLookaheadCacheManager.preWarmInitialClips(
                            getApplication(),
                            mappedShorts
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update { state ->
                        state.copy(
                            isShortsLoading = false,
                            shortsError = error.localizedMessage ?: "Failed to load Shorts API",
                            isCatalogLoading = false
                        )
                    }
                }
            )
        }
    }

    fun fetchAkashCatalog(forceRefresh: Boolean = false) {
        fetchShortsFeed(forceRefresh = forceRefresh)
    }

    private fun mapAkashCatalogItemToVideoItem(
        item: AkashCatalogItem,
        index: Int,
        presets: List<VisualThemePreset>,
        creatorsList: List<CreatorProfile>
    ): VideoItem {
        val isPhoto = item.mediaType.equals("photo", ignoreCase = true) ||
            item.mediaType.equals("image", ignoreCase = true)
        val isShort = item.mediaType.equals("short", ignoreCase = true)
        val matchedCreator = creatorsList[index % creatorsList.size]

        val rawHandle = AkashMediaService.cleanEmojis(item.creatorHandle.ifBlank { item.author })
        val normalizedHandle = if (rawHandle.startsWith("@")) rawHandle else "@$rawHandle"

        val displayCreatorName = AkashMediaService.cleanEmojis(
            item.displayName.ifBlank { item.author.removePrefix("@") }
        ).ifBlank { matchedCreator.name }

        val cleanTitle = AkashMediaService.cleanEmojis(item.title).ifBlank { "Untitled Video" }

        val durationSecInt = if (isPhoto) 0 else item.duration.roundToInt().coerceAtLeast(1)
        val formattedDuration = if (isPhoto) "PHOTO" else formatCatalogDuration(item.duration)
        val preset = presets[index % presets.size]

        val fallbackUploadedAt = item.uploadedAt.ifBlank { AkashMediaService.defaultIsoTimestampForIndex(index) }
        val hlsPath = "/_/h8a2/${item.fileCode}/master.m3u8"
        val dbRecord = runCatching {
            com.example.nexora.data.ShortsSqLiteDatabase.getInstance(getApplication())
                .upsertAndGetShortRecord(
                    fileCode = item.fileCode,
                    title = cleanTitle,
                    author = displayCreatorName,
                    creatorHandle = normalizedHandle,
                    duration = item.duration,
                    rawViewsCount = item.views.coerceAtLeast(0L),
                    fallbackCreatedAtIso = fallbackUploadedAt,
                    hlsMasterPath = hlsPath
                )
        }.getOrNull()

        val resolvedSimulatedViews = when {
            item.simulatedViews >= 1200L -> item.simulatedViews
            dbRecord != null && dbRecord.simulatedViews >= 1200L -> dbRecord.simulatedViews
            else -> AkashMediaService.computeSimulatedViews(item.fileCode, item.views.coerceAtLeast(0L), index + 1)
        }
        val viewsFormatted = item.formattedViews.takeIf { it.isNotBlank() && !it.startsWith("0 ") }
            ?: AkashMediaService.formatViewsCount(resolvedSimulatedViews, item.fileCode)

        val resolvedUploadedAt = dbRecord?.uploadedAt?.takeIf { it.isNotBlank() } ?: fallbackUploadedAt
        val resolvedRelativeTime = item.relativeTime.takeIf { it.isNotBlank() }
            ?: AkashMediaService.computeRelativeTime(resolvedUploadedAt, index)

        val resolvedAdaptiveUrl = if (isPhoto) null else item.adaptiveStreamUrl.ifBlank {
            item.streamUrl.ifBlank { AkashMediaService.adaptiveHlsStreamUrl(item.fileCode) }
        }
        val resolvedHighestQualityUrl = if (isPhoto) null else item.highestQualityStreamUrl.ifBlank {
            item.directStreamUrl.ifBlank { AkashMediaService.highestQualityStreamUrl(item.fileCode) }
        }

        return VideoItem(
            id = item.fileCode,
            title = cleanTitle,
            description = "$cleanTitle • Streamed natively via Akash Media (${when { isPhoto -> "Photo Post"; isShort -> "9:16 Short Loop"; else -> "16:9 Widescreen" }}).",
            creatorId = matchedCreator.id,
            creatorName = displayCreatorName,
            creatorHandle = normalizedHandle,
            creatorAvatarSeed = (index % 5) + 1,
            creatorAvatarUrl = item.authorAvatarUrl,
            viewsText = viewsFormatted,
            rawViews = resolvedSimulatedViews,
            simulatedViews = resolvedSimulatedViews,
            formattedViews = viewsFormatted,
            uploadedAt = resolvedUploadedAt,
            relativeTime = resolvedRelativeTime,
            duration = formattedDuration,
            durationSeconds = durationSecInt,
            category = NexoraSeedData.categories.getOrElse((index % (NexoraSeedData.categories.size - 1)) + 1) { "Movies" },
            hashtags = if (isShort) {
                listOf("#Shorts", "#SpatialComputing", "#AkashMedia")
            } else {
                listOf("#Widescreen", "#AtmosphericCinema", "#AkashMedia")
            },
            topBadge = when {
                isPhoto -> "PHOTO"
                isShort -> "SHORT"
                else -> "16:9 HD"
            },
            isFeaturedPremiere = index == 0,
            isEditorsPick = index % 2 == 0,
            visualPreset = preset,
            previewProgress = 0.25f,
            likesCount = 148 + (index * 42),
            aspectRatio = when {
                isPhoto -> 4f / 5f
                isShort -> 9f / 16f
                else -> 16f / 9f
            },
            musicTrack = "$displayCreatorName · Original Spatial Stream",
            fileCode = item.fileCode,
            mediaType = when {
                isPhoto -> "photo"
                isShort -> "short"
                else -> "long_video"
            },
            thumbnailUrl = item.thumbnailUrl.ifBlank { AkashMediaService.thumbnailUrl(item.fileCode) },
            streamUrl = resolvedAdaptiveUrl,
            directStreamUrl = resolvedHighestQualityUrl,
            adaptiveStreamUrl = resolvedAdaptiveUrl,
            highestQualityStreamUrl = resolvedHighestQualityUrl,
            qualityMode = "single_toggle",
            hasHighestQualityToggle = true,
            availableQualities = emptyList(),
            qualityStreams = emptyMap(),
            rawDurationSeconds = if (isPhoto) 0.0 else item.duration
        )
    }

    private fun seedInitialDatabaseIfNeeded() {
        viewModelScope.launch {
            repository.recordWatchProgress("vid_nordic_glass", 0.35f)
            repository.recordWatchProgress("vid_orbital_dyson", 0.62f)
            repository.recordWatchProgress("vid_liquid_glass_math", 0.78f)
        }
    }

    private fun observePersistentData() {
        viewModelScope.launch {
            repository.savedVideos.collect { entities ->
                if (entities.isNotEmpty()) {
                    _uiState.update { it.copy(savedVideoIds = entities.map { e -> e.videoId }.toSet()) }
                }
            }
        }
        viewModelScope.launch {
            repository.watchHistory.collect { entities ->
                val map = entities.associate { it.videoId to it.progressFraction }
                _uiState.update { it.copy(watchHistoryProgress = map) }
            }
        }
        viewModelScope.launch {
            repository.playlists.collect { entities ->
                if (entities.isNotEmpty()) {
                    val mapped = entities.map { e ->
                        Playlist(
                            id = e.id,
                            title = e.title,
                            description = e.description,
                            isPublic = e.isPublic,
                            videoIds = e.videoIdsCsv.split(",").filter { id -> id.isNotBlank() },
                            createdAt = e.createdAt
                        )
                    }
                    _uiState.update { state ->
                        val mergedIds = mapped.map { it.id }.toSet()
                        val defaults = NexoraSeedData.initialPlaylists.filter { it.id !in mergedIds }
                        state.copy(playlists = mapped + defaults)
                    }
                }
            }
        }
        viewModelScope.launch {
            repository.uploadedVideos.collect { uploaded ->
                if (uploaded.isNotEmpty()) {
                    val customVideos = uploaded.map { u ->
                        val preset = runCatching { VisualThemePreset.valueOf(u.visualPresetName) }
                            .getOrDefault(VisualThemePreset.NORDIC_PAVILION)
                        val slides = u.carouselPresetsCsv
                            .split(",")
                            .mapNotNull { s -> runCatching { VisualThemePreset.valueOf(s.trim()) }.getOrNull() }
                            .ifEmpty { listOf(preset) }
                        VideoItem(
                            id = u.id,
                            title = u.title,
                            description = u.description,
                            creatorId = "creator_aether",
                            creatorName = _uiState.value.ownStudioProfile.name,
                            creatorHandle = _uiState.value.ownStudioProfile.handle,
                            creatorAvatarSeed = 1,
                            viewsText = "1.2K views",
                            rawViews = 1200L,
                            relativeTime = "Just now",
                            duration = u.duration,
                            durationSeconds = 900,
                            category = u.category,
                            hashtags = listOf("#SpatialComputing", "#NordicLight"),
                            topBadge = if (slides.size > 1) "${slides.size} SLIDES" else if (u.is4kHdr) "4K HDR" else "NEW",
                            visualPreset = preset,
                            carouselSlides = slides,
                            previewProgress = 0.15f
                        )
                    }
                    _uiState.update { state ->
                        val seedIds = customVideos.map { it.id }.toSet()
                        val remaining = state.videos.filter { it.id !in seedIds }
                        state.copy(videos = customVideos + remaining)
                    }
                }
            }
        }
        viewModelScope.launch {
            repository.ownStudioProfile.collect { entity ->
                if (entity != null) {
                    val preset = runCatching { VisualThemePreset.valueOf(entity.bannerPresetName) }
                        .getOrDefault(VisualThemePreset.NORDIC_PAVILION)
                    val updatedOwn = _uiState.value.ownStudioProfile.copy(
                        name = entity.name,
                        handle = entity.handle,
                        category = entity.category,
                        bio = entity.bio,
                        location = entity.location,
                        website = entity.website,
                        bannerPreset = preset
                    )
                    _uiState.update { state ->
                        val updatedCreators = state.creators.map {
                            if (it.id == "creator_aether") updatedOwn else it
                        }
                        val updatedActive = if (state.activeCreator.id == "creator_aether") updatedOwn else state.activeCreator
                        state.copy(
                            ownStudioProfile = updatedOwn,
                            creators = updatedCreators,
                            activeCreator = updatedActive
                        )
                    }
                }
            }
        }
        viewModelScope.launch {
            repository.subscribedStudios.collect { entities ->
                if (entities.isNotEmpty()) {
                    _uiState.update { it.copy(subscribedCreatorIds = entities.map { e -> e.creatorId }.toSet()) }
                }
            }
        }
        viewModelScope.launch {
            repository.likedPosts.collect { entities ->
                val likedIds = entities.map { it.videoId }.toSet()
                _uiState.update { state ->
                    val updatedVideos = state.videos.map { v ->
                        val shouldBeLiked = v.id in likedIds
                        if (v.isLiked != shouldBeLiked) {
                            v.copy(isLiked = shouldBeLiked)
                        } else v
                    }
                    val updatedShorts = state.shortVideos.map { v ->
                        val shouldBeLiked = v.id in likedIds
                        if (v.isLiked != shouldBeLiked) {
                            v.copy(isLiked = shouldBeLiked)
                        } else v
                    }
                    state.copy(videos = updatedVideos, shortVideos = updatedShorts)
                }
            }
        }
        viewModelScope.launch {
            repository.repostedPosts.collect { entities ->
                val repostedIds = entities.map { it.videoId }.toSet()
                _uiState.update { state ->
                    val updatedVideos = state.videos.map { v ->
                        val shouldBeReposted = v.id in repostedIds
                        if (v.isReposted != shouldBeReposted) {
                            v.copy(isReposted = shouldBeReposted)
                        } else v
                    }
                    val updatedShorts = state.shortVideos.map { v ->
                        val shouldBeReposted = v.id in repostedIds
                        if (v.isReposted != shouldBeReposted) {
                            v.copy(isReposted = shouldBeReposted)
                        } else v
                    }
                    state.copy(videos = updatedVideos, shortVideos = updatedShorts)
                }
            }
        }
        viewModelScope.launch {
            repository.viewedPulses.collect { entities ->
                val viewedIds = entities.map { it.pulseId }.toSet()
                if (viewedIds.isNotEmpty()) {
                    _uiState.update { state ->
                        state.copy(
                            spatialPulses = state.spatialPulses.map { p ->
                                if (p.id in viewedIds) p.copy(isViewed = true) else p
                            }
                        )
                    }
                }
            }
        }
        viewModelScope.launch {
            repository.directMessages.collect { entities ->
                if (entities.isNotEmpty()) {
                    _uiState.update { state ->
                        val grouped = entities.groupBy { it.creatorId }
                        val updatedThreads = state.directThreads.map { thread ->
                            val extra = grouped[thread.creatorId].orEmpty().map { e ->
                                DirectChatMessage(
                                    id = e.id,
                                    senderId = if (e.isFromMe) "creator_aether" else e.creatorId,
                                    senderName = e.senderName,
                                    text = e.text,
                                    timestamp = e.timestamp,
                                    isFromMe = e.isFromMe,
                                    sharedPreset = e.sharedPresetName?.let {
                                        runCatching { VisualThemePreset.valueOf(it) }.getOrNull()
                                    }
                                )
                            }
                            val existingIds = thread.messages.map { it.id }.toSet()
                            val newOnes = extra.filter { it.id !in existingIds }
                            if (newOnes.isNotEmpty()) {
                                thread.copy(messages = thread.messages + newOnes)
                            } else thread
                        }
                        state.copy(directThreads = updatedThreads)
                    }
                }
            }
        }
    }

    private fun startLiveBroadcastTicker() {
        viewModelScope.launch {
            while (true) {
                delay(1000L)
                _uiState.update { state ->
                    state.copy(liveUptimeSeconds = state.liveUptimeSeconds + 1)
                }
            }
        }
    }

    fun capturePointerOrigin(origin: ClickOrigin) {
        _uiState.update { it.copy(lastClickOrigin = origin) }
    }

    fun selectTab(tab: NavTab) {
        if (tab == _uiState.value.activeTab) {
            refreshTab(tab)
            return
        }
        _uiState.update { state ->
            val currentOrigin = state.lastClickOrigin.copy(timestamp = System.currentTimeMillis())
            val updatedThreads = if (tab == NavTab.MESSAGES) {
                state.directThreads.map { t ->
                    if (t.creatorId == state.activeDmCreatorId) t.copy(unreadCount = 0) else t
                }
            } else {
                state.directThreads
            }
            state.copy(
                previousTab = if (state.activeTab != NavTab.PROFILE) state.activeTab else state.previousTab,
                activeTab = tab,
                activeCreator = if (tab == NavTab.PROFILE) state.ownStudioProfile else state.activeCreator,
                isChatConversationOpen = if (tab == NavTab.MESSAGES) state.isChatConversationOpen else false,
                directThreads = updatedThreads,
                stageTransitionOrigin = currentOrigin,
                isNotificationsOpen = false
            )
        }
    }

    fun refreshTab(tab: NavTab = _uiState.value.activeTab) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isRefreshing = true,
                    tabRefreshTrigger = System.currentTimeMillis()
                )
            }
            when (tab) {
                NavTab.HOME -> {
                    fetchAkashCatalog()
                    fetchShortsFeed()
                    showToast("Feed refreshed")
                }
                NavTab.EXPLORE -> {
                    fetchAkashCatalog()
                    showToast("Explore refreshed")
                }
                NavTab.LIVE -> {
                    fetchShortsFeed()
                    showToast("Reels refreshed")
                }
                NavTab.PROFILE -> {
                    fetchSavedReelsFromVault()
                    fetchAkashCatalog()
                    showToast("Profile refreshed")
                }
                NavTab.LIBRARY -> {
                    fetchSavedReelsFromVault()
                    fetchAkashCatalog()
                    showToast("Library refreshed")
                }
                NavTab.MESSAGES -> {
                    showToast("Messages refreshed")
                }
            }
            delay(500L)
            _uiState.update { it.copy(isRefreshing = false) }
        }
    }

    fun navigateBackFromProfile() {
        _uiState.update { state ->
            val currentOrigin = state.lastClickOrigin.copy(timestamp = System.currentTimeMillis())
            val targetTab = if (state.previousTab == NavTab.PROFILE) NavTab.HOME else state.previousTab
            state.copy(
                activeTab = targetTab,
                stageTransitionOrigin = currentOrigin
            )
        }
    }

    fun openCreatorProfile(creatorId: String) {
        val targetHandle = if (creatorId.startsWith("@")) creatorId else "@$creatorId"
        val isOwn = creatorId == "creator_aether" || creatorId == _uiState.value.ownStudioProfile.id || targetHandle.equals(_uiState.value.ownStudioProfile.handle, ignoreCase = true)
        if (isOwn && _uiState.value.activeTab == NavTab.PROFILE && _uiState.value.activeCreator.id == _uiState.value.ownStudioProfile.id) {
            refreshTab(NavTab.PROFILE)
            return
        }
        _uiState.update { state ->
            val currentOrigin = state.lastClickOrigin.copy(timestamp = System.currentTimeMillis())
            val targetCreator = when {
                creatorId == "creator_aether" || creatorId == state.ownStudioProfile.id || targetHandle.equals(state.ownStudioProfile.handle, ignoreCase = true) -> state.ownStudioProfile
                else -> state.creators.find { it.id == creatorId || it.handle.equals(targetHandle, ignoreCase = true) } ?: run {
                    val matchingVideo = (state.shortVideos + state.videos).firstOrNull {
                        it.creatorId == creatorId || it.creatorHandle.equals(targetHandle, ignoreCase = true)
                    }
                    if (matchingVideo != null) {
                        val handle = matchingVideo.formattedCreatorHandle
                        CreatorProfile(
                            id = creatorId,
                            name = matchingVideo.cleanCreatorName,
                            handle = handle,
                            category = matchingVideo.category.ifBlank { "Shorts Creator" },
                            bio = "Sovereign Short Video Creator on Akash Shorts.",
                            fullBiography = "Creator publishing vertical short videos on the Akash Sovereign Network.",
                            equipmentSpecs = emptyList(),
                            location = "Sovereign Cloud",
                            website = "akashbox.duckdns.org/${handle.removePrefix("@")}",
                            subscribersText = "12.4K",
                            totalViewsText = matchingVideo.viewsText,
                            publishedWorksCount = (state.shortVideos + state.videos)
                                .distinctBy { it.id }
                                .count { it.creatorId == creatorId || it.creatorHandle.equals(handle, ignoreCase = true) }
                                .coerceAtLeast(1),
                            memberSince = "2026",
                            growthPercent = "+12.0%",
                            isOnline = true,
                            isVerified = true,
                            avatarSeed = creatorId.hashCode().let { if (it < 0) -it else it } % 6 + 1,
                            bannerPreset = matchingVideo.visualPreset,
                            avatarUrl = matchingVideo.thumbnailUrl
                        )
                    } else {
                        CreatorProfile(
                            id = creatorId,
                            name = targetHandle.removePrefix("@"),
                            handle = targetHandle,
                            category = "Shorts Creator",
                            bio = "Creator on the Akash Sovereign Short Video Network.",
                            fullBiography = "Universal sovereign creator publishing vertical short videos on the decentralized network.",
                            equipmentSpecs = emptyList(),
                            location = "Sovereign Cloud",
                            website = "akashbox.duckdns.org/${targetHandle.removePrefix("@")}",
                            subscribersText = "1.2K",
                            totalViewsText = "12.5K views",
                            publishedWorksCount = 1,
                            memberSince = "2026",
                            growthPercent = "+8.5%",
                            isOnline = true,
                            isVerified = true,
                            avatarSeed = creatorId.hashCode().let { if (it < 0) -it else it } % 6 + 1
                        )
                    }
                }
            }
            state.copy(
                previousTab = if (state.activeTab != NavTab.PROFILE) state.activeTab else state.previousTab,
                activeTab = NavTab.PROFILE,
                activeCreator = targetCreator,
                profileSubTab = ProfileSubTab.OVERVIEW,
                stageTransitionOrigin = currentOrigin,
                activePulseStory = null,
                isChatConversationOpen = false,
                isNotificationsOpen = false
            )
        }

        viewModelScope.launch {
            val token = resolveCurrentIdToken()
            val handleQuery = if (creatorId.startsWith("@")) creatorId else _uiState.value.activeCreator.handle
            if (handleQuery.isNotBlank() && !handleQuery.equals(_uiState.value.ownStudioProfile.handle, ignoreCase = true)) {
                AkashMediaService.fetchCreatorProfile(handleQuery, token).onSuccess { res ->
                    val presets = VisualThemePreset.entries
                    val creatorsList = _uiState.value.creators
                    val mappedShorts = res.shorts.mapIndexed { idx, item ->
                        mapAkashCatalogItemToVideoItem(item, idx, presets, creatorsList)
                    }
                    _uiState.update { state ->
                        if (state.activeCreator.handle.equals(res.handle, ignoreCase = true)) {
                            val updated = state.activeCreator.copy(
                                name = res.displayName,
                                avatarUrl = res.avatarUrl ?: state.activeCreator.avatarUrl,
                                totalViewsText = "${res.totalViews} views",
                                publishedWorksCount = mappedShorts.size.coerceAtLeast(state.activeCreator.publishedWorksCount)
                            )
                            state.copy(
                                activeCreator = updated,
                                shortVideos = if (mappedShorts.isNotEmpty()) mappedShorts + state.shortVideos.filterNot { s -> mappedShorts.any { it.id == s.id } } else state.shortVideos
                            )
                        } else state
                    }
                }
            }
        }
    }

    fun selectCategory(category: String) {
        _uiState.update { state ->
            val currentOrigin = state.lastClickOrigin.copy(timestamp = System.currentTimeMillis())
            state.copy(
                selectedCategory = category,
                stageTransitionOrigin = currentOrigin
            )
        }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun selectExploreHashtag(hashtag: String?) {
        _uiState.update { state ->
            val nextTag = if (state.selectedHashtag == hashtag) null else hashtag
            state.copy(selectedHashtag = nextTag)
        }
    }

    fun selectExploreSortMode(mode: ExploreSortMode) {
        _uiState.update { it.copy(exploreSortMode = mode) }
    }

    fun selectLiveCategory(category: String) {
        _uiState.update { it.copy(liveCategoryFilter = category) }
    }

    fun selectLiveChannel(video: VideoItem) {
        _uiState.update { state ->
            val currentOrigin = state.lastClickOrigin.copy(timestamp = System.currentTimeMillis())
            state.copy(
                activeTab = NavTab.LIVE,
                activeLiveStream = video,
                stageTransitionOrigin = currentOrigin
            )
        }
    }

    fun selectLibrarySubTab(subTab: LibrarySubTab) {
        _uiState.update { state ->
            val currentOrigin = state.lastClickOrigin.copy(timestamp = System.currentTimeMillis())
            state.copy(
                librarySubTab = subTab,
                stageTransitionOrigin = currentOrigin
            )
        }
    }

    fun selectProfileSubTab(subTab: ProfileSubTab) {
        _uiState.update { state ->
            val currentOrigin = state.lastClickOrigin.copy(timestamp = System.currentTimeMillis())
            state.copy(
                profileSubTab = subTab,
                stageTransitionOrigin = currentOrigin
            )
        }
        if (subTab == ProfileSubTab.SAVED_REELS) {
            fetchSavedReelsFromVault()
        }
    }

    fun selectProfileVideosFilter(filter: String) {
        _uiState.update { it.copy(profileVideosFilter = filter) }
    }

    fun openVideoPlayer(video: VideoItem) {
        if (video.isPhotoPost) {
            return
        }
        if (video.isLiveStream) {
            selectLiveChannel(video)
            return
        }
        val isShort = (video.isShortVideo && video.rawDurationSeconds <= 120.0) ||
            _uiState.value.shortVideos.any { it.id == video.id }

        if (isShort) {
            // Note: Watch completion history (POST /_/u/history) is intentionally disabled per user preference
            _uiState.update { state ->
                val currentOrigin = state.lastClickOrigin.copy(timestamp = System.currentTimeMillis())
                val updatedShorts = if (state.shortVideos.any { it.id == video.id }) {
                    state.shortVideos
                } else {
                    listOf(video) + state.shortVideos
                }
                state.copy(
                    shortVideos = updatedShorts,
                    activeClipId = video.id,
                    modalTransitionOrigin = currentOrigin,
                    isNotificationsOpen = false
                )
            }
        }
    }

    fun updateVideoProgress(videoId: String, progressFraction: Float) {
        // Watch completion history tracking is disabled per user preference ("Don't save history")
    }

    fun toggleSaveVideo(videoId: String) {
        val currentlySaved = videoId in _uiState.value.savedVideoIds
        val targetClip = _uiState.value.shortVideos.find { it.id == videoId }
            ?: _uiState.value.videos.find { it.id == videoId }
        val fileCode = targetClip?.effectiveFileCode ?: videoId

        _uiState.update { state ->
            val nextSet = if (currentlySaved) {
                state.savedVideoIds - videoId - fileCode
            } else {
                state.savedVideoIds + videoId + fileCode
            }
            val updatedVaultList = if (currentlySaved) {
                state.savedReelsFromVault.filterNot { it.id == videoId || it.effectiveFileCode == fileCode }
            } else if (targetClip != null && state.savedReelsFromVault.none { it.id == targetClip.id }) {
                listOf(targetClip) + state.savedReelsFromVault
            } else {
                state.savedReelsFromVault
            }
            val msg = if (currentlySaved) "Removed from Saved Reels" else "Saved to Sovereign Vault"
            state.copy(
                savedVideoIds = nextSet,
                savedReelsFromVault = updatedVaultList,
                toastMessage = msg
            )
        }
        viewModelScope.launch {
            repository.toggleSavedVideo(videoId, currentlySaved)
            val token = resolveCurrentIdToken()
            AkashMediaService.toggleSaveReel(token, fileCode).onSuccess { resp ->
                _uiState.update { state ->
                    val reconciledSet = if (resp.isSaved) {
                        state.savedVideoIds + videoId + resp.fileCode
                    } else {
                        state.savedVideoIds - videoId - resp.fileCode
                    }
                    state.copy(savedVideoIds = reconciledSet)
                }
            }
        }
    }

    fun clearWatchHistory() {
        _uiState.update { it.copy(watchHistoryProgress = emptyMap(), toastMessage = "Watch history cleared") }
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    fun toggleSubscribeCreator(creatorId: String) {
        val currentlySub = creatorId in _uiState.value.subscribedCreatorIds
        _uiState.update { state ->
            val nextSet = if (currentlySub) state.subscribedCreatorIds - creatorId else state.subscribedCreatorIds + creatorId
            val creatorName = state.creators.find { it.id == creatorId }?.name ?: "Studio"
            val msg = if (currentlySub) "Unfollowed $creatorName" else "Subscribed to $creatorName"
            state.copy(subscribedCreatorIds = nextSet, toastMessage = msg)
        }
        viewModelScope.launch {
            repository.toggleSubscription(creatorId, currentlySub)
        }
    }

    fun toggleVideoLike(videoId: String) {
        var nextLikedState = false
        val targetClip = _uiState.value.shortVideos.find { it.id == videoId }
            ?: _uiState.value.videos.find { it.id == videoId }
        val fileCode = targetClip?.effectiveFileCode ?: videoId

        _uiState.update { state ->
            val updatedVideos = state.videos.map { v ->
                if (v.id == videoId) {
                    val liked = !v.isLiked
                    nextLikedState = liked
                    v.copy(
                        isLiked = liked,
                        likesCount = if (liked) v.likesCount + 1 else (v.likesCount - 1).coerceAtLeast(0)
                    )
                } else v
            }
            val updatedShorts = state.shortVideos.map { v ->
                if (v.id == videoId) {
                    val liked = if (state.videos.any { it.id == videoId }) nextLikedState else !v.isLiked
                    nextLikedState = liked
                    v.copy(
                        isLiked = liked,
                        likesCount = if (liked) v.likesCount + 1 else (v.likesCount - 1).coerceAtLeast(0)
                    )
                } else v
            }
            state.copy(
                videos = updatedVideos,
                shortVideos = updatedShorts
            )
        }
        viewModelScope.launch {
            repository.setPostLiked(videoId, nextLikedState)
            val token = resolveCurrentIdToken()
            AkashMediaService.toggleLikeReel(token, fileCode).onSuccess { resp ->
                _uiState.update { state ->
                    val updatedShorts = state.shortVideos.map { v ->
                        if (v.id == videoId || v.effectiveFileCode == resp.fileCode) {
                            v.copy(
                                isLiked = resp.isLiked,
                                likesCount = if (resp.likesCount >= 0) resp.likesCount else v.likesCount
                            )
                        } else v
                    }
                    val updatedVideos = state.videos.map { v ->
                        if (v.id == videoId || v.effectiveFileCode == resp.fileCode) {
                            v.copy(
                                isLiked = resp.isLiked,
                                likesCount = if (resp.likesCount >= 0) resp.likesCount else v.likesCount
                            )
                        } else v
                    }
                    state.copy(shortVideos = updatedShorts, videos = updatedVideos)
                }
            }
        }
    }

    fun doubleTapLikeVideo(videoId: String) {
        val target = _uiState.value.shortVideos.find { it.id == videoId }
            ?: _uiState.value.videos.find { it.id == videoId }
            ?: return
        val fileCode = target.effectiveFileCode
        if (!target.isLiked) {
            _uiState.update { state ->
                val updatedVideos = state.videos.map { v ->
                    if (v.id == videoId && !v.isLiked) {
                        v.copy(isLiked = true, likesCount = v.likesCount + 1)
                    } else v
                }
                val updatedShorts = state.shortVideos.map { v ->
                    if (v.id == videoId && !v.isLiked) {
                        v.copy(isLiked = true, likesCount = v.likesCount + 1)
                    } else v
                }
                state.copy(videos = updatedVideos, shortVideos = updatedShorts)
            }
            viewModelScope.launch {
                repository.setPostLiked(videoId, true)
                val token = resolveCurrentIdToken()
                AkashMediaService.toggleLikeReel(token, fileCode).onSuccess { resp ->
                    _uiState.update { state ->
                        val updatedShorts = state.shortVideos.map { v ->
                            if (v.id == videoId || v.effectiveFileCode == resp.fileCode) {
                                v.copy(
                                    isLiked = resp.isLiked,
                                    likesCount = if (resp.likesCount >= 0) resp.likesCount else v.likesCount
                                )
                            } else v
                        }
                        val updatedVideos = state.videos.map { v ->
                            if (v.id == videoId || v.effectiveFileCode == resp.fileCode) {
                                v.copy(
                                    isLiked = resp.isLiked,
                                    likesCount = if (resp.likesCount >= 0) resp.likesCount else v.likesCount
                                )
                            } else v
                        }
                        state.copy(shortVideos = updatedShorts, videos = updatedVideos)
                    }
                }
            }
        }
    }

    fun toggleRepostVideo(videoId: String) {
        var nextReposted = false
        _uiState.update { state ->
            val updatedVideos = state.videos.map { v ->
                if (v.id == videoId) {
                    val reposted = !v.isReposted
                    nextReposted = reposted
                    v.copy(
                        isReposted = reposted,
                        repostsCount = if (reposted) v.repostsCount + 1 else (v.repostsCount - 1).coerceAtLeast(0)
                    )
                } else v
            }
            val updatedShorts = state.shortVideos.map { v ->
                if (v.id == videoId) {
                    val reposted = if (state.videos.any { it.id == videoId }) nextReposted else !v.isReposted
                    nextReposted = reposted
                    v.copy(
                        isReposted = reposted,
                        repostsCount = if (reposted) v.repostsCount + 1 else (v.repostsCount - 1).coerceAtLeast(0)
                    )
                } else v
            }
            val msg = if (nextReposted) "Echoed to your Studio Feed" else "Removed Echo"
            state.copy(videos = updatedVideos, shortVideos = updatedShorts, toastMessage = msg)
        }
        viewModelScope.launch {
            repository.setPostReposted(videoId, nextReposted)
        }
    }

    // Ephemeral Spatial Pulses (Stories)
    fun openSpatialPulse(pulse: SpatialPulseStory) {
        _uiState.update { state ->
            val currentOrigin = state.lastClickOrigin.copy(timestamp = System.currentTimeMillis())
            val updatedPulses = state.spatialPulses.map {
                if (it.id == pulse.id) it.copy(isViewed = true) else it
            }
            state.copy(
                activePulseStory = pulse.copy(isViewed = true),
                spatialPulses = updatedPulses,
                modalTransitionOrigin = currentOrigin,
                isNotificationsOpen = false
            )
        }
        viewModelScope.launch {
            repository.markPulseViewed(pulse.id)
        }
    }

    fun closeSpatialPulse() {
        _uiState.update { it.copy(activePulseStory = null) }
    }

    fun publishSpatialPulse(caption: String, preset: VisualThemePreset) {
        val newSlide = SpatialPulseSlide(
            id = "ps_custom_${System.currentTimeMillis()}",
            caption = caption.ifBlank { "Live spatial study from ${_uiState.value.ownStudioProfile.name}" },
            preset = preset,
            timestamp = "Just now"
        )
        _uiState.update { state ->
            val updatedPulses = state.spatialPulses.map { pulse ->
                if (pulse.creatorId == "creator_aether") {
                    pulse.copy(slides = pulse.slides + newSlide, isViewed = false)
                } else pulse
            }
            state.copy(
                spatialPulses = updatedPulses,
                isUploadModalOpen = false,
                toastMessage = "Published to your 24h Spatial Pulse"
            )
        }
    }

    fun sendPulseReaction(pulse: SpatialPulseStory, reactionOrReply: String) {
        val trimmed = reactionOrReply.trim()
        if (trimmed.isEmpty()) return
        val targetCreatorId = if (pulse.creatorId == "creator_aether") "creator_kurogane" else pulse.creatorId
        sendDirectMessage(
            creatorId = targetCreatorId,
            text = "Replied to Pulse: $trimmed",
            sharedPreset = pulse.slides.firstOrNull()?.preset
        )
        showToast("Sent reaction to ${pulse.creatorName}")
    }

    // Direct Messages ("Spatial Lounge")
    fun setChatConversationOpen(isOpen: Boolean) {
        _uiState.update { it.copy(isChatConversationOpen = isOpen) }
    }

    fun openDmModal(creatorId: String? = null) {
        _uiState.update { state ->
            val currentOrigin = state.lastClickOrigin.copy(timestamp = System.currentTimeMillis())
            val selectedId = creatorId ?: state.activeDmCreatorId
            val updatedThreads = state.directThreads.map { t ->
                if (t.creatorId == selectedId) t.copy(unreadCount = 0) else t
            }
            state.copy(
                isDmModalOpen = true,
                isChatConversationOpen = true,
                activeDmCreatorId = selectedId,
                directThreads = updatedThreads,
                modalTransitionOrigin = currentOrigin,
                isNotificationsOpen = false
            )
        }
    }

    fun closeDmModal() {
        _uiState.update { it.copy(isDmModalOpen = false, isChatConversationOpen = false) }
    }

    fun selectDmThread(creatorId: String) {
        _uiState.update { state ->
            val updatedThreads = state.directThreads.map { t ->
                if (t.creatorId == creatorId) t.copy(unreadCount = 0) else t
            }
            state.copy(
                activeDmCreatorId = creatorId,
                directThreads = updatedThreads
            )
        }
    }

    fun sendDirectMessage(
        creatorId: String,
        text: String,
        sharedPreset: VisualThemePreset? = null
    ) {
        val trimmed = text.trim()
        if (trimmed.isEmpty() && sharedPreset == null) return
        val timeFmt = SimpleDateFormat("HH:mm", Locale.US).format(Date())
        val msgId = "dm_${System.currentTimeMillis()}"
        val ownName = _uiState.value.ownStudioProfile.name
        val newMsg = DirectChatMessage(
            id = msgId,
            senderId = "creator_aether",
            senderName = ownName,
            text = trimmed.ifEmpty { "Shared a spatial scene (${sharedPreset?.label})" },
            timestamp = timeFmt,
            isFromMe = true,
            sharedPreset = sharedPreset
        )
        _uiState.update { state ->
            val updatedThreads = state.directThreads.map { thread ->
                if (thread.creatorId == creatorId) {
                    thread.copy(
                        unreadCount = 0,
                        messages = thread.messages + newMsg
                    )
                } else thread
            }
            state.copy(directThreads = updatedThreads)
        }
        viewModelScope.launch {
            repository.insertDirectMessage(
                DirectMessageEntity(
                    id = msgId,
                    creatorId = creatorId,
                    senderName = ownName,
                    text = newMsg.text,
                    timestamp = timeFmt,
                    isFromMe = true,
                    sharedPresetName = sharedPreset?.name
                )
            )
        }
    }

    fun addVideoComment(videoId: String, commentText: String) {
        val cleanText = AkashMediaService.cleanEmojis(commentText).trim()
        if (cleanText.isEmpty()) {
            showToast("Zero-Emoji Policy: emojis are not permitted.")
            return
        }
        val own = _uiState.value.ownStudioProfile
        val tempId = "c_${System.currentTimeMillis()}"
        val optimisticComment = VideoComment(
            id = tempId,
            authorName = own.name,
            authorHandle = own.handle,
            avatarSeed = own.avatarSeed,
            text = cleanText,
            timestamp = "Just now",
            likes = 1,
            isLiked = true,
            avatarUrl = own.avatarUrl,
            isDeletable = true
        )
        _uiState.update { state ->
            val updatedVideos = state.videos.map { v ->
                if (v.id == videoId) v.copy(comments = listOf(optimisticComment) + v.comments) else v
            }
            val updatedShorts = state.shortVideos.map { v ->
                if (v.id == videoId) v.copy(comments = listOf(optimisticComment) + v.comments) else v
            }
            state.copy(videos = updatedVideos, shortVideos = updatedShorts)
        }

        viewModelScope.launch {
            val token = resolveCurrentIdToken()
            val video = _uiState.value.shortVideos.find { it.id == videoId }
                ?: _uiState.value.videos.find { it.id == videoId }
            val fileCode = video?.effectiveFileCode ?: videoId
            if (!token.isNullOrBlank() && fileCode.isNotBlank()) {
                val result = AkashMediaService.postComment(token, fileCode, cleanText)
                result.fold(
                    onSuccess = { posted ->
                        _uiState.update { state ->
                            val updateFn: (VideoItem) -> VideoItem = { v ->
                                if (v.id == videoId) {
                                    v.copy(comments = v.comments.map { if (it.id == tempId) it.copy(id = posted.id) else it })
                                } else v
                            }
                            state.copy(videos = state.videos.map(updateFn), shortVideos = state.shortVideos.map(updateFn))
                        }
                    },
                    onFailure = { err ->
                        showToast("Failed to sync comment: ${err.message}")
                    }
                )
            }
        }
    }

    fun deleteVideoComment(videoId: String, commentId: String) {
        _uiState.update { state ->
            val updatedVideos = state.videos.map { v ->
                if (v.id == videoId) v.copy(comments = v.comments.filterNot { it.id == commentId }) else v
            }
            val updatedShorts = state.shortVideos.map { v ->
                if (v.id == videoId) v.copy(comments = v.comments.filterNot { it.id == commentId }) else v
            }
            state.copy(videos = updatedVideos, shortVideos = updatedShorts, toastMessage = "Comment deleted")
        }

        viewModelScope.launch {
            val token = resolveCurrentIdToken()
            if (!token.isNullOrBlank()) {
                AkashMediaService.deleteComment(token, commentId)
            }
        }
    }

    fun toggleCommentLike(videoId: String, commentId: String) {
        _uiState.update { state ->
            val updatedVideos = state.videos.map { v ->
                if (v.id == videoId) {
                    val updatedComments = v.comments.map { c ->
                        if (c.id == commentId) {
                            val nextLiked = !c.isLiked
                            c.copy(
                                isLiked = nextLiked,
                                likes = if (nextLiked) c.likes + 1 else (c.likes - 1).coerceAtLeast(0)
                            )
                        } else c
                    }
                    v.copy(comments = updatedComments)
                } else v
            }
            val updatedShorts = state.shortVideos.map { v ->
                if (v.id == videoId) {
                    val updatedComments = v.comments.map { c ->
                        if (c.id == commentId) {
                            val nextLiked = !c.isLiked
                            c.copy(
                                isLiked = nextLiked,
                                likes = if (nextLiked) c.likes + 1 else (c.likes - 1).coerceAtLeast(0)
                            )
                        } else c
                    }
                    v.copy(comments = updatedComments)
                } else v
            }
            state.copy(videos = updatedVideos, shortVideos = updatedShorts)
        }
    }

    fun sendLiveChatMessage(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        val timeFmt = SimpleDateFormat("HH:mm", Locale.US).format(Date())
        val msg = ChatMessage(
            id = "chat_${System.currentTimeMillis()}",
            username = _uiState.value.ownStudioProfile.name,
            avatarSeed = 1,
            badge = "VIP",
            message = trimmed,
            timestamp = timeFmt
        )
        _uiState.update { state ->
            state.copy(liveChatMessages = state.liveChatMessages + msg)
        }
    }

    fun spawnLiveReaction(emoji: String) {
        val id = System.currentTimeMillis()
        val frac = (0.18f + (id % 65) / 100f).coerceIn(0.15f, 0.85f)
        val particle = FloatingReactionParticle(id = id, emoji = emoji, horizontalFraction = frac)
        _uiState.update { state ->
            state.copy(floatingReactions = (state.floatingReactions + particle).takeLast(12))
        }
        viewModelScope.launch {
            delay(1800L)
            _uiState.update { state ->
                state.copy(floatingReactions = state.floatingReactions.filterNot { it.id == id })
            }
        }
    }

    // Notifications Dropdown
    fun toggleNotificationsDropdown() {
        _uiState.update { state ->
            val currentOrigin = state.lastClickOrigin.copy(timestamp = System.currentTimeMillis())
            state.copy(
                isNotificationsOpen = !state.isNotificationsOpen,
                modalTransitionOrigin = currentOrigin
            )
        }
    }

    fun closeNotificationsDropdown() {
        _uiState.update { it.copy(isNotificationsOpen = false) }
    }

    fun markAllNotificationsRead() {
        _uiState.update { state ->
            state.copy(
                notifications = state.notifications.map { it.copy(isUnread = false) },
                toastMessage = "All notifications marked as read"
            )
        }
    }

    fun onNotificationClicked(item: NotificationItem) {
        _uiState.update { state ->
            val updatedNotifs = state.notifications.map {
                if (it.id == item.id) it.copy(isUnread = false) else it
            }
            state.copy(notifications = updatedNotifs, isNotificationsOpen = false)
        }
        item.relatedVideoId?.let { vidId ->
            val video = _uiState.value.videos.find { it.id == vidId }
            if (video != null) {
                openVideoPlayer(video)
                return
            }
        }
        item.relatedCreatorId?.let { creatorId ->
            openCreatorProfile(creatorId)
        }
    }

    // Upload Modal
    fun openUploadModal() {
        _uiState.update { state ->
            val currentOrigin = state.lastClickOrigin.copy(timestamp = System.currentTimeMillis())
            state.copy(
                isUploadModalOpen = true,
                modalTransitionOrigin = currentOrigin,
                isNotificationsOpen = false
            )
        }
    }

    fun closeUploadModal() {
        _uiState.update { it.copy(isUploadModalOpen = false) }
    }

    fun publishNewVideo(
        title: String,
        description: String,
        category: String,
        duration: String,
        is4kHdr: Boolean,
        visualPreset: VisualThemePreset,
        carouselSlides: List<VisualThemePreset> = emptyList()
    ) {
        val cleanTitle = AkashMediaService.cleanEmojis(title).ifBlank { "Untitled Spatial Short" }
        val cleanDescription = AkashMediaService.cleanEmojis(description)
        val newId = "vid_custom_${System.currentTimeMillis()}"
        val own = _uiState.value.ownStudioProfile
        val finalSlides = carouselSlides.ifEmpty { listOf(visualPreset) }
        val simViews = AkashMediaService.computeSimulatedViews(newId, 1L, 1)
        val simViewsFormatted = AkashMediaService.formatViewsCount(simViews, newId)
        val newVideo = VideoItem(
            id = newId,
            title = cleanTitle,
            description = cleanDescription.ifBlank { "Published from ${own.name} Creator Studio in 4K HDR." },
            creatorId = own.id,
            creatorName = own.name,
            creatorHandle = own.handle,
            creatorAvatarSeed = own.avatarSeed,
            viewsText = simViewsFormatted,
            rawViews = simViews,
            simulatedViews = simViews,
            formattedViews = simViewsFormatted,
            relativeTime = "Just now",
            duration = duration.ifBlank { "0:28" },
            durationSeconds = 28,
            category = category,
            hashtags = listOf("#SpatialComputing", "#NordicLight"),
            topBadge = if (finalSlides.size > 1) "${finalSlides.size} SLIDES" else if (is4kHdr) "4K HDR" else "NEW",
            isEditorsPick = true,
            visualPreset = finalSlides.first(),
            carouselSlides = finalSlides,
            previewProgress = 0.1f,
            likesCount = 142
        )
        _uiState.update { state ->
            state.copy(
                videos = listOf(newVideo) + state.videos,
                shortVideos = listOf(newVideo) + state.shortVideos,
                isUploadModalOpen = false,
                selectedCategory = "For You",
                activeTab = NavTab.HOME,
                toastMessage = "Published \"${newVideo.title}\" to spatial feed"
            )
        }
        viewModelScope.launch {
            repository.insertUploadedVideo(
                UploadedVideoEntity(
                    id = newId,
                    title = newVideo.title,
                    description = newVideo.description,
                    category = newVideo.category,
                    duration = newVideo.duration,
                    is4kHdr = is4kHdr,
                    visualPresetName = finalSlides.first().name,
                    carouselPresetsCsv = finalSlides.joinToString(",") { it.name }
                )
            )

            // Auto-refresh Akash Shorts feed
            fetchShortsFeed(forceRefresh = true)
        }
    }

    fun onModularShortCreated(
        step3Result: com.example.nexora.network.AkashStep3CreateMediaResult,
        title: String,
        caption: String,
        author: String,
        durationSeconds: Double,
        visualPreset: VisualThemePreset = VisualThemePreset.NORDIC_PAVILION
    ) {
        val cleanTitle = AkashMediaService.cleanEmojis(title).ifBlank { "Akash Short" }
        val cleanCaption = AkashMediaService.cleanEmojis(caption)
        val cleanAuthor = AkashMediaService.cleanEmojis(author).ifBlank { _uiState.value.ownStudioProfile.name }
        val own = _uiState.value.ownStudioProfile
        val hashtags = cleanCaption.split(" ")
            .map { it.trim() }
            .filter { it.startsWith("#") && it.length > 1 }
            .ifEmpty { listOf("#AkashShorts", "#Pristine1080p") }

        val durInt = durationSeconds.roundToInt().coerceAtLeast(1)
        val formattedDur = formatCatalogDuration(durationSeconds)
        val simViews = AkashMediaService.computeSimulatedViews(step3Result.fileCode, 1L, 1)
        val simViewsFormatted = AkashMediaService.formatViewsCount(simViews, step3Result.fileCode)

        val createdShort = VideoItem(
            id = step3Result.fileCode,
            title = cleanTitle,
            description = if (cleanCaption.isNotBlank()) "$cleanTitle • $cleanCaption" else "$cleanTitle • Streamed natively via Akash Shorts",
            creatorId = own.id,
            creatorName = cleanAuthor,
            creatorHandle = own.handle,
            creatorAvatarSeed = own.avatarSeed,
            creatorAvatarUrl = own.avatarUrl,
            viewsText = simViewsFormatted,
            rawViews = simViews,
            simulatedViews = simViews,
            formattedViews = simViewsFormatted,
            relativeTime = "Just now",
            duration = formattedDur,
            durationSeconds = durInt,
            category = "For You",
            hashtags = hashtags,
            topBadge = "SHORT",
            isFeaturedPremiere = true,
            isEditorsPick = true,
            visualPreset = visualPreset,
            previewProgress = 0.1f,
            likesCount = 148,
            aspectRatio = 9f / 16f,
            musicTrack = "$cleanAuthor · Original Spatial Stream",
            fileCode = step3Result.fileCode,
            mediaType = "short",
            thumbnailUrl = step3Result.thumbnailUrl,
            streamUrl = step3Result.adaptiveStreamUrl,
            directStreamUrl = step3Result.highestQualityStreamUrl,
            adaptiveStreamUrl = step3Result.adaptiveStreamUrl,
            highestQualityStreamUrl = step3Result.highestQualityStreamUrl,
            qualityMode = "single_toggle",
            hasHighestQualityToggle = true,
            availableQualities = emptyList(),
            qualityStreams = emptyMap(),
            rawDurationSeconds = durationSeconds
        )

        _uiState.update { state ->
            state.copy(
                shortVideos = listOf(createdShort) + state.shortVideos.filterNot { it.id == createdShort.id },
                videos = listOf(createdShort) + state.videos.filterNot { it.id == createdShort.id },
                isUploadModalOpen = false,
                selectedCategory = "For You",
                activeTab = NavTab.LIVE,
                toastMessage = "Published \"${createdShort.title}\" (${step3Result.fileCode}) to Akash Shorts"
            )
        }

        viewModelScope.launch {
            fetchShortsFeed(forceRefresh = true)
        }
    }

    // Playlist Modal
    fun openPlaylistModal() {
        _uiState.update { state ->
            val currentOrigin = state.lastClickOrigin.copy(timestamp = System.currentTimeMillis())
            state.copy(
                isPlaylistModalOpen = true,
                modalTransitionOrigin = currentOrigin
            )
        }
    }

    fun closePlaylistModal() {
        _uiState.update { it.copy(isPlaylistModalOpen = false) }
    }

    fun createPlaylist(title: String, description: String, isPublic: Boolean, selectedVideoIds: List<String>) {
        val playlist = Playlist(
            id = "pl_${System.currentTimeMillis()}",
            title = title.ifBlank { "Spatial Curation" },
            description = description.ifBlank { "Custom studio collection" },
            isPublic = isPublic,
            videoIds = selectedVideoIds.ifEmpty { listOf("vid_nordic_glass") }
        )
        _uiState.update { state ->
            state.copy(
                playlists = listOf(playlist) + state.playlists,
                isPlaylistModalOpen = false,
                librarySubTab = LibrarySubTab.CUSTOM_PLAYLISTS,
                toastMessage = "Created playlist \"${playlist.title}\""
            )
        }
        viewModelScope.launch {
            repository.savePlaylist(playlist)
        }
    }

    fun deletePlaylist(playlistId: String) {
        _uiState.update { state ->
            state.copy(
                playlists = state.playlists.filterNot { it.id == playlistId },
                toastMessage = "Playlist deleted"
            )
        }
        viewModelScope.launch {
            repository.deletePlaylist(playlistId)
        }
    }

    fun saveVideoToFirstPlaylist(videoId: String) {
        val firstPl = _uiState.value.playlists.firstOrNull() ?: return
        if (videoId !in firstPl.videoIds) {
            val updated = firstPl.copy(videoIds = firstPl.videoIds + videoId)
            _uiState.update { state ->
                state.copy(
                    playlists = state.playlists.map { if (it.id == firstPl.id) updated else it },
                    toastMessage = "Added to \"${firstPl.title}\""
                )
            }
            viewModelScope.launch {
                repository.addVideoToPlaylist(firstPl, videoId)
            }
        } else {
            showToast("Already in \"${firstPl.title}\"")
        }
    }

    // Edit Profile Modal
    fun openEditProfileModal() {
        _uiState.update { state ->
            val currentOrigin = state.lastClickOrigin.copy(timestamp = System.currentTimeMillis())
            state.copy(
                isEditProfileModalOpen = true,
                modalTransitionOrigin = currentOrigin
            )
        }
    }

    fun closeEditProfileModal() {
        _uiState.update { it.copy(isEditProfileModalOpen = false) }
    }

    fun checkHandleAvailability(handle: String, onResult: (isAvailable: Boolean, message: String?) -> Unit) {
        viewModelScope.launch {
            val res = AkashMediaService.checkHandleAvailability(handle)
            res.fold(
                onSuccess = { onResult(it.available, it.message) },
                onFailure = { onResult(false, it.message) }
            )
        }
    }

    fun saveStudioProfileEdits(
        name: String,
        handle: String,
        category: String,
        bio: String,
        location: String,
        website: String,
        bannerPreset: VisualThemePreset,
        avatarSeed: Int = _uiState.value.ownStudioProfile.avatarSeed
    ) {
        val cleanName = AkashMediaService.cleanEmojis(name)
        val rawHandle = AkashMediaService.cleanEmojis(handle).trim().removePrefix("@").lowercase()
        if (!AkashMediaService.validateHandleFormat(rawHandle)) {
            showToast("Invalid handle. 3-24 characters (a-z, 0-9, _) only. No emojis.")
            return
        }
        val normalizedHandle = "@$rawHandle"
        val currentOwn = _uiState.value.ownStudioProfile
        val updated = currentOwn.copy(
            name = cleanName.ifBlank { currentOwn.name },
            handle = normalizedHandle,
            category = AkashMediaService.cleanEmojis(category).ifBlank { currentOwn.category },
            bio = AkashMediaService.cleanEmojis(bio).ifBlank { currentOwn.bio },
            location = AkashMediaService.cleanEmojis(location).ifBlank { currentOwn.location },
            website = AkashMediaService.cleanEmojis(website).ifBlank { currentOwn.website },
            bannerPreset = bannerPreset,
            avatarSeed = avatarSeed
        )

        viewModelScope.launch {
            val token = resolveCurrentIdToken()
            if (!token.isNullOrBlank()) {
                val updateResult = AkashMediaService.updateUserProfile(
                    firebaseIdToken = token,
                    displayName = updated.name,
                    handle = rawHandle,
                    avatarUrl = updated.avatarUrl
                )
                updateResult.fold(
                    onSuccess = { res ->
                        if (res.isConflict) {
                            showToast("Conflict: @$rawHandle is already taken by another user.")
                            return@launch
                        }
                        if (!res.success) {
                            showToast(res.message ?: "Failed to update profile")
                            return@launch
                        }
                        _uiState.update { state ->
                            val updatedCreators = state.creators.map { if (it.id == updated.id) updated else it }
                            val updatedVideos = state.videos.map {
                                if (it.creatorId == updated.id) it.copy(creatorName = updated.name, creatorHandle = updated.handle) else it
                            }
                            state.copy(
                                ownStudioProfile = updated,
                                activeCreator = if (state.activeCreator.id == updated.id) updated else state.activeCreator,
                                creators = updatedCreators,
                                videos = updatedVideos,
                                isEditProfileModalOpen = false,
                                toastMessage = "Universal identity updated to $normalizedHandle"
                            )
                        }
                        repository.updateOwnStudioProfile(updated)
                    },
                    onFailure = { err ->
                        showToast("Profile update error: ${err.message}")
                    }
                )
            } else {
                _uiState.update { state ->
                    val updatedCreators = state.creators.map { if (it.id == updated.id) updated else it }
                    val updatedVideos = state.videos.map {
                        if (it.creatorId == updated.id) it.copy(creatorName = updated.name, creatorHandle = updated.handle) else it
                    }
                    state.copy(
                        ownStudioProfile = updated,
                        activeCreator = if (state.activeCreator.id == updated.id) updated else state.activeCreator,
                        creators = updatedCreators,
                        videos = updatedVideos,
                        isEditProfileModalOpen = false,
                        toastMessage = "Profile saved: $normalizedHandle"
                    )
                }
                repository.updateOwnStudioProfile(updated)
            }
        }
    }

    // Account Centre Modal
    fun openAccountCentreModal() {
        _uiState.update { state ->
            val currentOrigin = state.lastClickOrigin.copy(timestamp = System.currentTimeMillis())
            state.copy(
                isAccountCentreModalOpen = true,
                modalTransitionOrigin = currentOrigin,
                isNotificationsOpen = false
            )
        }
    }

    fun closeAccountCentreModal() {
        _uiState.update { it.copy(isAccountCentreModalOpen = false) }
    }

    // Admin Telemetry & Moderation Modal
    fun openAdminModal() {
        _uiState.update { state ->
            val currentOrigin = state.lastClickOrigin.copy(timestamp = System.currentTimeMillis())
            state.copy(
                isAdminModalOpen = true,
                isAccountCentreModalOpen = false,
                modalTransitionOrigin = currentOrigin,
                isNotificationsOpen = false
            )
        }
    }

    fun closeAdminModal() {
        _uiState.update { it.copy(isAdminModalOpen = false) }
    }

    fun moderateFlaggedItem(itemId: String, approve: Boolean) {
        _uiState.update { state ->
            val actionLabel = if (approve) "Approved stream" else "Removed flagged stream"
            state.copy(
                moderationQueue = state.moderationQueue.filterNot { it.id == itemId },
                toastMessage = actionLabel
            )
        }
    }

    // Spatial Clips (Vertical Short-Form Video Feed) Viewer
    fun openSpatialClipsViewer(videoId: String) {
        _uiState.update { state ->
            val currentOrigin = state.lastClickOrigin.copy(timestamp = System.currentTimeMillis())
            state.copy(
                activeClipId = videoId,
                modalTransitionOrigin = currentOrigin,
                isNotificationsOpen = false
            )
        }
    }

    fun closeSpatialClipsViewer() {
        _uiState.update { it.copy(activeClipId = null) }
    }

    fun showToast(message: String) {
        _uiState.update { it.copy(toastMessage = message) }
    }

    fun clearToast() {
        _uiState.update { it.copy(toastMessage = null) }
    }
}
