package com.example.nexora.ui.modals

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PersonAddAlt1
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.nexora.data.NexoraSeedData
import com.example.nexora.data.VisualThemePreset
import com.example.nexora.ui.components.SpatialVisualCanvas
import com.example.ui.theme.NexoraColors
import com.example.ui.theme.NexoraTypography
import com.example.ui.theme.liquidGlassAccent
import com.example.ui.theme.liquidGlassCard
import com.example.ui.theme.liquidGlassWhitePill

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun InstagramShareDetailsStep(
    creationMode: InstagramCreationMode,
    activePreset: VisualThemePreset,
    selectedSlides: List<VisualThemePreset>,
    pickedUriString: String?,
    selectedFilter: InstagramFilterPreset,
    filterStrength: Float,
    adjustmentState: InstagramAdjustmentState,
    aspectRatio: InstagramAspectRatio,
    title: String,
    onTitleChange: (String) -> Unit,
    description: String,
    onDescriptionChange: (String) -> Unit,
    selectedCategory: String,
    onCategoryChange: (String) -> Unit,
    duration: String,
    onDurationChange: (String) -> Unit,
    taggedPeople: List<String>,
    onToggleTagPerson: (String) -> Unit,
    selectedLocation: String,
    onLocationChange: (String) -> Unit,
    selectedAudio: InstagramAudioTrack?,
    onSelectAudio: (InstagramAudioTrack?) -> Unit,
    audiencePublic: Boolean,
    onAudienceChange: (Boolean) -> Unit,
    is4kHdr: Boolean,
    onIs4kHdrChange: (Boolean) -> Unit,
    hideLikesAndViews: Boolean,
    onHideLikesChange: (Boolean) -> Unit,
    turnOffComments: Boolean,
    onTurnOffCommentsChange: (Boolean) -> Unit,
    alsoShareToPulse: Boolean,
    onAlsoShareToPulseChange: (Boolean) -> Unit,
    isUploading: Boolean,
    uploadProgress: Float,
    onBackToEditor: () -> Unit,
    onDismiss: () -> Unit,
    onShareSubmit: () -> Unit
) {
    var expandedSection by remember { mutableStateOf<String?>(null) }
    var advancedExpanded by remember { mutableStateOf(false) }

    val quickLocations = remember {
        listOf(
            "Tokyo, Japan",
            "Zurich Design District",
            "Reykjavik Glass Pavilion",
            "New York SoHo",
            "Kyoto Bamboo Sanctuary",
            "London Tate Modern"
        )
    }

    val availableHandles = remember {
        listOf(
            "@vasilynoir",
            "@kurogane",
            "@lumen_studio",
            "@sora_vance",
            "@elena_rostova",
            "@nordic_synth"
        )
    }

    val quickHashtags = remember {
        listOf("#SpatialComputing", "#Architecture", "#4KHDR", "#MinimalDesign", "#Reels")
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Instagram Step 3 Top Header Bar (<- | New post / New reel | Share)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .liquidGlassWhitePill(999.dp)
                        .clickable(enabled = !isUploading) { onBackToEditor() }
                        .testTag("upload_close_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to filter editor",
                        tint = NexoraColors.InkPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column {
                    Text(
                        text = when (creationMode) {
                            InstagramCreationMode.POST -> "New post"
                            InstagramCreationMode.STORY -> "Add to story"
                            InstagramCreationMode.REEL -> "New reel"
                            InstagramCreationMode.LIVE -> "Live broadcast details"
                        },
                        style = NexoraTypography.SectionTitle.copy(
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold
                        ),
                        color = NexoraColors.InkPrimary
                    )
                    Text(
                        text = buildString {
                            append("Step 3 of 3 · ${aspectRatio.label} · ${selectedFilter.label}")
                            if (selectedFilter != InstagramFilterPreset.NORMAL) {
                                append(" (${filterStrength.toInt()}%)")
                            }
                            val modCount = adjustmentState.modifiedChannelCount()
                            if (modCount > 0) append(" · +$modCount edits")
                        },
                        style = NexoraTypography.MetaCaption,
                        color = NexoraColors.InkSecondary
                    )
                }
            }

            Box(
                modifier = Modifier
                    .height(38.dp)
                    .liquidGlassAccent(999.dp)
                    .clickable(enabled = !isUploading) { onShareSubmit() }
                    .padding(horizontal = 18.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isUploading) "Sharing..." else "Share",
                    style = NexoraTypography.NavPillLabel.copy(
                        fontWeight = FontWeight.Bold,
                        color = NexoraColors.InkAccent
                    )
                )
            }
        }

        // Scrollable Instagram Share Form
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 680.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. Instagram Media Thumbnail + Caption Input Card
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .liquidGlassCard(cornerRadius = 22.dp)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        // Thumbnail preview with real GPU ColorMatrix + Optical Shaders & multi-slide badge
                        Box(
                            modifier = Modifier
                                .size(width = 84.dp, height = 96.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .border(1.5.dp, Color.White, RoundedCornerShape(14.dp))
                        ) {
                            InstagramFilteredMediaViewport(
                                activePreset = activePreset,
                                pickedUriString = pickedUriString,
                                filter = selectedFilter,
                                filterStrength = filterStrength,
                                adjustments = adjustmentState,
                                isAnimated = false,
                                isThumbnail = true
                            )
                            if (selectedSlides.size > 1) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(6.dp)
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .background(NexoraColors.CanvasBase.copy(alpha = 0.65f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Collections,
                                        contentDescription = "Carousel",
                                        tint = Color.White,
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                            }
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .fillMaxWidth()
                                    .background(NexoraColors.CanvasBase.copy(alpha = 0.55f))
                                    .padding(vertical = 2.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = selectedFilter.label,
                                    style = NexoraTypography.BadgeMicro.copy(
                                        color = Color.White,
                                        fontSize = 9.sp
                                    ),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        // Caption & Title Input
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = title,
                                onValueChange = onTitleChange,
                                label = {
                                    Text(
                                        if (creationMode == InstagramCreationMode.STORY) {
                                            "Story caption"
                                        } else {
                                            "Write a caption..."
                                        }
                                    )
                                },
                                placeholder = {
                                    Text("Share the story behind this ${creationMode.title.lowercase()}...")
                                },
                                maxLines = 3,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("upload_title_input")
                            )
                        }
                    }

                    // Quick Hashtag Pills
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        quickHashtags.forEach { tag ->
                            Box(
                                modifier = Modifier
                                    .height(28.dp)
                                    .liquidGlassWhitePill(999.dp)
                                    .clickable {
                                        if (!title.contains(tag)) {
                                            onTitleChange(if (title.isBlank()) tag else "$title $tag")
                                        }
                                    }
                                    .padding(horizontal = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = tag,
                                    style = NexoraTypography.BadgeMicro.copy(
                                        color = NexoraColors.InkAccent,
                                        fontSize = 10.sp
                                    )
                                )
                            }
                        }
                    }

                    // Secondary Notes / Description Input (preserves upload_desc_input testTag)
                    if (creationMode != InstagramCreationMode.STORY) {
                        OutlinedTextField(
                            value = description,
                            onValueChange = onDescriptionChange,
                            label = { Text("Additional notes / alt text (Optional)") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("upload_desc_input")
                        )
                    }
                }

                // 2. Instagram Detail Action Rows Card (Tag people, Add location, Add music, Audience)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .liquidGlassCard(cornerRadius = 22.dp)
                ) {
                    // Row A: Tag People
                    InstagramSettingActionRow(
                        icon = Icons.Filled.PersonAddAlt1,
                        title = "Tag people",
                        valueSummary = if (taggedPeople.isEmpty()) {
                            "Add collaborators or creators"
                        } else {
                            taggedPeople.joinToString(", ")
                        },
                        hasActiveValue = taggedPeople.isNotEmpty(),
                        onClick = {
                            expandedSection = if (expandedSection == "tags") null else "tags"
                        }
                    )

                    AnimatedVisibility(
                        visible = expandedSection == "tags",
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(NexoraColors.Pearl100)
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "Tap creators to tag in this ${creationMode.label.lowercase()}:",
                                style = NexoraTypography.MetaCaption
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                availableHandles.forEach { handle ->
                                    val isTagged = handle in taggedPeople
                                    Box(
                                        modifier = Modifier
                                            .height(32.dp)
                                            .then(
                                                if (isTagged) Modifier.liquidGlassAccent(999.dp)
                                                else Modifier.liquidGlassWhitePill(999.dp)
                                            )
                                            .clickable { onToggleTagPerson(handle) }
                                            .padding(horizontal = 12.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            if (isTagged) {
                                                Icon(
                                                    imageVector = Icons.Filled.Check,
                                                    contentDescription = null,
                                                    tint = NexoraColors.InkAccent,
                                                    modifier = Modifier.size(12.dp)
                                                )
                                            }
                                            Text(
                                                text = handle,
                                                style = NexoraTypography.BadgeMicro.copy(
                                                    color = if (isTagged) NexoraColors.InkAccent else NexoraColors.InkSecondary,
                                                    fontWeight = if (isTagged) FontWeight.Bold else FontWeight.Medium
                                                )
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    HorizontalDivider(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        color = NexoraColors.Pearl300.copy(alpha = 0.55f)
                    )

                    // Row B: Add Location
                    InstagramSettingActionRow(
                        icon = Icons.Filled.LocationOn,
                        title = "Add location",
                        valueSummary = selectedLocation.ifBlank { "Search or pick a location" },
                        hasActiveValue = selectedLocation.isNotBlank(),
                        onClick = {
                            expandedSection = if (expandedSection == "location") null else "location"
                        }
                    )

                    // Quick Location Pills (Always visible like Instagram's horizontal suggestion bar when no location is chosen, or expandable)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        quickLocations.forEach { loc ->
                            val isSelected = selectedLocation == loc
                            Box(
                                modifier = Modifier
                                    .height(30.dp)
                                    .then(
                                        if (isSelected) Modifier.liquidGlassAccent(999.dp)
                                        else Modifier.liquidGlassWhitePill(999.dp)
                                    )
                                    .clickable {
                                        onLocationChange(if (isSelected) "" else loc)
                                    }
                                    .padding(horizontal = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = loc,
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontSize = 11.sp,
                                        color = if (isSelected) NexoraColors.InkAccent else NexoraColors.InkSecondary,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                    )
                                )
                            }
                        }
                    }

                    HorizontalDivider(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        color = NexoraColors.Pearl300.copy(alpha = 0.55f)
                    )

                    // Row C: Add Music / Audio Track
                    InstagramSettingActionRow(
                        icon = Icons.Filled.MusicNote,
                        title = "Add music",
                        valueSummary = selectedAudio?.let { "${it.title} · ${it.artist}" }
                            ?: "Original audio · Tap to add soundtrack",
                        hasActiveValue = selectedAudio != null,
                        onClick = {
                            expandedSection = if (expandedSection == "music") null else "music"
                        }
                    )

                    AnimatedVisibility(
                        visible = expandedSection == "music",
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(NexoraColors.Pearl100)
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            InstagramCatalogAudioTracks.forEach { track ->
                                val isChosen = selectedAudio?.id == track.id
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(
                                            if (isChosen) NexoraColors.ElectricIndigo.copy(alpha = 0.22f)
                                            else NexoraColors.Pearl300
                                        )
                                        .clickable {
                                            onSelectAudio(if (isChosen) null else track)
                                        }
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = track.title,
                                            style = NexoraTypography.CardTitle.copy(fontSize = 13.sp),
                                            color = if (isChosen) NexoraColors.InkAccent else NexoraColors.InkPrimary
                                        )
                                        Text(
                                            text = "${track.artist} · ${track.durationLabel}",
                                            style = NexoraTypography.MetaCaption
                                        )
                                    }
                                    if (isChosen) {
                                        Icon(
                                            imageVector = Icons.Filled.Check,
                                            contentDescription = "Selected",
                                            tint = NexoraColors.InkAccent,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    HorizontalDivider(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        color = NexoraColors.Pearl300.copy(alpha = 0.55f)
                    )

                    // Row D: Audience Visibility
                    InstagramSettingActionRow(
                        icon = if (audiencePublic) Icons.Filled.Public else Icons.Filled.Star,
                        title = "Audience",
                        valueSummary = if (audiencePublic) "Everyone" else "Close Friends & VIP Subscribers",
                        hasActiveValue = !audiencePublic,
                        onClick = { onAudienceChange(!audiencePublic) }
                    )
                }

                // 3. Category & Runtime Selector Card (for Feed / Reel / Live)
                if (creationMode != InstagramCreationMode.STORY) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .liquidGlassCard(cornerRadius = 22.dp)
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Topic & Feed Channel",
                            style = NexoraTypography.CardTitle.copy(fontSize = 14.sp)
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            NexoraSeedData.categories.filterNot { it == "For You" }.forEach { cat ->
                                val isSelected = cat == selectedCategory
                                Box(
                                    modifier = Modifier
                                        .height(32.dp)
                                        .then(
                                            if (isSelected) Modifier.liquidGlassAccent(999.dp)
                                            else Modifier.liquidGlassWhitePill(999.dp)
                                        )
                                        .clickable { onCategoryChange(cat) }
                                        .padding(horizontal = 12.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = cat,
                                        style = NexoraTypography.BadgeMicro.copy(
                                            color = if (isSelected) NexoraColors.InkAccent else NexoraColors.InkSecondary,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                // 4. Instagram Advanced Settings Accordion (HDR, Like/View counts, Commenting, Cross-post)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .liquidGlassCard(cornerRadius = 22.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { advancedExpanded = !advancedExpanded }
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Tune,
                                contentDescription = null,
                                tint = NexoraColors.InkPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Column {
                                Text(
                                    text = "Advanced settings",
                                    style = NexoraTypography.CardTitle.copy(fontSize = 14.sp)
                                )
                                Text(
                                    text = "4K HDR quality, like counts, comments & cross-posting",
                                    style = NexoraTypography.MetaCaption
                                )
                            }
                        }
                        Icon(
                            imageVector = if (advancedExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                            contentDescription = "Toggle advanced settings",
                            tint = NexoraColors.InkSecondary
                        )
                    }

                    AnimatedVisibility(
                        visible = advancedExpanded,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            HorizontalDivider(color = NexoraColors.Pearl300.copy(alpha = 0.55f))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Upload at highest quality (4K 60fps HDR)",
                                        style = NexoraTypography.CardTitle.copy(fontSize = 13.5.sp)
                                    )
                                    Text(
                                        text = "Always upload highest resolution media even on cellular",
                                        style = NexoraTypography.MetaCaption
                                    )
                                }
                                Switch(
                                    checked = is4kHdr,
                                    onCheckedChange = onIs4kHdrChange
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Hide like and view counts on this post",
                                        style = NexoraTypography.CardTitle.copy(fontSize = 13.5.sp)
                                    )
                                    Text(
                                        text = "Only you will see the total number of likes and views",
                                        style = NexoraTypography.MetaCaption
                                    )
                                }
                                Switch(
                                    checked = hideLikesAndViews,
                                    onCheckedChange = onHideLikesChange
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Turn off commenting",
                                        style = NexoraTypography.CardTitle.copy(fontSize = 13.5.sp)
                                    )
                                    Text(
                                        text = "You can change this later from the menu at the top of your post",
                                        style = NexoraTypography.MetaCaption
                                    )
                                }
                                Switch(
                                    checked = turnOffComments,
                                    onCheckedChange = onTurnOffCommentsChange
                                )
                            }

                            if (creationMode != InstagramCreationMode.STORY) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "Also share to 24h Spatial Pulse",
                                            style = NexoraTypography.CardTitle.copy(fontSize = 13.5.sp)
                                        )
                                        Text(
                                            text = "Highlight this post in your top story ring for 24 hours",
                                            style = NexoraTypography.MetaCaption
                                        )
                                    }
                                    Switch(
                                        checked = alsoShareToPulse,
                                        onCheckedChange = onAlsoShareToPulseChange
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        // Sticky Instagram Share Bottom Bar in Nexora Liquid Glass
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(bottom = 12.dp)
                .liquidGlassCard(cornerRadius = 24.dp)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (isUploading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                        .clip(RoundedCornerShape(999.dp))
                        .background(NexoraColors.Pearl300)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(uploadProgress)
                            .height(5.dp)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(NexoraColors.Lavender500, NexoraColors.Sky400)
                                )
                            )
                    )
                }
            }

            Box(
                modifier = Modifier
                    .widthIn(max = 680.dp)
                    .fillMaxWidth()
                    .height(48.dp)
                    .align(Alignment.CenterHorizontally)
                    .liquidGlassAccent(999.dp)
                    .clickable(enabled = !isUploading) { onShareSubmit() }
                    .testTag("upload_publish_submit_btn"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = when {
                        isUploading -> "Sharing..."
                        creationMode == InstagramCreationMode.STORY -> "Share to Your Story"
                        creationMode == InstagramCreationMode.REEL -> "Share Reel"
                        creationMode == InstagramCreationMode.LIVE -> "Start Live Broadcast"
                        else -> "Share"
                    },
                    style = NexoraTypography.NavPillLabel.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = NexoraColors.InkAccent,
                        fontSize = 15.sp
                    )
                )
            }
        }
    }
}

@Composable
private fun InstagramSettingActionRow(
    icon: ImageVector,
    title: String,
    valueSummary: String,
    hasActiveValue: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (hasActiveValue) NexoraColors.InkAccent else NexoraColors.InkPrimary,
                modifier = Modifier.size(20.dp)
            )
            Column {
                Text(
                    text = title,
                    style = NexoraTypography.CardTitle.copy(fontSize = 14.sp),
                    color = NexoraColors.InkPrimary
                )
                Text(
                    text = valueSummary,
                    style = NexoraTypography.MetaCaption.copy(
                        color = if (hasActiveValue) NexoraColors.InkAccent else NexoraColors.InkSecondary,
                        fontWeight = if (hasActiveValue) FontWeight.SemiBold else FontWeight.Normal
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Icon(
            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = NexoraColors.InkSecondary,
            modifier = Modifier.size(20.dp)
        )
    }
}
