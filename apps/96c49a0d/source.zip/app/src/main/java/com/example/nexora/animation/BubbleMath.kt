package com.example.nexora.animation

import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class ClickOrigin(
    val x: Float = 540f,
    val y: Float = 120f,
    val u: Float = 0.5f,
    val v: Float = 0.1f,
    val timestamp: Long = 0L
) {
    companion object {
        fun fromRootCoordinates(
            x: Float,
            y: Float,
            viewportWidth: Float,
            viewportHeight: Float,
            timestamp: Long = System.currentTimeMillis()
        ): ClickOrigin {
            val safeW = max(viewportWidth, 1f)
            val safeH = max(viewportHeight, 1f)
            val u = (x / safeW).coerceIn(0.05f, 0.95f)
            val v = (y / safeH).coerceIn(0.05f, 0.95f)
            return ClickOrigin(x = x, y = y, u = u, v = v, timestamp = timestamp)
        }
    }
}

data class StageBubbleGeometry(
    val pivotX: Float,
    val pivotY: Float,
    val pivotFractionX: Float,
    val pivotFractionY: Float,
    val initialTranslationX: Float,
    val initialTranslationY: Float,
    val maxRadius: Float
) {
    fun scaleAt(progress: Float, initialScale: Float = 0.055f): Float {
        val p = progress.coerceIn(0f, 1f)
        return initialScale + (1f - initialScale) * p
    }

    fun translationXAt(progress: Float): Float {
        val p = progress.coerceIn(0f, 1f)
        return initialTranslationX * (1f - p)
    }

    fun translationYAt(progress: Float): Float {
        val p = progress.coerceIn(0f, 1f)
        return initialTranslationY * (1f - p)
    }

    fun effectiveOriginScreenXAt(containerLeft: Float, progress: Float): Float {
        return containerLeft + pivotX + translationXAt(progress)
    }

    fun effectiveOriginScreenYAt(containerTop: Float, progress: Float): Float {
        return containerTop + pivotY + translationYAt(progress)
    }
}

data class ModalBubbleGeometry(
    val modalCenterX: Float,
    val modalCenterY: Float,
    val deltaX: Float,
    val deltaY: Float
) {
    fun scaleAt(progress: Float, initialScale: Float = 0.04f): Float {
        val p = progress.coerceIn(0f, 1f)
        return initialScale + (1f - initialScale) * p
    }

    fun translationXAt(progress: Float): Float {
        val p = progress.coerceIn(0f, 1f)
        return deltaX * (1f - p)
    }

    fun translationYAt(progress: Float): Float {
        val p = progress.coerceIn(0f, 1f)
        return deltaY * (1f - p)
    }
}

data class VideoCardGeometry(
    val outerCornerRadiusDp: Float,
    val outerPaddingDp: Float,
    val innerThumbnailCornerRadiusDp: Float,
    val thumbnailHeightDp: Float,
    val minMetadataHeightDp: Float,
    val avatarDiameterDp: Float
)

object BubbleMath {
    /**
     * Concentric Corner Radius Law:
     * R_inner = max(R_outer - P, 8dp)
     */
    fun concentricInnerRadius(
        outerRadiusDp: Float,
        paddingDp: Float,
        minRadiusDp: Float = 8f
    ): Float {
        return max(outerRadiusDp - paddingDp, minRadiusDp)
    }

    /**
     * Mathematical Video Card Geometry from measured card width W (in dp):
     * - Outer Card Corner Radius: r = min(0.055 * W, 24dp)
     * - Outer Card Padding: P = 10dp
     * - Inner Thumbnail Corner Radius: r_thumb = max(r - 4dp, 12dp)
     * - Thumbnail Container Height: H_t = 0.64 * W (exact 100:64 aspect ratio = 1.5625f)
     * - Bottom Metadata Bar Minimum Height: H_m >= 0.165 * W
     * - Creator Avatar Diameter: D_a = clamp(34dp, 0.115 * W, 44dp)
     */
    fun computeVideoCardGeometry(cardWidthDp: Float): VideoCardGeometry {
        val safeW = max(cardWidthDp, 120f)
        val outerRadius = min(0.055f * safeW, 24f)
        val padding = 10f
        val innerThumbRadius = max(outerRadius - 4f, 12f)
        val thumbHeight = 0.64f * safeW
        val metadataMinHeight = 0.165f * safeW
        val avatarDiameter = (0.115f * safeW).coerceIn(34f, 44f)
        return VideoCardGeometry(
            outerCornerRadiusDp = outerRadius,
            outerPaddingDp = padding,
            innerThumbnailCornerRadiusDp = innerThumbRadius,
            thumbnailHeightDp = thumbHeight,
            minMetadataHeightDp = metadataMinHeight,
            avatarDiameterDp = avatarDiameter
        )
    }

    /**
     * Homothety Translation Formula for Stage & Tab Views:
     * 1. Local transform pivot inside container:
     *    A_x = clamp(O_x - L, 0, W), A_y = clamp(O_y - T, 0, H)
     * 2. Residual initial translation (tx0, ty0):
     *    targetAtOrigin_x = L + A_x, targetAtOrigin_y = T + A_y
     *    tx0 = O_x - targetAtOrigin_x, ty0 = O_y - targetAtOrigin_y
     * 3. Maximum Euclidean distance R_max from (A_x, A_y) to the 4 corners of the container
     */
    fun computeStageBubbleGeometry(
        originX: Float,
        originY: Float,
        containerLeft: Float,
        containerTop: Float,
        containerWidth: Float,
        containerHeight: Float
    ): StageBubbleGeometry {
        val safeW = max(containerWidth, 1f)
        val safeH = max(containerHeight, 1f)
        val ax = (originX - containerLeft).coerceIn(0f, safeW)
        val ay = (originY - containerTop).coerceIn(0f, safeH)

        val pivotFractionX = (ax / safeW).coerceIn(0f, 1f)
        val pivotFractionY = (ay / safeH).coerceIn(0f, 1f)

        val targetAtOriginX = containerLeft + ax
        val targetAtOriginY = containerTop + ay
        val tx0 = originX - targetAtOriginX
        val ty0 = originY - targetAtOriginY

        val dTopLeft = hypotDist(0f - ax, 0f - ay)
        val dTopRight = hypotDist(safeW - ax, 0f - ay)
        val dBottomLeft = hypotDist(0f - ax, safeH - ay)
        val dBottomRight = hypotDist(safeW - ax, safeH - ay)
        val maxRadius = max(max(dTopLeft, dTopRight), max(dBottomLeft, dBottomRight))

        return StageBubbleGeometry(
            pivotX = ax,
            pivotY = ay,
            pivotFractionX = pivotFractionX,
            pivotFractionY = pivotFractionY,
            initialTranslationX = tx0,
            initialTranslationY = ty0,
            maxRadius = maxRadius
        )
    }

    /**
     * Center-to-Center Vector Formula for Centered Modals:
     * M_cx = W_v / 2, M_cy = H_v / 2
     * Delta_x = O_x - M_cx, Delta_y = O_y - M_cy
     */
    fun computeModalBubbleGeometry(
        originX: Float,
        originY: Float,
        viewportWidth: Float,
        viewportHeight: Float
    ): ModalBubbleGeometry {
        val mCx = viewportWidth / 2f
        val mCy = viewportHeight / 2f
        return ModalBubbleGeometry(
            modalCenterX = mCx,
            modalCenterY = mCy,
            deltaX = originX - mCx,
            deltaY = originY - mCy
        )
    }

    private fun hypotDist(dx: Float, dy: Float): Float = sqrt(dx * dx + dy * dy)
}
