package com.example.nexora.ui.views

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.nexora.animation.ClickOrigin
import com.example.nexora.animation.StageBubbleContainer
import com.example.nexora.data.CreatorProfile
import com.example.nexora.data.CuratedCollection
import com.example.nexora.data.NexoraSeedData
import com.example.nexora.data.ProfileSubTab
import com.example.nexora.data.VideoItem
import com.example.nexora.network.AkashMediaService
import com.example.nexora.ui.components.CreatorAvatarBadge
import com.example.nexora.ui.components.SpatialVisualCanvas
import com.example.nexora.ui.modals.FollowersSheetModal
import com.example.nexora.ui.modals.SocialListType
import com.example.ui.theme.NexoraColors
import com.example.ui.theme.NexoraTypography
import com.example.ui.theme.PlusJakartaSansFamily
import com.example.ui.theme.liquidGlassAccent
import com.example.ui.theme.liquidGlassCard
import com.example.ui.theme.liquidGlassDarkOverlay
import com.example.ui.theme.liquidGlassWhitePill

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreatorProfileView(
    creator: CreatorProfile,
    isOwnProfile: Boolean,
    isSubscribed: Boolean,
    activeSubTab: ProfileSubTab,
    videosFilter: String,
    creatorVideos: List<VideoItem>,
    collections: List<CuratedCollection>,
    savedVideoIds: Set<String>,
    transitionOrigin: ClickOrigin,
    onBack: () -> Unit,
    onSelectSubTab: (ProfileSubTab) -> Unit,
    onSelectVideosFilter: (String) -> Unit,
    onToggleSubscribe: (String) -> Unit,
    onOpenEditProfile: () -> Unit,
    onOpenAccountCentre: () -> Unit = {},
    onWatchVideo: (VideoItem) -> Unit,
    onEnterLiveRoom: () -> Unit,
    onToggleSave: (String) -> Unit,
    onShareProfile: () -> Unit,
    isRefreshing: Boolean = false,
    onRefresh: () -> Unit = {},
    refreshTrigger: Long = 0L,
    modifier: Modifier = Modifier,
    savedReels: List<VideoItem> = emptyList(),
    likedReels: List<VideoItem> = emptyList(),
    isSavedReelsLoading: Boolean = false,
    isAuthenticated: Boolean = false,
    onSignOut: () -> Unit = {},
    onOpenReelsTab: () -> Unit = {}
) {
    BackHandler { onBack() }

    var isFollowersSheetOpen by remember { mutableStateOf(false) }
    var selectedSocialListType by remember { mutableStateOf(SocialListType.FOLLOWERS) }

    val studioVideos = remember(creatorVideos) {
        creatorVideos.filter { !it.isLiveStream }
    }

    val cleanCreatorName = remember(creator.name) {
        AkashMediaService.cleanEmojis(creator.name).ifBlank { "Akash Creator" }
    }
    val cleanCreatorHandle = remember(creator.handle) {
        val stripped = AkashMediaService.cleanEmojis(creator.handle).ifBlank { "creator" }
        if (stripped.startsWith("@")) stripped else "@$stripped"
    }
    val cleanCreatorBio = remember(creator.bio) {
        AkashMediaService.cleanEmojis(creator.bio)
    }

    val listState = rememberLazyListState()

    LaunchedEffect(refreshTrigger) {
        if (refreshTrigger > 0L) {
            listState.animateScrollToItem(0)
        }
    }

    PullToRefreshBox(
        isRefreshing = isRefreshing,
        onRefresh = onRefresh,
        modifier = modifier.fillMaxSize()
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val screenWidth = maxWidth
            val isDesktop = screenWidth >= 768.dp

            val density = LocalDensity.current
            val viewportSize = remember(maxWidth, maxHeight, density) {
                with(density) {
                    IntSize(maxWidth.roundToPx(), maxHeight.roundToPx())
                }
            }

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("creator_profile_view"),
            contentPadding = PaddingValues(
                start = if (isDesktop) 24.dp else 14.dp,
                end = if (isDesktop) 24.dp else 14.dp,
                top = 12.dp,
                bottom = 104.dp
            ),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Instagram / Sovereign Vault Profile Card (Avatar, Handle, Name, Stats, Bio)
            item(key = "instagram_profile_header_card") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .liquidGlassCard(cornerRadius = 28.dp)
                        .padding(16.dp)
                        .testTag("instagram_profile_card"),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Avatar & Stats Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        CreatorAvatarBadge(
                            name = cleanCreatorName,
                            seed = creator.avatarSeed,
                            avatarUrl = creator.avatarUrl,
                            size = if (isDesktop) 80.dp else 72.dp,
                            isSquircle = false,
                            borderWidth = 2.dp,
                            showOnlineDot = creator.isOnline
                        )

                        // Stat Counters: Reels, Saved, Liked
                        Row(
                            modifier = Modifier.weight(1f),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            InstagramStatTile(
                                value = studioVideos.size.toString(),
                                label = "Reels",
                                onClick = { onSelectSubTab(ProfileSubTab.OVERVIEW) }
                            )

                            InstagramStatTile(
                                value = savedReels.size.toString(),
                                label = "Saved",
                                onClick = { onSelectSubTab(ProfileSubTab.SAVED_REELS) },
                                testTag = "profile_saved_stat"
                            )

                            InstagramStatTile(
                                value = likedReels.size.toString(),
                                label = "Liked",
                                onClick = { onSelectSubTab(ProfileSubTab.LIKED_REELS) },
                                testTag = "profile_liked_stat"
                            )
                        }
                    }

                    // Identity: Display Name & Handle (Zero Emoji Enforced)
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = cleanCreatorName,
                                fontFamily = PlusJakartaSansFamily,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = if (isDesktop) 22.sp else 18.sp,
                                color = NexoraColors.InkPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )

                            if (isOwnProfile && isAuthenticated) {
                                Row(
                                    modifier = Modifier
                                        .liquidGlassAccent(999.dp)
                                        .padding(horizontal = 8.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.VerifiedUser,
                                        contentDescription = "Vault Synced",
                                        tint = NexoraColors.ElectricIndigo,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Text(
                                        text = "Vault Synced",
                                        style = NexoraTypography.BadgeMicro.copy(
                                            color = NexoraColors.InkAccent,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }
                        }

                        Text(
                            text = cleanCreatorHandle,
                            style = NexoraTypography.MetaCaption.copy(
                                color = NexoraColors.InkSecondary,
                                fontWeight = FontWeight.Bold
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Location & Category Row
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .liquidGlassAccent(999.dp)
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.LocationOn,
                                contentDescription = "Location",
                                tint = NexoraColors.InkAccent,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = AkashMediaService.cleanEmojis(
                                    if (creator.location.isBlank()) creator.country else creator.location
                                ),
                                style = NexoraTypography.BadgeMicro.copy(color = NexoraColors.InkAccent)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .liquidGlassWhitePill(999.dp)
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = AkashMediaService.cleanEmojis(creator.category),
                                style = NexoraTypography.BadgeMicro.copy(color = NexoraColors.InkSecondary)
                            )
                        }
                    }

                    // Biography Section
                    if (cleanCreatorBio.isNotBlank()) {
                        Text(
                            text = cleanCreatorBio,
                            style = NexoraTypography.BodyRegular.copy(fontSize = 13.5.sp),
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }

                    // Action Controls Cluster
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_action_controls_row"),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .liquidGlassWhitePill(999.dp)
                                    .clickable { onShareProfile() }
                                    .testTag("social_website_btn"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Language,
                                    contentDescription = "Website",
                                    tint = NexoraColors.InkSecondary,
                                    modifier = Modifier.size(17.dp)
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .liquidGlassWhitePill(999.dp)
                                    .clickable { onShareProfile() }
                                    .testTag("social_share_btn"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Share,
                                    contentDescription = "Social Link",
                                    tint = NexoraColors.InkSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (isOwnProfile) {
                                // Pencil Edit Button
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .liquidGlassAccent(999.dp)
                                        .clickable { onOpenEditProfile() }
                                        .testTag("edit_profile_btn"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Edit,
                                        contentDescription = "Edit Profile",
                                        tint = NexoraColors.InkAccent,
                                        modifier = Modifier.size(17.dp)
                                    )
                                }

                                if (isAuthenticated) {
                                    Box(
                                        modifier = Modifier
                                            .size(38.dp)
                                            .liquidGlassWhitePill(999.dp)
                                            .clickable { onSignOut() }
                                            .testTag("profile_sign_out_btn"),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.Logout,
                                            contentDescription = "Sign Out",
                                            tint = NexoraColors.LiveRose,
                                            modifier = Modifier.size(17.dp)
                                        )
                                    }
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .height(38.dp)
                                        .then(
                                            if (isSubscribed) {
                                                Modifier.liquidGlassAccent(999.dp)
                                            } else {
                                                Modifier
                                                    .clip(CircleShape)
                                                    .background(NexoraColors.ElectricIndigo)
                                            }
                                        )
                                        .clickable { onToggleSubscribe(creator.id) }
                                        .padding(horizontal = 16.dp)
                                        .testTag("profile_subscribe_btn"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = if (isSubscribed) Icons.Filled.Check else Icons.Filled.PersonAdd,
                                            contentDescription = if (isSubscribed) "Following" else "Follow",
                                            tint = if (isSubscribed) NexoraColors.InkAccent else Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = if (isSubscribed) "Following" else "Follow",
                                            style = NexoraTypography.NavPillLabel.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSubscribed) NexoraColors.InkAccent else Color.White
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 2. Equal Spaced Profile Subtabs Row (Reels, and owner-only Saved Reels / Liked Reels)
            item(key = "equal_spaced_profile_tabs") {
                val visibleTabs = if (isOwnProfile) {
                    ProfileSubTab.entries
                } else {
                    listOf(ProfileSubTab.OVERVIEW)
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("profile_tabs_row"),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    visibleTabs.forEach { tab ->
                        val isSelected = tab == activeSubTab
                        val tabIcon = when (tab) {
                            ProfileSubTab.OVERVIEW -> Icons.Filled.GridOn
                            ProfileSubTab.SAVED_REELS -> Icons.Filled.Bookmark
                            ProfileSubTab.LIKED_REELS -> Icons.Filled.Favorite
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp)
                                .then(
                                    if (isSelected) Modifier.liquidGlassAccent(999.dp)
                                    else Modifier.liquidGlassWhitePill(999.dp)
                                )
                                .clickable { onSelectSubTab(tab) }
                                .testTag("profile_tab_${tab.name.lowercase()}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = tabIcon,
                                    contentDescription = tab.label,
                                    tint = if (isSelected) NexoraColors.InkAccent else NexoraColors.InkSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = tab.label,
                                    style = NexoraTypography.NavPillLabel.copy(
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) NexoraColors.InkAccent else NexoraColors.InkSecondary
                                    ),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }

            // 3. Tab Content Panels (Reels Grid, Saved Reels Grid, Liked Reels Grid)
            item(key = "profile_tab_stage_${activeSubTab.name}") {
                StageBubbleContainer(
                    triggerKey = activeSubTab,
                    origin = transitionOrigin
                ) {
                    when (activeSubTab) {
                        ProfileSubTab.OVERVIEW -> {
                            SovereignReelsGridContent(
                                videos = studioVideos,
                                emptyTitle = "No Reels Published Yet",
                                emptySubtitle = "Vertical short videos from the Akash Sovereign feed will appear here.",
                                onWatchVideo = onWatchVideo,
                                onExploreReels = onOpenReelsTab
                            )
                        }

                        ProfileSubTab.SAVED_REELS -> {
                            if (isSavedReelsLoading && savedReels.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 48.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CircularProgressIndicator(
                                        color = NexoraColors.ElectricIndigo,
                                        strokeWidth = 2.5.dp,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            } else {
                                SovereignReelsGridContent(
                                    videos = savedReels,
                                    emptyTitle = "No Saved Reels Yet",
                                    emptySubtitle = "Tap the Bookmark icon on any Reel to save it to your Akash Sovereign User Vault.",
                                    onWatchVideo = onWatchVideo,
                                    onExploreReels = onOpenReelsTab
                                )
                            }
                        }

                        ProfileSubTab.LIKED_REELS -> {
                            SovereignReelsGridContent(
                                videos = likedReels,
                                emptyTitle = "No Liked Reels Yet",
                                emptySubtitle = "Double-tap or tap the Heart icon on any Reel to add it to your Liked Reels.",
                                onWatchVideo = onWatchVideo,
                                onExploreReels = onOpenReelsTab
                            )
                        }
                    }
                }
            }
        }

        // 4. Followers / Following Bottom Sheet Modal
        FollowersSheetModal(
            visible = isFollowersSheetOpen,
            listType = selectedSocialListType,
            creators = NexoraSeedData.creators,
            subscribedCreatorIds = setOf("creator_aether", "creator_kurogane"),
            origin = transitionOrigin,
            viewportSize = viewportSize,
            onDismiss = { isFollowersSheetOpen = false },
            onToggleSubscribe = onToggleSubscribe,
            onSelectCreator = { _ ->
                isFollowersSheetOpen = false
            }
        )
    }
}
}

@Composable
private fun InstagramStatTile(
    value: String,
    label: String,
    onClick: () -> Unit,
    testTag: String? = null
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .then(if (testTag != null) Modifier.testTag(testTag) else Modifier)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(1.dp)
    ) {
        Text(
            text = value,
            fontFamily = PlusJakartaSansFamily,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 17.sp,
            color = NexoraColors.InkPrimary
        )
        Text(
            text = label,
            style = NexoraTypography.MetaCaption.copy(
                fontSize = 11.5.sp,
                color = NexoraColors.InkSecondary
            )
        )
    }
}

@Composable
private fun SovereignReelsGridContent(
    videos: List<VideoItem>,
    emptyTitle: String,
    emptySubtitle: String,
    onWatchVideo: (VideoItem) -> Unit,
    onExploreReels: () -> Unit
) {
    val context = LocalContext.current
    if (videos.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .liquidGlassCard(24.dp)
                .padding(horizontal = 24.dp, vertical = 36.dp)
                .testTag("profile_empty_reels_grid"),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = emptyTitle,
                style = NexoraTypography.CardTitle.copy(
                    fontSize = 16.sp,
                    color = NexoraColors.InkPrimary
                ),
                textAlign = TextAlign.Center
            )
            Text(
                text = emptySubtitle,
                style = NexoraTypography.MetaCaption.copy(
                    fontSize = 13.sp,
                    color = NexoraColors.InkSecondary
                ),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .liquidGlassAccent(999.dp)
                    .clickable { onExploreReels() }
                    .padding(horizontal = 18.dp, vertical = 9.dp)
                    .testTag("profile_explore_reels_btn"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Explore Reels Feed",
                    style = NexoraTypography.NavPillLabel.copy(
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = NexoraColors.InkAccent
                    )
                )
            }
        }
        return
    }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        videos.chunked(3).forEach { rowItems ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                rowItems.forEach { video ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(9f / 16f)
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { onWatchVideo(video) }
                            .testTag("instagram_grid_item_${video.id}")
                    ) {
                        SpatialVisualCanvas(preset = video.visualPreset, isAnimated = false)

                        val thumbUrl = video.effectiveThumbnailUrl
                        if (!thumbUrl.isNullOrBlank()) {
                            AsyncImage(
                                model = ImageRequest.Builder(context)
                                    .data(thumbUrl)
                                    .crossfade(true)
                                    .build(),
                                contentDescription = video.cleanTitle,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color.Transparent,
                                            Color(0x440F172A),
                                            Color(0xCC0F172A)
                                        )
                                    )
                                )
                        )

                        // Top Right Play Badge
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(6.dp)
                                .size(22.dp)
                                .liquidGlassDarkOverlay(999.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.PlayArrow,
                                contentDescription = "Play Reel",
                                tint = Color.White,
                                modifier = Modifier.size(12.dp)
                            )
                        }

                        // Bottom Overlay Creator Handle + Views Counter
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text(
                                text = video.formattedCreatorHandle,
                                style = NexoraTypography.BadgeMicro.copy(
                                    fontSize = 10.sp,
                                    color = Color.White.copy(alpha = 0.9f),
                                    fontWeight = FontWeight.Bold
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = video.viewsText,
                                style = NexoraTypography.BadgeMicro.copy(
                                    fontSize = 9.5.sp,
                                    color = Color.White.copy(alpha = 0.78f),
                                    fontWeight = FontWeight.Medium
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                repeat(3 - rowItems.size) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}
