package com.example.nexora.ui.modals

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import com.example.nexora.data.VisualThemePreset
import com.example.nexora.ui.components.SpatialVisualCanvas
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

internal enum class InstagramFilterCategory(val label: String) {
    ALL("All"),
    CINEMATIC("Cinematic"),
    ANALOG_FILM("Film"),
    SPATIAL_SHADERS("Spatial"),
    EDITORIAL("Editorial"),
    ESSENTIALS("Classic"),
    SAVED("Saved")
}

internal enum class InstagramSplitTonePreset(
    val label: String,
    val highlightColor: Color,
    val shadowColor: Color
) {
    NONE("Neutral", Color.Transparent, Color.Transparent),
    GOLD_TEAL("Gold / Teal", Color(0xFFFFB74D), Color(0xFF00ACC1)),
    CYBER_NEON("Cyber / Cyan", Color(0xFFFF4081), Color(0xFF00E5FF)),
    AMBER_EMERALD("Amber / Jade", Color(0xFFFFA726), Color(0xFF26A69A)),
    LAVENDER_SLATE("Iris / Slate", Color(0xFFB388FF), Color(0xFF3949AB))
}

internal enum class InstagramFilterPreset(
    val label: String,
    val subtitle: String,
    val category: InstagramFilterCategory,
    val contrastScale: Float = 1f,
    val saturationScale: Float = 1f,
    val rScale: Float = 1f,
    val gScale: Float = 1f,
    val bScale: Float = 1f,
    val rOffset: Float = 0f,
    val gOffset: Float = 0f,
    val bOffset: Float = 0f,
    val monochromeMix: Float = 0f,
    val fadeLift: Float = 0f,
    val grainAmount: Float = 0f,
    val halationIntensity: Float = 0f,
    val chromaticShift: Float = 0f,
    val scanlineIntensity: Float = 0f,
    val anamorphicStreak: Float = 0f,
    val naturalVignette: Float = 0f,
    val tintColor: Color = Color.Transparent,
    val tintAlpha: Float = 0f,
    val secondaryTintColor: Color = Color.Transparent
) {
    // 1. Classic & Essentials
    NORMAL(
        label = "Normal",
        subtitle = "Original Optical",
        category = InstagramFilterCategory.ESSENTIALS
    ),
    CLARENDON(
        label = "Clarendon",
        subtitle = "Crisp Cyan & Punch",
        category = InstagramFilterCategory.ESSENTIALS,
        contrastScale = 1.18f,
        saturationScale = 1.22f,
        rScale = 0.96f,
        gScale = 1.04f,
        bScale = 1.14f,
        tintColor = Color(0xFF38BDF8),
        tintAlpha = 0.14f
    ),
    JUNO(
        label = "Juno",
        subtitle = "Warm Citrus Glow",
        category = InstagramFilterCategory.ESSENTIALS,
        contrastScale = 1.14f,
        saturationScale = 1.28f,
        rScale = 1.10f,
        gScale = 1.04f,
        bScale = 0.92f,
        rOffset = 8f,
        gOffset = 4f,
        tintColor = Color(0xFFF59E0B),
        tintAlpha = 0.14f
    ),
    LARK(
        label = "Lark",
        subtitle = "Airy Lifted Verdant",
        category = InstagramFilterCategory.ESSENTIALS,
        contrastScale = 0.95f,
        saturationScale = 1.10f,
        rScale = 0.98f,
        gScale = 1.08f,
        bScale = 1.06f,
        fadeLift = 14f,
        tintColor = Color(0xFF34D399),
        tintAlpha = 0.12f
    ),
    PRISM(
        label = "Prism",
        subtitle = "Iridescent Violet",
        category = InstagramFilterCategory.ESSENTIALS,
        contrastScale = 1.10f,
        saturationScale = 1.25f,
        rScale = 1.06f,
        gScale = 0.96f,
        bScale = 1.16f,
        tintColor = Color(0xFFA855F7),
        tintAlpha = 0.18f
    ),

    // 2. Cinematic LUTs
    TEAL_ORANGE(
        label = "Teal & Orange",
        subtitle = "LUT · Blockbuster",
        category = InstagramFilterCategory.CINEMATIC,
        contrastScale = 1.22f,
        saturationScale = 1.18f,
        rScale = 1.14f,
        gScale = 1.01f,
        bScale = 1.12f,
        rOffset = 6f,
        gOffset = -3f,
        bOffset = 10f,
        naturalVignette = 0.28f,
        tintColor = Color(0xFFFF8A3D),
        tintAlpha = 0.18f,
        secondaryTintColor = Color(0xFF0097A7)
    ),
    BLEACH_BYPASS(
        label = "Bleach Bypass",
        subtitle = "LUT · Silver Retention",
        category = InstagramFilterCategory.CINEMATIC,
        contrastScale = 1.38f,
        saturationScale = 0.42f,
        rScale = 1.02f,
        gScale = 1.04f,
        bScale = 1.08f,
        rOffset = -12f,
        gOffset = -10f,
        bOffset = -6f,
        grainAmount = 0.35f,
        naturalVignette = 0.36f,
        tintColor = Color(0xFF64748B),
        tintAlpha = 0.16f
    ),
    ANAMORPHIC(
        label = "Anamorphic",
        subtitle = "LUT · Streak Flare",
        category = InstagramFilterCategory.CINEMATIC,
        contrastScale = 1.16f,
        saturationScale = 1.12f,
        rScale = 0.94f,
        gScale = 1.02f,
        bScale = 1.20f,
        bOffset = 14f,
        anamorphicStreak = 0.85f,
        naturalVignette = 0.25f,
        tintColor = Color(0xFF3B82F6),
        tintAlpha = 0.18f,
        secondaryTintColor = Color(0xFF8B5CF6)
    ),
    NOIR_70MM(
        label = "Noir 70mm",
        subtitle = "LUT · Silver Halide",
        category = InstagramFilterCategory.CINEMATIC,
        contrastScale = 1.34f,
        saturationScale = 0.0f,
        monochromeMix = 1.0f,
        rOffset = -10f,
        gOffset = -10f,
        bOffset = -8f,
        grainAmount = 0.42f,
        naturalVignette = 0.45f,
        tintColor = Color(0xFF0F172A),
        tintAlpha = 0.24f
    ),

    // 3. Analog Film Stocks
    KODAK_PORTRA(
        label = "Portra 400",
        subtitle = "Film · Golden Pastel",
        category = InstagramFilterCategory.ANALOG_FILM,
        contrastScale = 1.04f,
        saturationScale = 1.12f,
        rScale = 1.10f,
        gScale = 1.05f,
        bScale = 0.94f,
        rOffset = 12f,
        gOffset = 8f,
        bOffset = 2f,
        fadeLift = 12f,
        grainAmount = 0.32f,
        tintColor = Color(0xFFFBBF24),
        tintAlpha = 0.14f
    ),
    FUJI_VELVIA(
        label = "Velvia 50",
        subtitle = "Film · Vivid Chroma",
        category = InstagramFilterCategory.ANALOG_FILM,
        contrastScale = 1.26f,
        saturationScale = 1.52f,
        rScale = 1.12f,
        gScale = 1.10f,
        bScale = 1.14f,
        rOffset = -6f,
        gOffset = -4f,
        bOffset = -4f,
        grainAmount = 0.18f,
        naturalVignette = 0.22f,
        tintColor = Color(0xFF10B981),
        tintAlpha = 0.14f,
        secondaryTintColor = Color(0xFFEC4899)
    ),
    ILFORD_HP5(
        label = "Ilford B&W",
        subtitle = "Film · 400 ISO Mono",
        category = InstagramFilterCategory.ANALOG_FILM,
        contrastScale = 1.22f,
        saturationScale = 0.0f,
        monochromeMix = 1.0f,
        fadeLift = 10f,
        grainAmount = 0.68f,
        naturalVignette = 0.32f,
        tintColor = Color(0xFF334155),
        tintAlpha = 0.18f
    ),
    CINESTILL_800T(
        label = "CineStill 800T",
        subtitle = "Film · Tungsten Halation",
        category = InstagramFilterCategory.ANALOG_FILM,
        contrastScale = 1.18f,
        saturationScale = 1.16f,
        rScale = 1.06f,
        gScale = 0.98f,
        bScale = 1.18f,
        rOffset = 6f,
        bOffset = 14f,
        grainAmount = 0.45f,
        halationIntensity = 0.88f,
        naturalVignette = 0.28f,
        tintColor = Color(0xFFFF3D00),
        tintAlpha = 0.18f,
        secondaryTintColor = Color(0xFF00B0FF)
    ),

    // 4. Atmospheric & Spatial Shaders
    CYBER_DUOTONE(
        label = "Duotone",
        subtitle = "Shader · Neon Split",
        category = InstagramFilterCategory.SPATIAL_SHADERS,
        contrastScale = 1.28f,
        saturationScale = 0.55f,
        rScale = 1.22f,
        gScale = 0.85f,
        bScale = 1.28f,
        rOffset = 14f,
        bOffset = 22f,
        tintColor = Color(0xFFEC4899),
        tintAlpha = 0.28f,
        secondaryTintColor = Color(0xFF06B6D4)
    ),
    CHROMATIC_SHIFT(
        label = "Chromatic",
        subtitle = "Shader · RGB Prism",
        category = InstagramFilterCategory.SPATIAL_SHADERS,
        contrastScale = 1.15f,
        saturationScale = 1.30f,
        rScale = 1.08f,
        gScale = 1.02f,
        bScale = 1.14f,
        chromaticShift = 0.92f,
        tintColor = Color(0xFF6366F1),
        tintAlpha = 0.16f,
        secondaryTintColor = Color(0xFFF43F5E)
    ),
    HALATION_BLOOM(
        label = "Halation",
        subtitle = "Shader · Ruby Diffusion",
        category = InstagramFilterCategory.SPATIAL_SHADERS,
        contrastScale = 1.08f,
        saturationScale = 1.20f,
        rScale = 1.16f,
        gScale = 1.02f,
        bScale = 0.96f,
        rOffset = 14f,
        fadeLift = 8f,
        halationIntensity = 1.0f,
        grainAmount = 0.25f,
        tintColor = Color(0xFFFF5252),
        tintAlpha = 0.20f,
        secondaryTintColor = Color(0xFFFFAB40)
    ),
    VHS_1994(
        label = "VHS 1994",
        subtitle = "Shader · Analog Tape",
        category = InstagramFilterCategory.SPATIAL_SHADERS,
        contrastScale = 0.92f,
        saturationScale = 1.24f,
        rScale = 1.08f,
        gScale = 0.96f,
        bScale = 1.12f,
        fadeLift = 20f,
        grainAmount = 0.52f,
        chromaticShift = 0.65f,
        scanlineIntensity = 0.90f,
        tintColor = Color(0xFF8B5CF6),
        tintAlpha = 0.16f
    ),

    // 5. Editorial & Architectural
    NORDIC_MATTE(
        label = "Nordic Matte",
        subtitle = "Editorial · Slate Fade",
        category = InstagramFilterCategory.EDITORIAL,
        contrastScale = 0.88f,
        saturationScale = 0.68f,
        rScale = 0.94f,
        gScale = 1.00f,
        bScale = 1.08f,
        fadeLift = 24f,
        grainAmount = 0.16f,
        tintColor = Color(0xFF94A3B8),
        tintAlpha = 0.18f
    ),
    HIGH_KEY_ALABASTER(
        label = "Alabaster",
        subtitle = "Editorial · High-Key",
        category = InstagramFilterCategory.EDITORIAL,
        contrastScale = 0.94f,
        saturationScale = 0.82f,
        rScale = 1.06f,
        gScale = 1.07f,
        bScale = 1.10f,
        rOffset = 20f,
        gOffset = 22f,
        bOffset = 26f,
        fadeLift = 16f,
        tintColor = Color(0xFFE2E8F0),
        tintAlpha = 0.22f
    ),
    BRUTALIST_MONO(
        label = "Brutalist Mono",
        subtitle = "Editorial · Graphite",
        category = InstagramFilterCategory.EDITORIAL,
        contrastScale = 1.44f,
        saturationScale = 0.0f,
        monochromeMix = 1.0f,
        rOffset = -14f,
        gOffset = -12f,
        bOffset = -10f,
        grainAmount = 0.28f,
        naturalVignette = 0.30f,
        tintColor = Color(0xFF1E293B),
        tintAlpha = 0.22f
    )
}

internal enum class InstagramAdjustmentChannel(
    val label: String,
    val minVal: Float,
    val maxVal: Float,
    val defaultVal: Float = 0f
) {
    BRIGHTNESS("Brightness", -50f, 50f, 0f),
    CONTRAST("Contrast", -50f, 50f, 0f),
    HIGHLIGHTS("Highlights", -50f, 50f, 0f),
    SHADOWS("Shadows", -50f, 50f, 0f),
    WARMTH("Warmth", -50f, 50f, 0f),
    SATURATION("Saturation", -50f, 50f, 0f),
    SHARPNESS("Sharpness", 0f, 100f, 0f),
    GRAIN("Grain", 0f, 100f, 0f),
    FADE("Fade", 0f, 100f, 0f),
    VIGNETTE("Vignette", 0f, 100f, 0f)
}

internal data class InstagramAdjustmentState(
    val brightness: Float = 0f,
    val contrast: Float = 0f,
    val highlights: Float = 0f,
    val shadows: Float = 0f,
    val warmth: Float = 0f,
    val saturation: Float = 0f,
    val sharpness: Float = 0f,
    val grain: Float = 0f,
    val fade: Float = 0f,
    val vignette: Float = 0f,
    val isLuxEnabled: Boolean = false,
    val splitTone: InstagramSplitTonePreset = InstagramSplitTonePreset.NONE
) {
    fun getValue(channel: InstagramAdjustmentChannel): Float = when (channel) {
        InstagramAdjustmentChannel.BRIGHTNESS -> brightness
        InstagramAdjustmentChannel.CONTRAST -> contrast
        InstagramAdjustmentChannel.HIGHLIGHTS -> highlights
        InstagramAdjustmentChannel.SHADOWS -> shadows
        InstagramAdjustmentChannel.WARMTH -> warmth
        InstagramAdjustmentChannel.SATURATION -> saturation
        InstagramAdjustmentChannel.SHARPNESS -> sharpness
        InstagramAdjustmentChannel.GRAIN -> grain
        InstagramAdjustmentChannel.FADE -> fade
        InstagramAdjustmentChannel.VIGNETTE -> vignette
    }

    fun withValue(channel: InstagramAdjustmentChannel, newValue: Float): InstagramAdjustmentState = when (channel) {
        InstagramAdjustmentChannel.BRIGHTNESS -> copy(brightness = newValue)
        InstagramAdjustmentChannel.CONTRAST -> copy(contrast = newValue)
        InstagramAdjustmentChannel.HIGHLIGHTS -> copy(highlights = newValue)
        InstagramAdjustmentChannel.SHADOWS -> copy(shadows = newValue)
        InstagramAdjustmentChannel.WARMTH -> copy(warmth = newValue)
        InstagramAdjustmentChannel.SATURATION -> copy(saturation = newValue)
        InstagramAdjustmentChannel.SHARPNESS -> copy(sharpness = newValue)
        InstagramAdjustmentChannel.GRAIN -> copy(grain = newValue)
        InstagramAdjustmentChannel.FADE -> copy(fade = newValue)
        InstagramAdjustmentChannel.VIGNETTE -> copy(vignette = newValue)
    }

    fun isModified(channel: InstagramAdjustmentChannel): Boolean {
        return abs(getValue(channel) - channel.defaultVal) >= 1f
    }

    fun hasAnyModifications(): Boolean {
        return InstagramAdjustmentChannel.entries.any { isModified(it) } ||
            isLuxEnabled ||
            splitTone != InstagramSplitTonePreset.NONE
    }

    fun modifiedChannelCount(): Int {
        val sliderMods = InstagramAdjustmentChannel.entries.count { isModified(it) }
        val splitMod = if (splitTone != InstagramSplitTonePreset.NONE) 1 else 0
        val luxMod = if (isLuxEnabled) 1 else 0
        return sliderMods + splitMod + luxMod
    }
}

internal data class CustomUserFilterPreset(
    val id: String,
    val name: String,
    val baseFilter: InstagramFilterPreset,
    val filterStrength: Float,
    val adjustments: InstagramAdjustmentState
)

internal fun buildCombinedColorMatrix(
    filter: InstagramFilterPreset,
    strengthPercent: Float,
    adjustments: InstagramAdjustmentState
): ColorMatrix {
    val t = (strengthPercent / 100f).coerceIn(0f, 1f)

    // 1. Interpolate filter parameters with identity by strength `t`
    val fContrast = 1f + (filter.contrastScale - 1f) * t
    val fSaturation = 1f + (filter.saturationScale - 1f) * t
    val fRScale = 1f + (filter.rScale - 1f) * t
    val fGScale = 1f + (filter.gScale - 1f) * t
    val fBScale = 1f + (filter.bScale - 1f) * t
    val fROffset = filter.rOffset * t
    val fGOffset = filter.gOffset * t
    val fBOffset = filter.bOffset * t
    val fFadeLift = filter.fadeLift * t
    val fMonoMix = filter.monochromeMix * t

    // 2. Manual adjustment factors
    val luxBoost = if (adjustments.isLuxEnabled) 0.14f else 0f
    val adjContrast = 1f + (adjustments.contrast / 100f) + (adjustments.highlights / 220f) +
        (adjustments.sharpness / 360f) + luxBoost
    val totalContrast = (fContrast * adjContrast).coerceIn(0.35f, 2.35f)

    val adjSaturation = 1f + (adjustments.saturation / 75f) + (luxBoost * 0.5f)
    val totalSaturation = (fSaturation * adjSaturation).coerceIn(0f, 2.5f)

    val fadeOffset = (adjustments.fade * 0.42f) + fFadeLift
    val fadeScale = 1f - (adjustments.fade / 360f)

    val brightnessOffset = (adjustments.brightness * 1.45f) +
        (adjustments.shadows * 0.65f) +
        (adjustments.highlights * 0.35f) +
        fadeOffset

    val warmthR = (adjustments.warmth * 0.55f) + (if (adjustments.isLuxEnabled) 4f else 0f)
    val warmthG = (adjustments.warmth * 0.16f)
    val warmthB = -(adjustments.warmth * 0.58f)

    // 3. Base Saturation Matrix (with optional high-contrast monochrome blend)
    val satMatrix = ColorMatrix().apply {
        setToSaturation(totalSaturation * (1f - fMonoMix))
    }

    // 4. Contrast + Channel Balance + Offsets Matrix
    val contrastTranslate = (1f - totalContrast) * 128f
    val rMult = fRScale * totalContrast * fadeScale
    val gMult = fGScale * totalContrast * fadeScale
    val bMult = fBScale * totalContrast * fadeScale

    val rTrans = contrastTranslate + fROffset + brightnessOffset + warmthR
    val gTrans = contrastTranslate + fGOffset + brightnessOffset + warmthG
    val bTrans = contrastTranslate + fBOffset + brightnessOffset + warmthB

    val gradeMatrix = ColorMatrix(
        floatArrayOf(
            rMult, 0f, 0f, 0f, rTrans,
            0f, gMult, 0f, 0f, gTrans,
            0f, 0f, bMult, 0f, bTrans,
            0f, 0f, 0f, 1f, 0f
        )
    )

    gradeMatrix.timesAssign(satMatrix)
    return gradeMatrix
}

@Composable
internal fun InstagramFilteredMediaViewport(
    activePreset: VisualThemePreset,
    pickedUriString: String?,
    filter: InstagramFilterPreset,
    filterStrength: Float = 100f,
    adjustments: InstagramAdjustmentState = InstagramAdjustmentState(),
    isAnimated: Boolean = true,
    isThumbnail: Boolean = false,
    bypassGrading: Boolean = false,
    modifier: Modifier = Modifier
) {
    val combinedMatrix = remember(filter, filterStrength, adjustments) {
        buildCombinedColorMatrix(filter, filterStrength, adjustments)
    }
    val layerPaint = remember { Paint() }
    val strengthFactor = (filterStrength / 100f).coerceIn(0f, 1f)

    Box(
        modifier = modifier
            .fillMaxSize()
            .drawWithContent {
                val applyGrade = !bypassGrading && (
                    filter != InstagramFilterPreset.NORMAL ||
                        adjustments.hasAnyModifications()
                    )

                if (applyGrade) {
                    layerPaint.colorFilter = ColorFilter.colorMatrix(combinedMatrix)
                    drawIntoCanvas { canvas ->
                        canvas.saveLayer(Rect(0f, 0f, size.width, size.height), layerPaint)
                        drawContent()
                        canvas.restore()
                    }
                    drawOpticalShaderOverlays(
                        filter = filter,
                        strength = strengthFactor,
                        adjustments = adjustments,
                        isThumbnail = isThumbnail
                    )
                } else {
                    drawContent()
                }
            }
    ) {
        if (pickedUriString != null) {
            AsyncImage(
                model = pickedUriString,
                contentDescription = "Selected media",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            SpatialVisualCanvas(
                preset = activePreset,
                isAnimated = isAnimated
            )
        }
    }
}

private fun DrawScope.drawOpticalShaderOverlays(
    filter: InstagramFilterPreset,
    strength: Float,
    adjustments: InstagramAdjustmentState,
    isThumbnail: Boolean
) {
    val w = size.width
    val h = size.height
    val maxDim = w.coerceAtLeast(h)

    // 1. Primary / Secondary Filter Optical Tint & Duotone Gradient
    val effectiveTintAlpha = (filter.tintAlpha * strength).coerceIn(0f, 0.55f)
    if (effectiveTintAlpha > 0.01f && filter.tintColor != Color.Transparent) {
        if (filter.secondaryTintColor != Color.Transparent) {
            drawRect(
                brush = Brush.linearGradient(
                    colors = listOf(
                        filter.tintColor.copy(alpha = effectiveTintAlpha),
                        filter.secondaryTintColor.copy(alpha = effectiveTintAlpha * 0.92f)
                    ),
                    start = Offset(0f, 0f),
                    end = Offset(w, h)
                )
            )
        } else {
            drawRect(color = filter.tintColor.copy(alpha = effectiveTintAlpha))
        }
    }

    // 2. Pro Split-Tone Highlight & Shadow Wash
    if (adjustments.splitTone != InstagramSplitTonePreset.NONE) {
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    adjustments.splitTone.highlightColor.copy(alpha = 0.18f),
                    Color.Transparent,
                    adjustments.splitTone.shadowColor.copy(alpha = 0.22f)
                )
            )
        )
    }

    // 3. Halation Bloom (CineStill 800T & Halation Bloom)
    val halation = (filter.halationIntensity * strength).coerceIn(0f, 1f)
    if (halation > 0.05f) {
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color(0xFFFF3D00).copy(alpha = 0.30f * halation),
                    Color(0xFFFF9100).copy(alpha = 0.14f * halation),
                    Color.Transparent
                ),
                center = Offset(w * 0.72f, h * 0.26f),
                radius = maxDim * 0.58f
            ),
            radius = maxDim * 0.58f,
            center = Offset(w * 0.72f, h * 0.26f)
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color(0xFFFF1744).copy(alpha = 0.22f * halation),
                    Color.Transparent
                ),
                center = Offset(w * 0.24f, h * 0.68f),
                radius = maxDim * 0.45f
            ),
            radius = maxDim * 0.45f,
            center = Offset(w * 0.24f, h * 0.68f)
        )
    }

    // 4. Horizontal Anamorphic Cinema Lens Streak
    val streak = (filter.anamorphicStreak * strength).coerceIn(0f, 1f)
    if (streak > 0.05f) {
        val streakY = h * 0.38f
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color.Transparent,
                    Color(0xFF38BDF8).copy(alpha = 0.28f * streak),
                    Color(0xFFE0F2FE).copy(alpha = 0.44f * streak),
                    Color(0xFF818CF8).copy(alpha = 0.28f * streak),
                    Color.Transparent
                ),
                startY = streakY - h * 0.07f,
                endY = streakY + h * 0.07f
            )
        )
    }

    // 5. Chromatic Aberration / RGB Edge Dispersion
    val chroma = (filter.chromaticShift * strength).coerceIn(0f, 1f)
    if (chroma > 0.05f) {
        val rimWidth = (if (isThumbnail) 3f else 8f) * chroma
        // Left/Top Cyan Rim
        drawRect(
            brush = Brush.horizontalGradient(
                colors = listOf(
                    Color(0xFF00E5FF).copy(alpha = 0.38f * chroma),
                    Color.Transparent
                ),
                startX = 0f,
                endX = w * 0.14f
            )
        )
        // Right/Bottom Crimson-Magenta Rim
        drawRect(
            brush = Brush.horizontalGradient(
                colors = listOf(
                    Color.Transparent,
                    Color(0xFFFF1744).copy(alpha = 0.38f * chroma)
                ),
                startX = w * 0.86f,
                endX = w
            )
        )
        drawRect(
            color = Color(0xFF00E5FF).copy(alpha = 0.24f * chroma),
            style = Stroke(width = rimWidth)
        )
    }

    // 6. VHS 1994 CRT Scanlines & Tracking Glitch Line
    val scanlines = (filter.scanlineIntensity * strength).coerceIn(0f, 1f)
    if (scanlines > 0.05f) {
        val stepPx = if (isThumbnail) 5f else 6.5f
        var y = 0f
        while (y < h) {
            drawLine(
                color = Color.Black.copy(alpha = 0.18f * scanlines),
                start = Offset(0f, y),
                end = Offset(w, y),
                strokeWidth = 1.4f
            )
            y += stepPx
        }
        // Subtle VHS phosphor tracking bar near bottom
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color.Transparent,
                    Color.White.copy(alpha = 0.18f * scanlines),
                    Color(0xFF38BDF8).copy(alpha = 0.14f * scanlines),
                    Color.Transparent
                ),
                startY = h * 0.82f,
                endY = h * 0.88f
            )
        )
    }

    // 7. Procedural Analog Film Grain (Deterministic Silver-Halide Particles)
    val totalGrain = ((filter.grainAmount * strength) + (adjustments.grain / 100f)).coerceIn(0f, 1.2f)
    if (totalGrain > 0.04f) {
        val particleCount = if (isThumbnail) 36 else 135
        val baseAlpha = (totalGrain * 0.22f).coerceIn(0.03f, 0.28f)
        for (i in 0 until particleCount) {
            val seed = (i + 1) * 7919
            val gx = ((abs(sin(seed * 0.173f))) * w)
            val gy = ((abs(cos(seed * 0.291f))) * h)
            val isBrightSpeck = (i % 3 == 0)
            drawCircle(
                color = if (isBrightSpeck) {
                    Color.White.copy(alpha = baseAlpha * 0.9f)
                } else {
                    Color(0xFF0F172A).copy(alpha = baseAlpha)
                },
                radius = if (isThumbnail) 1.0f else 1.45f,
                center = Offset(gx, gy)
            )
        }
    }

    // 8. Sharpness / Lux Micro-Contrast Specular Accent
    val acutance = ((adjustments.sharpness / 100f) + if (adjustments.isLuxEnabled) 0.35f else 0f)
        .coerceIn(0f, 1f)
    if (acutance > 0.05f && !isThumbnail) {
        drawRect(
            color = Color.White.copy(alpha = 0.16f * acutance),
            style = Stroke(width = 1.5f)
        )
    }

    // 9. Radial Optical Vignette
    val totalVignette = ((filter.naturalVignette * strength) + (adjustments.vignette / 100f))
        .coerceIn(0f, 1f)
    if (totalVignette > 0.03f) {
        drawRect(
            brush = Brush.radialGradient(
                colorStops = arrayOf(
                    0.0f to Color.Transparent,
                    0.52f to Color.Transparent,
                    1.0f to Color(0xFF060916).copy(alpha = (0.72f * totalVignette).coerceAtMost(0.78f))
                ),
                center = Offset(w * 0.5f, h * 0.5f),
                radius = maxDim * 0.68f
            )
        )
    }
}
