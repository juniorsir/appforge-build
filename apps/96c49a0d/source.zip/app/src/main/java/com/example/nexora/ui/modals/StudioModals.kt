package com.example.nexora.ui.modals

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.example.nexora.animation.BubbleModalPanel
import com.example.nexora.animation.ClickOrigin
import com.example.nexora.data.CreatorProfile
import com.example.nexora.data.FlaggedContentItem
import com.example.nexora.data.NexoraSeedData
import com.example.nexora.data.VideoItem
import com.example.nexora.data.VisualThemePreset
import com.example.nexora.ui.components.CreatorAvatarBadge
import com.example.nexora.ui.components.SpatialVisualCanvas
import com.example.nexora.ui.components.VerifiedBadge
import com.example.nexora.network.AkashMediaService
import com.example.ui.theme.NexoraColors
import com.example.ui.theme.NexoraTypography
import com.example.ui.theme.PlusJakartaSansFamily
import com.example.ui.theme.liquidGlassAccent
import com.example.ui.theme.liquidGlassCard
import com.example.ui.theme.liquidGlassWhitePill
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun UploadModal(
    visible: Boolean,
    origin: ClickOrigin,
    viewportSize: IntSize,
    onDismiss: () -> Unit,
    onPublish: (
        title: String,
        description: String,
        category: String,
        duration: String,
        is4kHdr: Boolean,
        visualPreset: VisualThemePreset,
        carouselSlides: List<VisualThemePreset>
    ) -> Unit,
    onPublishPulse: (caption: String, preset: VisualThemePreset) -> Unit = { _, _ -> },
    onModularShortCreated: (
        result: com.example.nexora.network.AkashStep3CreateMediaResult,
        title: String,
        caption: String,
        author: String,
        durationSeconds: Double,
        visualPreset: VisualThemePreset
    ) -> Unit = { _, _, _, _, _, _ -> },
    defaultAuthorName: String = "Akash Creator"
) {
    InstagramUploadFullScreenStage(
        visible = visible,
        onDismiss = onDismiss,
        onPublish = onPublish,
        onPublishPulse = onPublishPulse,
        onModularShortCreated = onModularShortCreated,
        defaultAuthorName = defaultAuthorName
    )
}

@Composable
fun PlaylistModal(
    visible: Boolean,
    allVideos: List<VideoItem>,
    origin: ClickOrigin,
    viewportSize: IntSize,
    onDismiss: () -> Unit,
    onCreatePlaylist: (title: String, description: String, isPublic: Boolean, videoIds: List<String>) -> Unit
) {
    BubbleModalPanel(
        visible = visible,
        origin = origin,
        viewportSize = viewportSize,
        onDismiss = onDismiss,
        modifier = Modifier
            .padding(16.dp)
            .widthIn(max = 520.dp)
            .fillMaxWidth()
    ) {
        var title by remember { mutableStateOf("") }
        var isPublic by remember { mutableStateOf(true) }
        val selectedIds = remember {
            mutableStateListOf<String>().apply {
                allVideos.take(2).forEach { add(it.id) }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .liquidGlassCard(28.dp)
                .verticalScroll(rememberScrollState())
                .padding(18.dp)
                .testTag("playlist_modal_panel"),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "New Playlist", style = NexoraTypography.SectionTitle)
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .liquidGlassWhitePill(999.dp)
                        .clickable { onDismiss() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Close",
                        tint = NexoraColors.InkSecondary,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Name") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("playlist_title_input")
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isPublic) "Public" else "Private",
                    style = NexoraTypography.NavPillLabel
                )
                Switch(checked = isPublic, onCheckedChange = { isPublic = it })
            }

            Column(
                modifier = Modifier.heightIn(max = 180.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                allVideos.filter { !it.isLiveStream }.take(5).forEach { video ->
                    val checked = video.id in selectedIds
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(NexoraColors.Pearl200)
                            .clickable {
                                if (checked) selectedIds.remove(video.id) else selectedIds.add(video.id)
                            }
                            .padding(horizontal = 8.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = checked,
                            onCheckedChange = {
                                if (checked) selectedIds.remove(video.id) else selectedIds.add(video.id)
                            }
                        )
                        Text(
                            text = video.title,
                            style = NexoraTypography.BodyRegular,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Box(
                    modifier = Modifier
                        .height(38.dp)
                        .liquidGlassAccent(999.dp)
                        .clickable {
                            onCreatePlaylist(title, "", isPublic, selectedIds.toList())
                        }
                        .padding(horizontal = 18.dp)
                        .testTag("playlist_create_submit_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Create",
                        style = NexoraTypography.NavPillLabel.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraColors.InkAccent
                        )
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EditProfileModal(
    visible: Boolean,
    profile: CreatorProfile,
    origin: ClickOrigin = ClickOrigin(),
    viewportSize: IntSize = IntSize.Zero,
    onDismiss: () -> Unit,
    onOpenAccountCentre: () -> Unit = {},
    onSave: (
        name: String,
        handle: String,
        category: String,
        bio: String,
        location: String,
        website: String,
        bannerPreset: VisualThemePreset,
        avatarSeed: Int
    ) -> Unit
) {
    BackHandler(enabled = visible) { onDismiss() }

    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically(
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioNoBouncy,
                stiffness = Spring.StiffnessMediumLow
            ),
            initialOffsetY = { fullHeight -> fullHeight }
        ) + fadeIn(animationSpec = tween(220, easing = FastOutSlowInEasing)),
        exit = slideOutVertically(
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioNoBouncy,
                stiffness = Spring.StiffnessMediumLow
            ),
            targetOffsetY = { fullHeight -> fullHeight }
        ) + fadeOut(animationSpec = tween(180, easing = FastOutSlowInEasing)),
        modifier = Modifier
            .fillMaxSize()
            .zIndex(92f)
    ) {
        var name by remember(profile) { mutableStateOf(AkashMediaService.cleanEmojis(profile.name)) }
        var handle by remember(profile) { mutableStateOf(AkashMediaService.cleanEmojis(profile.handle).removePrefix("@")) }
        var category by remember(profile) { mutableStateOf(AkashMediaService.cleanEmojis(profile.category)) }
        var bio by remember(profile) { mutableStateOf(AkashMediaService.cleanEmojis(profile.bio)) }
        var location by remember(profile) { mutableStateOf(AkashMediaService.cleanEmojis(profile.location)) }
        var website by remember(profile) { mutableStateOf(AkashMediaService.cleanEmojis(profile.website)) }
        var bannerPreset by remember(profile) { mutableStateOf(profile.bannerPreset) }
        var avatarSeed by remember(profile) { mutableStateOf(profile.avatarSeed) }

        var handleCheckStatus by remember { mutableStateOf<String?>(null) }
        var isHandleValid by remember { mutableStateOf(true) }
        var isHandleChecking by remember { mutableStateOf(false) }

        LaunchedEffect(handle) {
            val clean = handle.trim().removePrefix("@").lowercase()
            if (clean.isBlank()) {
                handleCheckStatus = "Username cannot be empty"
                isHandleValid = false
                return@LaunchedEffect
            }
            if (!AkashMediaService.validateHandleFormat(clean)) {
                handleCheckStatus = "3-24 characters (a-z, 0-9, _) only. Zero emojis."
                isHandleValid = false
                return@LaunchedEffect
            }
            val originalHandle = AkashMediaService.cleanEmojis(profile.handle).removePrefix("@").lowercase()
            if (clean == originalHandle) {
                handleCheckStatus = "Current universal @handle"
                isHandleValid = true
                return@LaunchedEffect
            }
            isHandleChecking = true
            delay(350L)
            val res = AkashMediaService.checkHandleAvailability(clean)
            isHandleChecking = false
            res.fold(
                onSuccess = { r ->
                    if (r.available) {
                        handleCheckStatus = "Available: @$clean"
                        isHandleValid = true
                    } else {
                        handleCheckStatus = r.message ?: "Unavailable: @$clean is already taken"
                        isHandleValid = false
                    }
                },
                onFailure = {
                    handleCheckStatus = null
                    isHandleValid = true
                }
            )
        }

        val popularCategories = remember {
            listOf(
                "Spatial Design & Cinema",
                "Real-Time 3D & Sci-Fi",
                "Video Creator",
                "Digital Artist",
                "Architectural Cinema",
                "Music Sessions"
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(NexoraColors.CanvasBase)
                .testTag("edit_profile_modal")
        ) {

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                // 1. Full-Screen Top Navigation Bar (Instagram Header)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Cancel Button
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .liquidGlassWhitePill(999.dp)
                            .clickable { onDismiss() }
                            .testTag("cancel_profile_edits_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Cancel",
                            tint = NexoraColors.InkPrimary,
                            modifier = Modifier.size(19.dp)
                        )
                    }

                    // Header Title
                    Text(
                        text = "Edit profile",
                        fontFamily = PlusJakartaSansFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.5.sp,
                        color = NexoraColors.InkPrimary
                    )

                    // Done / Save Button
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .liquidGlassAccent(999.dp)
                            .clickable(enabled = isHandleValid && !isHandleChecking) {
                                val cleanName = AkashMediaService.cleanEmojis(name)
                                val rawHandle = AkashMediaService.cleanEmojis(handle).trim().removePrefix("@").lowercase()
                                val cleanHandle = if (rawHandle.isNotBlank()) "@$rawHandle" else "@aethervisuals"
                                val cleanCategory = AkashMediaService.cleanEmojis(category)
                                val cleanBio = AkashMediaService.cleanEmojis(bio)
                                val cleanLocation = AkashMediaService.cleanEmojis(location).ifBlank { "United States" }
                                val cleanWebsite = AkashMediaService.cleanEmojis(website)
                                onSave(cleanName, cleanHandle, cleanCategory, cleanBio, cleanLocation, cleanWebsite, bannerPreset, avatarSeed)
                            }
                            .testTag("save_profile_edits_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Check,
                            contentDescription = "Done",
                            tint = if (isHandleValid && !isHandleChecking) NexoraColors.InkAccent else NexoraColors.InkMuted,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                HorizontalDivider(
                    color = NexoraColors.SpecularBorderStrong,
                    thickness = 1.dp
                )

                // 2. Full-Screen Scrollable Content Area (Centered for Desktop/Tablet)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    Column(
                        modifier = Modifier
                            .widthIn(max = 640.dp)
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 20.dp, vertical = 20.dp),
                        verticalArrangement = Arrangement.spacedBy(22.dp)
                    ) {
                        // Avatar Section
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(96.dp)
                                    .border(
                                        width = 3.dp,
                                        brush = Brush.sweepGradient(
                                            listOf(
                                                NexoraColors.Lavender500,
                                                NexoraColors.Sky400,
                                                NexoraColors.ElectricIndigo,
                                                NexoraColors.Lavender500
                                            )
                                        ),
                                        shape = CircleShape
                                    )
                                    .padding(4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CreatorAvatarBadge(
                                    name = name.ifBlank { profile.name },
                                    seed = avatarSeed,
                                    avatarUrl = profile.avatarUrl,
                                    size = 88.dp,
                                    isSquircle = false,
                                    borderWidth = 0.dp,
                                    showOnlineDot = false
                                )
                            }

                            Text(
                                text = "Edit picture or avatar",
                                style = NexoraTypography.NavPillLabel.copy(
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraColors.InkAccent
                                ),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        avatarSeed = (avatarSeed % 6) + 1
                                    }
                                    .padding(horizontal = 14.dp, vertical = 6.dp)
                                    .testTag("edit_avatar_action_btn")
                            )

                            // Avatar Seed Style Selector (Chips 1..6)
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                for (s in 1..6) {
                                    val isSelected = s == avatarSeed
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .then(
                                                if (isSelected) Modifier.border(2.dp, NexoraColors.ElectricIndigo, CircleShape)
                                                else Modifier.border(1.dp, Color(0x33CBD5E1), CircleShape)
                                            )
                                            .clickable { avatarSeed = s },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        CreatorAvatarBadge(
                                            name = "A$s",
                                            seed = s,
                                            avatarUrl = null,
                                            size = 28.dp,
                                            isSquircle = false,
                                            borderWidth = 0.dp,
                                            showOnlineDot = false
                                        )
                                    }
                                }
                            }
                        }

                        // Form Fields Card Container
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .liquidGlassCard(24.dp)
                                .padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Name Field
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "Name",
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = NexoraColors.InkSecondary
                                    )
                                )
                                OutlinedTextField(
                                    value = name,
                                    onValueChange = { name = AkashMediaService.cleanEmojis(it) },
                                    placeholder = { Text("Name") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = NexoraColors.ElectricIndigo,
                                        unfocusedBorderColor = Color(0xFF363636),
                                        cursorColor = NexoraColors.ElectricIndigo,
                                        focusedTextColor = NexoraColors.InkPrimary,
                                        unfocusedTextColor = NexoraColors.InkPrimary
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("edit_profile_name_input")
                                )
                                Text(
                                    text = "Help people discover your account by using the name you're known by: either your full name, nickname, or studio name.",
                                    style = NexoraTypography.MetaCaption.copy(
                                        fontSize = 11.sp,
                                        color = NexoraColors.InkMuted
                                    ),
                                    modifier = Modifier.padding(start = 2.dp, top = 2.dp)
                                )
                            }

                            // Username Field
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "Username",
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = NexoraColors.InkSecondary
                                    )
                                )
                                OutlinedTextField(
                                    value = handle,
                                    onValueChange = {
                                        handle = AkashMediaService.cleanEmojis(it).trim().removePrefix("@").lowercase()
                                    },
                                    placeholder = { Text("username") },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Filled.AlternateEmail,
                                            contentDescription = "Username",
                                            tint = NexoraColors.InkSecondary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = if (isHandleValid) NexoraColors.ElectricIndigo else NexoraColors.LiveRose,
                                        unfocusedBorderColor = if (isHandleValid) Color(0xFF363636) else NexoraColors.LiveRose.copy(alpha = 0.5f),
                                        cursorColor = NexoraColors.ElectricIndigo,
                                        focusedTextColor = NexoraColors.InkPrimary,
                                        unfocusedTextColor = NexoraColors.InkPrimary
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("edit_profile_handle_input")
                                )
                                if (isHandleChecking) {
                                    Text(
                                        text = "Checking availability...",
                                        style = NexoraTypography.MetaCaption.copy(
                                            fontSize = 11.sp,
                                            color = NexoraColors.ElectricIndigo,
                                            fontWeight = FontWeight.SemiBold
                                        ),
                                        modifier = Modifier.padding(start = 2.dp, top = 2.dp)
                                    )
                                } else if (handleCheckStatus != null) {
                                    Text(
                                        text = handleCheckStatus ?: "",
                                        style = NexoraTypography.MetaCaption.copy(
                                            fontSize = 11.sp,
                                            color = if (isHandleValid) Color(0xFF16A34A) else NexoraColors.LiveRose,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        modifier = Modifier.padding(start = 2.dp, top = 2.dp)
                                    )
                                } else {
                                    Text(
                                        text = "In most cases, you'll be able to change your username back to @${handle.ifBlank { "username" }} for another 14 days.",
                                        style = NexoraTypography.MetaCaption.copy(
                                            fontSize = 11.sp,
                                            color = NexoraColors.InkMuted
                                        ),
                                        modifier = Modifier.padding(start = 2.dp, top = 2.dp)
                                    )
                                }
                            }

                            // Category Field + Quick Tag Pills
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "Category",
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = NexoraColors.InkSecondary
                                    )
                                )
                                OutlinedTextField(
                                    value = category,
                                    onValueChange = { category = AkashMediaService.cleanEmojis(it) },
                                    placeholder = { Text("Category") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = NexoraColors.ElectricIndigo,
                                        unfocusedBorderColor = Color(0xFF363636),
                                        cursorColor = NexoraColors.ElectricIndigo,
                                        focusedTextColor = NexoraColors.InkPrimary,
                                        unfocusedTextColor = NexoraColors.InkPrimary
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    popularCategories.forEach { cat ->
                                        val isSelected = category.equals(cat, ignoreCase = true)
                                        Box(
                                            modifier = Modifier
                                                .height(28.dp)
                                                .then(
                                                    if (isSelected) Modifier.liquidGlassAccent(999.dp)
                                                    else Modifier.liquidGlassWhitePill(999.dp)
                                                )
                                                .clickable { category = cat }
                                                .padding(horizontal = 12.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = cat,
                                                style = NexoraTypography.BadgeMicro.copy(
                                                    fontSize = 11.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                    color = if (isSelected) NexoraColors.InkAccent else NexoraColors.InkSecondary
                                                )
                                            )
                                        }
                                    }
                                }
                            }

                            // Bio Field
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Bio",
                                        style = NexoraTypography.BadgeMicro.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = NexoraColors.InkSecondary
                                        )
                                    )
                                    Text(
                                        text = "${bio.length} / 150",
                                        style = NexoraTypography.MetaCaption.copy(
                                            fontSize = 11.sp,
                                            color = if (bio.length > 150) NexoraColors.LiveRose else NexoraColors.InkMuted
                                        )
                                    )
                                }
                                OutlinedTextField(
                                    value = bio,
                                    onValueChange = {
                                        if (it.length <= 160) {
                                            bio = AkashMediaService.cleanEmojis(it)
                                        }
                                    },
                                    placeholder = { Text("Write a short bio to introduce your studio...") },
                                    minLines = 3,
                                    maxLines = 4,
                                    shape = RoundedCornerShape(14.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = NexoraColors.ElectricIndigo,
                                        unfocusedBorderColor = Color(0xFF363636),
                                        cursorColor = NexoraColors.ElectricIndigo,
                                        focusedTextColor = NexoraColors.InkPrimary,
                                        unfocusedTextColor = NexoraColors.InkPrimary
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("edit_profile_bio_input")
                                )
                            }

                            // Links / Website Field
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "Links",
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = NexoraColors.InkSecondary
                                    )
                                )
                                OutlinedTextField(
                                    value = website,
                                    onValueChange = { website = AkashMediaService.cleanEmojis(it) },
                                    placeholder = { Text("https://yourwebsite.com") },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Filled.Language,
                                            contentDescription = "Website",
                                            tint = NexoraColors.InkSecondary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = NexoraColors.ElectricIndigo,
                                        unfocusedBorderColor = Color(0xFF363636),
                                        cursorColor = NexoraColors.ElectricIndigo,
                                        focusedTextColor = NexoraColors.InkPrimary,
                                        unfocusedTextColor = NexoraColors.InkPrimary
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            // Location / Country Field
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "Location",
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = NexoraColors.InkSecondary
                                    )
                                )
                                OutlinedTextField(
                                    value = location,
                                    onValueChange = { input ->
                                        location = AkashMediaService.cleanEmojis(input)
                                    },
                                    placeholder = { Text("City, Country") },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Filled.LocationOn,
                                            contentDescription = "Location",
                                            tint = NexoraColors.InkSecondary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = NexoraColors.ElectricIndigo,
                                        unfocusedBorderColor = Color(0xFF363636),
                                        cursorColor = NexoraColors.ElectricIndigo,
                                        focusedTextColor = NexoraColors.InkPrimary,
                                        unfocusedTextColor = NexoraColors.InkPrimary
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }

                        // Visual Theme Preset Selector Card
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .liquidGlassCard(24.dp)
                                .padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "Profile Aesthetic & Banner",
                                style = NexoraTypography.BadgeMicro.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraColors.InkSecondary
                                )
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                VisualThemePreset.entries.forEach { preset ->
                                    val selected = preset == bannerPreset
                                    Box(
                                        modifier = Modifier
                                            .height(32.dp)
                                            .then(
                                                if (selected) Modifier.liquidGlassAccent(999.dp)
                                                else Modifier.liquidGlassWhitePill(999.dp)
                                            )
                                            .clickable { bannerPreset = preset }
                                            .padding(horizontal = 12.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                                        ) {
                                            if (selected) {
                                                Icon(
                                                    imageVector = Icons.Filled.Check,
                                                    contentDescription = "Selected",
                                                    tint = NexoraColors.InkAccent,
                                                    modifier = Modifier.size(13.dp)
                                                )
                                            }
                                            Text(
                                                text = preset.label,
                                                style = NexoraTypography.BadgeMicro.copy(
                                                    fontSize = 11.sp,
                                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                                    color = if (selected) NexoraColors.InkAccent else NexoraColors.InkSecondary
                                                )
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Instagram Footer Section (Personal Info & Accounts Centre)
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .liquidGlassCard(24.dp)
                                .padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Switch to professional account
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { /* Professional account toggle affordance */ }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Switch to professional account",
                                    style = NexoraTypography.NavPillLabel.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = NexoraColors.InkAccent
                                    )
                                )
                            }

                            HorizontalDivider(
                                color = NexoraColors.SpecularBorderStrong,
                                thickness = 1.dp
                            )

                            // Personal information settings
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onOpenAccountCentre() }
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(
                                    modifier = Modifier.weight(1f).padding(end = 12.dp),
                                    verticalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    Text(
                                        text = "Personal information settings",
                                        style = NexoraTypography.NavPillLabel.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = NexoraColors.InkPrimary
                                        )
                                    )
                                    Text(
                                        text = "Provide your personal information, sovereign vault sync, and account security in Accounts Centre.",
                                        style = NexoraTypography.MetaCaption.copy(
                                            fontSize = 11.5.sp,
                                            color = NexoraColors.InkMuted
                                        )
                                    )
                                }

                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                                    contentDescription = "Open Accounts Centre",
                                    tint = NexoraColors.InkSecondary,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(36.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun AdminDashboardModal(
    visible: Boolean,
    moderationQueue: List<FlaggedContentItem>,
    origin: ClickOrigin,
    viewportSize: IntSize,
    onDismiss: () -> Unit,
    onModerateItem: (itemId: String, approve: Boolean) -> Unit
) {
    BubbleModalPanel(
        visible = visible,
        origin = origin,
        viewportSize = viewportSize,
        onDismiss = onDismiss,
        modifier = Modifier
            .padding(16.dp)
            .widthIn(max = 640.dp)
            .fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .liquidGlassCard(28.dp)
                .verticalScroll(rememberScrollState())
                .padding(18.dp)
                .testTag("admin_dashboard_modal"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Shield,
                        contentDescription = null,
                        tint = NexoraColors.InkAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "Telemetry",
                        style = NexoraTypography.SectionTitle
                    )
                }

                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .liquidGlassWhitePill(999.dp)
                        .clickable { onDismiss() }
                        .testTag("admin_close_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Close",
                        tint = NexoraColors.InkSecondary,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }

            // Compact 2x2 Stat Strip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AdminStatTile("Active Streams", "1,428", Modifier.weight(1f))
                AdminStatTile("Bandwidth", "84.2 Gbps", Modifier.weight(1f))
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AdminStatTile("Creators", "18.9K", Modifier.weight(1f))
                AdminStatTile("Queue", "${moderationQueue.size}", Modifier.weight(1f))
            }

            if (moderationQueue.isEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(NexoraColors.Pearl200)
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = NexoraColors.EmeraldLive,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "Queue clear",
                        style = NexoraTypography.BodyRegular
                    )
                }
            } else {
                moderationQueue.forEach { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(NexoraColors.Pearl200)
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text(
                                text = item.videoTitle,
                                style = NexoraTypography.CardTitle.copy(fontSize = 13.5.sp),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = item.creatorName,
                                style = NexoraTypography.MetaCaption
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .liquidGlassAccent(999.dp)
                                    .clickable { onModerateItem(item.id, true) }
                                    .testTag("approve_flag_${item.id}"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Check,
                                    contentDescription = "Approve",
                                    tint = NexoraColors.InkAccent,
                                    modifier = Modifier.size(15.dp)
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .liquidGlassWhitePill(999.dp)
                                    .clickable { onModerateItem(item.id, false) }
                                    .testTag("remove_flag_${item.id}"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.DeleteOutline,
                                    contentDescription = "Remove",
                                    tint = NexoraColors.LiveRose,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminStatTile(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(NexoraColors.Pearl200)
            .border(1.dp, NexoraColors.SpecularBorderStrong, RoundedCornerShape(16.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(text = value, style = NexoraTypography.TelemetryValue.copy(fontSize = 18.sp))
        Text(text = label, style = NexoraTypography.MetaCaption.copy(fontSize = 11.sp))
    }
}


