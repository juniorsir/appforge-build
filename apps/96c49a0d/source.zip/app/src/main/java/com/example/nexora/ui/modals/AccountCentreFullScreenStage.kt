package com.example.nexora.ui.modals

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nexora.data.CreatorProfile
import com.example.nexora.ui.components.CreatorAvatarBadge
import com.example.nexora.ui.components.NexoraPrismLogo
import com.example.nexora.ui.components.VerifiedBadge
import com.example.ui.theme.NexoraColors
import com.example.ui.theme.NexoraTypography
import com.example.ui.theme.liquidGlassAccent
import com.example.ui.theme.liquidGlassCard
import com.example.ui.theme.liquidGlassWhitePill

enum class AccountCentreSection(val title: String) {
    HUB("Accounts Centre"),
    PROFILES("Profiles"),
    CONNECTED_EXPERIENCES("Connected experiences"),
    PASSWORD_SECURITY("Password and security"),
    PERSONAL_DETAILS("Personal details"),
    INFO_PERMISSIONS("Your information and permissions"),
    AD_PREFERENCES("Ad preferences"),
    PAYMENTS("Payments"),
    VERIFICATION("Akash Verified")
}

private data class ConnectedPlatformAccount(
    val id: String,
    val platformName: String,
    val handle: String,
    val badgeColor: Color,
    val isConnected: Boolean,
    val syncAvatarAndBio: Boolean = true
)

private data class ActiveDeviceSession(
    val id: String,
    val deviceName: String,
    val location: String,
    val statusText: String,
    val isCurrentDevice: Boolean
)

/**
 * Full-Screen Instagram / Meta-style Accounts Centre Page:
 * Occupies 100% of the screen (with top header and bottom navigation hidden) and provides
 * drill-down sub-pages with back navigation for Profiles, Connected Experiences,
 * Password & Security, Personal Details, Information & Permissions, Ad Preferences,
 * Payments, and Creator Verification.
 */
@Composable
fun AccountCentreFullScreenStage(
    visible: Boolean,
    profile: CreatorProfile,
    moderationQueueCount: Int,
    savedVideosCount: Int,
    playlistsCount: Int,
    onDismiss: () -> Unit,
    onOpenEditProfile: () -> Unit,
    onOpenAdminDashboard: () -> Unit,
    onClearWatchHistory: () -> Unit,
    onShowToast: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = visible,
        enter = slideInHorizontally(
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioNoBouncy,
                stiffness = Spring.StiffnessMediumLow
            ),
            initialOffsetX = { fullWidth -> fullWidth }
        ) + fadeIn(animationSpec = tween(220)),
        exit = slideOutHorizontally(
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioNoBouncy,
                stiffness = Spring.StiffnessMediumLow
            ),
            targetOffsetX = { fullWidth -> fullWidth }
        ) + fadeOut(animationSpec = tween(200)),
        modifier = modifier.fillMaxSize()
    ) {
        var currentSection by remember { mutableStateOf(AccountCentreSection.HUB) }

        // Connected Accounts State
        val connectedAccounts = remember(profile.handle) {
            mutableStateListOf(
                ConnectedPlatformAccount(
                    id = "acc_instagram",
                    platformName = "Akash Clips",
                    handle = profile.handle,
                    badgeColor = Color(0xFFE1306C),
                    isConnected = true,
                    syncAvatarAndBio = true
                ),
                ConnectedPlatformAccount(
                    id = "acc_threads",
                    platformName = "Akash Pulse",
                    handle = profile.handle,
                    badgeColor = Color(0xFFF5F5F5),
                    isConnected = true,
                    syncAvatarAndBio = true
                ),
                ConnectedPlatformAccount(
                    id = "acc_youtube",
                    platformName = "Akash Studio",
                    handle = "${profile.handle}.4k",
                    badgeColor = Color(0xFFFF0033),
                    isConnected = true,
                    syncAvatarAndBio = false
                ),
                ConnectedPlatformAccount(
                    id = "acc_x",
                    platformName = "Akash Spatial Feed",
                    handle = profile.handle,
                    badgeColor = Color(0xFF1D9BF0),
                    isConnected = false,
                    syncAvatarAndBio = false
                )
            )
        }

        // Connected Experiences State
        var autoSharePulsesToInstagram by remember { mutableStateOf(true) }
        var autoShareClipsToReels by remember { mutableStateOf(true) }
        var autoShareStreamsToThreads by remember { mutableStateOf(false) }
        var singleSignOnEnabled by remember { mutableStateOf(true) }
        var crossAppMessagingEnabled by remember { mutableStateOf(true) }

        // Password & Security State
        var twoFactorEnabled by remember { mutableStateOf(true) }
        var biometricPasskeyEnabled by remember { mutableStateOf(true) }
        var loginAlertsEnabled by remember { mutableStateOf(true) }
        var trustedDevicesOnly by remember { mutableStateOf(false) }
        val activeSessions = remember {
            mutableStateListOf(
                ActiveDeviceSession(
                    id = "sess_pixel",
                    deviceName = "Android 15 • Akash Spatial Studio",
                    location = "${profile.location} • Active now",
                    statusText = "This device",
                    isCurrentDevice = true
                ),
                ActiveDeviceSession(
                    id = "sess_vision",
                    deviceName = "Spatial Pro Headset • OS 2.4",
                    location = "Zurich, Switzerland • 2 hours ago",
                    statusText = "TrustedPasskey",
                    isCurrentDevice = false
                ),
                ActiveDeviceSession(
                    id = "sess_macbook",
                    deviceName = "Workstation Pro 16\" • Akash Web Studio",
                    location = "${profile.location} • Yesterday at 21:14",
                    statusText = "2FA Verified",
                    isCurrentDevice = false
                )
            )
        }

        // Personal Details State
        var contactEmail by remember(profile.handle) {
            mutableStateOf("${profile.handle.removePrefix("@")}@akash.studio")
        }
        var contactPhone by remember { mutableStateOf("+1 (415) 890-4419") }
        var birthDate by remember { mutableStateOf("14 October 1996") }
        var isAccountDeactivationScheduled by remember { mutableStateOf(false) }

        // Information & Permissions State
        var privateStudioMode by remember { mutableStateOf(false) }
        var cloudBackupEnabled by remember { mutableStateOf(true) }
        var spatialAutoplayEnabled by remember { mutableStateOf(true) }
        var contactsSyncEnabled by remember { mutableStateOf(false) }
        var activityStatusVisible by remember { mutableStateOf(true) }

        // Ad Preferences State
        var personalizedAdsEnabled by remember { mutableStateOf(true) }
        var partnerDataEnabled by remember { mutableStateOf(false) }
        var socialInteractionsInAds by remember { mutableStateOf(false) }
        val adTopicPreferences = remember {
            mutableStateMapOf(
                "Spatial Architecture" to "See more",
                "Cinema & Color Grading" to "See more",
                "3D Shaders & WebGL" to "See more",
                "Audio Synthesis" to "Standard",
                "Luxury Watches & Gear" to "See less",
                "Gaming & Esports" to "See less"
            )
        }

        // Payments State
        var selectedPaymentMethodId by remember { mutableStateOf("card_visa_4821") }
        var autoPayoutEnabled by remember { mutableStateOf(true) }
        var creatorBalanceUsd by remember { mutableStateOf(2840.50) }

        // Verification State
        var verifiedBadgeActive by remember { mutableStateOf(true) }
        var impersonationMonitoring by remember { mutableStateOf(true) }
        var priorityDistribution by remember { mutableStateOf(true) }

        // System Back Handler: Pop sub-page back to HUB first; if on HUB, close Account Centre
        BackHandler(enabled = visible) {
            if (currentSection != AccountCentreSection.HUB) {
                currentSection = AccountCentreSection.HUB
            } else {
                onDismiss()
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(NexoraColors.CanvasBase)
                .testTag("account_centre_modal")
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val maxDim = w.coerceAtLeast(h)
                drawRect(color = NexoraColors.CanvasBase)
                val topLeftCenter = Offset(w * 0.14f, h * 0.10f)
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(NexoraColors.MeshOrbTopLeftLav, Color.Transparent),
                        center = topLeftCenter,
                        radius = maxDim * 0.50f
                    ),
                    radius = maxDim * 0.50f,
                    center = topLeftCenter
                )
                val topRightCenter = Offset(w * 0.86f, h * 0.16f)
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(NexoraColors.MeshOrbTopRightSky, Color.Transparent),
                        center = topRightCenter,
                        radius = maxDim * 0.52f
                    ),
                    radius = maxDim * 0.52f,
                    center = topRightCenter
                )
                val bottomCenter = Offset(w * 0.50f, h * 0.86f)
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(NexoraColors.MeshOrbBottomCenterInd, Color.Transparent),
                        center = bottomCenter,
                        radius = maxDim * 0.55f
                    ),
                    radius = maxDim * 0.55f,
                    center = bottomCenter
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                // Full-Screen Top Navigation Bar
                AccountCentreTopBar(
                    currentSection = currentSection,
                    onBack = {
                        if (currentSection != AccountCentreSection.HUB) {
                            currentSection = AccountCentreSection.HUB
                        } else {
                            onDismiss()
                        }
                    },
                    onClose = onDismiss
                )

                // Animated Drill-Down Stage
                AnimatedContent(
                    targetState = currentSection,
                    transitionSpec = {
                        val isDrillingDown = targetState != AccountCentreSection.HUB
                        if (isDrillingDown) {
                            (slideInHorizontally(
                                animationSpec = spring(
                                    dampingRatio = Spring.DampingRatioNoBouncy,
                                    stiffness = Spring.StiffnessMediumLow
                                ),
                                initialOffsetX = { fullWidth -> fullWidth }
                            ) + fadeIn(tween(180))) togetherWith
                                (slideOutHorizontally(
                                    animationSpec = spring(
                                        dampingRatio = Spring.DampingRatioNoBouncy,
                                        stiffness = Spring.StiffnessMediumLow
                                    ),
                                    targetOffsetX = { fullWidth -> -fullWidth / 3 }
                                ) + fadeOut(tween(150)))
                        } else {
                            (slideInHorizontally(
                                animationSpec = spring(
                                    dampingRatio = Spring.DampingRatioNoBouncy,
                                    stiffness = Spring.StiffnessMediumLow
                                ),
                                initialOffsetX = { fullWidth -> -fullWidth / 3 }
                            ) + fadeIn(tween(180))) togetherWith
                                (slideOutHorizontally(
                                    animationSpec = spring(
                                        dampingRatio = Spring.DampingRatioNoBouncy,
                                        stiffness = Spring.StiffnessMediumLow
                                    ),
                                    targetOffsetX = { fullWidth -> fullWidth }
                                ) + fadeOut(tween(150)))
                        }.using(SizeTransform(clip = false))
                    },
                    label = "account_centre_subpage_transition",
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) { section ->
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        when (section) {
                            AccountCentreSection.HUB -> {
                                AccountCentreHubContent(
                                    profile = profile,
                                    connectedAccounts = connectedAccounts,
                                    moderationQueueCount = moderationQueueCount,
                                    onNavigateToSection = { currentSection = it },
                                    onOpenEditProfile = {
                                        onDismiss()
                                        onOpenEditProfile()
                                    },
                                    onOpenAdminDashboard = {
                                        onDismiss()
                                        onOpenAdminDashboard()
                                    },
                                    onShowToast = onShowToast
                                )
                            }

                            AccountCentreSection.PROFILES -> {
                                ProfilesAndAccountsSubPage(
                                    profile = profile,
                                    connectedAccounts = connectedAccounts,
                                    onToggleAccountConnection = { accountId ->
                                        val idx = connectedAccounts.indexOfFirst { it.id == accountId }
                                        if (idx >= 0) {
                                            val current = connectedAccounts[idx]
                                            val updated = current.copy(isConnected = !current.isConnected)
                                            connectedAccounts[idx] = updated
                                            onShowToast(
                                                if (updated.isConnected) {
                                                    "Linked ${updated.platformName} (${updated.handle})"
                                                } else {
                                                    "Removed ${updated.platformName} from Accounts Centre"
                                                }
                                            )
                                        }
                                    },
                                    onToggleSyncAvatar = { accountId ->
                                        val idx = connectedAccounts.indexOfFirst { it.id == accountId }
                                        if (idx >= 0) {
                                            val current = connectedAccounts[idx]
                                            connectedAccounts[idx] = current.copy(
                                                syncAvatarAndBio = !current.syncAvatarAndBio
                                            )
                                            onShowToast("Updated profile sync for ${current.platformName}")
                                        }
                                    },
                                    onOpenEditProfile = {
                                        onDismiss()
                                        onOpenEditProfile()
                                    }
                                )
                            }

                            AccountCentreSection.CONNECTED_EXPERIENCES -> {
                                ConnectedExperiencesSubPage(
                                    profile = profile,
                                    autoSharePulses = autoSharePulsesToInstagram,
                                    onAutoSharePulsesChange = {
                                        autoSharePulsesToInstagram = it
                                        onShowToast(
                                            if (it) "Auto-sharing Pulses to Akash Stories"
                                            else "Paused Pulse cross-sharing"
                                        )
                                    },
                                    autoShareClips = autoShareClipsToReels,
                                    onAutoShareClipsChange = {
                                        autoShareClipsToReels = it
                                        onShowToast(
                                            if (it) "Auto-sharing Spatial Clips to Akash Shorts"
                                            else "Paused Clips cross-sharing"
                                        )
                                    },
                                    autoShareStreams = autoShareStreamsToThreads,
                                    onAutoShareStreamsChange = {
                                        autoShareStreamsToThreads = it
                                        onShowToast(
                                            if (it) "Auto-posting stream premieres to Akash Pulse"
                                            else "Paused stream announcements"
                                        )
                                    },
                                    singleSignOn = singleSignOnEnabled,
                                    onSingleSignOnChange = {
                                        singleSignOnEnabled = it
                                        onShowToast(
                                            if (it) "Single Sign-On enabled across linked accounts"
                                            else "Single Sign-On restricted to individual login"
                                        )
                                    },
                                    crossAppMessaging = crossAppMessagingEnabled,
                                    onCrossAppMessagingChange = {
                                        crossAppMessagingEnabled = it
                                        onShowToast(
                                            if (it) "Cross-app Direct Messaging bridged"
                                            else "Cross-app Direct Messaging paused"
                                        )
                                    }
                                )
                            }

                            AccountCentreSection.PASSWORD_SECURITY -> {
                                PasswordAndSecuritySubPage(
                                    twoFactorEnabled = twoFactorEnabled,
                                    onTwoFactorChange = {
                                        twoFactorEnabled = it
                                        onShowToast(if (it) "2FA Spatial Auth enabled" else "2FA Spatial Auth paused")
                                    },
                                    biometricPasskeyEnabled = biometricPasskeyEnabled,
                                    onBiometricPasskeyChange = {
                                        biometricPasskeyEnabled = it
                                        onShowToast(if (it) "Hardware Passkey active" else "Hardware Passkey disabled")
                                    },
                                    loginAlertsEnabled = loginAlertsEnabled,
                                    onLoginAlertsChange = {
                                        loginAlertsEnabled = it
                                        onShowToast(if (it) "Real-time login alerts active" else "Login alerts muted")
                                    },
                                    trustedDevicesOnly = trustedDevicesOnly,
                                    onTrustedDevicesOnlyChange = {
                                        trustedDevicesOnly = it
                                        onShowToast(
                                            if (it) "Restricted sign-in to trusted hardware"
                                            else "Standard device sign-in allowed"
                                        )
                                    },
                                    activeSessions = activeSessions,
                                    onRevokeSession = { sessionId ->
                                        val removed = activeSessions.find { it.id == sessionId }
                                        activeSessions.removeAll { it.id == sessionId }
                                        onShowToast("Logged out of ${removed?.deviceName ?: "session"}")
                                    },
                                    onPasswordChanged = {
                                        onShowToast("Studio password updated across Accounts Centre")
                                    }
                                )
                            }

                            AccountCentreSection.PERSONAL_DETAILS -> {
                                PersonalDetailsSubPage(
                                    profile = profile,
                                    email = contactEmail,
                                    onEmailChange = { contactEmail = it },
                                    phone = contactPhone,
                                    onPhoneChange = { contactPhone = it },
                                    birthDate = birthDate,
                                    onBirthDateChange = { birthDate = it },
                                    isDeactivationScheduled = isAccountDeactivationScheduled,
                                    onToggleDeactivation = {
                                        isAccountDeactivationScheduled = !isAccountDeactivationScheduled
                                        onShowToast(
                                            if (isAccountDeactivationScheduled) {
                                                "Temporary studio hibernation scheduled (reversible anytime)"
                                            } else {
                                                "Studio hibernation cancelled — account active"
                                            }
                                        )
                                    },
                                    onSaveDetails = {
                                        onShowToast("Personal details saved to Accounts Centre")
                                    }
                                )
                            }

                            AccountCentreSection.INFO_PERMISSIONS -> {
                                InfoAndPermissionsSubPage(
                                    savedVideosCount = savedVideosCount,
                                    playlistsCount = playlistsCount,
                                    privateStudioMode = privateStudioMode,
                                    onPrivateStudioChange = {
                                        privateStudioMode = it
                                        onShowToast(if (it) "Private Studio mode enabled" else "Public Studio mode active")
                                    },
                                    cloudBackupEnabled = cloudBackupEnabled,
                                    onCloudBackupChange = {
                                        cloudBackupEnabled = it
                                        onShowToast(if (it) "Cloud Vault sync active" else "Cloud Vault sync paused")
                                    },
                                    spatialAutoplayEnabled = spatialAutoplayEnabled,
                                    onSpatialAutoplayChange = {
                                        spatialAutoplayEnabled = it
                                        onShowToast(if (it) "4K HDR Spatial Autoplay enabled" else "Autoplay paused")
                                    },
                                    contactsSyncEnabled = contactsSyncEnabled,
                                    onContactsSyncChange = {
                                        contactsSyncEnabled = it
                                        onShowToast(if (it) "Contacts discovery enabled" else "Contacts sync disconnected")
                                    },
                                    activityStatusVisible = activityStatusVisible,
                                    onActivityStatusChange = {
                                        activityStatusVisible = it
                                        onShowToast(if (it) "Online presence dot visible" else "Online presence hidden")
                                    },
                                    onClearHistory = {
                                        onClearWatchHistory()
                                        onShowToast("Search & watch history cleared")
                                    },
                                    onRequestDataArchive = {
                                        onShowToast("Encrypted studio archive queued for ${contactEmail}")
                                    }
                                )
                            }

                            AccountCentreSection.AD_PREFERENCES -> {
                                AdPreferencesSubPage(
                                    personalizedAds = personalizedAdsEnabled,
                                    onPersonalizedAdsChange = {
                                        personalizedAdsEnabled = it
                                        onShowToast(
                                            if (it) "Tailored spatial sponsorships enabled"
                                            else "Switched to contextual-only sponsorships"
                                        )
                                    },
                                    partnerData = partnerDataEnabled,
                                    onPartnerDataChange = {
                                        partnerDataEnabled = it
                                        onShowToast(
                                            if (it) "Partner activity signals enabled"
                                            else "Partner activity signals blocked"
                                        )
                                    },
                                    socialInteractions = socialInteractionsInAds,
                                    onSocialInteractionsChange = {
                                        socialInteractionsInAds = it
                                        onShowToast("Updated social endorsement visibility")
                                    },
                                    topicPreferences = adTopicPreferences,
                                    onCycleTopicPreference = { topic ->
                                        val current = adTopicPreferences[topic] ?: "Standard"
                                        val next = when (current) {
                                            "See more" -> "See less"
                                            "See less" -> "Standard"
                                            else -> "See more"
                                        }
                                        adTopicPreferences[topic] = next
                                        onShowToast("$topic set to \"$next\"")
                                    }
                                )
                            }

                            AccountCentreSection.PAYMENTS -> {
                                PaymentsSubPage(
                                    selectedCardId = selectedPaymentMethodId,
                                    onSelectCard = {
                                        selectedPaymentMethodId = it
                                        onShowToast("Updated default Akash Pay method")
                                    },
                                    autoPayoutEnabled = autoPayoutEnabled,
                                    onAutoPayoutChange = {
                                        autoPayoutEnabled = it
                                        onShowToast(
                                            if (it) "Automatic monthly creator payouts enabled"
                                            else "Switched to manual payout withdrawal"
                                        )
                                    },
                                    creatorBalanceUsd = creatorBalanceUsd,
                                    onWithdrawBalance = {
                                        if (creatorBalanceUsd > 0.0) {
                                            val amount = String.format("%.2f", creatorBalanceUsd)
                                            creatorBalanceUsd = 0.0
                                            onShowToast("Initiated instant payout of $$amount USD")
                                        } else {
                                            onShowToast("Balance already settled")
                                        }
                                    }
                                )
                            }

                            AccountCentreSection.VERIFICATION -> {
                                VerificationSubPage(
                                    profile = profile,
                                    verifiedBadgeActive = verifiedBadgeActive,
                                    onVerifiedBadgeChange = {
                                        verifiedBadgeActive = it
                                        onShowToast(
                                            if (it) "Akash Verified badge displayed on profile"
                                            else "Verified badge hidden"
                                        )
                                    },
                                    impersonationMonitoring = impersonationMonitoring,
                                    onImpersonationMonitoringChange = {
                                        impersonationMonitoring = it
                                        onShowToast(
                                            if (it) "Proactive impersonation shield active"
                                            else "Impersonation shield paused"
                                        )
                                    },
                                    priorityDistribution = priorityDistribution,
                                    onPriorityDistributionChange = {
                                        priorityDistribution = it
                                        onShowToast("Updated Verified stream priority")
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AccountCentreTopBar(
    currentSection: AccountCentreSection,
    onBack: () -> Unit,
    onClose: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .liquidGlassWhitePill(999.dp)
                .clickable { onBack() }
                .testTag("account_centre_back_btn"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                tint = NexoraColors.InkPrimary,
                modifier = Modifier.size(19.dp)
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            NexoraPrismLogo(size = 24.dp)
            Text(
                text = if (currentSection == AccountCentreSection.HUB) {
                    "AKASH ACCOUNTS CENTRE"
                } else {
                    currentSection.title.uppercase()
                },
                style = NexoraTypography.BadgeMicro.copy(
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = NexoraColors.InkPrimary,
                    letterSpacing = 0.8.sp
                )
            )
        }

        Spacer(modifier = Modifier.size(40.dp))
    }
}

@Composable
private fun AccountCentreHubContent(
    profile: CreatorProfile,
    connectedAccounts: List<ConnectedPlatformAccount>,
    moderationQueueCount: Int,
    onNavigateToSection: (AccountCentreSection) -> Unit,
    onOpenEditProfile: () -> Unit,
    onOpenAdminDashboard: () -> Unit,
    onShowToast: (String) -> Unit
) {
    val activeLinkedCount = connectedAccounts.count { it.isConnected } + 1

    LazyColumn(
        modifier = Modifier
            .widthIn(max = 680.dp)
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 6.dp, bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Hero Header
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "Accounts Centre",
                    style = NexoraTypography.SectionTitle.copy(fontSize = 26.sp),
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Manage your connected experiences and account settings across Akash Studio, Akash Shorts, and linked profiles.",
                    style = NexoraTypography.BodyRegular.copy(
                        fontSize = 13.5.sp,
                        color = NexoraColors.InkSecondary
                    ),
                    textAlign = TextAlign.Center
                )
            }
        }

        // 2. Profiles Card (Instagram Accounts Center Top Card)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .liquidGlassCard(cornerRadius = 24.dp)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(NexoraColors.Pearl200)
                        .border(1.dp, NexoraColors.SpecularBorderStrong, RoundedCornerShape(18.dp))
                        .clickable { onNavigateToSection(AccountCentreSection.PROFILES) }
                        .padding(14.dp)
                        .testTag("account_centre_profiles_card"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(modifier = Modifier.size(54.dp)) {
                            CreatorAvatarBadge(
                                name = profile.name,
                                seed = profile.avatarSeed,
                                avatarUrl = profile.avatarUrl,
                                size = 50.dp,
                                borderWidth = 2.dp,
                                showOnlineDot = true
                            )
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .size(22.dp)
                                    .clip(CircleShape)
                                    .background(NexoraColors.ElectricIndigo)
                                    .border(1.5.dp, Color.White, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$activeLinkedCount",
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontSize = 10.sp,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Text(
                                    text = "Profiles",
                                    style = NexoraTypography.CardTitle.copy(fontSize = 16.sp)
                                )
                                VerifiedBadge(size = 14.dp)
                            }
                            Text(
                                text = "${profile.name} (${profile.handle}) • $activeLinkedCount linked accounts",
                                style = NexoraTypography.MetaCaption.copy(fontSize = 12.sp),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        contentDescription = "Open Profiles",
                        tint = NexoraColors.InkSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Add or manage connected accounts",
                        style = NexoraTypography.NavPillLabel.copy(
                            color = NexoraColors.InkAccent,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.clickable {
                            onNavigateToSection(AccountCentreSection.PROFILES)
                        }
                    )

                    Box(
                        modifier = Modifier
                            .height(32.dp)
                            .liquidGlassAccent(999.dp)
                            .clickable { onOpenEditProfile() }
                            .padding(horizontal = 12.dp)
                            .testTag("account_centre_edit_profile_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Edit,
                                contentDescription = "Edit Studio",
                                tint = NexoraColors.InkAccent,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "Edit Studio",
                                style = NexoraTypography.BadgeMicro.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraColors.InkAccent
                                )
                            )
                        }
                    }
                }
            }
        }

        // 3. Connected Experiences Section
        item {
            AccountCentreGroupedSection(title = "Connected experiences") {
                AccountCentreNavRow(
                    icon = Icons.Filled.Share,
                    title = "Sharing across profiles",
                    subtitle = "Auto-share Pulses, Spatial Clips & streams",
                    onClick = { onNavigateToSection(AccountCentreSection.CONNECTED_EXPERIENCES) },
                    testTag = "row_connected_experiences"
                )
                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                AccountCentreNavRow(
                    icon = Icons.Filled.Key,
                    title = "Logging in with accounts",
                    subtitle = "Single sign-on & cross-platform messaging",
                    onClick = { onNavigateToSection(AccountCentreSection.CONNECTED_EXPERIENCES) },
                    testTag = "row_logging_in_accounts"
                )
            }
        }

        // 4. Account Settings Section (Instagram Core Menu Hub)
        item {
            AccountCentreGroupedSection(title = "Account settings") {
                AccountCentreNavRow(
                    icon = Icons.Filled.Security,
                    title = "Password and security",
                    subtitle = "Password, 2FA, passkeys & active sessions",
                    badgeText = "2FA ON",
                    onClick = { onNavigateToSection(AccountCentreSection.PASSWORD_SECURITY) },
                    testTag = "row_password_security"
                )
                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                AccountCentreNavRow(
                    icon = Icons.Filled.Person,
                    title = "Personal details",
                    subtitle = "Contact info, birth date & account ownership",
                    onClick = { onNavigateToSection(AccountCentreSection.PERSONAL_DETAILS) },
                    testTag = "row_personal_details"
                )
                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                AccountCentreNavRow(
                    icon = Icons.Filled.Visibility,
                    title = "Your information and permissions",
                    subtitle = "Privacy mode, history, archive & cloud vault",
                    onClick = { onNavigateToSection(AccountCentreSection.INFO_PERMISSIONS) },
                    testTag = "row_info_permissions"
                )
                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                AccountCentreNavRow(
                    icon = Icons.Filled.Campaign,
                    title = "Ad preferences",
                    subtitle = "Ad topics, partner data & sponsorships",
                    onClick = { onNavigateToSection(AccountCentreSection.AD_PREFERENCES) },
                    testTag = "row_ad_preferences"
                )
                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                AccountCentreNavRow(
                    icon = Icons.Filled.CreditCard,
                    title = "Payments",
                    subtitle = "Akash Pay methods & creator payouts",
                    onClick = { onNavigateToSection(AccountCentreSection.PAYMENTS) },
                    testTag = "row_payments"
                )
                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                AccountCentreNavRow(
                    icon = Icons.Filled.Verified,
                    title = "Akash Verified",
                    subtitle = "Verified badge, protection & priority reach",
                    badgeText = "ACTIVE",
                    onClick = { onNavigateToSection(AccountCentreSection.VERIFICATION) },
                    testTag = "row_verification"
                )
            }
        }

        // 5. Studio Governance & Quick Share Footer
        item {
            AccountCentreGroupedSection(title = "Studio administration") {
                AccountCentreNavRow(
                    icon = Icons.Filled.Shield,
                    title = "Creator Telemetry & Moderation",
                    subtitle = "Live bandwidth metrics & flagged queue ($moderationQueueCount)",
                    onClick = onOpenAdminDashboard,
                    testTag = "account_centre_telemetry_btn"
                )
                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                AccountCentreNavRow(
                    icon = Icons.Filled.Link,
                    title = "Copy Studio Identity Link",
                    subtitle = "akash.studio/${profile.handle.removePrefix("@")}",
                    onClick = {
                        onShowToast("Copied ${profile.handle} account link")
                    },
                    testTag = "account_centre_share_btn"
                )
            }
        }
    }
}

@Composable
private fun ProfilesAndAccountsSubPage(
    profile: CreatorProfile,
    connectedAccounts: List<ConnectedPlatformAccount>,
    onToggleAccountConnection: (String) -> Unit,
    onToggleSyncAvatar: (String) -> Unit,
    onOpenEditProfile: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .widthIn(max = 680.dp)
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SubPageIntroHeader(
                title = "Profiles & Connected Accounts",
                description = "Manage your primary Akash Studio identity and control which linked profiles share your avatar, name, and cross-app login."
            )
        }

        // Primary Akash Studio Identity Card
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .liquidGlassCard(24.dp)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CreatorAvatarBadge(
                        name = profile.name,
                        seed = profile.avatarSeed,
                        avatarUrl = profile.avatarUrl,
                        size = 56.dp,
                        borderWidth = 2.dp,
                        showOnlineDot = true
                    )
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = profile.name,
                                style = NexoraTypography.CardTitle.copy(fontSize = 16.sp)
                            )
                            VerifiedBadge(size = 15.dp)
                        }
                        Text(
                            text = "${profile.handle} • Primary Akash Studio",
                            style = NexoraTypography.MetaCaption
                        )
                        Text(
                            text = "${profile.location} • ${profile.website}",
                            style = NexoraTypography.MetaCaption.copy(color = NexoraColors.InkAccent)
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .liquidGlassAccent(999.dp)
                        .clickable { onOpenEditProfile() }
                        .testTag("subpage_edit_studio_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Edit Name, Handle, Bio & Banner",
                        style = NexoraTypography.NavPillLabel.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraColors.InkAccent
                        )
                    )
                }
            }
        }

        // Connected Accounts List
        item {
            AccountCentreGroupedSection(title = "Linked accounts in this centre") {
                connectedAccounts.forEachIndexed { index, account ->
                    if (index > 0) {
                        HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                    }
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(account.badgeColor.copy(alpha = 0.14f))
                                        .border(1.dp, account.badgeColor.copy(alpha = 0.45f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = account.platformName.take(2).uppercase(),
                                        style = NexoraTypography.BadgeMicro.copy(
                                            fontWeight = FontWeight.ExtraBold,
                                            color = account.badgeColor
                                        )
                                    )
                                }
                                Column {
                                    Text(
                                        text = account.platformName,
                                        style = NexoraTypography.CardTitle.copy(fontSize = 14.sp)
                                    )
                                    Text(
                                        text = if (account.isConnected) {
                                            "${account.handle} • Connected"
                                        } else {
                                            "Not linked"
                                        },
                                        style = NexoraTypography.MetaCaption
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .height(32.dp)
                                    .then(
                                        if (account.isConnected) {
                                            Modifier.liquidGlassWhitePill(999.dp)
                                        } else {
                                            Modifier.liquidGlassAccent(999.dp)
                                        }
                                    )
                                    .clickable { onToggleAccountConnection(account.id) }
                                    .padding(horizontal = 14.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (account.isConnected) "Unlink" else "Connect",
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (account.isConnected) {
                                            NexoraColors.InkSecondary
                                        } else {
                                            NexoraColors.InkAccent
                                        }
                                    )
                                )
                            }
                        }

                        if (account.isConnected) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(NexoraColors.Pearl200)
                                    .padding(horizontal = 12.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Sync profile photo & bio automatically",
                                    style = NexoraTypography.MetaCaption.copy(
                                        color = NexoraColors.InkPrimary
                                    )
                                )
                                Switch(
                                    checked = account.syncAvatarAndBio,
                                    onCheckedChange = { onToggleSyncAvatar(account.id) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ConnectedExperiencesSubPage(
    profile: CreatorProfile,
    autoSharePulses: Boolean,
    onAutoSharePulsesChange: (Boolean) -> Unit,
    autoShareClips: Boolean,
    onAutoShareClipsChange: (Boolean) -> Unit,
    autoShareStreams: Boolean,
    onAutoShareStreamsChange: (Boolean) -> Unit,
    singleSignOn: Boolean,
    onSingleSignOnChange: (Boolean) -> Unit,
    crossAppMessaging: Boolean,
    onCrossAppMessagingChange: (Boolean) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .widthIn(max = 680.dp)
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SubPageIntroHeader(
                title = "Connected Experiences",
                description = "Control how your content and login credentials work across ${profile.handle} and your linked social accounts."
            )
        }

        item {
            AccountCentreGroupedSection(title = "Sharing across profiles") {
                AccountCentreSwitchItem(
                    title = "Share 24h Spatial Pulses to Akash Stories",
                    subtitle = "Automatically syndicate new Pulses from ${profile.handle}",
                    checked = autoSharePulses,
                    onCheckedChange = onAutoSharePulsesChange
                )
                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                AccountCentreSwitchItem(
                    title = "Share 9:16 Spatial Clips to Akash Shorts",
                    subtitle = "Cross-post vertical HDR clips with original spatial audio",
                    checked = autoShareClips,
                    onCheckedChange = onAutoShareClipsChange
                )
                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                AccountCentreSwitchItem(
                    title = "Announce Widescreen Premieres on Akash Pulse",
                    subtitle = "Post an interactive preview card when a 4K stream goes live",
                    checked = autoShareStreams,
                    onCheckedChange = onAutoShareStreamsChange
                )
            }
        }

        item {
            AccountCentreGroupedSection(title = "Logging in & messaging across accounts") {
                AccountCentreSwitchItem(
                    title = "Allow Single Sign-On (SSO) across linked accounts",
                    subtitle = "Log in seamlessly to connected accounts without re-entering credentials",
                    checked = singleSignOn,
                    onCheckedChange = onSingleSignOnChange
                )
                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                AccountCentreSwitchItem(
                    title = "Bridge Direct Messages in Spatial Lounge",
                    subtitle = "Receive connected creator DMs inside your Akash inbox",
                    checked = crossAppMessaging,
                    onCheckedChange = onCrossAppMessagingChange
                )
            }
        }
    }
}

@Composable
private fun PasswordAndSecuritySubPage(
    twoFactorEnabled: Boolean,
    onTwoFactorChange: (Boolean) -> Unit,
    biometricPasskeyEnabled: Boolean,
    onBiometricPasskeyChange: (Boolean) -> Unit,
    loginAlertsEnabled: Boolean,
    onLoginAlertsChange: (Boolean) -> Unit,
    trustedDevicesOnly: Boolean,
    onTrustedDevicesOnlyChange: (Boolean) -> Unit,
    activeSessions: List<ActiveDeviceSession>,
    onRevokeSession: (String) -> Unit,
    onPasswordChanged: () -> Unit
) {
    var currentPassword by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var showPasswordEditor by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .widthIn(max = 680.dp)
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SubPageIntroHeader(
                title = "Password and Security",
                description = "Manage your password, Two-Factor Spatial Authentication (2FA), hardware passkeys, and active login sessions."
            )
        }

        // Security Checkup Banner
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .liquidGlassCard(22.dp)
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(NexoraColors.EmeraldLive.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = NexoraColors.EmeraldLive,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Security Checkup: Strong Protection",
                        style = NexoraTypography.CardTitle.copy(fontSize = 14.5.sp)
                    )
                    Text(
                        text = "Passkey & 2FA verification are protecting your studio.",
                        style = NexoraTypography.MetaCaption
                    )
                }
            }
        }

        // Login & Recovery
        item {
            AccountCentreGroupedSection(title = "Login & recovery") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showPasswordEditor = !showPasswordEditor },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .liquidGlassAccent(999.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Lock,
                                    contentDescription = null,
                                    tint = NexoraColors.InkAccent,
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "Change password",
                                    style = NexoraTypography.CardTitle.copy(fontSize = 14.sp)
                                )
                                Text(
                                    text = "Last updated 18 days ago",
                                    style = NexoraTypography.MetaCaption
                                )
                            }
                        }

                        Text(
                            text = if (showPasswordEditor) "Close" else "Update",
                            style = NexoraTypography.BadgeMicro.copy(
                                color = NexoraColors.InkAccent,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    AnimatedVisibility(visible = showPasswordEditor) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 6.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = currentPassword,
                                onValueChange = { currentPassword = it },
                                label = { Text("Current password") },
                                singleLine = true,
                                visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = newPassword,
                                onValueChange = { newPassword = it },
                                label = { Text("New password (min 8 characters)") },
                                singleLine = true,
                                visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth()
                            )
                            Box(
                                modifier = Modifier
                                    .align(Alignment.End)
                                    .height(36.dp)
                                    .liquidGlassAccent(999.dp)
                                    .clickable {
                                        if (newPassword.length >= 4) {
                                            currentPassword = ""
                                            newPassword = ""
                                            showPasswordEditor = false
                                            onPasswordChanged()
                                        }
                                    }
                                    .padding(horizontal = 16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Save New Password",
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = NexoraColors.InkAccent
                                    )
                                )
                            }
                        }
                    }
                }

                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)

                AccountCentreSwitchItem(
                    title = "Two-factor authentication (2FA)",
                    subtitle = "Require verification code or authenticator app on new logins",
                    checked = twoFactorEnabled,
                    onCheckedChange = onTwoFactorChange
                )
                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                AccountCentreSwitchItem(
                    title = "Biometric & Hardware Passkeys",
                    subtitle = "Sign in instantly with fingerprint or face unlock",
                    checked = biometricPasskeyEnabled,
                    onCheckedChange = onBiometricPasskeyChange
                )
                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                AccountCentreSwitchItem(
                    title = "Login alerts",
                    subtitle = "Get notified when an unrecognized device signs in",
                    checked = loginAlertsEnabled,
                    onCheckedChange = onLoginAlertsChange
                )
                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                AccountCentreSwitchItem(
                    title = "Restrict sign-in to trusted hardware",
                    subtitle = "Block browser logins from unverified IP regions",
                    checked = trustedDevicesOnly,
                    onCheckedChange = onTrustedDevicesOnlyChange
                )
            }
        }

        // Where You're Logged In
        item {
            AccountCentreGroupedSection(title = "Where you're logged in (${activeSessions.size})") {
                activeSessions.forEachIndexed { index, session ->
                    if (index > 0) {
                        HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .liquidGlassWhitePill(999.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Devices,
                                    contentDescription = null,
                                    tint = NexoraColors.InkAccent,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = session.deviceName,
                                    style = NexoraTypography.CardTitle.copy(fontSize = 13.5.sp)
                                )
                                Text(
                                    text = "${session.location} • ${session.statusText}",
                                    style = NexoraTypography.MetaCaption
                                )
                            }
                        }

                        if (session.isCurrentDevice) {
                            Box(
                                modifier = Modifier
                                    .height(26.dp)
                                    .liquidGlassAccent(999.dp)
                                    .padding(horizontal = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Current",
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontSize = 10.sp,
                                        color = NexoraColors.InkAccent,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .height(30.dp)
                                    .liquidGlassWhitePill(999.dp)
                                    .clickable { onRevokeSession(session.id) }
                                    .padding(horizontal = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Log out",
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = NexoraColors.LiveRose
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PersonalDetailsSubPage(
    profile: CreatorProfile,
    email: String,
    onEmailChange: (String) -> Unit,
    phone: String,
    onPhoneChange: (String) -> Unit,
    birthDate: String,
    onBirthDateChange: (String) -> Unit,
    isDeactivationScheduled: Boolean,
    onToggleDeactivation: () -> Unit,
    onSaveDetails: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .widthIn(max = 680.dp)
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SubPageIntroHeader(
                title = "Personal Details",
                description = "Akash uses this information to verify your identity and keep our creator community safe. You decide what personal details are visible."
            )
        }

        item {
            AccountCentreGroupedSection(title = "Contact info & identity") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = email,
                        onValueChange = onEmailChange,
                        label = { Text("Primary email address") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = phone,
                        onValueChange = onPhoneChange,
                        label = { Text("Verified phone number") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = birthDate,
                        onValueChange = onBirthDateChange,
                        label = { Text("Date of birth") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Identity confirmation: Verified (${profile.location})",
                            style = NexoraTypography.MetaCaption.copy(
                                color = NexoraColors.EmeraldLive,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                        Box(
                            modifier = Modifier
                                .height(36.dp)
                                .liquidGlassAccent(999.dp)
                                .clickable { onSaveDetails() }
                                .padding(horizontal = 18.dp)
                                .testTag("save_personal_details_btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Save Details",
                                style = NexoraTypography.BadgeMicro.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NexoraColors.InkAccent
                                )
                            )
                        }
                    }
                }
            }
        }

        item {
            AccountCentreGroupedSection(title = "Account ownership and control") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Deactivation or temporary studio hibernation",
                        style = NexoraTypography.CardTitle.copy(fontSize = 14.sp)
                    )
                    Text(
                        text = "Temporarily hide your studio profile, published streams, and Pulses until you log back in.",
                        style = NexoraTypography.MetaCaption
                    )
                    Box(
                        modifier = Modifier
                            .height(36.dp)
                            .liquidGlassWhitePill(999.dp)
                            .clickable { onToggleDeactivation() }
                            .padding(horizontal = 14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isDeactivationScheduled) {
                                "Cancel Scheduled Hibernation"
                            } else {
                                "Temporarily Hibernate Studio"
                            },
                            style = NexoraTypography.BadgeMicro.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isDeactivationScheduled) {
                                    NexoraColors.InkAccent
                                } else {
                                    NexoraColors.LiveRose
                                }
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoAndPermissionsSubPage(
    savedVideosCount: Int,
    playlistsCount: Int,
    privateStudioMode: Boolean,
    onPrivateStudioChange: (Boolean) -> Unit,
    cloudBackupEnabled: Boolean,
    onCloudBackupChange: (Boolean) -> Unit,
    spatialAutoplayEnabled: Boolean,
    onSpatialAutoplayChange: (Boolean) -> Unit,
    contactsSyncEnabled: Boolean,
    onContactsSyncChange: (Boolean) -> Unit,
    activityStatusVisible: Boolean,
    onActivityStatusChange: (Boolean) -> Unit,
    onClearHistory: () -> Unit,
    onRequestDataArchive: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .widthIn(max = 680.dp)
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SubPageIntroHeader(
                title = "Your Information and Permissions",
                description = "View and manage your studio privacy permissions, watch history, cloud vault sync, and downloadable data archives."
            )
        }

        item {
            AccountCentreGroupedSection(title = "Privacy & permissions") {
                AccountCentreSwitchItem(
                    title = "Private Studio Mode",
                    subtitle = "Only approved followers can view your 24h Spatial Pulses",
                    checked = privateStudioMode,
                    onCheckedChange = onPrivateStudioChange
                )
                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                AccountCentreSwitchItem(
                    title = "Show activity status",
                    subtitle = "Allow creators you follow to see when your studio is online",
                    checked = activityStatusVisible,
                    onCheckedChange = onActivityStatusChange
                )
                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                AccountCentreSwitchItem(
                    title = "4K HDR Spatial Autoplay",
                    subtitle = "Autoplay video streams in Home feed and Spatial Clips",
                    checked = spatialAutoplayEnabled,
                    onCheckedChange = onSpatialAutoplayChange
                )
                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                AccountCentreSwitchItem(
                    title = "Cloud Vault Sync ($savedVideosCount saved • $playlistsCount playlists)",
                    subtitle = "Sync saved streams, custom playlists, and playback progress",
                    checked = cloudBackupEnabled,
                    onCheckedChange = onCloudBackupChange
                )
                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                AccountCentreSwitchItem(
                    title = "Upload contacts for creator discovery",
                    subtitle = "Periodically sync contacts to find collaborators on Akash",
                    checked = contactsSyncEnabled,
                    onCheckedChange = onContactsSyncChange
                )
            }
        }

        item {
            AccountCentreGroupedSection(title = "Your activity & data portability") {
                AccountCentreNavRow(
                    icon = Icons.Filled.History,
                    title = "Clear search & watch history",
                    subtitle = "Reset recent stream watch progress and search queries",
                    onClick = onClearHistory,
                    testTag = "clear_history_action_row"
                )
                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                AccountCentreNavRow(
                    icon = Icons.Filled.Download,
                    title = "Download your information",
                    subtitle = "Request a portable archive of your videos, comments, and profile",
                    onClick = onRequestDataArchive,
                    testTag = "download_archive_action_row"
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AdPreferencesSubPage(
    personalizedAds: Boolean,
    onPersonalizedAdsChange: (Boolean) -> Unit,
    partnerData: Boolean,
    onPartnerDataChange: (Boolean) -> Unit,
    socialInteractions: Boolean,
    onSocialInteractionsChange: (Boolean) -> Unit,
    topicPreferences: Map<String, String>,
    onCycleTopicPreference: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .widthIn(max = 680.dp)
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SubPageIntroHeader(
                title = "Ad Preferences",
                description = "Control the sponsorship topics you see across Akash and how activity data is used to personalize creator promotions."
            )
        }

        item {
            AccountCentreGroupedSection(title = "Ad topics (Tap to toggle See more / See less)") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        topicPreferences.forEach { (topic, pref) ->
                            val isSeeMore = pref == "See more"
                            Box(
                                modifier = Modifier
                                    .height(34.dp)
                                    .then(
                                        if (isSeeMore) Modifier.liquidGlassAccent(999.dp)
                                        else Modifier.liquidGlassWhitePill(999.dp)
                                    )
                                    .clickable { onCycleTopicPreference(topic) }
                                    .padding(horizontal = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$topic • $pref",
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontSize = 11.sp,
                                        fontWeight = if (isSeeMore) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSeeMore) NexoraColors.InkAccent else NexoraColors.InkPrimary
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            AccountCentreGroupedSection(title = "Ad settings & partner data") {
                AccountCentreSwitchItem(
                    title = "Personalized creator sponsorships",
                    subtitle = "Tailor sponsored streams based on your categories & watch activity",
                    checked = personalizedAds,
                    onCheckedChange = onPersonalizedAdsChange
                )
                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                AccountCentreSwitchItem(
                    title = "Activity information from ad partners",
                    subtitle = "Use off-platform partner signals to refine ad relevance",
                    checked = partnerData,
                    onCheckedChange = onPartnerDataChange
                )
                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                AccountCentreSwitchItem(
                    title = "Include social interactions in sponsored posts",
                    subtitle = "Show followers when you endorse a featured studio premiere",
                    checked = socialInteractions,
                    onCheckedChange = onSocialInteractionsChange
                )
            }
        }
    }
}

@Composable
private fun PaymentsSubPage(
    selectedCardId: String,
    onSelectCard: (String) -> Unit,
    autoPayoutEnabled: Boolean,
    onAutoPayoutChange: (Boolean) -> Unit,
    creatorBalanceUsd: Double,
    onWithdrawBalance: () -> Unit
) {
    val paymentCards = remember {
        listOf(
            Triple("card_visa_4821", "Visa Infinite •••• 4821", "Expires 09/28 • Primary"),
            Triple("card_master_9014", "Mastercard Studio •••• 9014", "Expires 04/27 • Backup"),
            Triple("card_apple_pay", "Spatial Wallet / Google Pay", "Instant biometric checkout")
        )
    }

    LazyColumn(
        modifier = Modifier
            .widthIn(max = 680.dp)
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SubPageIntroHeader(
                title = "Payments (Akash Pay)",
                description = "Manage saved payment methods, creator monetization payouts, and subscription billing across your connected accounts."
            )
        }

        // Creator Payout Balance Card
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .liquidGlassCard(24.dp)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Available Creator Payout Balance",
                            style = NexoraTypography.MetaCaption
                        )
                        Text(
                            text = String.format("$%,.2f USD", creatorBalanceUsd),
                            style = NexoraTypography.TelemetryValue.copy(fontSize = 24.sp)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .height(38.dp)
                            .liquidGlassAccent(999.dp)
                            .clickable { onWithdrawBalance() }
                            .padding(horizontal = 16.dp)
                            .testTag("instant_payout_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (creatorBalanceUsd > 0.0) "Withdraw Now" else "Settled",
                            style = NexoraTypography.BadgeMicro.copy(
                                fontWeight = FontWeight.Bold,
                                color = NexoraColors.InkAccent
                            )
                        )
                    }
                }
            }
        }

        // Saved Payment Methods
        item {
            AccountCentreGroupedSection(title = "Saved payment methods") {
                paymentCards.forEachIndexed { index, (id, label, sub) ->
                    if (index > 0) {
                        HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                    }
                    val isSelected = id == selectedCardId
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectCard(id) }
                            .padding(vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .then(
                                        if (isSelected) Modifier.liquidGlassAccent(999.dp)
                                        else Modifier.liquidGlassWhitePill(999.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.AccountBalanceWallet,
                                    contentDescription = null,
                                    tint = NexoraColors.InkAccent,
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = label,
                                    style = NexoraTypography.CardTitle.copy(fontSize = 14.sp)
                                )
                                Text(text = sub, style = NexoraTypography.MetaCaption)
                            }
                        }

                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = "Selected",
                                tint = NexoraColors.InkAccent,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }

        item {
            AccountCentreGroupedSection(title = "Payout preferences") {
                AccountCentreSwitchItem(
                    title = "Automatic monthly creator payouts",
                    subtitle = "Transfer earnings automatically on the 1st of each month",
                    checked = autoPayoutEnabled,
                    onCheckedChange = onAutoPayoutChange
                )
            }
        }
    }
}

@Composable
private fun VerificationSubPage(
    profile: CreatorProfile,
    verifiedBadgeActive: Boolean,
    onVerifiedBadgeChange: (Boolean) -> Unit,
    impersonationMonitoring: Boolean,
    onImpersonationMonitoringChange: (Boolean) -> Unit,
    priorityDistribution: Boolean,
    onPriorityDistributionChange: (Boolean) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .widthIn(max = 680.dp)
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SubPageIntroHeader(
                title = "Akash Verified",
                description = "Your studio identity is authenticated with a verified badge, proactive impersonation protection, and priority spatial stream indexing."
            )
        }

        // Verified Badge Preview Card
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .liquidGlassCard(24.dp)
                    .padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                CreatorAvatarBadge(
                    name = profile.name,
                    seed = profile.avatarSeed,
                    avatarUrl = profile.avatarUrl,
                    size = 68.dp,
                    borderWidth = 2.dp,
                    showOnlineDot = true
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = profile.name,
                        style = NexoraTypography.SectionTitle.copy(fontSize = 19.sp)
                    )
                    if (verifiedBadgeActive) {
                        VerifiedBadge(size = 18.dp)
                    }
                }
                Text(
                    text = "${profile.handle} • Verified Creator Studio since 2025",
                    style = NexoraTypography.MetaCaption
                )
            }
        }

        item {
            AccountCentreGroupedSection(title = "Verified membership benefits") {
                AccountCentreSwitchItem(
                    title = "Display Verified Badge on profile & comments",
                    subtitle = "Show authenticity badge across Akash and linked profiles",
                    checked = verifiedBadgeActive,
                    onCheckedChange = onVerifiedBadgeChange
                )
                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                AccountCentreSwitchItem(
                    title = "Proactive impersonation monitoring",
                    subtitle = "Automatically detect and flag unauthorized clones of ${profile.handle}",
                    checked = impersonationMonitoring,
                    onCheckedChange = onImpersonationMonitoringChange
                )
                HorizontalDivider(color = NexoraColors.SpecularBorderStrong, thickness = 0.8.dp)
                AccountCentreSwitchItem(
                    title = "Priority 4K HDR Spatial Indexing",
                    subtitle = "Boost new premieres and Spatial Clips in For You discovery",
                    checked = priorityDistribution,
                    onCheckedChange = onPriorityDistributionChange
                )
            }
        }
    }
}

@Composable
private fun SubPageIntroHeader(
    title: String,
    description: String
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = title,
            style = NexoraTypography.SectionTitle.copy(fontSize = 23.sp)
        )
        Text(
            text = description,
            style = NexoraTypography.BodyRegular.copy(
                fontSize = 13.5.sp,
                color = NexoraColors.InkSecondary
            )
        )
    }
}

@Composable
private fun AccountCentreGroupedSection(
    title: String,
    content: @Composable () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .liquidGlassCard(cornerRadius = 24.dp)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = title,
            style = NexoraTypography.NavPillLabel.copy(
                fontWeight = FontWeight.Bold,
                color = NexoraColors.InkPrimary,
                fontSize = 13.5.sp
            ),
            modifier = Modifier.padding(bottom = 4.dp)
        )
        content()
    }
}

@Composable
private fun AccountCentreNavRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    badgeText: String? = null,
    onClick: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(vertical = 10.dp, horizontal = 4.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .liquidGlassWhitePill(999.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = NexoraColors.InkAccent,
                    modifier = Modifier.size(18.dp)
                )
            }
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = title,
                    style = NexoraTypography.CardTitle.copy(fontSize = 14.5.sp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    style = NexoraTypography.MetaCaption.copy(fontSize = 11.5.sp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (badgeText != null) {
                Box(
                    modifier = Modifier
                        .height(22.dp)
                        .liquidGlassAccent(999.dp)
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = badgeText,
                        style = NexoraTypography.BadgeMicro.copy(
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = NexoraColors.InkAccent
                        )
                    )
                }
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = "Open $title",
                tint = NexoraColors.InkSecondary,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun AccountCentreSwitchItem(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(end = 10.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = title,
                style = NexoraTypography.CardTitle.copy(fontSize = 14.sp)
            )
            Text(
                text = subtitle,
                style = NexoraTypography.MetaCaption.copy(fontSize = 11.5.sp)
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}
