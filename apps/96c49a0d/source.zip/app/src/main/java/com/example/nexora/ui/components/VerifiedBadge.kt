package com.example.nexora.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.NexoraColors
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Custom 8-Point Faceted Diamond Starburst Seal VerifiedBadge:
 * - Outer Scalloped 8-Point Starburst Path filled with 135deg linear gradient
 *   (#A855F7 Deep Lavender -> #6366F1 Electric Indigo -> #38BDF8 Icy Cyan)
 *   and a 1.2.dp white specular border.
 * - Inner Faceted Octagon Glow: subtle inner highlight overlay rgba(255,255,255,0.28).
 * - Center Precision Checkmark: crisp white vector stroke (strokeWidth = 2.dp,
 *   StrokeCap.Round, StrokeJoin.Round) with a tiny 4-point sparkle accent at top-right vertex.
 */
@Composable
fun VerifiedBadge(
    modifier: Modifier = Modifier,
    size: Dp = 14.dp
) {
    Canvas(
        modifier = modifier
            .size(size)
            .semantics { contentDescription = "Verified Studio Seal" }
    ) {
        val w = this.size.width
        val h = this.size.height
        val cx = w / 2f
        val cy = h / 2f
        val outerR = (w.coerceAtMost(h) / 2f) * 0.94f
        val valleyR = outerR * 0.78f

        // 1. Outer Scalloped 8-Point Starburst Path
        val starburstPath = Path()
        val numPoints = 8
        for (i in 0 until numPoints * 2) {
            val angle = (i * PI / numPoints) - (PI / 2.0)
            val r = if (i % 2 == 0) outerR else valleyR
            val px = cx + (r * cos(angle)).toFloat()
            val py = cy + (r * sin(angle)).toFloat()
            if (i == 0) {
                starburstPath.moveTo(px, py)
            } else {
                starburstPath.lineTo(px, py)
            }
        }
        starburstPath.close()

        val sealBrush = Brush.linearGradient(
            colors = listOf(
                NexoraColors.Lavender500, // #A855F7
                NexoraColors.ElectricIndigo, // #6366F1
                NexoraColors.Sky400 // #38BDF8
            ),
            start = Offset(0f, 0f),
            end = Offset(w, h)
        )

        drawPath(
            path = starburstPath,
            brush = sealBrush
        )

        // 1.2.dp White Specular Border
        drawPath(
            path = starburstPath,
            color = Color.White,
            style = Stroke(
                width = (1.2.dp.toPx()).coerceAtMost(w * 0.085f),
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )

        // 2. Inner Faceted Octagon Glow: rgba(255,255,255,0.28)
        val innerOctagonPath = Path()
        val innerR = outerR * 0.62f
        for (i in 0 until 8) {
            val angle = (i * PI / 4.0) - (PI / 8.0)
            val px = cx + (innerR * cos(angle)).toFloat()
            val py = cy + (innerR * sin(angle)).toFloat()
            if (i == 0) innerOctagonPath.moveTo(px, py) else innerOctagonPath.lineTo(px, py)
        }
        innerOctagonPath.close()

        drawPath(
            path = innerOctagonPath,
            color = Color(0x47FFFFFF) // rgba(255, 255, 255, 0.28)
        )

        // 3. Center Precision Checkmark
        val checkPath = Path().apply {
            moveTo(w * 0.31f, h * 0.52f)
            lineTo(w * 0.45f, h * 0.66f)
            lineTo(w * 0.70f, h * 0.37f)
        }
        drawPath(
            path = checkPath,
            color = Color.White,
            style = Stroke(
                width = (2.dp.toPx()).coerceAtMost(w * 0.13f),
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )

        // 4. Tiny 4-point sparkle accent at the top-right vertex
        val spCx = w * 0.75f
        val spCy = h * 0.25f
        val spOuter = w * 0.11f
        val spInner = spOuter * 0.32f
        val sparklePath = Path().apply {
            moveTo(spCx, spCy - spOuter)
            lineTo(spCx + spInner, spCy - spInner)
            lineTo(spCx + spOuter, spCy)
            lineTo(spCx + spInner, spCy + spInner)
            lineTo(spCx, spCy + spOuter)
            lineTo(spCx - spInner, spCy + spInner)
            lineTo(spCx - spOuter, spCy)
            lineTo(spCx - spInner, spCy - spInner)
            close()
        }
        drawPath(
            path = sparklePath,
            color = Color.White
        )
    }
}
