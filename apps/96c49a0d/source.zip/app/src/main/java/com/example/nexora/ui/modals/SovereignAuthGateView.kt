package com.example.nexora.ui.modals

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag

/**
 * Sovereign Authentication Gate for Reels & User Vault:
 * Delegates to the clean Instagram-style [DedicatedLoginStage] with optional back navigation.
 */
@Composable
fun SovereignAuthGateView(
    onAuthenticated: (
        uid: String,
        displayName: String,
        email: String,
        handle: String,
        avatarUrl: String?,
        idToken: String?
    ) -> Unit,
    onBack: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    DedicatedLoginStage(
        onAuthenticated = onAuthenticated,
        onContinueAsGuest = { onBack?.invoke() },
        onBack = onBack,
        modifier = modifier.testTag("sovereign_auth_gate_view")
    )
}
