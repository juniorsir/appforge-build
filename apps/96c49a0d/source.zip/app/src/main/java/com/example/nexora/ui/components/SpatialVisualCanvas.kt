package com.example.nexora.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.example.nexora.data.VisualThemePreset
import com.example.ui.theme.NexoraColors
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Smooth Instagram Dark UI Shimmer Placeholder (#121212 -> #1C1C1E -> #262626 -> #121212)
 * for zero-jank media and card loading states.
 */
@Composable
fun InstagramDarkShimmerBox(
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "ig_dark_shimmer")
    val translateFrac by transition.animateFloat(
        initialValue = -1f,
        targetValue = 2f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1150, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_translate"
    )

    Canvas(modifier = modifier.background(NexoraColors.Pearl100)) {
        val w = size.width.coerceAtLeast(1f)
        val h = size.height.coerceAtLeast(1f)
        val startX = translateFrac * w
        drawRect(
            brush = Brush.linearGradient(
                colors = listOf(
                    NexoraColors.Pearl100,
                    NexoraColors.Pearl200,
                    NexoraColors.Pearl300,
                    NexoraColors.Pearl200,
                    NexoraColors.Pearl100
                ),
                start = Offset(startX, 0f),
                end = Offset(startX + w * 0.85f, h * 0.45f)
            )
        )
    }
}

/**
 * Renders rich procedural 4K-style spatial artwork and animated video/live scenes
 * (Nordic Glass Pavilions, Cybernetic Light Fields, Bioluminescent Fjord, Analog Modular Synth,
 * Brutalist Water Monolith, Orbital Dyson Horizon, Minimalist Kyoto Rain, Volumetric Cloud Atrium).
 *
 * Optimized for 60fps:
 * - Only runs an InfiniteTransition when [isAnimated] is true (zero idle CPU/GPU work on static cards).
 * - Reads animated phase inside the Canvas DrawScope (draw-phase invalidation only, zero recompositions).
 * - Reuses a remembered [Path] instance to avoid per-frame object allocations inside DrawScope.
 */
@Composable
fun SpatialVisualCanvas(
    preset: VisualThemePreset,
    modifier: Modifier = Modifier,
    isAnimated: Boolean = false,
    playbackPhase: Float = 0f
) {
    val livePhaseState = if (isAnimated) {
        val infiniteTransition = rememberInfiniteTransition(label = "spatial_scene")
        infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = (2f * PI).toFloat(),
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 9000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "phase"
        )
    } else {
        null
    }

    val reusablePath = remember { Path() }

    Canvas(modifier = modifier.fillMaxSize()) {
        val phase = if (livePhaseState != null) {
            livePhaseState.value + playbackPhase * 6f
        } else {
            playbackPhase * 4f + 0.8f
        }
        val w = size.width
        val h = size.height

        when (preset) {
            VisualThemePreset.NORDIC_PAVILION -> {
                // Twilight Fjord & Glass Pavilion
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF0A0A0D),
                            Color(0xFF121216),
                            Color(0xFF1C1C22),
                            Color(0xFF0A0A0D)
                        )
                    )
                )
                // Pastel Aurora / Twilight Glow
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0x550095F6), Color(0x388134AF), Color.Transparent),
                        center = Offset(w * (0.68f + 0.05f * sin(phase)), h * 0.28f),
                        radius = w * 0.55f
                    ),
                    center = Offset(w * 0.68f, h * 0.28f),
                    radius = w * 0.55f
                )
                // Mountain silhouette
                reusablePath.reset()
                reusablePath.apply {
                    moveTo(0f, h * 0.68f)
                    lineTo(w * 0.22f, h * 0.42f)
                    lineTo(w * 0.46f, h * 0.58f)
                    lineTo(w * 0.76f, h * 0.34f)
                    lineTo(w, h * 0.55f)
                    lineTo(w, h)
                    lineTo(0f, h)
                    close()
                }
                drawPath(reusablePath, color = Color(0xFF0A0A0D).copy(alpha = 0.78f))

                // Cantilevered Glass Pavilion Structure
                val pavLeft = w * 0.16f
                val pavRight = w * 0.78f
                val pavTop = h * 0.40f
                val pavBottom = h * 0.74f

                // Warm interior architectural glow
                drawRoundRect(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color(0x440095F6),
                            Color(0x6638BDF8),
                            Color(0x55DD2A7B),
                            Color(0x330095F6)
                        ),
                        startX = pavLeft,
                        endX = pavRight
                    ),
                    topLeft = Offset(pavLeft, pavTop),
                    size = Size(pavRight - pavLeft, pavBottom - pavTop),
                    cornerRadius = CornerRadius(6f, 6f)
                )
                // Roof & floor slab beams
                drawRect(
                    color = Color(0xEEFFFFFF),
                    topLeft = Offset(pavLeft - w * 0.04f, pavTop - 4f),
                    size = Size(pavRight - pavLeft + w * 0.08f, 5f)
                )
                drawRect(
                    color = Color(0xCCBAE6FD),
                    topLeft = Offset(pavLeft - w * 0.02f, pavBottom),
                    size = Size(pavRight - pavLeft + w * 0.04f, 4f)
                )
                // Glass mullions
                for (i in 1..4) {
                    val mx = pavLeft + (pavRight - pavLeft) * (i / 5f)
                    drawLine(
                        color = Color(0x99FFFFFF),
                        start = Offset(mx, pavTop),
                        end = Offset(mx, pavBottom),
                        strokeWidth = 2f
                    )
                }
                // Fjord water reflection lines
                for (r in 1..6) {
                    val ry = pavBottom + (h - pavBottom) * (r / 7f)
                    val waveOffset = sin(phase + r) * 14f
                    drawLine(
                        brush = Brush.horizontalGradient(
                            listOf(Color.Transparent, Color(0x660095F6), Color(0x66DD2A7B), Color.Transparent)
                        ),
                        start = Offset(pavLeft + waveOffset, ry),
                        end = Offset(pavRight + waveOffset, ry),
                        strokeWidth = 2f
                    )
                }
            }

            VisualThemePreset.ORBITAL_RING -> {
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(NexoraColors.CanvasBase, NexoraColors.Pearl100, NexoraColors.Pearl200)
                    )
                )
                // Planet horizon arc
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Color(0xFF0095F6), Color(0xFF8134AF), Color.Transparent),
                        center = Offset(w * 0.5f, h * 1.35f),
                        radius = w * 0.95f
                    ),
                    center = Offset(w * 0.5f, h * 1.35f),
                    radius = w * 0.95f
                )
                // Orbital Dyson Ring
                for (i in 0..2) {
                    val rx = w * (0.36f - i * 0.05f)
                    val ry = h * (0.26f - i * 0.03f)
                    drawOval(
                        brush = Brush.linearGradient(
                            listOf(Color(0xFFDD2A7B), Color(0xFF0095F6), Color(0x88FFFFFF))
                        ),
                        topLeft = Offset(w * 0.5f - rx, h * 0.44f - ry),
                        size = Size(rx * 2f, ry * 2f),
                        style = Stroke(width = (3.5f - i).coerceAtLeast(1f))
                    )
                }
                // Orbiting light node
                val angle = phase
                val nodeX = w * 0.5f + cos(angle) * (w * 0.36f)
                val nodeY = h * 0.44f + sin(angle) * (h * 0.26f)
                drawCircle(
                    color = Color.White,
                    radius = 5f,
                    center = Offset(nodeX, nodeY)
                )
            }

            VisualThemePreset.ANALOG_SYNTH -> {
                drawRect(
                    brush = Brush.linearGradient(
                        listOf(NexoraColors.CanvasBase, Color(0xFF281E3E), NexoraColors.Pearl100)
                    )
                )
                // Oscilloscope harmonic waves
                val waveCount = 3
                for (wIdx in 0 until waveCount) {
                    reusablePath.reset()
                    val steps = 36
                    for (s in 0..steps) {
                        val frac = s / steps.toFloat()
                        val x = frac * w
                        val amp = h * (0.14f - wIdx * 0.03f)
                        val y = h * 0.5f + sin(frac * 10f + phase * (1.2f + wIdx * 0.4f)) * amp
                        if (s == 0) reusablePath.moveTo(x, y) else reusablePath.lineTo(x, y)
                    }
                    drawPath(
                        path = reusablePath,
                        color = when (wIdx) {
                            0 -> Color(0xFFDD2A7B)
                            1 -> Color(0xFF0095F6)
                            else -> Color(0x99FFFFFF)
                        },
                        style = Stroke(width = 3f - wIdx * 0.6f, cap = StrokeCap.Round)
                    )
                }
            }

            VisualThemePreset.CYBER_LIGHTFIELD -> {
                drawRect(
                    brush = Brush.linearGradient(
                        listOf(NexoraColors.CanvasBase, NexoraColors.Pearl100, NexoraColors.Pearl200)
                    )
                )
                // Concentric refracting glass rings
                val cx = w * (0.5f + 0.06f * cos(phase))
                val cy = h * 0.5f
                for (i in 1..5) {
                    val r = (w.coerceAtMost(h) * 0.11f) * i
                    drawRoundRect(
                        brush = Brush.linearGradient(
                            listOf(Color(0x99DD2A7B), Color(0x990095F6), Color(0x44FFFFFF))
                        ),
                        topLeft = Offset(cx - r, cy - r * 0.68f),
                        size = Size(r * 2f, r * 1.36f),
                        cornerRadius = CornerRadius(r * 0.45f, r * 0.45f),
                        style = Stroke(width = 2.2f)
                    )
                }
            }

            VisualThemePreset.FJORD_AURORA -> {
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(NexoraColors.CanvasBase, NexoraColors.Pearl100, NexoraColors.Pearl200)
                    )
                )
                // Aurora ribbons
                for (band in 0..2) {
                    reusablePath.reset()
                    for (s in 0..32) {
                        val frac = s / 32f
                        val x = frac * w
                        val y = h * (0.28f + band * 0.1f) + sin(frac * 6f + phase + band) * (h * 0.08f)
                        if (s == 0) reusablePath.moveTo(x, y) else reusablePath.lineTo(x, y)
                    }
                    drawPath(
                        path = reusablePath,
                        brush = Brush.horizontalGradient(
                            listOf(Color.Transparent, Color(0xAA0095F6), Color(0xAADD2A7B), Color.Transparent)
                        ),
                        style = Stroke(width = 18f - band * 4f, cap = StrokeCap.Round)
                    )
                }
            }

            VisualThemePreset.BRUTALIST_MONOLITH -> {
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(NexoraColors.Pearl100, NexoraColors.Pearl200, NexoraColors.CanvasBase)
                    )
                )
                // Concrete architectural slabs & light slit
                drawRect(
                    color = NexoraColors.CanvasBase,
                    topLeft = Offset(w * 0.12f, h * 0.15f),
                    size = Size(w * 0.34f, h * 0.65f)
                )
                drawRect(
                    color = NexoraColors.Pearl100,
                    topLeft = Offset(w * 0.52f, h * 0.22f),
                    size = Size(w * 0.36f, h * 0.58f)
                )
                // Radiant light beam through aperture
                drawLine(
                    brush = Brush.verticalGradient(
                        listOf(Color.White, Color(0xAA0095F6), Color.Transparent)
                    ),
                    start = Offset(w * 0.49f, h * 0.1f),
                    end = Offset(w * (0.49f + 0.04f * sin(phase)), h * 0.9f),
                    strokeWidth = 10f,
                    cap = StrokeCap.Round
                )
            }

            VisualThemePreset.KYOTO_COURTYARD -> {
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(NexoraColors.CanvasBase, NexoraColors.Pearl100, NexoraColors.Pearl50)
                    )
                )
                // Rain ripples on pond
                for (i in 0..4) {
                    val rippleFrac = ((phase * 0.35f + i * 0.2f) % 1f)
                    val cx = w * (0.25f + (i * 0.15f))
                    val cy = h * (0.55f + (i % 2) * 0.12f)
                    drawOval(
                        color = Color(0xFF0095F6).copy(alpha = (1f - rippleFrac) * 0.65f),
                        topLeft = Offset(cx - w * 0.12f * rippleFrac, cy - h * 0.05f * rippleFrac),
                        size = Size(w * 0.24f * rippleFrac, h * 0.10f * rippleFrac),
                        style = Stroke(width = 2f)
                    )
                }
            }

            VisualThemePreset.CLOUD_ATRIUM -> {
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(NexoraColors.Pearl100, NexoraColors.Pearl200, NexoraColors.Pearl300)
                    )
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Color(0x990095F6), Color(0x66DD2A7B), Color.Transparent),
                        center = Offset(w * 0.5f, h * 0.42f),
                        radius = w * 0.42f
                    ),
                    center = Offset(w * 0.5f, h * 0.42f),
                    radius = w * 0.42f
                )
            }
        }
    }
}

/**
 * Reusable creator profile photo avatar component supporting circular geometry,
 * network/catalog profile photo loading via Coil with hardware bitmap caching & smooth crossfade,
 * studio portrait fallback, and optional online dot.
 */
@Composable
fun CreatorAvatarBadge(
    name: String,
    seed: Int,
    size: Dp,
    modifier: Modifier = Modifier,
    isSquircle: Boolean = false,
    cornerRadius: Dp = 20.dp,
    borderWidth: Dp = 1.5.dp,
    showOnlineDot: Boolean = false,
    avatarUrl: String? = null
) {
    val context = LocalContext.current
    val shape = CircleShape
    val resolvedAvatarUrl = remember(name, seed, avatarUrl) {
        avatarUrl?.takeIf { it.isNotBlank() } ?: run {
            val cleanName = name.removePrefix("@").trim().lowercase()
            val imgIdx = (((cleanName.hashCode().ushr(1)) + seed) % 68) + 1
            "https://i.pravatar.cc/150?img=$imgIdx"
        }
    }
    val imageRequest = remember(context, resolvedAvatarUrl) {
        ImageRequest.Builder(context)
            .data(resolvedAvatarUrl)
            .crossfade(180)
            .memoryCachePolicy(CachePolicy.ENABLED)
            .diskCachePolicy(CachePolicy.ENABLED)
            .build()
    }

    Box(modifier = modifier.size(size)) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(shape)
                .then(
                    if (borderWidth > 0.dp) {
                        Modifier.border(borderWidth, Color.White.copy(alpha = 0.85f), shape)
                    } else {
                        Modifier
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            SubcomposeAsyncImage(
                model = imageRequest,
                contentDescription = "$name profile photo",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(shape),
                loading = {
                    StudioPortraitAvatarCanvas(
                        seed = seed + name.hashCode().ushr(1),
                        modifier = Modifier.fillMaxSize()
                    )
                },
                error = {
                    StudioPortraitAvatarCanvas(
                        seed = seed + name.hashCode().ushr(1),
                        modifier = Modifier.fillMaxSize()
                    )
                }
            )
        }
        if (showOnlineDot) {
            val dotSize = (size.value * 0.26f).coerceIn(9f, 16f).dp
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(dotSize)
                    .clip(CircleShape)
                    .background(NexoraColors.EmeraldLive)
                    .border(1.5.dp, NexoraColors.CanvasBase, CircleShape)
            )
        }
    }
}

@Composable
private fun StudioPortraitAvatarCanvas(
    seed: Int,
    modifier: Modifier = Modifier
) {
    val variant = (seed.ushr(1)) % 5
    val bgColors = when (variant) {
        1 -> listOf(NexoraColors.Pearl100, Color(0xFF0095F6), Color(0xFF8134AF))
        2 -> listOf(NexoraColors.CanvasBase, Color(0xFFDD2A7B), Color(0xFF515BD4))
        3 -> listOf(NexoraColors.Pearl200, Color(0xFF8134AF), Color(0xFFF58529))
        4 -> listOf(NexoraColors.CanvasBase, Color(0xFF0095F6), Color(0xFFDD2A7B))
        else -> listOf(NexoraColors.Pearl100, Color(0xFF515BD4), Color(0xFF0095F6))
    }
    val skinTone = when (variant) {
        1 -> Color(0xFFF3C6A8)
        2 -> Color(0xFFD99B78)
        3 -> Color(0xFFF7D5BA)
        4 -> Color(0xFFC6865E)
        else -> Color(0xFFEAC0A2)
    }
    val hairColor = when (variant) {
        1 -> Color(0xFF1E1B24)
        2 -> Color(0xFF2C1E18)
        3 -> Color(0xFF3B2314)
        4 -> Color(0xFF14141B)
        else -> Color(0xFF231F20)
    }
    val jacketColor = when (variant) {
        1 -> NexoraColors.Pearl100
        2 -> NexoraColors.Pearl200
        3 -> NexoraColors.CanvasBase
        4 -> NexoraColors.Pearl50
        else -> NexoraColors.Pearl100
    }

    val reusablePath = remember { Path() }

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Studio backdrop gradient
        drawRect(brush = Brush.linearGradient(bgColors))

        // Studio rim glow behind head
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = 0.35f), Color.Transparent),
                center = Offset(w * 0.5f, h * 0.42f),
                radius = w * 0.48f
            ),
            center = Offset(w * 0.5f, h * 0.42f),
            radius = w * 0.48f
        )

        // Shoulders / torso portrait silhouette
        drawOval(
            color = jacketColor,
            topLeft = Offset(w * 0.14f, h * 0.64f),
            size = Size(w * 0.72f, h * 0.54f)
        )

        // Inner crew neck / collar accent
        drawOval(
            color = Color.White.copy(alpha = 0.85f),
            topLeft = Offset(w * 0.36f, h * 0.63f),
            size = Size(w * 0.28f, h * 0.14f)
        )

        // Neck
        drawRoundRect(
            color = skinTone,
            topLeft = Offset(w * 0.42f, h * 0.52f),
            size = Size(w * 0.16f, h * 0.16f),
            cornerRadius = CornerRadius(w * 0.06f, w * 0.06f)
        )

        // Back hair volume
        drawCircle(
            color = hairColor,
            radius = w * 0.23f,
            center = Offset(w * 0.5f, h * 0.38f)
        )

        // Face oval
        drawOval(
            color = skinTone,
            topLeft = Offset(w * 0.31f, h * 0.24f),
            size = Size(w * 0.38f, h * 0.36f)
        )

        // Hair crown / fringe
        reusablePath.reset()
        reusablePath.apply {
            moveTo(w * 0.29f, h * 0.38f)
            quadraticTo(w * 0.32f, h * 0.18f, w * 0.52f, h * 0.20f)
            quadraticTo(w * 0.70f, h * 0.21f, w * 0.70f, h * 0.37f)
            quadraticTo(w * 0.58f, h * 0.29f, w * 0.45f, h * 0.31f)
            quadraticTo(w * 0.35f, h * 0.32f, w * 0.29f, h * 0.38f)
            close()
        }
        drawPath(reusablePath, color = hairColor)

        // Eyes
        drawCircle(
            color = NexoraColors.CanvasBase,
            radius = (w * 0.024f).coerceAtLeast(1.2f),
            center = Offset(w * 0.43f, h * 0.41f)
        )
        drawCircle(
            color = NexoraColors.CanvasBase,
            radius = (w * 0.024f).coerceAtLeast(1.2f),
            center = Offset(w * 0.57f, h * 0.41f)
        )

        // Subtle warm smile arc
        reusablePath.reset()
        reusablePath.apply {
            moveTo(w * 0.45f, h * 0.49f)
            quadraticTo(w * 0.50f, h * 0.53f, w * 0.55f, h * 0.49f)
        }
        drawPath(
            path = reusablePath,
            color = Color(0xFF8C4A32),
            style = Stroke(width = (w * 0.022f).coerceAtLeast(1f), cap = StrokeCap.Round)
        )
    }
}
