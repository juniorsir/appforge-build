package com.example.nexora.ui.modals

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyHorizontalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Drafts
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Gif
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MarkEmailUnread
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nexora.data.DirectChatMessage
import com.example.nexora.data.DirectMessageThread
import com.example.nexora.data.VisualThemePreset
import com.example.nexora.ui.components.CreatorAvatarBadge
import com.example.nexora.ui.components.PremiumChatIcon
import com.example.nexora.ui.components.SpatialVisualCanvas
import com.example.nexora.ui.components.VerifiedBadge
import com.example.ui.theme.NexoraColors
import com.example.ui.theme.NexoraTypography
import com.example.ui.theme.liquidGlassAccent
import com.example.ui.theme.liquidGlassCard
import com.example.ui.theme.liquidGlassDarkOverlay
import com.example.ui.theme.liquidGlassWhitePill
import kotlin.math.abs
import kotlin.math.sin
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

internal data class VoiceWavePayload(
    val durationLabel: String,
    val title: String,
    val seed: Int
) {
    fun toToken(): String = "[VOICE:$durationLabel|$title|$seed]"
}

internal data class ReplyQuotePayload(
    val senderName: String,
    val snippet: String
) {
    fun toToken(): String {
        val safeSender = senderName.replace("|", " ").replace("]", "")
        val safeSnippet = snippet.replace("|", " ").replace("]", "").take(48)
        return "[REPLY_QUOTE:$safeSender|$safeSnippet]"
    }
}

internal fun parseVoiceWaveFromMessage(text: String): VoiceWavePayload? {
    val match = Regex("\\[VOICE:([^\\]]+)\\]").find(text) ?: return null
    val parts = match.groupValues[1].split("|")
    if (parts.size < 2) return null
    return VoiceWavePayload(
        durationLabel = parts[0],
        title = parts[1],
        seed = parts.getOrNull(2)?.toIntOrNull() ?: 7
    )
}

internal fun parseReplyQuoteFromMessage(text: String): ReplyQuotePayload? {
    val match = Regex("\\[REPLY_QUOTE:([^\\]]+)\\]").find(text) ?: return null
    val parts = match.groupValues[1].split("|")
    if (parts.size < 2) return null
    return ReplyQuotePayload(
        senderName = parts[0],
        snippet = parts[1]
    )
}

internal fun cleanDirectMessageText(rawText: String): String {
    return rawText
        .replace(Regex("\\[REPLY_QUOTE:[^\\]]+\\]"), "")
        .replace(Regex("\\[GIF:[^\\]]+\\]"), "")
        .replace(Regex("\\[VOICE:[^\\]]+\\]"), "")
        .trim()
}

internal fun formatLastMessagePreview(msg: DirectChatMessage?): String {
    if (msg == null) return "Start a spatial conversation..."
    val gif = parseGifFromComment(msg.text)
    if (gif != null) return "GIF • ${gif.title}"
    val voice = parseVoiceWaveFromMessage(msg.text)
    if (voice != null) return "Spatial Voice • ${voice.durationLabel}"
    if (msg.sharedPreset != null) return "Scene • ${msg.sharedPreset.label}"
    val cleaned = cleanDirectMessageText(msg.text)
    return cleaned.ifEmpty { "Sent a message" }
}

/**
 * Two-Stage Frosted Liquid Glass Chat & Direct Messages Experience:
 * - Stage 1: Spatial Inbox Hub with Floating Glass Thought Bubbles, Search/Filter Pills,
 *   and High-Efficiency Thread Cards with inline Instant Peek & Quick Reply.
 * - Stage 2: Full Conversation View with Quick Thread Switcher Rail, Animated GIF Studio,
 *   Playable Spatial Voice Wave Notes, Spatial Scene Cards, and Message Emoji Reactions.
 */
@Composable
internal fun SpatialDirectMessagesExperience(
    threads: List<DirectMessageThread>,
    activeCreatorId: String,
    isModalCompact: Boolean,
    onSelectThread: (String) -> Unit,
    onSendMessage: (creatorId: String, text: String, sharedPreset: VisualThemePreset?) -> Unit,
    onOpenCreatorProfile: (String) -> Unit,
    onCloseModal: (() -> Unit)? = null,
    isConversationOpen: Boolean? = null,
    onConversationStateChange: ((Boolean) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    // Stage 1 = Inbox Hub (`false`), Stage 2 = Full Chat View (`true`)
    var localConversationOpen by remember { mutableStateOf(false) }
    val conversationOpen = isConversationOpen ?: localConversationOpen
    val updateConversationOpen: (Boolean) -> Unit = { open ->
        localConversationOpen = open
        onConversationStateChange?.invoke(open)
    }
    var inboxSearchQuery by remember { mutableStateOf("") }
    var isSearchExpanded by remember { mutableStateOf(false) }
    val searchFocusRequester = remember { FocusRequester() }
    val coroutineScope = rememberCoroutineScope()
    var selectedInboxFilter by remember { mutableStateOf("All") }
    var peekExpandedCreatorId by remember { mutableStateOf<String?>(null) }
    var peekQuickDraft by remember { mutableStateOf("") }

    val pinnedThreadIds = remember {
        mutableStateMapOf("creator_lumina" to true)
    }
    val mutedThreadIds = remember { mutableStateMapOf<String, Boolean>() }
    val customUnreadThreadIds = remember { mutableStateMapOf<String, Boolean>() }
    val deletedThreadIds = remember { mutableStateListOf<String>() }

    var selectedLongPressThread by remember { mutableStateOf<DirectMessageThread?>(null) }
    var selectedLongPressThought by remember {
        mutableStateOf<Pair<DirectMessageThread, Pair<String, VisualThemePreset>>?>(null)
    }

    // Floating Glass Thought Bubbles (editable for user's own studio + creator live moods)
    var ownThoughtText by remember { mutableStateOf("Tuning 8K spatial audio") }
    var isEditingOwnThought by remember { mutableStateOf(false) }
    var ownThoughtDraft by remember { mutableStateOf(ownThoughtText) }

    val creatorThoughts = remember {
        mapOf(
            "creator_lumina" to ("Refraction shader live" to VisualThemePreset.NORDIC_PAVILION),
            "creator_kurogane" to ("Binaural rain session" to VisualThemePreset.KYOTO_COURTYARD),
            "creator_elena" to ("Fjord aurora cut" to VisualThemePreset.FJORD_AURORA),
            "creator_solaris" to ("Modular synth patch" to VisualThemePreset.ANALOG_SYNTH),
            "creator_vortex" to ("Orbital ring render" to VisualThemePreset.ORBITAL_RING)
        )
    }

    // Per-message reactions stored in session state
    val messageReactions = remember {
        mutableStateMapOf(
            "dm_1" to "FIRE",
            "dm_2" to "LOVE",
            "dm_3" to "100%"
        )
    }

    val activeThreads = remember(threads, deletedThreadIds.toList()) {
        threads.filterNot { deletedThreadIds.contains(it.creatorId) }
    }
    val activeThread = activeThreads.find { it.creatorId == activeCreatorId } ?: activeThreads.firstOrNull()
    val totalUnread = activeThreads.count { it.unreadCount > 0 || customUnreadThreadIds[it.creatorId] == true }

    val filteredThreads = remember(
        activeThreads,
        inboxSearchQuery,
        selectedInboxFilter,
        pinnedThreadIds.toMap(),
        customUnreadThreadIds.toMap()
    ) {
        val base = activeThreads.filter { thread ->
            val matchesQuery = if (inboxSearchQuery.isBlank()) {
                true
            } else {
                val q = inboxSearchQuery.trim()
                thread.creatorName.contains(q, ignoreCase = true) ||
                    thread.creatorHandle.contains(q, ignoreCase = true) ||
                    thread.messages.any { it.text.contains(q, ignoreCase = true) }
            }
            val isUnread = (thread.unreadCount > 0) || (customUnreadThreadIds[thread.creatorId] == true)
            val matchesTab = when (selectedInboxFilter) {
                "Unread" -> isUnread
                "Online" -> thread.isOnline
                "Pinned" -> pinnedThreadIds[thread.creatorId] == true
                else -> true
            }
            matchesQuery && matchesTab
        }
        base.sortedByDescending { pinnedThreadIds[it.creatorId] == true }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .then(
                    if (isModalCompact) {
                        Modifier
                            .clip(RoundedCornerShape(28.dp))
                            .background(NexoraColors.CanvasBase)
                            .padding(14.dp)
                    } else {
                        Modifier.background(NexoraColors.CanvasBase)
                    }
                ),
            verticalArrangement = if (!isModalCompact && conversationOpen) Arrangement.Top else Arrangement.spacedBy(10.dp)
        ) {
        AnimatedContent(
            targetState = conversationOpen,
            transitionSpec = {
                fadeIn(tween(220, easing = FastOutSlowInEasing)) togetherWith
                    fadeOut(tween(180, easing = FastOutSlowInEasing))
            },
            label = "spatial_dm_two_stage_transition",
            modifier = Modifier.fillMaxSize()
        ) { showConversation ->
            if (!showConversation) {
                // =========================================================================
                // STAGE 1: SPATIAL INBOX HUB (Floating Thought Bubbles + Instant Peek List)
                // =========================================================================
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .then(
                            if (!isModalCompact) {
                                Modifier
                                    .windowInsetsPadding(WindowInsets.statusBars)
                                    .padding(start = 16.dp, end = 16.dp, top = 22.dp, bottom = 8.dp)
                            } else {
                                Modifier
                            }
                        ),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // 1. Top Inbox Header Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            PremiumChatIcon(
                                isSelected = true,
                                unreadCount = totalUnread,
                                size = 22.dp
                            )
                            Text(
                                text = "Messages",
                                style = NexoraTypography.CardTitle.copy(
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val isSearchActive = isSearchExpanded || inboxSearchQuery.isNotEmpty()
                            // Search icon button replacing the former "Open Chat" text button
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isSearchActive) Color.White
                                        else NexoraColors.Pearl100
                                    )
                                    .clickable {
                                        isSearchExpanded = !isSearchExpanded
                                        if (isSearchExpanded) {
                                            coroutineScope.launch {
                                                delay(80)
                                                try {
                                                    searchFocusRequester.requestFocus()
                                                } catch (_: Exception) {}
                                            }
                                        } else {
                                            inboxSearchQuery = ""
                                        }
                                    }
                                    .testTag(
                                        if (isModalCompact) "dm_open_active_chat_btn"
                                        else "stage_dm_open_active_chat_btn"
                                    )
                                    .testTag("dm_inbox_search_toggle_btn"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isSearchExpanded && inboxSearchQuery.isEmpty()) Icons.Filled.Close else Icons.Filled.Search,
                                    contentDescription = "Search inbox",
                                    tint = if (isSearchActive) Color(0xFF000000) else Color.White,
                                    modifier = Modifier.size(17.dp)
                                )
                            }

                            if (onCloseModal != null) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(NexoraColors.Pearl100)
                                        .clickable { onCloseModal() }
                                        .testTag("dm_close_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Close,
                                        contentDescription = "Close Direct Messages",
                                        tint = Color.White,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            }
                        }
                    }

                    // 2. Expandable Search Capsule (Revealed when user clicks search icon in top header or has active query)
                    AnimatedVisibility(
                        visible = isSearchExpanded || inboxSearchQuery.isNotEmpty(),
                        enter = expandVertically(animationSpec = tween(220, easing = FastOutSlowInEasing)) + fadeIn(animationSpec = tween(220)),
                        exit = shrinkVertically(animationSpec = tween(180, easing = FastOutSlowInEasing)) + fadeOut(animationSpec = tween(180))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(38.dp)
                                .clip(RoundedCornerShape(999.dp))
                                .background(NexoraColors.Pearl100)
                                .padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Search,
                                contentDescription = "Search conversations",
                                tint = NexoraColors.InkSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            BasicTextField(
                                value = inboxSearchQuery,
                                onValueChange = { inboxSearchQuery = it },
                                singleLine = true,
                                textStyle = NexoraTypography.BadgeMicro.copy(
                                    fontSize = 13.sp,
                                    color = Color.White,
                                    fontWeight = FontWeight.Medium
                                ),
                                cursorBrush = SolidColor(NexoraColors.ElectricIndigo),
                                modifier = Modifier
                                    .weight(1f)
                                    .focusRequester(searchFocusRequester)
                                    .testTag("dm_inbox_search_input"),
                                decorationBox = { inner ->
                                    if (inboxSearchQuery.isEmpty()) {
                                        Text(
                                            text = "Search creators, messages...",
                                            style = NexoraTypography.BadgeMicro.copy(
                                                fontSize = 12.5.sp,
                                                color = NexoraColors.InkSecondary
                                            ),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    inner()
                                }
                            )
                            if (inboxSearchQuery.isNotEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .clickable { inboxSearchQuery = "" },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Close,
                                        contentDescription = "Clear search",
                                        tint = NexoraColors.InkSecondary,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Filter Chips Menu Row (Crisp White Active Pill)
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(top = 4.dp, bottom = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(listOf("All", "Unread", "Online", "Pinned"), key = { it }) { filterName ->
                            val isSelected = selectedInboxFilter == filterName
                            val badgeText = when (filterName) {
                                "Unread" -> if (totalUnread > 0) " • $totalUnread" else ""
                                else -> ""
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(999.dp))
                                    .background(
                                        if (isSelected) Color.White
                                        else NexoraColors.Pearl100
                                    )
                                    .clickable { selectedInboxFilter = filterName }
                                    .padding(horizontal = 16.dp, vertical = 7.dp)
                                    .testTag("dm_filter_chip_${filterName.lowercase()}")
                            ) {
                                Text(
                                    text = "$filterName$badgeText",
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold,
                                        color = if (isSelected) Color(0xFF000000) else Color.White.copy(alpha = 0.85f)
                                    )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 3. Floating Glass Thought Bubbles with Live Spatial Mood Previews
                    SpatialThoughtNotesRow(
                        threads = threads,
                        ownThoughtText = ownThoughtText,
                        isEditingOwnThought = isEditingOwnThought,
                        ownThoughtDraft = ownThoughtDraft,
                        creatorThoughts = creatorThoughts,
                        onStartEditOwnThought = {
                            ownThoughtDraft = ownThoughtText
                            isEditingOwnThought = true
                        },
                        onOwnThoughtDraftChange = { ownThoughtDraft = it },
                        onSaveOwnThought = {
                            if (ownThoughtDraft.isNotBlank()) {
                                ownThoughtText = ownThoughtDraft.trim()
                            }
                            isEditingOwnThought = false
                        },
                        onCancelEditOwnThought = { isEditingOwnThought = false },
                        onClickCreatorThought = { thread, thoughtText ->
                            onSelectThread(thread.creatorId)
                            updateConversationOpen(true)
                            onSendMessage(
                                thread.creatorId,
                                "[REPLY_QUOTE:${thread.creatorName.substringBefore(" ")}|$thoughtText] Love this spatial mood!",
                                null
                            )
                        },
                        onLongClickCreatorThought = { thread, thoughtData ->
                            selectedLongPressThought = thread to thoughtData
                        },
                        testTag = if (isModalCompact) "dm_threads_row" else "stage_dm_threads_row",
                        itemTestTagPrefix = if (isModalCompact) "dm_thread_" else "stage_dm_thread_"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // 4. High-Efficiency Inbox Thread Cards with Instant Peek & Quick Reply
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false)
                            .padding(bottom = if (isModalCompact) 4.dp else 56.dp)
                            .testTag("dm_inbox_threads_list"),
                        contentPadding = PaddingValues(top = 4.dp, bottom = 20.dp),
                        verticalArrangement = Arrangement.spacedBy(18.dp)
                    ) {
                        items(filteredThreads, key = { it.creatorId }) { thread ->
                            val isPinned = pinnedThreadIds[thread.creatorId] == true
                            val isMuted = mutedThreadIds[thread.creatorId] == true
                            val isCustomUnread = customUnreadThreadIds[thread.creatorId] == true
                            val isPeekExpanded = peekExpandedCreatorId == thread.creatorId

                            SpatialInboxThreadCard(
                                thread = thread,
                                isPinned = isPinned,
                                isMuted = isMuted,
                                isCustomUnread = isCustomUnread,
                                isPeekExpanded = isPeekExpanded,
                                peekQuickDraft = if (isPeekExpanded) peekQuickDraft else "",
                                onPeekDraftChange = { peekQuickDraft = it },
                                onTogglePin = {
                                    pinnedThreadIds[thread.creatorId] = !isPinned
                                },
                                onTogglePeek = {
                                    peekExpandedCreatorId = if (isPeekExpanded) null else thread.creatorId
                                    peekQuickDraft = ""
                                },
                                onOpenFullConversation = {
                                    onSelectThread(thread.creatorId)
                                    updateConversationOpen(true)
                                },
                                onLongPressThread = {
                                    selectedLongPressThread = thread
                                },
                                onSendQuickReply = { text, preset ->
                                    onSelectThread(thread.creatorId)
                                    onSendMessage(thread.creatorId, text, preset)
                                    peekQuickDraft = ""
                                }
                            )
                        }
                    }
                }
            } else {
                // =========================================================================
                // STAGE 2: FULL CONVERSATION VIEW (with Quick Switcher, GIF Studio & Voice)
                // =========================================================================
                SpatialConversationDetailView(
                    threads = activeThreads,
                    activeThread = activeThread,
                    isModalCompact = isModalCompact,
                    totalUnread = totalUnread,
                    messageReactions = messageReactions,
                    onToggleReaction = { msgId, emoji ->
                        if (messageReactions[msgId] == emoji) {
                            messageReactions.remove(msgId)
                        } else {
                            messageReactions[msgId] = emoji
                        }
                    },
                    onBackToInbox = { updateConversationOpen(false) },
                    onSelectThread = onSelectThread,
                    onSendMessage = onSendMessage,
                    onOpenCreatorProfile = onOpenCreatorProfile,
                    onCloseModal = onCloseModal
                )
            }
        }
    }

    // Long-Press Quick Actions Modal for Conversation Cards
    AnimatedVisibility(
        visible = selectedLongPressThread != null,
        enter = fadeIn(tween(160)) + scaleIn(
            initialScale = 0.88f,
            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow)
        ),
        exit = fadeOut(tween(130)) + scaleOut(targetScale = 0.90f, animationSpec = tween(140))
    ) {
        selectedLongPressThread?.let { thread ->
            val isPinned = pinnedThreadIds[thread.creatorId] == true
            val isMuted = mutedThreadIds[thread.creatorId] == true
            val isUnread = (thread.unreadCount > 0) || (customUnreadThreadIds[thread.creatorId] == true)

            BackHandler { selectedLongPressThread = null }

            SpatialThreadLongPressModal(
                thread = thread,
                isPinned = isPinned,
                isMuted = isMuted,
                isUnread = isUnread,
                onDismiss = { selectedLongPressThread = null },
                onTogglePin = {
                    pinnedThreadIds[thread.creatorId] = !isPinned
                    selectedLongPressThread = null
                },
                onToggleUnread = {
                    customUnreadThreadIds[thread.creatorId] = !isUnread
                    selectedLongPressThread = null
                },
                onToggleMute = {
                    mutedThreadIds[thread.creatorId] = !isMuted
                    selectedLongPressThread = null
                },
                onDeleteThread = {
                    deletedThreadIds.add(thread.creatorId)
                    selectedLongPressThread = null
                }
            )
        }
    }

    // Long-Press Spatial Mood Note Peek Modal for Creator Thought Bubbles
    AnimatedVisibility(
        visible = selectedLongPressThought != null,
        enter = fadeIn(tween(200)) + scaleIn(initialScale = 0.90f, animationSpec = tween(220)),
        exit = fadeOut(tween(150)) + scaleOut(targetScale = 0.92f, animationSpec = tween(160))
    ) {
        selectedLongPressThought?.let { (thread, thoughtData) ->
            val (thoughtText, preset) = thoughtData

            BackHandler { selectedLongPressThought = null }

            SpatialMoodNotePeekModal(
                thread = thread,
                thoughtText = thoughtText,
                preset = preset,
                onDismiss = { selectedLongPressThought = null },
                onQuoteAndReply = {
                    selectedLongPressThought = null
                    onSelectThread(thread.creatorId)
                    updateConversationOpen(true)
                    onSendMessage(
                        thread.creatorId,
                        "[REPLY_QUOTE:${thread.creatorName.substringBefore(" ")}|$thoughtText] Inspiring spatial note!",
                        preset
                    )
                }
            )
        }
    }
}
}

/**
 * Floating Glass Thought Bubbles with Live Spatial Mood Previews:
 * Displays creator portals with animated spatial backdrops and floating frosted thought notes.
 */
@Composable
private fun SpatialThoughtNotesRow(
    threads: List<DirectMessageThread>,
    ownThoughtText: String,
    isEditingOwnThought: Boolean,
    ownThoughtDraft: String,
    creatorThoughts: Map<String, Pair<String, VisualThemePreset>>,
    onStartEditOwnThought: () -> Unit,
    onOwnThoughtDraftChange: (String) -> Unit,
    onSaveOwnThought: () -> Unit,
    onCancelEditOwnThought: () -> Unit,
    onClickCreatorThought: (DirectMessageThread, String) -> Unit,
    onLongClickCreatorThought: (DirectMessageThread, Pair<String, VisualThemePreset>) -> Unit,
    testTag: String,
    itemTestTagPrefix: String
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // Inline Editor when user taps their own floating thought bubble
        AnimatedVisibility(
            visible = isEditingOwnThought,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(NexoraColors.Pearl100)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                BasicTextField(
                    value = ownThoughtDraft,
                    onValueChange = onOwnThoughtDraftChange,
                    singleLine = true,
                    textStyle = NexoraTypography.BadgeMicro.copy(
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    ),
                    cursorBrush = SolidColor(NexoraColors.ElectricIndigo),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("dm_own_thought_input"),
                    decorationBox = { inner ->
                        if (ownThoughtDraft.isEmpty()) {
                            Text(
                                text = "Share a floating spatial thought...",
                                style = NexoraTypography.BadgeMicro.copy(
                                    fontSize = 12.sp,
                                    color = NexoraColors.InkSecondary
                                )
                            )
                        }
                        inner()
                    }
                )
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF262626))
                        .clickable { onSaveOwnThought() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Check,
                        contentDescription = "Save thought",
                        tint = NexoraColors.EmeraldLive,
                        modifier = Modifier.size(14.dp)
                    )
                }
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF262626))
                        .clickable { onCancelEditOwnThought() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Cancel",
                        tint = NexoraColors.InkSecondary,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(vertical = 4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag(testTag)
        ) {
            // 1. User's Own Floating Thought Bubble Card (Clean & Borderless)
            item(key = "own_spatial_thought_card") {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .width(98.dp)
                        .clickable { onStartEditOwnThought() }
                        .testTag("dm_own_thought_bubble")
                ) {
                    // Floating Thought Cloud (Borderless)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(NexoraColors.Pearl100)
                            .padding(horizontal = 9.dp, vertical = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = ownThoughtText,
                                style = NexoraTypography.BadgeMicro.copy(
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White,
                                    lineHeight = 12.sp
                                ),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Icon(
                                imageVector = Icons.Filled.Edit,
                                contentDescription = "Edit thought",
                                tint = Color.White.copy(alpha = 0.85f),
                                modifier = Modifier.size(10.dp)
                            )
                        }
                    }

                    // Avatar + Live Spatial Mood Backdrop (Borderless)
                    Box(
                        modifier = Modifier.size(54.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                        ) {
                            SpatialVisualCanvas(
                                preset = VisualThemePreset.CYBER_LIGHTFIELD,
                                isAnimated = false,
                                playbackPhase = 0.25f
                            )
                        }
                        CreatorAvatarBadge(
                            name = "You",
                            seed = 1,
                            size = 40.dp,
                            borderWidth = 0.dp,
                            showOnlineDot = true
                        )
                    }

                    Text(
                        text = "Your Note",
                        style = NexoraTypography.BadgeMicro.copy(
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NexoraColors.InkSecondary
                        ),
                        maxLines = 1
                    )
                }
            }

            // 2. Creator Floating Thought Bubbles with Live Spatial Mood Previews (Clean & Borderless)
            items(threads, key = { it.creatorId }) { thread ->
                val (thoughtText, preset) = creatorThoughts[thread.creatorId]
                    ?: ("Spatial studio live" to VisualThemePreset.CLOUD_ATRIUM)

                val haptic = LocalHapticFeedback.current

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .width(98.dp)
                        .pointerInput(thread.creatorId) {
                            detectTapGestures(
                                onTap = { onClickCreatorThought(thread, thoughtText) },
                                onLongPress = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    onLongClickCreatorThought(thread, thoughtText to preset)
                                }
                            )
                        }
                        .testTag("$itemTestTagPrefix${thread.creatorId}")
                ) {
                    // Floating Thought Bubble (Borderless)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(NexoraColors.Pearl100)
                            .padding(horizontal = 9.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = thoughtText,
                            style = NexoraTypography.BadgeMicro.copy(
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White,
                                lineHeight = 12.sp
                            ),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Live Spatial Mood Ring + Creator Avatar (Borderless)
                    Box(
                        modifier = Modifier.size(54.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                        ) {
                            SpatialVisualCanvas(
                                preset = preset,
                                isAnimated = false,
                                playbackPhase = (thread.avatarSeed * 0.17f) % 1f
                            )
                        }
                        CreatorAvatarBadge(
                            name = thread.creatorName,
                            seed = thread.avatarSeed,
                            size = 40.dp,
                            borderWidth = 0.dp,
                            showOnlineDot = thread.isOnline
                        )
                    }

                    Text(
                        text = thread.creatorName.substringBefore(" "),
                        style = NexoraTypography.BadgeMicro.copy(
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

/**
 * High-Efficiency Inbox Thread Card with Instant Peek & Inline Quick Reply:
 * Lets the user preview the last 3 messages and reply in 1 tap directly inside the inbox
 * or tap the card to enter the full conversation screen.
 */
@Composable
private fun SpatialInboxThreadCard(
    thread: DirectMessageThread,
    isPinned: Boolean,
    isMuted: Boolean,
    isCustomUnread: Boolean,
    isPeekExpanded: Boolean,
    peekQuickDraft: String,
    onPeekDraftChange: (String) -> Unit,
    onTogglePin: () -> Unit,
    onTogglePeek: () -> Unit,
    onOpenFullConversation: () -> Unit,
    onLongPressThread: () -> Unit,
    onSendQuickReply: (String, VisualThemePreset?) -> Unit
) {
    val lastMsg = thread.messages.lastOrNull()
    val lastPreview = remember(lastMsg) { formatLastMessagePreview(lastMsg) }
    val haptic = LocalHapticFeedback.current
    val isUnreadEffective = (thread.unreadCount > 0) || isCustomUnread
    val callController = LocalSpatialCallController.current
    val isThreadInCall = callController.activeCallThread?.creatorId == thread.creatorId
    val hasMissedCall = callController.hasMissedCallFrom(thread)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                if (isPeekExpanded) NexoraColors.Pearl100
                else Color.Transparent
            )
            .pointerInput(thread.creatorId) {
                detectTapGestures(
                    onTap = { onOpenFullConversation() },
                    onLongPress = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onLongPressThread()
                    }
                )
            }
            .padding(horizontal = 6.dp, vertical = 8.dp)
            .testTag("dm_inbox_card_${thread.creatorId}"),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            CreatorAvatarBadge(
                name = thread.creatorName,
                seed = thread.avatarSeed,
                size = 50.dp,
                isSquircle = false,
                borderWidth = 0.dp,
                showOnlineDot = thread.isOnline
            )

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Text(
                        text = thread.creatorName,
                        style = NexoraTypography.CardTitle.copy(
                            fontSize = 15.sp,
                            fontWeight = if (isUnreadEffective) FontWeight.ExtraBold else FontWeight.SemiBold,
                            color = Color.White
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    VerifiedBadge(size = 13.dp)
                    if (isPinned) {
                        Icon(
                            imageVector = Icons.Filled.PushPin,
                            contentDescription = "Pinned",
                            tint = NexoraColors.ElectricIndigo,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                    if (isMuted) {
                        Icon(
                            imageVector = Icons.Filled.NotificationsOff,
                            contentDescription = "Muted",
                            tint = NexoraColors.InkMuted,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                    Spacer(modifier = Modifier.weight(1f))
                    Text(
                        text = lastMsg?.timestamp ?: "Now",
                        style = NexoraTypography.BadgeMicro.copy(
                            fontSize = 11.sp,
                            fontWeight = if (isUnreadEffective) FontWeight.Bold else FontWeight.Normal,
                            color = if (isUnreadEffective) NexoraColors.ElectricIndigo else NexoraColors.InkSecondary
                        )
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = lastPreview,
                        style = NexoraTypography.NavPillLabel.copy(
                            fontSize = 13.sp,
                            fontWeight = if (hasMissedCall || isUnreadEffective) FontWeight.Bold else FontWeight.Normal,
                            color = when {
                                hasMissedCall -> NexoraColors.LiveRose
                                isUnreadEffective -> Color.White
                                else -> NexoraColors.InkSecondary
                            }
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )

                    if (isUnreadEffective) {
                        val countLabel = if (thread.unreadCount > 0) "${thread.unreadCount}" else "1"
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(999.dp))
                                .background(
                                    if (hasMissedCall) NexoraColors.LiveRose
                                    else NexoraColors.ElectricIndigo
                                )
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = countLabel,
                                style = NexoraTypography.BadgeMicro.copy(
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                            )
                        }
                    }
                }
            }

            // Call Button (shown ONLY when user had a missed call from this user or call is active) + Instant Peek Button
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (hasMissedCall || isThreadInCall) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    isThreadInCall -> Color.White
                                    hasMissedCall -> NexoraColors.LiveRose.copy(alpha = 0.2f)
                                    else -> NexoraColors.Pearl100
                                }
                            )
                            .clickable {
                                callController.startCall(thread, startMinimized = false)
                            }
                            .testTag("dm_inbox_call_btn_${thread.creatorId}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Call,
                            contentDescription = "Call back ${thread.creatorName}",
                            tint = when {
                                isThreadInCall -> Color(0xFF000000)
                                hasMissedCall -> NexoraColors.LiveRose
                                else -> Color.White
                            },
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(
                            if (isPeekExpanded) Color.White
                            else NexoraColors.Pearl100
                        )
                        .clickable { onTogglePeek() }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("dm_peek_btn_${thread.creatorId}"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (isPeekExpanded) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                            contentDescription = if (isPeekExpanded) "Collapse Peek" else "Instant Peek",
                            tint = if (isPeekExpanded) Color(0xFF000000) else NexoraColors.InkSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "Peek",
                            style = NexoraTypography.BadgeMicro.copy(
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isPeekExpanded) Color(0xFF000000) else NexoraColors.InkPrimary
                            )
                        )
                    }
                }
            }
        }

        // Expandable Instant Peek Panel (shows recent messages + 1-tap quick replies inline, no outer border)
        AnimatedVisibility(
            visible = isPeekExpanded,
            enter = expandVertically(spring(stiffness = Spring.StiffnessMediumLow)) + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(NexoraColors.CanvasBase)
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                thread.messages.takeLast(3).forEach { msg ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (msg.isFromMe) Arrangement.End else Arrangement.Start
                    ) {
                        Box(
                            modifier = Modifier
                                .widthIn(max = 240.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(
                                    if (msg.isFromMe) NexoraColors.ElectricIndigo
                                    else Color(0xFF262626)
                                )
                                .padding(horizontal = 11.dp, vertical = 7.dp)
                        ) {
                            Text(
                                text = formatLastMessagePreview(msg),
                                style = NexoraTypography.BadgeMicro.copy(
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color.White
                                ),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                // 1-Tap Quick Reply Chips + Inline Mini Composer
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(
                        listOf(
                            "Pure fire!" to null,
                            "Let's collab" to null,
                            "Fjord Scene" to VisualThemePreset.FJORD_AURORA,
                            "Voice Wave" to null
                        ),
                        key = { it.first }
                    ) { (label, preset) ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(999.dp))
                                .background(Color(0xFF262626))
                                .clickable {
                                    if (label.contains("Voice Wave")) {
                                        onSendQuickReply(
                                            VoiceWavePayload("0:11", "Spatial Audio Note", 9).toToken(),
                                            null
                                        )
                                    } else {
                                        onSendQuickReply(label, preset)
                                    }
                                }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = label,
                                style = NexoraTypography.BadgeMicro.copy(
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White
                                )
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .height(36.dp)
                            .clip(RoundedCornerShape(999.dp))
                            .background(Color(0xFF262626))
                            .padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BasicTextField(
                            value = peekQuickDraft,
                            onValueChange = onPeekDraftChange,
                            singleLine = true,
                            textStyle = NexoraTypography.BadgeMicro.copy(
                                fontSize = 12.5.sp,
                                color = Color.White
                            ),
                            cursorBrush = SolidColor(NexoraColors.ElectricIndigo),
                            modifier = Modifier.weight(1f),
                            decorationBox = { inner ->
                                if (peekQuickDraft.isEmpty()) {
                                    Text(
                                        text = "Quick inline reply to ${thread.creatorName.substringBefore(" ")}...",
                                        style = NexoraTypography.BadgeMicro.copy(
                                            fontSize = 11.5.sp,
                                            color = NexoraColors.InkSecondary
                                        ),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                inner()
                            }
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(NexoraColors.ElectricIndigo)
                            .clickable {
                                if (peekQuickDraft.isNotBlank()) {
                                    onSendQuickReply(peekQuickDraft.trim(), null)
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send inline reply",
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * STAGE 2: Full Conversation View with Quick Switcher Rail, Infinite 2-Row GIF Studio,
 * Playable Spatial Voice Wave Notes, Spatial Scene Cards, and Emoji Message Reactions.
 */
@Composable
private fun SpatialConversationDetailView(
    threads: List<DirectMessageThread>,
    activeThread: DirectMessageThread?,
    isModalCompact: Boolean,
    totalUnread: Int,
    messageReactions: Map<String, String>,
    onToggleReaction: (String, String) -> Unit,
    onBackToInbox: () -> Unit,
    onSelectThread: (String) -> Unit,
    onSendMessage: (creatorId: String, text: String, sharedPreset: VisualThemePreset?) -> Unit,
    onOpenCreatorProfile: (String) -> Unit,
    onCloseModal: (() -> Unit)?
) {
    if (activeThread == null) return

    var messageInput by remember(activeThread.creatorId) { mutableStateOf("") }
    var replyingToMessage by remember(activeThread.creatorId) { mutableStateOf<DirectChatMessage?>(null) }
    var activeReactionPickerMessageId by remember(activeThread.creatorId) { mutableStateOf<String?>(null) }
    var isScenePickerOpen by remember(activeThread.creatorId) { mutableStateOf(false) }
    var isGifPickerOpen by remember(activeThread.creatorId) { mutableStateOf(false) }
    var isMediaPickerOpen by remember(activeThread.creatorId) { mutableStateOf(false) }
    val callController = LocalSpatialCallController.current
    val isCallActive = callController.activeCallThread?.creatorId == activeThread.creatorId
    val hasMissedCall = callController.hasMissedCallFrom(activeThread)
    var gifSearchQuery by remember(activeThread.creatorId) { mutableStateOf("") }
    var selectedGifCategory by remember { mutableStateOf("Trending") }
    var playingVoiceMessageId by remember { mutableStateOf<String?>(null) }
    var voiceClipCounter by remember { mutableIntStateOf(1) }

    val coroutineScope = rememberCoroutineScope()
    val messagesListState = rememberLazyListState()
    val gifGridState = rememberLazyGridState()

    // Auto-scroll to latest message when thread changes or new message arrives
    LaunchedEffect(activeThread.creatorId, activeThread.messages.size) {
        if (activeThread.messages.isNotEmpty()) {
            runCatching {
                messagesListState.animateScrollToItem(activeThread.messages.lastIndex)
            }
        }
    }

    // Infinite GIF pagination state for Chat GIF Studio
    var publicGifs by remember { mutableStateOf(PublicGifRepository.curatedPublicGifs) }
    var nextTenorPos by remember { mutableStateOf<String?>(null) }
    var nextOffset by remember { mutableIntStateOf(0) }
    var currentPage by remember { mutableIntStateOf(0) }
    var isFetchingPublicGifs by remember { mutableStateOf(false) }
    var isLoadingMoreGifs by remember { mutableStateOf(false) }

    LaunchedEffect(gifSearchQuery, selectedGifCategory, isGifPickerOpen) {
        currentPage = 0
        nextTenorPos = null
        nextOffset = 0
        publicGifs = PublicGifRepository.filterCurated(gifSearchQuery, selectedGifCategory)

        if (isGifPickerOpen) {
            isFetchingPublicGifs = true
            runCatching { gifGridState.scrollToItem(0) }
            if (gifSearchQuery.isNotBlank()) {
                delay(220)
            }
            val firstPage = PublicGifRepository.fetchPublicGifPage(
                query = gifSearchQuery,
                category = selectedGifCategory,
                tenorPos = null,
                offset = 0,
                pageIndex = 0
            )
            publicGifs = firstPage.items
            nextTenorPos = firstPage.nextTenorPos
            nextOffset = firstPage.nextOffset
            currentPage = 1
            isFetchingPublicGifs = false
        }
    }

    val shouldLoadMoreGifs by remember {
        derivedStateOf {
            val layoutInfo = gifGridState.layoutInfo
            val totalItems = layoutInfo.totalItemsCount
            val lastVisible = layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            totalItems > 0 && lastVisible >= (totalItems - 6).coerceAtLeast(1)
        }
    }

    suspend fun loadNextInfiniteChatGifBatch() {
        if (isLoadingMoreGifs || isFetchingPublicGifs) return
        isLoadingMoreGifs = true
        val pageResult = PublicGifRepository.fetchPublicGifPage(
            query = gifSearchQuery,
            category = selectedGifCategory,
            tenorPos = nextTenorPos,
            offset = nextOffset,
            pageIndex = currentPage
        )
        val existingIds = publicGifs.asSequence().map { it.id }.toHashSet()
        val uniqueNew = pageResult.items.filterNot { it.id in existingIds }
        if (uniqueNew.isNotEmpty()) {
            publicGifs = publicGifs + uniqueNew
        }
        nextTenorPos = pageResult.nextTenorPos
        nextOffset = pageResult.nextOffset
        currentPage += 1
        isLoadingMoreGifs = false
    }

    LaunchedEffect(shouldLoadMoreGifs, isGifPickerOpen) {
        if (isGifPickerOpen && shouldLoadMoreGifs) {
            loadNextInfiniteChatGifBatch()
        }
    }

    fun dispatchRichMessage(rawContent: String, preset: VisualThemePreset? = null) {
        val quotePrefix = replyingToMessage?.let { quoted ->
            ReplyQuotePayload(
                senderName = if (quoted.isFromMe) "You" else quoted.senderName,
                snippet = formatLastMessagePreview(quoted)
            ).toToken()
        }.orEmpty()

        onSendMessage(activeThread.creatorId, "$quotePrefix$rawContent", preset)
        replyingToMessage = null
        messageInput = ""
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (!isModalCompact) Modifier.fillMaxSize() else Modifier)
            .background(NexoraColors.CanvasBase),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // TOP SECTION: Quick Top Bar (back_icon)(profile_icon) (name)(live_indicator under the name)(call_icon) + Call Banner
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(NexoraColors.CanvasBase)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(if (isModalCompact) WindowInsets(0, 0, 0, 0) else WindowInsets.statusBars)
                    .padding(
                        start = 14.dp,
                        end = 14.dp,
                        top = if (isModalCompact) 10.dp else 22.dp,
                        bottom = 12.dp
                    ),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // (back_icon)
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(NexoraColors.Pearl100)
                        .clickable { onBackToInbox() }
                        .testTag("dm_back_to_inbox_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to Inbox",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // (profile_icon)
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clickable {
                            onCloseModal?.invoke()
                            onOpenCreatorProfile(activeThread.creatorId)
                        }
                        .testTag("dm_top_profile_icon"),
                    contentAlignment = Alignment.Center
                ) {
                    CreatorAvatarBadge(
                        name = activeThread.creatorName,
                        seed = activeThread.avatarSeed,
                        size = 40.dp,
                        isSquircle = false,
                        borderWidth = 0.dp,
                        showOnlineDot = false
                    )
                }

                // (name)(live_indicator under the name)
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            onCloseModal?.invoke()
                            onOpenCreatorProfile(activeThread.creatorId)
                        },
                    verticalArrangement = Arrangement.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = activeThread.creatorName,
                            style = NexoraTypography.CardTitle.copy(
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        VerifiedBadge(size = 13.dp)
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(
                                    when {
                                        hasMissedCall && !isCallActive -> NexoraColors.LiveRose
                                        activeThread.isOnline -> NexoraColors.EmeraldLive
                                        else -> NexoraColors.InkMuted
                                    }
                                )
                        )
                        Text(
                            text = when {
                                hasMissedCall && !isCallActive -> "Missed call"
                                activeThread.isOnline -> "Active now"
                                else -> "Offline"
                            },
                            style = NexoraTypography.BadgeMicro.copy(
                                fontSize = 11.sp,
                                color = when {
                                    hasMissedCall && !isCallActive -> NexoraColors.LiveRose
                                    activeThread.isOnline -> NexoraColors.EmeraldLive
                                    else -> NexoraColors.InkSecondary
                                },
                                fontWeight = if (activeThread.isOnline || hasMissedCall) FontWeight.SemiBold else FontWeight.Normal
                            )
                        )
                    }
                }

                // (call_icon) — shown ONLY when user had a missed call from that user (or call is currently active)
                if (hasMissedCall || isCallActive) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    isCallActive -> Color.White
                                    hasMissedCall -> NexoraColors.LiveRose.copy(alpha = 0.2f)
                                    else -> NexoraColors.Pearl100
                                }
                            )
                            .clickable {
                                if (isCallActive) {
                                    callController.expandCall()
                                } else {
                                    callController.startCall(activeThread, startMinimized = false)
                                }
                            }
                            .testTag("dm_call_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Call,
                            contentDescription = "Call back ${activeThread.creatorName}",
                            tint = when {
                                isCallActive -> Color(0xFF000000)
                                hasMissedCall -> NexoraColors.LiveRose
                                else -> Color.White
                            },
                            modifier = Modifier.size(21.dp)
                        )
                    }
                }

                if (onCloseModal != null) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(NexoraColors.Pearl100)
                            .clickable { onCloseModal() }
                            .testTag("dm_close_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Close Direct Messages",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Animated In-Call / Audio Ringing Banner (Borderless, with One-Tap ANC & Expand Stage)
            AnimatedVisibility(
                visible = isCallActive,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(999.dp))
                        .background(NexoraColors.Pearl100)
                        .clickable { callController.expandCall() }
                        .padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(9.dp)
                                .clip(CircleShape)
                                .background(NexoraColors.EmeraldLive)
                        )
                        Text(
                            text = "HD Call • ${formatCallDuration(callController.callDurationSeconds)}",
                            style = NexoraTypography.BadgeMicro.copy(
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(999.dp))
                                .background(
                                    if (callController.isNoiseCancellationEnabled) Color.White
                                    else Color(0xFF262626)
                                )
                                .clickable { callController.toggleNoiseCancellation() }
                                .padding(horizontal = 8.dp, vertical = 2.5.dp)
                        ) {
                            Text(
                                text = if (callController.isNoiseCancellationEnabled) "ANC ON" else "ANC OFF",
                                style = NexoraTypography.BadgeMicro.copy(
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (callController.isNoiseCancellationEnabled) Color(0xFF000000) else Color.White
                                )
                            )
                        }
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .height(26.dp)
                                .clip(RoundedCornerShape(999.dp))
                                .background(Color(0xFF262626))
                                .clickable { callController.expandCall() }
                                .padding(horizontal = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Stage",
                                style = NexoraTypography.BadgeMicro.copy(
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                        }
                        Box(
                            modifier = Modifier
                                .height(26.dp)
                                .clip(RoundedCornerShape(999.dp))
                                .background(NexoraColors.LiveRose)
                                .clickable { callController.endCall() }
                                .padding(horizontal = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "End",
                                style = NexoraTypography.BadgeMicro.copy(
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                            )
                        }
                    }
                }
            }
        }

        // MIDDLE SECTION: Messages Stream filling 100% available vertical space
        LazyColumn(
            state = messagesListState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 14.dp)
                .testTag(
                    if (isModalCompact) "dm_messages_list" else "stage_dm_messages_list"
                ),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(top = 10.dp, bottom = 10.dp)
        ) {
            items(activeThread.messages, key = { it.id }) { msg ->
                RichDirectMessageBubble(
                    msg = msg,
                    partnerAvatarSeed = activeThread.avatarSeed,
                    activeReaction = messageReactions[msg.id],
                    isReactionMenuOpen = activeReactionPickerMessageId == msg.id,
                    isPlayingVoice = playingVoiceMessageId == msg.id,
                    onToggleReactionMenu = {
                        activeReactionPickerMessageId =
                            if (activeReactionPickerMessageId == msg.id) null else msg.id
                    },
                    onSelectReaction = { emoji ->
                        onToggleReaction(msg.id, emoji)
                        activeReactionPickerMessageId = null
                    },
                    onQuoteReply = {
                        replyingToMessage = msg
                        activeReactionPickerMessageId = null
                    },
                    onToggleVoicePlay = {
                        playingVoiceMessageId =
                            if (playingVoiceMessageId == msg.id) null else msg.id
                    }
                )
            }
        }

        // BOTTOM SECTION: Quoted Reply Banner + Expandable GIF/Media Drawers + Multi-Modal Composer Bar (Borderless & Clear)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(NexoraColors.CanvasBase)
        ) {
            // Replying-To Quote Banner (when active)
            if (replyingToMessage != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(NexoraColors.Pearl100)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (replyingToMessage?.isFromMe == true) "Replying to yourself" else "Replying to ${activeThread.creatorName}",
                            style = NexoraTypography.BadgeMicro.copy(
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = NexoraColors.ElectricIndigo
                            )
                        )
                        Text(
                            text = formatLastMessagePreview(replyingToMessage),
                            style = NexoraTypography.BadgeMicro.copy(
                                fontSize = 12.sp,
                                color = Color.White
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Cancel quote reply",
                        tint = NexoraColors.InkSecondary,
                        modifier = Modifier
                            .size(16.dp)
                            .clickable { replyingToMessage = null }
                    )
                }
            }

            // Expandable GIF Studio (when gif_ico is tapped)
            AnimatedVisibility(
                visible = isGifPickerOpen,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(230.dp)
                        .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
                        .background(NexoraColors.Pearl100)
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Search & close
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .height(36.dp)
                                .clip(RoundedCornerShape(999.dp))
                                .background(Color(0xFF262626))
                                .padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Search,
                                contentDescription = "Search GIFs",
                                tint = NexoraColors.InkSecondary,
                                modifier = Modifier.size(15.dp)
                            )
                            BasicTextField(
                                value = gifSearchQuery,
                                onValueChange = { gifSearchQuery = it },
                                singleLine = true,
                                textStyle = NexoraTypography.BadgeMicro.copy(
                                    fontSize = 12.5.sp,
                                    color = Color.White
                                ),
                                cursorBrush = SolidColor(NexoraColors.ElectricIndigo),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("dm_gif_search_input"),
                                decorationBox = { inner ->
                                    if (gifSearchQuery.isEmpty()) {
                                        Text(
                                            text = "Search infinite GIFs...",
                                            style = NexoraTypography.BadgeMicro.copy(
                                                fontSize = 11.5.sp,
                                                color = NexoraColors.InkSecondary
                                            ),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    inner()
                                }
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(999.dp))
                                    .background(NexoraColors.ElectricIndigo)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "${publicGifs.size}+ ∞",
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontSize = 8.5.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color.White
                                    )
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF262626))
                                .clickable { isGifPickerOpen = false },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Close GIF Studio",
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }

                    // Categories
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(PublicGifRepository.categories, key = { it }) { cat ->
                            val isSelected = selectedGifCategory == cat && gifSearchQuery.isBlank()
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(999.dp))
                                    .background(
                                        if (isSelected) Color.White
                                        else Color(0xFF262626)
                                    )
                                    .clickable {
                                        selectedGifCategory = cat
                                        gifSearchQuery = ""
                                    }
                                    .padding(horizontal = 11.dp, vertical = 4.5.dp)
                            ) {
                                Text(
                                    text = cat,
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontSize = 10.5.sp,
                                        fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold,
                                        color = if (isSelected) Color(0xFF000000) else Color.White.copy(alpha = 0.85f)
                                    )
                                )
                            }
                        }
                    }

                    // 2 Rows of GIFs with infinite scroll
                    LazyHorizontalGrid(
                        rows = GridCells.Fixed(2),
                        state = gifGridState,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .testTag("dm_gif_picker_grid"),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(publicGifs, key = { it.id }) { gif ->
                            AnimatedCommentGifCard(
                                sticker = gif,
                                modifier = Modifier
                                    .width(140.dp)
                                    .fillMaxHeight()
                                    .clickable {
                                        val prefix = if (messageInput.isNotBlank()) "${messageInput.trim()} " else ""
                                        dispatchRichMessage("$prefix${gif.toToken()}")
                                        isGifPickerOpen = false
                                        gifSearchQuery = ""
                                    }
                            )
                        }
                    }
                }
            }

            // Expandable Media Picker Drawer (when media_icon is tapped)
            AnimatedVisibility(
                visible = isMediaPickerOpen,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
                        .background(NexoraColors.Pearl100)
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Attach Spatial Media & Photo Scenes",
                            style = NexoraTypography.BadgeMicro.copy(
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Close media picker",
                            tint = Color.White,
                            modifier = Modifier
                                .size(16.dp)
                                .clickable { isMediaPickerOpen = false }
                        )
                    }

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(vertical = 2.dp)
                    ) {
                        items(VisualThemePreset.entries, key = { it.name }) { preset ->
                            Box(
                                modifier = Modifier
                                    .width(118.dp)
                                    .height(68.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable {
                                        dispatchRichMessage("Shared ${preset.label}", preset)
                                        isMediaPickerOpen = false
                                    }
                            ) {
                                SpatialVisualCanvas(
                                    preset = preset,
                                    isAnimated = false,
                                    playbackPhase = 0.5f
                                )
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomStart)
                                        .padding(4.dp)
                                        .clip(RoundedCornerShape(999.dp))
                                        .background(Color(0xB3000000))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = preset.label,
                                        style = NexoraTypography.BadgeMicro.copy(
                                            fontSize = 8.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        ),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Multi-Modal Composer Bar: (voice recorder)(msg_pill)(gif_ico)(media_icon)(send_icon) — Borderless & Clear
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(if (isModalCompact) WindowInsets(0, 0, 0, 0) else WindowInsets.navigationBars)
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // 1. (voice recorder)
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(NexoraColors.Pearl100)
                        .clickable {
                            val durations = listOf("0:09", "0:14", "0:19", "0:24")
                            val dur = durations[voiceClipCounter % durations.size]
                            voiceClipCounter += 1
                            dispatchRichMessage(
                                VoiceWavePayload(
                                    durationLabel = dur,
                                    title = "Spatial Voice Note",
                                    seed = voiceClipCounter * 13
                                ).toToken()
                            )
                        }
                        .testTag("dm_send_voice_wave_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Mic,
                        contentDescription = "Voice recorder",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // 2. (msg_pill)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .clip(RoundedCornerShape(999.dp))
                        .background(NexoraColors.Pearl100)
                        .padding(horizontal = 14.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    BasicTextField(
                        value = messageInput,
                        onValueChange = { messageInput = it },
                        singleLine = true,
                        textStyle = NexoraTypography.NavPillLabel.copy(
                            fontSize = 14.5.sp,
                            color = Color.White
                        ),
                        cursorBrush = SolidColor(NexoraColors.ElectricIndigo),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag(
                                if (isModalCompact) "dm_message_input" else "stage_dm_message_input"
                            ),
                        decorationBox = { inner ->
                            if (messageInput.isEmpty()) {
                                Text(
                                    text = "Message...",
                                    style = NexoraTypography.NavPillLabel.copy(
                                        fontSize = 14.5.sp,
                                        color = NexoraColors.InkSecondary
                                    ),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            inner()
                        }
                    )
                }

                // 3. (gif_ico)
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(
                            if (isGifPickerOpen) NexoraColors.ElectricIndigo
                            else NexoraColors.Pearl100
                        )
                        .clickable {
                            isGifPickerOpen = !isGifPickerOpen
                            if (isGifPickerOpen) isMediaPickerOpen = false
                        }
                        .testTag("dm_gif_toggle_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Gif,
                        contentDescription = "Toggle GIF Studio",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }

                // 4. (media_icon)
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(
                            if (isMediaPickerOpen) NexoraColors.ElectricIndigo
                            else NexoraColors.Pearl100
                        )
                        .clickable {
                            isMediaPickerOpen = !isMediaPickerOpen
                            if (isMediaPickerOpen) isGifPickerOpen = false
                        }
                        .testTag("dm_media_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Image,
                        contentDescription = "Attach Media",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // 5. (send_icon)
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(NexoraColors.ElectricIndigo)
                        .clickable {
                            if (messageInput.isNotBlank()) {
                                dispatchRichMessage(messageInput.trim(), null)
                            } else {
                                dispatchRichMessage("LOVE", null)
                            }
                        }
                        .testTag(
                            if (isModalCompact) "dm_send_button" else "stage_dm_send_button"
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send Message",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

/**
 * Rich Message Bubble supporting Quoted Replies, Spatial Scene Cards, Animated Public GIFs,
 * Interactive Spatial Voice Wave Notes, and Floating Emoji Reactions — Borderless & Crystal Clear.
 */
@Composable
private fun RichDirectMessageBubble(
    msg: DirectChatMessage,
    partnerAvatarSeed: Int,
    activeReaction: String?,
    isReactionMenuOpen: Boolean,
    isPlayingVoice: Boolean,
    onToggleReactionMenu: () -> Unit,
    onSelectReaction: (String) -> Unit,
    onQuoteReply: () -> Unit,
    onToggleVoicePlay: () -> Unit
) {
    val parsedGif = remember(msg.text) { parseGifFromComment(msg.text) }
    val parsedVoice = remember(msg.text) { parseVoiceWaveFromMessage(msg.text) }
    val parsedQuote = remember(msg.text) { parseReplyQuoteFromMessage(msg.text) }
    val cleanedText = remember(msg.text) { cleanDirectMessageText(msg.text) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (msg.isFromMe) Alignment.End else Alignment.Start,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Floating Emoji Reaction & Quote-Reply Bar when bubble is tapped
        AnimatedVisibility(
            visible = isReactionMenuOpen,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(999.dp))
                    .background(Color(0xFF262626))
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("LOVE", "FIRE", "WOW", "HAHA", "100%", "CLAP").forEach { reactionTag ->
                    Box(
                        modifier = Modifier
                            .height(26.dp)
                            .clip(RoundedCornerShape(999.dp))
                            .background(
                                if (activeReaction == reactionTag) NexoraColors.ElectricIndigo
                                else Color.Transparent
                            )
                            .clickable { onSelectReaction(reactionTag) }
                            .padding(horizontal = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = reactionTag, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    modifier = Modifier
                        .clickable { onQuoteReply() }
                        .padding(horizontal = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Reply,
                        contentDescription = "Quote Reply",
                        tint = NexoraColors.ElectricIndigo,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "Reply",
                        style = NexoraTypography.BadgeMicro.copy(
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                }
            }
        }

        Row(
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (!msg.isFromMe) {
                CreatorAvatarBadge(
                    name = msg.senderName,
                    seed = partnerAvatarSeed,
                    size = 28.dp,
                    isSquircle = false,
                    borderWidth = 0.dp,
                    showOnlineDot = false
                )
            }

            Box {
                Column(
                    modifier = Modifier
                        .widthIn(max = 286.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            if (msg.isFromMe) {
                                NexoraColors.ElectricIndigo
                            } else {
                                Color(0xFF262626)
                            }
                        )
                        .clickable { onToggleReactionMenu() }
                        .padding(horizontal = 13.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // 1. Quoted Reply Context Bar (if present) — Borderless
                    if (parsedQuote != null) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (msg.isFromMe) Color.Black.copy(alpha = 0.22f)
                                    else NexoraColors.CanvasBase
                                )
                                .padding(horizontal = 9.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = parsedQuote.senderName,
                                style = NexoraTypography.BadgeMicro.copy(
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (msg.isFromMe) Color.White else NexoraColors.ElectricIndigo
                                )
                            )
                            Text(
                                text = parsedQuote.snippet,
                                style = NexoraTypography.BadgeMicro.copy(
                                    fontSize = 11.sp,
                                    color = Color.White.copy(alpha = 0.85f)
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    // 2. Shared Spatial Scene Card (if present)
                    msg.sharedPreset?.let { preset ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(86.dp)
                                .clip(RoundedCornerShape(12.dp))
                        ) {
                            SpatialVisualCanvas(
                                preset = preset,
                                isAnimated = false,
                                playbackPhase = 0.4f
                            )
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(6.dp)
                                    .clip(RoundedCornerShape(999.dp))
                                    .background(Color(0xB3000000))
                                    .padding(horizontal = 8.dp, vertical = 2.5.dp)
                            ) {
                                Text(
                                    text = preset.label,
                                    style = NexoraTypography.BadgeMicro.copy(
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                )
                            }
                        }
                    }

                    // 3. Embedded Animated Public GIF Card (if present)
                    if (parsedGif != null) {
                        AnimatedCommentGifCard(
                            sticker = parsedGif,
                            modifier = Modifier
                                .width(196.dp)
                                .height(120.dp)
                        )
                    }

                    // 4. Interactive Spatial Voice Wave Note (if present)
                    if (parsedVoice != null) {
                        SpatialVoiceWaveBubble(
                            voice = parsedVoice,
                            isPlaying = isPlayingVoice,
                            onTogglePlay = onToggleVoicePlay
                        )
                    }

                    // 5. Message Text (High-Contrast White on both Blue and Dark Charcoal bubbles)
                    if (cleanedText.isNotEmpty()) {
                        Text(
                            text = cleanedText,
                            style = NexoraTypography.NavPillLabel.copy(
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color.White,
                                lineHeight = 19.sp
                            )
                        )
                    }
                }

                // Active Emoji Reaction Pill Badge on bottom corner (Borderless)
                if (activeReaction != null) {
                    Box(
                        modifier = Modifier
                            .align(if (msg.isFromMe) Alignment.BottomStart else Alignment.BottomEnd)
                            .padding(horizontal = 4.dp)
                            .clip(RoundedCornerShape(999.dp))
                            .background(NexoraColors.Pearl100)
                            .clickable { onSelectReaction(activeReaction) }
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(text = activeReaction, fontSize = 11.5.sp)
                    }
                }
            }
        }

        Text(
            text = msg.timestamp,
            style = NexoraTypography.BadgeMicro.copy(
                fontSize = 10.sp,
                color = NexoraColors.InkSecondary
            ),
            modifier = Modifier.padding(horizontal = if (msg.isFromMe) 6.dp else 38.dp)
        )
    }
}

/**
 * Interactive Spatial Voice Wave Note Bubble:
 * Renders a Play/Pause button, animated 22-bar kinetic waveform canvas, and spatial audio badge (Borderless & Clear).
 */
@Composable
private fun SpatialVoiceWaveBubble(
    voice: VoiceWavePayload,
    isPlaying: Boolean,
    onTogglePlay: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "voice_wave_${voice.seed}")
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "voice_phase"
    )

    Row(
        modifier = Modifier
            .width(220.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color.Black.copy(alpha = 0.24f))
            .clickable { onTogglePlay() }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = if (isPlaying) "Pause Voice Note" else "Play Voice Note",
                tint = Color(0xFF121212),
                modifier = Modifier.size(17.dp)
            )
        }

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(20.dp)
            ) {
                val barCount = 22
                val step = size.width / barCount
                for (i in 0 until barCount) {
                    val baseAmp = 0.25f + 0.70f * abs(sin((i * 0.65f) + voice.seed))
                    val animatedAmp = if (isPlaying) {
                        0.22f + 0.78f * abs(sin((wavePhase * 6.28f) + i * 0.55f))
                    } else {
                        baseAmp
                    }
                    val barH = (size.height * animatedAmp).coerceAtLeast(3.dp.toPx())
                    val x = i * step + step * 0.5f
                    drawLine(
                        color = if (i % 2 == 0) Color.White else Color.White.copy(alpha = 0.75f),
                        start = Offset(x, (size.height - barH) * 0.5f),
                        end = Offset(x, (size.height + barH) * 0.5f),
                        strokeWidth = 2.4.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isPlaying) "Playing Spatial Wave..." else voice.title,
                    style = NexoraTypography.BadgeMicro.copy(
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
                Text(
                    text = voice.durationLabel,
                    style = NexoraTypography.BadgeMicro.copy(
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                )
            }
        }
    }
}

/**
 * Instagram-Style Elevated Frosted Glass Action Card:
 * Features a lifted conversation row preview suspended above a soft dimmed backdrop scrim,
 * with a sleek frosted context menu directly below containing Instagram-style actions:
 * - Pin to top / Unpin (PushPin on right)
 * - Mark as unread / Mark as read (Drafts/Email on right)
 * - Mute alerts / Unmute alerts (NotificationsOff on right)
 * - Delete (Signature LiveRose red accent on right)
 * Separated by subtle frosted hairline dividers.
 */
@Composable
private fun SpatialThreadLongPressModal(
    thread: DirectMessageThread,
    isPinned: Boolean,
    isMuted: Boolean,
    isUnread: Boolean,
    onDismiss: () -> Unit,
    onTogglePin: () -> Unit,
    onToggleUnread: () -> Unit,
    onToggleMute: () -> Unit,
    onDeleteThread: () -> Unit
) {
    val lastMsg = thread.messages.lastOrNull()
    val lastPreview = remember(lastMsg) { formatLastMessagePreview(lastMsg) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.65f))
            .clickable(onClick = onDismiss)
            .testTag("dm_thread_long_press_backdrop"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.88f)
                .widthIn(max = 350.dp)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { /* Consume taps on card container */ },
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. Instagram-Style Lifted Thread Preview Card (Borderless & Clear)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(NexoraColors.CanvasBase)
                    .padding(horizontal = 14.dp, vertical = 12.dp)
                    .testTag("dm_lifted_thread_preview"),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CreatorAvatarBadge(
                        name = thread.creatorName,
                        seed = thread.avatarSeed,
                        size = 46.dp,
                        isSquircle = false,
                        borderWidth = 0.dp,
                        showOnlineDot = thread.isOnline
                    )

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Text(
                                text = thread.creatorName,
                                style = NexoraTypography.CardTitle.copy(
                                    fontSize = 14.5.sp,
                                    fontWeight = if (isUnread) FontWeight.ExtraBold else FontWeight.Bold,
                                    color = Color.White
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            VerifiedBadge(size = 13.dp)
                            if (isPinned) {
                                Icon(
                                    imageVector = Icons.Filled.PushPin,
                                    contentDescription = "Pinned",
                                    tint = NexoraColors.ElectricIndigo,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                            if (isMuted) {
                                Icon(
                                    imageVector = Icons.Filled.NotificationsOff,
                                    contentDescription = "Muted",
                                    tint = NexoraColors.InkMuted,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                            Spacer(modifier = Modifier.weight(1f))
                            Text(
                                text = lastMsg?.timestamp ?: "Now",
                                style = NexoraTypography.BadgeMicro.copy(
                                    fontSize = 10.sp,
                                    fontWeight = if (isUnread) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isUnread) NexoraColors.ElectricIndigo else NexoraColors.InkSecondary
                                )
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = lastPreview,
                                style = NexoraTypography.NavPillLabel.copy(
                                    fontSize = 12.5.sp,
                                    fontWeight = if (isUnread) FontWeight.SemiBold else FontWeight.Normal,
                                    color = if (isUnread) Color.White else NexoraColors.InkSecondary
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )

                            if (isUnread) {
                                val countLabel = if (thread.unreadCount > 0) "${thread.unreadCount}" else "1"
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(999.dp))
                                        .background(NexoraColors.ElectricIndigo)
                                        .padding(horizontal = 7.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = countLabel,
                                        style = NexoraTypography.BadgeMicro.copy(
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = Color.White
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 2. Instagram-Style Elevated Context Menu Card (Borderless)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(NexoraColors.CanvasBase)
                    .testTag("dm_thread_long_press_card")
            ) {
                // Item 1: Pin to top / Unpin
                InstagramFrostedActionRow(
                    title = if (isPinned) "Unpin" else "Pin to top",
                    icon = Icons.Filled.PushPin,
                    isDestructive = false,
                    testTag = "dm_action_pin",
                    onClick = onTogglePin
                )

                HorizontalDivider(
                    color = Color.White.copy(alpha = 0.08f),
                    thickness = 0.75.dp
                )

                // Item 2: Mark as unread / Mark as read
                InstagramFrostedActionRow(
                    title = if (isUnread) "Mark as read" else "Mark as unread",
                    icon = if (isUnread) Icons.Filled.Drafts else Icons.Filled.MarkEmailUnread,
                    isDestructive = false,
                    testTag = "dm_action_unread",
                    onClick = onToggleUnread
                )

                HorizontalDivider(
                    color = Color.White.copy(alpha = 0.08f),
                    thickness = 0.75.dp
                )

                // Item 3: Mute alerts / Unmute alerts
                InstagramFrostedActionRow(
                    title = if (isMuted) "Unmute alerts" else "Mute alerts",
                    icon = if (isMuted) Icons.Filled.Notifications else Icons.Filled.NotificationsOff,
                    isDestructive = false,
                    testTag = "dm_action_mute",
                    onClick = onToggleMute
                )

                HorizontalDivider(
                    color = Color.White.copy(alpha = 0.08f),
                    thickness = 0.75.dp
                )

                // Item 4: Delete (Instagram Red / LiveRose)
                InstagramFrostedActionRow(
                    title = "Delete",
                    icon = Icons.Filled.DeleteOutline,
                    isDestructive = true,
                    testTag = "dm_action_delete",
                    onClick = onDeleteThread
                )
            }
        }
    }
}

/**
 * Clean Instagram-style row inside the elevated frosted glass context action card.
 * Title on the left, crisp icon on the right, with tactile ripple feedback.
 */
@Composable
private fun InstagramFrostedActionRow(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isDestructive: Boolean = false,
    testTag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = title,
            style = NexoraTypography.CardTitle.copy(
                fontSize = 14.5.sp,
                fontWeight = if (isDestructive) FontWeight.Bold else FontWeight.SemiBold,
                color = if (isDestructive) NexoraColors.LiveRose else Color.White
            )
        )
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = if (isDestructive) NexoraColors.LiveRose else Color.White.copy(alpha = 0.85f),
            modifier = Modifier.size(19.dp)
        )
    }
}

/**
 * Full Spatial Mood Note Peek Modal:
 * Triggered on long-pressing any creator thought bubble in the inbox strip.
 * Shows the creator's live spatial mood canvas, full thought note, and 1-tap quote reply.
 */
@Composable
private fun SpatialMoodNotePeekModal(
    thread: DirectMessageThread,
    thoughtText: String,
    preset: VisualThemePreset,
    onDismiss: () -> Unit,
    onQuoteAndReply: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.62f))
            .clickable(onClick = onDismiss)
            .testTag("dm_thought_peek_backdrop"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .widthIn(max = 400.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(NexoraColors.CanvasBase)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { /* Consume taps on card */ }
                .testTag("dm_thought_peek_card"),
            verticalArrangement = Arrangement.spacedBy(0.dp)
        ) {
            // Top Kinetic Visual Canvas Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(118.dp)
            ) {
                SpatialVisualCanvas(
                    preset = preset,
                    isAnimated = true,
                    playbackPhase = 0.35f
                )

                // Soft gradient scrim to seamlessly blend canvas with dark body
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Black.copy(alpha = 0.35f),
                                    NexoraColors.CanvasBase
                                )
                            )
                        )
                )

                // Top Controls: Preset label + Close button
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .background(Color(0xB3000000))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = preset.label,
                            style = NexoraTypography.BadgeMicro.copy(
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(Color(0xB3000000))
                            .clickable { onDismiss() }
                            .testTag("dm_thought_peek_close_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Close peek",
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }

            // Body Content
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Creator identity
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CreatorAvatarBadge(
                        name = thread.creatorName,
                        seed = thread.avatarSeed,
                        size = 46.dp,
                        isSquircle = false,
                        borderWidth = 0.dp,
                        showOnlineDot = thread.isOnline
                    )

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Text(
                                text = thread.creatorName,
                                style = NexoraTypography.CardTitle.copy(
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            VerifiedBadge(size = 14.dp)
                        }
                        Text(
                            text = "@${thread.creatorHandle} • Live Spatial Mood",
                            style = NexoraTypography.BadgeMicro.copy(
                                fontSize = 11.sp,
                                color = NexoraColors.InkSecondary
                            )
                        )
                    }
                }

                // Full thought text card (Borderless)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color(0xFF262626))
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            tint = NexoraColors.ElectricIndigo,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "“$thoughtText”",
                            style = NexoraTypography.CardTitle.copy(
                                fontSize = 14.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White,
                                lineHeight = 20.sp
                            )
                        )
                    }
                }

                // Action buttons: Quote & Reply (Primary) + Dismiss (Secondary)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .clip(RoundedCornerShape(999.dp))
                            .background(NexoraColors.ElectricIndigo)
                            .clickable { onQuoteAndReply() }
                            .testTag("dm_thought_peek_reply_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Reply,
                                contentDescription = "Quote and reply",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Quote & Reply",
                                style = NexoraTypography.BadgeMicro.copy(
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .height(46.dp)
                            .clip(RoundedCornerShape(999.dp))
                            .background(Color(0xFF262626))
                            .clickable { onDismiss() }
                            .padding(horizontal = 16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Dismiss",
                            style = NexoraTypography.BadgeMicro.copy(
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                        )
                    }
                }
            }
        }
    }
}

