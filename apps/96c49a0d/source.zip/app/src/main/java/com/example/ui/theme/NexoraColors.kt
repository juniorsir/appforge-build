package com.example.ui.theme

import androidx.compose.ui.graphics.Color

object NexoraColors {
    // Base Canvas & ChatGPT / YouTube Light-Dark Charcoal Scale (#1E1E1E Login Page Base + #272727 / #2F2F2F Surfaces)
    val CanvasBase = Color(0xFF1E1E1E)
    val Pearl50    = Color(0xFF1E1E1E)
    val Pearl100   = Color(0xFF272727)
    val Pearl200   = Color(0xFF2F2F2F)
    val Pearl300   = Color(0xFF383838)

    // Ambient Radial Mesh Orb Colors (Disabled so all screens share the exact flat #1E1E1E background of the login page)
    val MeshOrbTopLeftLav      = Color.Transparent
    val MeshOrbTopRightSky     = Color.Transparent
    val MeshOrbBottomCenterInd = Color.Transparent

    // Instagram Sunset Gradient Scale (Amber -> Magenta-Red -> Purple -> Indigo)
    val InstagramSunsetAmber  = Color(0xFFF58529)
    val InstagramSunsetPink   = Color(0xFFDD2A7B)
    val InstagramSunsetPurple = Color(0xFF8134AF)
    val InstagramSunsetIndigo = Color(0xFF515BD4)

    val Lavender100 = Color(0xFF272727)
    val Lavender200 = Color(0xFF2F2F2F)
    val Lavender300 = Color(0xFF8134AF)
    val Lavender400 = Color(0xFFDD2A7B)
    val Lavender500 = Color(0xFFE1306C)

    // Instagram Blue Scale (#0095F6)
    val Sky100 = Color(0xFF272727)
    val Sky200 = Color(0xFF2F2F2F)
    val Sky300 = Color(0xFF3897F0)
    val Sky400 = Color(0xFF0095F6)

    // High-Contrast Light-Dark Mode Typography Hierarchy
    val InkPrimary   = Color(0xFFF5F5F5) // Crisp Off-White - Primary titles & headings
    val InkAccent    = Color(0xFF0095F6) // Active pill labels & interactive accents
    val InkSecondary = Color(0xFFB4B4B4) // Secondary Gray - Subtitles & active metadata
    val InkBody      = Color(0xFFE8E8ED) // Soft White - Descriptions & body copy
    val InkMuted     = Color(0xFF8E8E93) // Muted Gray - Timestamps, view counts, inactive tabs

    // Semantic Status Accents
    val LiveRose       = Color(0xFFFF3040) // Crimson Red - Likes & Live indicator
    val EmeraldLive    = Color(0xFF10B981) // Verified / Online status dot
    val AmberStar      = Color(0xFFFCAF45) // Warm Amber - Featured / Rating accent
    val ElectricIndigo = Color(0xFF0095F6) // Primary accent

    // Soft Charcoal Hairline Borders & Strokes
    val SpecularBorderStrong = Color(0xFF333333) // Card Hairline Border
    val SpecularBorderNav    = Color(0xFF363636) // Navigation Pill Border
    val SpecularBorderSubtle = Color(0xFF424242) // Elevated Pill / Input Border
    val AmbientShadowTint    = Color(0x80000000) // Soft Elevation Shadow
}
