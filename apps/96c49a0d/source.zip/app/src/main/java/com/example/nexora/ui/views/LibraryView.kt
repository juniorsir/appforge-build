package com.example.nexora.ui.views

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.nexora.data.CreatorProfile
import com.example.nexora.data.LibrarySubTab
import com.example.nexora.data.Playlist
import com.example.nexora.data.VideoItem
import com.example.nexora.data.VisualThemePreset
import com.example.nexora.ui.components.CreatorAvatarBadge
import com.example.nexora.ui.components.NexoraVideoCard
import com.example.nexora.ui.components.SpatialVisualCanvas
import com.example.nexora.ui.components.VerifiedBadge
import com.example.ui.theme.NexoraColors
import com.example.ui.theme.NexoraTypography
import com.example.ui.theme.liquidGlassAccent
import com.example.ui.theme.liquidGlassCard
import com.example.ui.theme.liquidGlassDarkOverlay
import com.example.ui.theme.liquidGlassWhitePill

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryView(
    activeSubTab: LibrarySubTab,
    allVideos: List<VideoItem>,
    savedVideoIds: Set<String>,
    watchHistoryProgress: Map<String, Float>,
    playlists: List<Playlist>,
    creators: List<CreatorProfile>,
    subscribedCreatorIds: Set<String>,
    onSelectSubTab: (LibrarySubTab) -> Unit,
    onOpenPlaylistModal: () -> Unit,
    onDeletePlaylist: (String) -> Unit,
    onClearHistory: () -> Unit,
    onVideoClick: (VideoItem) -> Unit,
    onCreatorClick: (String) -> Unit,
    onToggleSave: (String) -> Unit,
    onToggleSubscribe: (String) -> Unit,
    onShareVideo: (VideoItem) -> Unit,
    isRefreshing: Boolean = false,
    onRefresh: () -> Unit = {},
    refreshTrigger: Long = 0L,
    isGlobalAudioMuted: Boolean = false,
    onToggleMute: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val savedVideos = allVideos.filter { it.id in savedVideoIds }
    val historyVideos = allVideos.filter { it.id in watchHistoryProgress.keys }
    val subscribedStudios = creators.filter { it.id in subscribedCreatorIds }

    val listState = rememberLazyListState()

    LaunchedEffect(refreshTrigger) {
        if (refreshTrigger > 0L) {
            listState.animateScrollToItem(0)
        }
    }

    PullToRefreshBox(
        isRefreshing = isRefreshing,
        onRefresh = onRefresh,
        modifier = modifier.fillMaxSize()
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val screenWidth = maxWidth
            val columns = when {
                screenWidth > 1024.dp -> 3
                screenWidth >= 600.dp -> 2
                else -> 1
            }

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("library_view_list"),
                contentPadding = PaddingValues(
                    start = if (screenWidth >= 768.dp) 24.dp else 14.dp,
                    end = if (screenWidth >= 768.dp) 24.dp else 14.dp,
                    top = 8.dp,
                    bottom = 104.dp
                ),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
            // 1. Icon-Only Sub-Navigation Bar + Circular "+" Playlist Button
            item(key = "library_header_and_tabs") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("library_subtabs_row")
                    ) {
                        items(LibrarySubTab.entries.filter { it != LibrarySubTab.CUSTOM_PLAYLISTS }, key = { it.name }) { tab ->
                            val isSelected = tab == activeSubTab
                            val tabIcon = when (tab) {
                                LibrarySubTab.SAVED_VIDEOS -> Icons.Filled.Bookmark
                                LibrarySubTab.WATCH_HISTORY -> Icons.Filled.History
                                LibrarySubTab.CUSTOM_PLAYLISTS -> Icons.Filled.VideoLibrary
                                LibrarySubTab.SUBSCRIBED_STUDIOS -> Icons.Filled.Groups
                            }
                            Box(
                                modifier = Modifier
                                    .size(width = 50.dp, height = 38.dp)
                                    .then(
                                        if (isSelected) {
                                            Modifier.liquidGlassAccent(999.dp)
                                        } else {
                                            Modifier.liquidGlassWhitePill(999.dp)
                                        }
                                    )
                                    .clickable { onSelectSubTab(tab) }
                                    .testTag("library_tab_${tab.name.lowercase()}"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = tabIcon,
                                    contentDescription = tab.label,
                                    tint = if (isSelected) NexoraColors.InkAccent else NexoraColors.InkSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (activeSubTab == LibrarySubTab.WATCH_HISTORY && historyVideos.isNotEmpty()) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .liquidGlassWhitePill(999.dp)
                                    .clickable { onClearHistory() }
                                    .testTag("clear_history_btn"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.DeleteOutline,
                                    contentDescription = "Clear History",
                                    tint = NexoraColors.LiveRose,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            when (activeSubTab) {
                LibrarySubTab.SAVED_VIDEOS -> {
                    val chunked = savedVideos.chunked(columns)
                    items(chunked, key = { r -> "saved_" + r.joinToString("_") { it.id } }) { rowItems ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(20.dp)
                        ) {
                            rowItems.forEach { video ->
                                Box(modifier = Modifier.weight(1f)) {
                                    NexoraVideoCard(
                                        video = video,
                                        isSaved = true,
                                        onVideoClick = onVideoClick,
                                        onCreatorClick = onCreatorClick,
                                        onToggleSave = onToggleSave,
                                        onShareClick = onShareVideo,
                                        resumeProgress = watchHistoryProgress[video.id],
                                        isMuted = isGlobalAudioMuted,
                                        onToggleMute = onToggleMute
                                    )
                                }
                            }
                            repeat(columns - rowItems.size) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }

                LibrarySubTab.WATCH_HISTORY -> {
                    val chunked = historyVideos.chunked(columns)
                    items(chunked, key = { r -> "hist_" + r.joinToString("_") { it.id } }) { rowItems ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(20.dp)
                        ) {
                            rowItems.forEach { video ->
                                Box(modifier = Modifier.weight(1f)) {
                                    NexoraVideoCard(
                                        video = video,
                                        isSaved = video.id in savedVideoIds,
                                        onVideoClick = onVideoClick,
                                        onCreatorClick = onCreatorClick,
                                        onToggleSave = onToggleSave,
                                        onShareClick = onShareVideo,
                                        resumeProgress = watchHistoryProgress[video.id],
                                        isMuted = isGlobalAudioMuted,
                                        onToggleMute = onToggleMute
                                    )
                                }
                            }
                            repeat(columns - rowItems.size) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }

                LibrarySubTab.CUSTOM_PLAYLISTS -> {
                    // Playlist feature removed
                }

                LibrarySubTab.SUBSCRIBED_STUDIOS -> {
                    items(subscribedStudios, key = { "sub_${it.id}" }) { studio ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .liquidGlassCard(22.dp)
                                .clickable { onCreatorClick(studio.id) }
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                CreatorAvatarBadge(
                                    name = studio.name,
                                    seed = studio.avatarSeed,
                                    size = 44.dp,
                                    isSquircle = false,
                                    showOnlineDot = studio.isOnline
                                )
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                                    ) {
                                        Text(
                                            text = studio.name,
                                            style = NexoraTypography.CardTitle
                                        )
                                        VerifiedBadge(size = 14.dp)
                                    }
                                    Text(
                                        text = studio.subscribersText,
                                        style = NexoraTypography.MetaCaption
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .liquidGlassAccent(999.dp)
                                    .clickable { onToggleSubscribe(studio.id) },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Check,
                                    contentDescription = "Following",
                                    tint = NexoraColors.InkAccent,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
}

@Composable
private fun PlaylistMosaicCard(
    playlist: Playlist,
    videos: List<VideoItem>,
    onPlayPlaylist: () -> Unit,
    onDeletePlaylist: () -> Unit
) {
    val presets = (0 until 4).map { idx ->
        videos.getOrNull(idx)?.visualPreset ?: VisualThemePreset.entries[idx % VisualThemePreset.entries.size]
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .liquidGlassCard(cornerRadius = 24.dp)
            .clickable { onPlayPlaylist() }
            .padding(10.dp)
            .testTag("playlist_card_${playlist.id}"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(168.dp)
                .clip(RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        SpatialVisualCanvas(preset = presets[0], playbackPhase = 0.2f)
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        SpatialVisualCanvas(preset = presets[1], playbackPhase = 0.5f)
                    }
                }
                Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        SpatialVisualCanvas(preset = presets[2], playbackPhase = 0.7f)
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        SpatialVisualCanvas(preset = presets[3], playbackPhase = 0.9f)
                    }
                }
            }

            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(10.dp)
                    .size(28.dp)
                    .liquidGlassDarkOverlay(999.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (playlist.isPublic) Icons.Filled.Public else Icons.Filled.Lock,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(13.dp)
                )
            }

            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(10.dp)
                    .liquidGlassDarkOverlay(999.dp)
                    .padding(horizontal = 9.dp, vertical = 3.dp)
            ) {
                Text(
                    text = "${playlist.videoIds.size}",
                    style = NexoraTypography.BadgeMicro.copy(color = Color.White)
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = playlist.title,
                style = NexoraTypography.CardTitle,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .liquidGlassAccent(999.dp)
                        .clickable { onPlayPlaylist() }
                        .testTag("play_playlist_${playlist.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = "Play",
                        tint = NexoraColors.InkAccent,
                        modifier = Modifier.size(17.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .liquidGlassWhitePill(999.dp)
                        .clickable { onDeletePlaylist() }
                        .testTag("delete_playlist_${playlist.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.DeleteOutline,
                        contentDescription = "Delete",
                        tint = NexoraColors.InkSecondary,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }
        }
    }
}
