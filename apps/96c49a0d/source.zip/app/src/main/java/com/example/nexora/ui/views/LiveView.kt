package com.example.nexora.ui.views

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nexora.data.ChatMessage
import com.example.nexora.data.NexoraSeedData
import com.example.nexora.data.VideoItem
import com.example.nexora.ui.components.CreatorAvatarBadge
import com.example.nexora.ui.components.NexoraVideoCard
import com.example.nexora.ui.components.SpatialVisualCanvas
import com.example.nexora.ui.components.VerifiedBadge
import com.example.nexora.viewmodel.FloatingReactionParticle
import com.example.ui.theme.NexoraColors
import com.example.ui.theme.NexoraTypography
import com.example.ui.theme.liquidGlassAccent
import com.example.ui.theme.liquidGlassCard
import com.example.ui.theme.liquidGlassDarkOverlay
import com.example.ui.theme.liquidGlassWhitePill
import kotlin.math.roundToInt

private fun liveCategoryIconFor(cat: String): ImageVector = when (cat) {
    "3D & Design" -> Icons.Filled.ViewInAr
    "Music Sessions" -> Icons.Filled.GraphicEq
    "Game Dev" -> Icons.Filled.SportsEsports
    "IRL & Travel" -> Icons.Filled.Public
    else -> Icons.Filled.GridView
}

@Composable
fun LiveView(
    activeLiveStream: VideoItem,
    allLiveStreams: List<VideoItem>,
    liveCategoryFilter: String,
    liveUptimeSeconds: Int,
    chatMessages: List<ChatMessage>,
    floatingReactions: List<FloatingReactionParticle>,
    subscribedCreatorIds: Set<String>,
    savedVideoIds: Set<String>,
    onSelectLiveCategory: (String) -> Unit,
    onSelectLiveChannel: (VideoItem) -> Unit,
    onSendChatMessage: (String) -> Unit,
    onSpawnReaction: (String) -> Unit,
    onCreatorClick: (String) -> Unit,
    onToggleSubscribe: (String) -> Unit,
    onToggleSave: (String) -> Unit,
    onShareStream: (VideoItem) -> Unit,
    onOpenTheaterPlayer: (VideoItem) -> Unit,
    isGlobalAudioMuted: Boolean = false,
    onToggleMute: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val filteredChannels = allLiveStreams.filter { stream ->
        liveCategoryFilter == "All Live" ||
            stream.liveCategory.equals(liveCategoryFilter, ignoreCase = true)
    }

    val hrs = liveUptimeSeconds / 3600
    val mins = (liveUptimeSeconds % 3600) / 60
    val secs = liveUptimeSeconds % 60
    val formattedUptime = String.format("%02d:%02d:%02d", hrs, mins, secs)

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val screenWidth = maxWidth
        val isSplitDesktop = screenWidth >= 900.dp
        val columns = when {
            screenWidth > 1024.dp -> 3
            screenWidth >= 600.dp -> 2
            else -> 1
        }
        val chunkedChannels = filteredChannels.chunked(columns)

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("live_view_list"),
            contentPadding = PaddingValues(
                start = if (screenWidth >= 768.dp) 24.dp else 14.dp,
                end = if (screenWidth >= 768.dp) 24.dp else 14.dp,
                top = 8.dp,
                bottom = 104.dp
            ),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // 1. Top Live Broadcast Stage
            item(key = "live_broadcast_stage_split") {
                if (isSplitDesktop) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(18.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(modifier = Modifier.weight(0.7f)) {
                            LiveBroadcastStagePanel(
                                stream = activeLiveStream,
                                formattedUptime = formattedUptime,
                                isSubscribed = activeLiveStream.creatorId in subscribedCreatorIds,
                                floatingReactions = floatingReactions,
                                onCreatorClick = onCreatorClick,
                                onToggleSubscribe = onToggleSubscribe,
                                onShareStream = onShareStream,
                                onOpenTheater = { onOpenTheaterPlayer(activeLiveStream) },
                                isMuted = isGlobalAudioMuted,
                                onToggleMute = onToggleMute
                            )
                        }
                        Box(modifier = Modifier.weight(0.3f)) {
                            LiveStudioChatPanel(
                                messages = chatMessages,
                                onSendMessage = onSendChatMessage,
                                onSpawnReaction = onSpawnReaction
                            )
                        }
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        LiveBroadcastStagePanel(
                            stream = activeLiveStream,
                            formattedUptime = formattedUptime,
                            isSubscribed = activeLiveStream.creatorId in subscribedCreatorIds,
                            floatingReactions = floatingReactions,
                            onCreatorClick = onCreatorClick,
                            onToggleSubscribe = onToggleSubscribe,
                            onShareStream = onShareStream,
                            onOpenTheater = { onOpenTheaterPlayer(activeLiveStream) },
                            isMuted = isGlobalAudioMuted,
                            onToggleMute = onToggleMute
                        )
                        LiveStudioChatPanel(
                            messages = chatMessages,
                            onSendMessage = onSendChatMessage,
                            onSpawnReaction = onSpawnReaction
                        )
                    }
                }
            }

            // 2. Icon-Only Live Category Filter Row
            item(key = "live_channels_filter_header") {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.testTag("live_category_row")
                ) {
                    items(NexoraSeedData.liveCategories, key = { it }) { cat ->
                        val isSelected = cat == liveCategoryFilter
                        Box(
                            modifier = Modifier
                                .size(width = 48.dp, height = 36.dp)
                                .then(
                                    if (isSelected) {
                                        Modifier.liquidGlassAccent(999.dp)
                                    } else {
                                        Modifier.liquidGlassWhitePill(999.dp)
                                    }
                                )
                                .clickable { onSelectLiveCategory(cat) }
                                .testTag("live_cat_${cat.lowercase().replace(" ", "_")}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = liveCategoryIconFor(cat),
                                contentDescription = cat,
                                tint = if (isSelected) NexoraColors.InkAccent else NexoraColors.InkSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            // 3. Active Live Channels Grid
            items(
                items = chunkedChannels,
                key = { row -> "live_row_" + row.joinToString("_") { it.id } }
            ) { rowItems ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    rowItems.forEach { channel ->
                        Box(modifier = Modifier.weight(1f)) {
                            NexoraVideoCard(
                                video = channel,
                                isSaved = channel.id in savedVideoIds,
                                onVideoClick = onSelectLiveChannel,
                                onCreatorClick = onCreatorClick,
                                onToggleSave = onToggleSave,
                                onShareClick = onShareStream,
                                isMuted = isGlobalAudioMuted,
                                onToggleMute = onToggleMute
                            )
                        }
                    }
                    repeat(columns - rowItems.size) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun LiveBroadcastStagePanel(
    stream: VideoItem,
    formattedUptime: String,
    isSubscribed: Boolean,
    floatingReactions: List<FloatingReactionParticle>,
    onCreatorClick: (String) -> Unit,
    onToggleSubscribe: (String) -> Unit,
    onShareStream: (VideoItem) -> Unit,
    onOpenTheater: () -> Unit,
    isMuted: Boolean = false,
    onToggleMute: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "live_stage_pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(750, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .liquidGlassCard(cornerRadius = 28.dp)
            .padding(10.dp)
            .testTag("live_stage_card"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(290.dp)
                .clip(RoundedCornerShape(20.dp))
        ) {
            SpatialVisualCanvas(
                preset = stream.visualPreset,
                isAnimated = true
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(0x440F172A),
                                Color.Transparent,
                                Color(0x990F172A)
                            )
                        )
                    )
            )

            // Top-Left Icon Telemetry Pills
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(NexoraColors.LiveRose),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .graphicsLayer { alpha = pulseAlpha }
                            .clip(CircleShape)
                            .background(Color.White)
                    )
                }

                Row(
                    modifier = Modifier
                        .liquidGlassDarkOverlay(999.dp)
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Visibility,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                    Text(
                        text = stream.viewsText.replace(" watching", ""),
                        style = NexoraTypography.BadgeMicro.copy(color = Color.White)
                    )
                }

                Box(
                    modifier = Modifier
                        .liquidGlassDarkOverlay(999.dp)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = formattedUptime,
                        style = NexoraTypography.BadgeMicro.copy(color = Color(0xDDFFFFFF))
                    )
                }
            }

            // Floating Emoji Particle Reactions
            Box(modifier = Modifier.fillMaxSize()) {
                floatingReactions.forEach { particle ->
                    key(particle.id) {
                        val animProgress = remember { Animatable(0f) }
                        LaunchedEffect(particle.id) {
                            animProgress.animateTo(
                                targetValue = 1f,
                                animationSpec = tween(durationMillis = 1600, easing = LinearEasing)
                            )
                        }
                        val p = animProgress.value
                        Text(
                            text = particle.emoji,
                            fontSize = 24.sp,
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .offset {
                                    IntOffset(
                                        x = (-30 - (particle.horizontalFraction * 120f)).roundToInt(),
                                        y = (-24 - (p * 200f)).roundToInt()
                                    )
                                }
                                .graphicsLayer {
                                    alpha = (1f - p).coerceIn(0f, 1f)
                                    scaleX = 0.8f + p * 0.5f
                                    scaleY = 0.8f + p * 0.5f
                                }
                        )
                    }
                }
            }

            // Bottom-Right Icon Controls
            Row(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .liquidGlassDarkOverlay(999.dp)
                        .clickable { onToggleMute() }
                        .testTag("live_mute_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = "Mute",
                        tint = Color.White,
                        modifier = Modifier.size(17.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .liquidGlassDarkOverlay(999.dp)
                        .clickable { onOpenTheater() }
                        .testTag("live_theater_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Tv,
                        contentDescription = "Theater Mode",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .liquidGlassDarkOverlay(999.dp)
                        .clickable { onOpenTheater() }
                        .testTag("live_fullscreen_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Fullscreen,
                        contentDescription = "Fullscreen",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Below-stage Streamer Identity Bar + Icon-Only Follow & Share Buttons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .clickable { onCreatorClick(stream.creatorId) }
            ) {
                CreatorAvatarBadge(
                    name = stream.creatorName,
                    seed = stream.creatorAvatarSeed,
                    size = 38.dp,
                    showOnlineDot = true
                )
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = stream.title.removePrefix("LIVE: "),
                        style = NexoraTypography.CardTitle,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = stream.creatorName,
                            style = NexoraTypography.CreatorSubtitle
                        )
                        VerifiedBadge(size = 13.dp)
                    }
                }
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .then(
                            if (isSubscribed) {
                                Modifier.liquidGlassAccent(999.dp)
                            } else {
                                Modifier.liquidGlassWhitePill(999.dp)
                            }
                        )
                        .clickable { onToggleSubscribe(stream.creatorId) }
                        .testTag("live_follow_cta"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isSubscribed) Icons.Filled.Check else Icons.Filled.PersonAdd,
                        contentDescription = if (isSubscribed) "Following" else "Follow",
                        tint = if (isSubscribed) NexoraColors.InkAccent else NexoraColors.InkSecondary,
                        modifier = Modifier.size(17.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .liquidGlassWhitePill(999.dp)
                        .clickable { onShareStream(stream) }
                        .testTag("live_share_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Share,
                        contentDescription = "Share",
                        tint = NexoraColors.InkSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun LiveStudioChatPanel(
    messages: List<ChatMessage>,
    onSendMessage: (String) -> Unit,
    onSpawnReaction: (String) -> Unit
) {
    var draftMessage by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(350.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(NexoraColors.Pearl100)
            .padding(12.dp)
            .testTag("live_studio_chat_panel"),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.Chat,
                contentDescription = "Live Chat",
                tint = Color.White,
                modifier = Modifier.size(18.dp)
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(999.dp))
                    .background(NexoraColors.CanvasBase)
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(NexoraColors.EmeraldLive)
                )
                Text(
                    text = "1.4K",
                    style = NexoraTypography.BadgeMicro.copy(
                        fontSize = 10.sp,
                        color = Color.White
                    )
                )
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(NexoraColors.CanvasBase)
                        .padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CreatorAvatarBadge(
                        name = msg.username,
                        seed = msg.avatarSeed,
                        size = 26.dp,
                        borderWidth = 0.dp
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = msg.username,
                            style = NexoraTypography.BadgeMicro.copy(
                                fontSize = 11.sp,
                                color = NexoraColors.InkSecondary
                            )
                        )
                        Text(
                            text = msg.message,
                            style = NexoraTypography.BodyRegular.copy(
                                fontSize = 13.sp,
                                color = Color.White
                            ),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val reactions = listOf("FIRE", "BRAVO", "100%", "HYPE", "PRO")
            reactions.forEach { reactionLabel ->
                Box(
                    modifier = Modifier
                        .height(30.dp)
                        .clip(RoundedCornerShape(999.dp))
                        .background(NexoraColors.CanvasBase)
                        .clickable { onSpawnReaction(reactionLabel) }
                        .padding(horizontal = 11.dp)
                        .testTag("reaction_btn_$reactionLabel"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = reactionLabel, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(38.dp)
                .clip(RoundedCornerShape(999.dp))
                .background(NexoraColors.CanvasBase)
                .padding(start = 12.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BasicTextField(
                value = draftMessage,
                onValueChange = { draftMessage = it },
                singleLine = true,
                textStyle = NexoraTypography.BodyRegular.copy(color = Color.White),
                cursorBrush = SolidColor(NexoraColors.InkAccent),
                modifier = Modifier
                    .weight(1f)
                    .testTag("live_chat_input"),
                decorationBox = { inner ->
                    if (draftMessage.isEmpty()) {
                        Text(
                            text = "Add a comment...",
                            style = NexoraTypography.BodyRegular.copy(
                                fontSize = 12.5.sp,
                                color = NexoraColors.InkSecondary
                            )
                        )
                    }
                    inner()
                }
            )

            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(NexoraColors.ElectricIndigo)
                    .clickable {
                        if (draftMessage.isNotBlank()) {
                            onSendMessage(draftMessage)
                            draftMessage = ""
                        }
                    }
                    .testTag("live_chat_send_btn"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send",
                    tint = Color.White,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}
