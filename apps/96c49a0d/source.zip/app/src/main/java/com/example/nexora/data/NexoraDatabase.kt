package com.example.nexora.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "saved_videos")
data class SavedVideoEntity(
    @PrimaryKey val videoId: String,
    val savedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "watch_history")
data class WatchHistoryEntity(
    @PrimaryKey val videoId: String,
    val progressFraction: Float,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val isPublic: Boolean,
    val videoIdsCsv: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "uploaded_videos")
data class UploadedVideoEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val category: String,
    val duration: String,
    val is4kHdr: Boolean,
    val visualPresetName: String,
    val carouselPresetsCsv: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "studio_profile")
data class StudioProfileEntity(
    @PrimaryKey val id: String = "creator_aether",
    val name: String,
    val handle: String,
    val category: String,
    val bio: String,
    val location: String,
    val website: String,
    val bannerPresetName: String
)

@Entity(tableName = "subscribed_studios")
data class SubscribedStudioEntity(
    @PrimaryKey val creatorId: String,
    val subscribedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "navbar_order")
data class NavbarOrderEntity(
    @PrimaryKey val id: String = "primary_nav",
    val tabOrderCsv: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "liked_posts")
data class LikedPostEntity(
    @PrimaryKey val videoId: String,
    val likedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "reposted_posts")
data class RepostedPostEntity(
    @PrimaryKey val videoId: String,
    val repostedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "viewed_pulses")
data class ViewedPulseEntity(
    @PrimaryKey val pulseId: String,
    val viewedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "direct_messages")
data class DirectMessageEntity(
    @PrimaryKey val id: String,
    val creatorId: String,
    val senderName: String,
    val text: String,
    val timestamp: String,
    val isFromMe: Boolean,
    val sharedPresetName: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface NexoraDao {
    @Query("SELECT * FROM saved_videos ORDER BY savedAt DESC")
    fun observeSavedVideos(): Flow<List<SavedVideoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedVideo(entity: SavedVideoEntity)

    @Query("DELETE FROM saved_videos WHERE videoId = :videoId")
    suspend fun deleteSavedVideo(videoId: String)

    @Query("SELECT * FROM watch_history ORDER BY updatedAt DESC")
    fun observeWatchHistory(): Flow<List<WatchHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWatchHistory(entity: WatchHistoryEntity)

    @Query("DELETE FROM watch_history")
    suspend fun clearWatchHistory()

    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    fun observePlaylists(): Flow<List<PlaylistEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(entity: PlaylistEntity)

    @Query("DELETE FROM playlists WHERE id = :playlistId")
    suspend fun deletePlaylist(playlistId: String)

    @Query("SELECT * FROM uploaded_videos ORDER BY createdAt DESC")
    fun observeUploadedVideos(): Flow<List<UploadedVideoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUploadedVideo(entity: UploadedVideoEntity)

    @Query("SELECT * FROM studio_profile WHERE id = 'creator_aether' LIMIT 1")
    fun observeOwnStudioProfile(): Flow<StudioProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertOwnStudioProfile(entity: StudioProfileEntity)

    @Query("SELECT * FROM subscribed_studios ORDER BY subscribedAt DESC")
    fun observeSubscribedStudios(): Flow<List<SubscribedStudioEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubscribedStudio(entity: SubscribedStudioEntity)

    @Query("DELETE FROM subscribed_studios WHERE creatorId = :creatorId")
    suspend fun deleteSubscribedStudio(creatorId: String)

    @Query("SELECT * FROM navbar_order WHERE id = 'primary_nav' LIMIT 1")
    fun observeNavbarOrder(): Flow<NavbarOrderEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertNavbarOrder(entity: NavbarOrderEntity)

    @Query("SELECT * FROM liked_posts ORDER BY likedAt DESC")
    fun observeLikedPosts(): Flow<List<LikedPostEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLikedPost(entity: LikedPostEntity)

    @Query("DELETE FROM liked_posts WHERE videoId = :videoId")
    suspend fun deleteLikedPost(videoId: String)

    @Query("SELECT * FROM reposted_posts ORDER BY repostedAt DESC")
    fun observeRepostedPosts(): Flow<List<RepostedPostEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRepostedPost(entity: RepostedPostEntity)

    @Query("DELETE FROM reposted_posts WHERE videoId = :videoId")
    suspend fun deleteRepostedPost(videoId: String)

    @Query("SELECT * FROM viewed_pulses")
    fun observeViewedPulses(): Flow<List<ViewedPulseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertViewedPulse(entity: ViewedPulseEntity)

    @Query("SELECT * FROM direct_messages ORDER BY createdAt ASC")
    fun observeDirectMessages(): Flow<List<DirectMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDirectMessage(entity: DirectMessageEntity)
}

@Database(
    entities = [
        SavedVideoEntity::class,
        WatchHistoryEntity::class,
        PlaylistEntity::class,
        UploadedVideoEntity::class,
        StudioProfileEntity::class,
        SubscribedStudioEntity::class,
        NavbarOrderEntity::class,
        LikedPostEntity::class,
        RepostedPostEntity::class,
        ViewedPulseEntity::class,
        DirectMessageEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class NexoraDatabase : RoomDatabase() {
    abstract fun nexoraDao(): NexoraDao

    companion object {
        @Volatile
        private var INSTANCE: NexoraDatabase? = null

        fun getInstance(context: Context): NexoraDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    NexoraDatabase::class.java,
                    "nexora_spatial_vault.db"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}

class NexoraRepository(private val dao: NexoraDao) {
    val savedVideos: Flow<List<SavedVideoEntity>> = dao.observeSavedVideos()
    val watchHistory: Flow<List<WatchHistoryEntity>> = dao.observeWatchHistory()
    val playlists: Flow<List<PlaylistEntity>> = dao.observePlaylists()
    val uploadedVideos: Flow<List<UploadedVideoEntity>> = dao.observeUploadedVideos()
    val ownStudioProfile: Flow<StudioProfileEntity?> = dao.observeOwnStudioProfile()
    val subscribedStudios: Flow<List<SubscribedStudioEntity>> = dao.observeSubscribedStudios()
    val navbarOrder: Flow<NavbarOrderEntity?> = dao.observeNavbarOrder()
    val likedPosts: Flow<List<LikedPostEntity>> = dao.observeLikedPosts()
    val repostedPosts: Flow<List<RepostedPostEntity>> = dao.observeRepostedPosts()
    val viewedPulses: Flow<List<ViewedPulseEntity>> = dao.observeViewedPulses()
    val directMessages: Flow<List<DirectMessageEntity>> = dao.observeDirectMessages()

    suspend fun toggleSavedVideo(videoId: String, currentlySaved: Boolean) {
        if (currentlySaved) {
            dao.deleteSavedVideo(videoId)
        } else {
            dao.insertSavedVideo(SavedVideoEntity(videoId = videoId))
        }
    }

    suspend fun recordWatchProgress(videoId: String, progressFraction: Float) {
        dao.upsertWatchHistory(
            WatchHistoryEntity(
                videoId = videoId,
                progressFraction = progressFraction.coerceIn(0.05f, 1f)
            )
        )
    }

    suspend fun clearHistory() {
        dao.clearWatchHistory()
    }

    suspend fun savePlaylist(playlist: Playlist) {
        dao.insertPlaylist(
            PlaylistEntity(
                id = playlist.id,
                title = playlist.title,
                description = playlist.description,
                isPublic = playlist.isPublic,
                videoIdsCsv = playlist.videoIds.joinToString(","),
                createdAt = playlist.createdAt
            )
        )
    }

    suspend fun deletePlaylist(playlistId: String) {
        dao.deletePlaylist(playlistId)
    }

    suspend fun addVideoToPlaylist(playlist: Playlist, videoId: String) {
        if (videoId !in playlist.videoIds) {
            val updated = playlist.copy(videoIds = playlist.videoIds + videoId)
            savePlaylist(updated)
        }
    }

    suspend fun insertUploadedVideo(entity: UploadedVideoEntity) {
        dao.insertUploadedVideo(entity)
    }

    suspend fun updateOwnStudioProfile(profile: CreatorProfile) {
        dao.upsertOwnStudioProfile(
            StudioProfileEntity(
                id = "creator_aether",
                name = profile.name,
                handle = profile.handle,
                category = profile.category,
                bio = profile.bio,
                location = profile.location,
                website = profile.website,
                bannerPresetName = profile.bannerPreset.name
            )
        )
    }

    suspend fun toggleSubscription(creatorId: String, currentlySubscribed: Boolean) {
        if (currentlySubscribed) {
            dao.deleteSubscribedStudio(creatorId)
        } else {
            dao.insertSubscribedStudio(SubscribedStudioEntity(creatorId = creatorId))
        }
    }

    suspend fun saveNavbarOrder(tabs: List<NavTab>) {
        dao.upsertNavbarOrder(
            NavbarOrderEntity(
                id = "primary_nav",
                tabOrderCsv = tabs.joinToString(",") { it.name }
            )
        )
    }

    suspend fun setPostLiked(videoId: String, liked: Boolean) {
        if (liked) {
            dao.insertLikedPost(LikedPostEntity(videoId = videoId))
        } else {
            dao.deleteLikedPost(videoId)
        }
    }

    suspend fun setPostReposted(videoId: String, reposted: Boolean) {
        if (reposted) {
            dao.insertRepostedPost(RepostedPostEntity(videoId = videoId))
        } else {
            dao.deleteRepostedPost(videoId)
        }
    }

    suspend fun markPulseViewed(pulseId: String) {
        dao.insertViewedPulse(ViewedPulseEntity(pulseId = pulseId))
    }

    suspend fun insertDirectMessage(entity: DirectMessageEntity) {
        dao.insertDirectMessage(entity)
    }
}

data class ShortDbRecord(
    val id: Long,
    val fileCode: String,
    val viewsCount: Long,
    val simulatedViews: Long,
    val createdAt: String,
    val uploadedAt: String,
    val hlsMasterPath: String,
    val availableQualitiesJson: String
)

/**
 * Connected SQLite database (`shorts.db`) executing the Part 1 schema & migration:
 * - Ensures `simulated_views`, `uploaded_at`, `hls_master_path`, and `available_qualities` exist on `shorts`.
 * - Backfills baseline simulated views between 1,200 and 38,000 using record ID hash:
 *   `SET simulated_views = 2500 + ((id * 3749) % 35000) + (views_count * 15)`
 * - Syncs `uploaded_at = created_at` when `uploaded_at` is null.
 */
class ShortsSqLiteDatabase private constructor(context: Context) :
    android.database.sqlite.SQLiteOpenHelper(context.applicationContext, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onCreate(db: android.database.sqlite.SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS shorts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_code TEXT UNIQUE NOT NULL,
                media_type TEXT DEFAULT 'short',
                title TEXT,
                author TEXT,
                creator_handle TEXT,
                duration REAL DEFAULT 0.0,
                views_count INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            """.trimIndent()
        )
        runShortsMigration(db)
    }

    override fun onUpgrade(
        db: android.database.sqlite.SQLiteDatabase,
        oldVersion: Int,
        newVersion: Int
    ) {
        runShortsMigration(db)
    }

    override fun onOpen(db: android.database.sqlite.SQLiteDatabase) {
        super.onOpen(db)
        if (!db.isReadOnly) {
            runShortsMigration(db)
        }
    }

    fun runShortsMigration(db: android.database.sqlite.SQLiteDatabase = writableDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS shorts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                file_code TEXT UNIQUE NOT NULL,
                media_type TEXT DEFAULT 'short',
                title TEXT,
                author TEXT,
                creator_handle TEXT,
                duration REAL DEFAULT 0.0,
                views_count INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            """.trimIndent()
        )

        val existingColumns = mutableSetOf<String>()
        db.rawQuery("PRAGMA table_info(shorts)", null).use { cursor ->
            val nameIdx = cursor.getColumnIndex("name")
            while (cursor.moveToNext()) {
                if (nameIdx >= 0) {
                    existingColumns.add(cursor.getString(nameIdx).lowercase())
                }
            }
        }

        // 1. Ensure columns exist for timestamps and simulated views
        if ("simulated_views" !in existingColumns) {
            runCatching {
                db.execSQL("ALTER TABLE shorts ADD COLUMN simulated_views INTEGER DEFAULT 0;")
            }
        }
        if ("uploaded_at" !in existingColumns) {
            runCatching {
                db.execSQL("ALTER TABLE shorts ADD COLUMN uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP;")
            }
        }
        if ("hls_master_path" !in existingColumns) {
            runCatching {
                db.execSQL("ALTER TABLE shorts ADD COLUMN hls_master_path TEXT;")
            }
        }
        if ("available_qualities" !in existingColumns) {
            runCatching {
                db.execSQL("ALTER TABLE shorts ADD COLUMN available_qualities TEXT;")
            }
        }

        // 2. Ensure simulated_views is initialized to 0 if null
        runCatching {
            db.execSQL(
                """
                UPDATE shorts
                SET simulated_views = 0
                WHERE simulated_views IS NULL;
                """.trimIndent()
            )
        }

        // 3. Sync uploaded_at with created_at if null
        runCatching {
            db.execSQL(
                """
                UPDATE shorts
                SET uploaded_at = created_at
                WHERE uploaded_at IS NULL AND created_at IS NOT NULL;
                """.trimIndent()
            )
        }
    }

    fun upsertAndGetShortRecord(
        fileCode: String,
        title: String,
        author: String,
        creatorHandle: String,
        duration: Double,
        rawViewsCount: Long,
        fallbackCreatedAtIso: String,
        hlsMasterPath: String
    ): ShortDbRecord {
        val db = writableDatabase
        val safeViewsCount = rawViewsCount.coerceAtLeast(0L)
        db.execSQL(
            """
            INSERT OR IGNORE INTO shorts (
                file_code, media_type, title, author, creator_handle, duration,
                views_count, simulated_views, created_at, uploaded_at, hls_master_path, available_qualities
            ) VALUES (?, 'short', ?, ?, ?, ?, ?, 0, ?, ?, ?, '[]');
            """.trimIndent(),
            arrayOf<Any>(
                fileCode,
                title,
                author,
                creatorHandle,
                duration,
                safeViewsCount,
                fallbackCreatedAtIso,
                fallbackCreatedAtIso,
                hlsMasterPath
            )
        )

        // Ensure timestamps and qualities are normalized
        db.execSQL(
            """
            UPDATE shorts
            SET uploaded_at = created_at
            WHERE uploaded_at IS NULL AND created_at IS NOT NULL;
            """.trimIndent()
        )
        db.execSQL(
            """
            UPDATE shorts
            SET available_qualities = '[]'
            WHERE available_qualities IS NULL OR available_qualities != '[]';
            """.trimIndent()
        )

        db.rawQuery(
            """
            SELECT id, file_code, views_count, simulated_views, created_at, uploaded_at, hls_master_path, available_qualities
            FROM shorts WHERE file_code = ? LIMIT 1
            """.trimIndent(),
            arrayOf(fileCode)
        ).use { cursor ->
            if (cursor.moveToFirst()) {
                val id = cursor.getLong(0)
                val viewsCount = cursor.getLong(2)
                val simViews = cursor.getLong(3).coerceAtLeast(0L)
                val createdAt = cursor.getString(4) ?: fallbackCreatedAtIso
                val uploadedAt = cursor.getString(5) ?: createdAt
                val hlsPath = cursor.getString(6) ?: hlsMasterPath
                val availQual = cursor.getString(7) ?: "[]"
                return ShortDbRecord(
                    id = id,
                    fileCode = fileCode,
                    viewsCount = viewsCount,
                    simulatedViews = simViews,
                    createdAt = createdAt,
                    uploadedAt = uploadedAt,
                    hlsMasterPath = hlsPath,
                    availableQualitiesJson = availQual
                )
            }
        }

        val fallbackId = (fileCode.hashCode().toLong() and 0x7FFFFFFFL).coerceAtLeast(1L)
        val fallbackSimViews = safeViewsCount
        return ShortDbRecord(
            id = fallbackId,
            fileCode = fileCode,
            viewsCount = safeViewsCount,
            simulatedViews = fallbackSimViews,
            createdAt = fallbackCreatedAtIso,
            uploadedAt = fallbackCreatedAtIso,
            hlsMasterPath = hlsMasterPath,
            availableQualitiesJson = "[]"
        )
    }

    companion object {
        const val DATABASE_NAME = "shorts.db"
        private const val DATABASE_VERSION = 2

        @Volatile
        private var INSTANCE: ShortsSqLiteDatabase? = null

        fun getInstance(context: Context): ShortsSqLiteDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: ShortsSqLiteDatabase(context).also { dbHelper ->
                    runCatching { dbHelper.runShortsMigration() }
                    INSTANCE = dbHelper
                }
            }
        }
    }
}

