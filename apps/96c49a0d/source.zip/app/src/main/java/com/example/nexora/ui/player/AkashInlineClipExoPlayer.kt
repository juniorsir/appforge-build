package com.example.nexora.ui.player

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.view.Gravity
import android.view.TextureView
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.CacheWriter
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import coil.Coil
import coil.compose.SubcomposeAsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.example.nexora.data.VideoItem
import com.example.nexora.network.AkashMediaService
import com.example.nexora.ui.components.InstagramDarkShimmerBox
import com.example.nexora.ui.components.SpatialVisualCanvas
import com.example.ui.theme.NexoraColors
import com.example.ui.theme.NexoraTypography
import com.example.ui.theme.liquidGlassDarkOverlay
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlin.math.abs

/**
 * Akash Shorts Single-Toggle Quality Controller:
 * - No multi-resolution dropdown menus (1080p/720p/480p/360p removed).
 * - Default (forceHighestQuality = false): Auto-adapts to network bandwidth via item.adaptiveStreamUrl || item.streamUrl.
 * - Highest Quality Toggle ON (forceHighestQuality = true): Immediately switches to item.highestQualityStreamUrl
 *   while preserving current playback position.
 */
object AkashQualityController {
    var forceHighestQuality by mutableStateOf(false)
    var forceHighestQualityAlways: Boolean
        get() = forceHighestQuality
        set(value) {
            forceHighestQuality = value
        }
    var measuredBandwidthMbps by mutableFloatStateOf(12.5f)

    fun toggleHighestQuality(): Boolean {
        val nextState = !forceHighestQuality
        forceHighestQuality = nextState
        return nextState
    }

    fun toggleForceHighestQuality(enabled: Boolean) {
        forceHighestQuality = enabled
    }

    fun detectBandwidthMbps(context: Context): Float {
        return runCatching {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val network = cm?.activeNetwork
            val caps = if (network != null) cm.getNetworkCapabilities(network) else null
            if (caps != null) {
                val downstreamKbps = caps.linkDownstreamBandwidthKbps
                val estimatedMbps = when {
                    downstreamKbps > 0 -> (downstreamKbps / 1000f).coerceIn(0.4f, 100f)
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> 18.0f
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> 6.5f
                    else -> 4.0f
                }
                val normalized = if (estimatedMbps > 45f) 14.8f else estimatedMbps
                measuredBandwidthMbps = normalized
                normalized
            } else {
                measuredBandwidthMbps
            }
        }.getOrDefault(measuredBandwidthMbps)
    }

    fun currentActiveSummaryLabel(context: Context? = null): String {
        if (context != null) {
            detectBandwidthMbps(context)
        }
        return if (forceHighestQuality) {
            "Highest Quality: ON"
        } else {
            "Auto Adaptive (HQ OFF)"
        }
    }

    fun resolveStreamUrlForClip(context: Context, clip: VideoItem): String {
        detectBandwidthMbps(context)
        return if (forceHighestQuality) {
            clip.effectiveHighestQualityStreamUrl
        } else {
            clip.effectiveAdaptiveStreamUrl
        }
    }
}

/**
 * Akash Shorts Lookahead Pre-Buffering & Disk Cache Manager:
 * - Pre-caches the first 3MB (`PRECACHE_BYTES_2MB`) of upcoming Shorts using ExoPlayer `CacheDataSource` & `CacheWriter`.
 * - Deduplicates concurrent pre-cache jobs so scrolling never spawns redundant network reads.
 * - Pre-loads thumbnails into memory/disk cache via Coil `ImageLoader`.
 * - Provides a shared `CacheDataSource.Factory` with `X-App-Token` so `ExoPlayer` reads pre-cached bytes immediately with HTTP 206 byte-range support.
 */
@OptIn(UnstableApi::class)
object ReelsLookaheadCacheManager {
    const val PRECACHE_BYTES_2MB: Long = 3L * 1024L * 1024L // 3 MB lookahead window for instant start
    private const val MAX_CACHE_BYTES: Long = 300L * 1024L * 1024L // 300 MB LRU disk cache

    @Volatile
    private var simpleCache: SimpleCache? = null

    @Volatile
    private var cacheDataSourceFactory: CacheDataSource.Factory? = null

    private val inFlightPreCaches = ConcurrentHashMap.newKeySet<String>()
    private val completedPreCaches = ConcurrentHashMap.newKeySet<String>()

    private fun getOrCreateSimpleCache(context: Context): SimpleCache {
        return simpleCache ?: synchronized(this) {
            simpleCache ?: run {
                val appContext = context.applicationContext
                val cacheDir = File(appContext.cacheDir, "akash_shorts_precache")
                if (!cacheDir.exists()) {
                    cacheDir.mkdirs()
                }
                val evictor = LeastRecentlyUsedCacheEvictor(MAX_CACHE_BYTES)
                val databaseProvider = StandaloneDatabaseProvider(appContext)
                SimpleCache(cacheDir, evictor, databaseProvider).also {
                    simpleCache = it
                }
            }
        }
    }

    fun getCacheDataSourceFactory(context: Context): CacheDataSource.Factory {
        return cacheDataSourceFactory ?: synchronized(this) {
            cacheDataSourceFactory ?: run {
                val upstreamHttpFactory = DefaultHttpDataSource.Factory()
                    .setDefaultRequestProperties(
                        mapOf(
                            AkashMediaService.HEADER_APP_TOKEN_UPPER to AkashMediaService.APP_TOKEN,
                            AkashMediaService.HEADER_APP_TOKEN to AkashMediaService.APP_TOKEN
                        )
                    )
                    .setAllowCrossProtocolRedirects(true)
                    .setConnectTimeoutMs(10_000)
                    .setReadTimeoutMs(15_000)

                CacheDataSource.Factory()
                    .setCache(getOrCreateSimpleCache(context))
                    .setUpstreamDataSourceFactory(upstreamHttpFactory)
                    .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
                    .also {
                        cacheDataSourceFactory = it
                    }
            }
        }
    }

    fun resolveDirectStreamUrl(clip: VideoItem, context: Context? = null): String {
        if (context != null) {
            return AkashQualityController.resolveStreamUrlForClip(context, clip)
        }
        return clip.effectiveHighestQualityStreamUrl
    }

    fun resolveThumbnailUrl(clip: VideoItem): String {
        val fileCode = clip.fileCode?.takeIf { it.isNotBlank() } ?: clip.id
        return clip.effectiveThumbnailUrl ?: AkashMediaService.thumbnailUrl(fileCode)
    }

    /**
     * Pre-caches the first 3MB of a Short into ExoPlayer's `SimpleCache` via `CacheDataSource` & `CacheWriter`.
     */
    suspend fun preCacheReelFirst2MB(context: Context, clip: VideoItem) = withContext(Dispatchers.IO) {
        val streamUrl = clip.effectiveHighestQualityStreamUrl
        if (streamUrl.isBlank() || streamUrl in completedPreCaches) return@withContext
        if (!inFlightPreCaches.add(streamUrl)) return@withContext

        try {
            runCatching {
                val startNs = System.nanoTime()
                var bytesCached = 0L
                val dataSource = getCacheDataSourceFactory(context).createDataSource()
                val dataSpec = DataSpec.Builder()
                    .setUri(Uri.parse(streamUrl))
                    .setPosition(0L)
                    .setLength(PRECACHE_BYTES_2MB)
                    .setKey(streamUrl)
                    .build()

                val cacheWriter = CacheWriter(
                    dataSource,
                    dataSpec,
                    null
                ) { _, bytesCachedTotal, _ ->
                    bytesCached = bytesCachedTotal
                    coroutineContext.ensureActive()
                }
                cacheWriter.cache()
                val elapsedSec = ((System.nanoTime() - startNs) / 1_000_000_000.0).coerceAtLeast(0.05)
                if (bytesCached > 32_768L) {
                    val mbps = ((bytesCached * 8.0) / (elapsedSec * 1_000_000.0)).toFloat().coerceIn(0.4f, 50f)
                    AkashQualityController.measuredBandwidthMbps = mbps
                }
                completedPreCaches.add(streamUrl)
            }
        } finally {
            inFlightPreCaches.remove(streamUrl)
        }
    }

    /**
     * Pre-loads the thumbnail image for a Short using Coil's ImageLoader with memory + disk caching.
     */
    fun preloadReelThumbnail(context: Context, clip: VideoItem) {
        val thumbUrl = resolveThumbnailUrl(clip)
        if (thumbUrl.isBlank()) return
        val appContext = context.applicationContext
        val request = ImageRequest.Builder(appContext)
            .data(thumbUrl)
            .addHeader(AkashMediaService.HEADER_APP_TOKEN_UPPER, AkashMediaService.APP_TOKEN)
            .addHeader(AkashMediaService.HEADER_APP_TOKEN, AkashMediaService.APP_TOKEN)
            .memoryCachePolicy(CachePolicy.ENABLED)
            .diskCachePolicy(CachePolicy.ENABLED)
            .build()
        Coil.imageLoader(appContext).enqueue(request)
    }

    /**
     * Pre-warms initial feed thumbnails and top video streams in the background.
     */
    suspend fun preWarmInitialClips(context: Context, clips: List<VideoItem>) = withContext(Dispatchers.IO) {
        clips.take(5).forEach { clip ->
            preloadReelThumbnail(context, clip)
        }
        clips.take(2).forEach { clip ->
            preCacheReelFirst2MB(context, clip)
        }
    }
}

/**
 * Enforces single-video playback across the entire app so two ExoPlayer instances
 * can never play audio or video simultaneously.
 */
object AkashActivePlaybackCoordinator {
    private var currentActivePlayer: ExoPlayer? = null

    fun claimActivePlayer(player: ExoPlayer) {
        val previous = currentActivePlayer
        if (previous != null && previous !== player) {
            runCatching {
                previous.playWhenReady = false
                previous.pause()
            }
        }
        currentActivePlayer = player
    }

    fun releasePlayer(player: ExoPlayer) {
        if (currentActivePlayer === player) {
            currentActivePlayer = null
        }
    }
}

/**
 * Hardware-accelerated TextureView + AspectRatioFrameLayout ExoPlayer surface for Akash Shorts:
 * - Preserves bit-for-bit 1080p quality with zero artificial sharpening or aggressive canvas filtering.
 * - Supports Network-Adaptive Quality Switching and Force Highest Quality Override while preserving HTTP 206 byte-range seeking.
 */
@OptIn(UnstableApi::class)
@Composable
fun AkashInlineClipExoPlayer(
    clip: VideoItem,
    isActivePage: Boolean,
    isPaused: Boolean,
    modifier: Modifier = Modifier,
    isNextPage: Boolean = false,
    isPreviousPage: Boolean = false,
    isMuted: Boolean = false,
    resizeMode: Int = AspectRatioFrameLayout.RESIZE_MODE_FIT,
    seekTrigger: Int = 0,
    seekFraction: Float = 0f,
    onProgressUpdate: (progressFraction: Float, durationSeconds: Int) -> Unit = { _, _ -> }
) {
    val fileCode = clip.fileCode?.takeIf { it.isNotBlank() } ?: clip.id
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val forceHighestQuality = AkashQualityController.forceHighestQuality
    val highestQualityStreamUrl = remember(clip.id, clip.highestQualityStreamUrl, clip.directStreamUrl, fileCode) {
        clip.effectiveHighestQualityStreamUrl
    }
    val adaptiveStreamUrl = remember(clip.id, clip.adaptiveStreamUrl, clip.streamUrl, fileCode) {
        clip.effectiveAdaptiveStreamUrl
    }

    // Active video source determination per Part 3.B:
    // forceHighestQuality ? item.highest_quality_stream_url : (item.adaptive_stream_url || item.stream_url)
    val directStreamUrl = remember(
        clip.id,
        adaptiveStreamUrl,
        highestQualityStreamUrl,
        forceHighestQuality
    ) {
        if (forceHighestQuality) {
            highestQualityStreamUrl
        } else {
            adaptiveStreamUrl
        }
    }

    var errorText by remember(clip.id) { mutableStateOf<String?>(null) }
    var hasRenderedFirstFrame by remember(clip.id) { mutableStateOf(false) }
    var isExoPlaying by remember(clip.id) { mutableStateOf(false) }
    var isBuffering by remember(clip.id) { mutableStateOf(false) }
    var videoAspectRatio by remember(clip.id) {
        mutableFloatStateOf(clip.aspectRatio.takeIf { it > 0f && it.isFinite() } ?: (9f / 16f))
    }
    var retryCounter by remember(clip.id) { mutableIntStateOf(0) }
    var loadedMediaUri by remember(clip.id) { mutableStateOf<String?>(null) }
    var targetStartPositionMs by remember(clip.id) { mutableLongStateOf(0L) }
    var needsInitialAvSyncSnap by remember(clip.id) { mutableStateOf(true) }

    val currentIsMuted by rememberUpdatedState(isMuted)
    val currentIsActivePage by rememberUpdatedState(isActivePage)
    val currentIsPaused by rememberUpdatedState(isPaused)

    val exoPlayer = remember(context, clip.id) {
        val cacheDataSourceFactory = ReelsLookaheadCacheManager.getCacheDataSourceFactory(context)

        val mediaSourceFactory = DefaultMediaSourceFactory(context)
            .setDataSourceFactory(cacheDataSourceFactory)

        val renderersFactory = DefaultRenderersFactory(context)
            .setEnableDecoderFallback(true)
            .setAllowedVideoJoiningTimeMs(5_000L)

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.CONTENT_TYPE_MOVIE)
            .build()

        val smoothLoadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                /* minBufferMs = */ 8_000,
                /* maxBufferMs = */ 32_000,
                /* bufferForPlaybackMs = */ 1_200,
                /* bufferForPlaybackAfterRebufferMs = */ 2_200
            )
            .setPrioritizeTimeOverSizeThresholds(true)
            .setBackBuffer(
                /* backBufferDurationMs = */ 6_000,
                /* retainBackBufferFromKeyframe = */ true
            )
            .build()

        ExoPlayer.Builder(context, renderersFactory)
            .setMediaSourceFactory(mediaSourceFactory)
            .setLoadControl(smoothLoadControl)
            .setAudioAttributes(audioAttributes, /* handleAudioFocus = */ false)
            .setSeekParameters(SeekParameters.EXACT)
            .build()
            .apply {
                repeatMode = Player.REPEAT_MODE_ONE // Infinite looping until swiped away
                videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT
                volume = 0f // Hold audio silent until first video frame locks onto the surface
            }
    }

    // Hold audio output until the first video frame is rendered and buffering is complete (audio = video)
    val effectiveVolume = if (
        isMuted ||
        !hasRenderedFirstFrame ||
        isBuffering ||
        !isActivePage ||
        isPaused
    ) {
        0f
    } else {
        1f
    }

    LaunchedEffect(exoPlayer, effectiveVolume) {
        exoPlayer.volume = effectiveVolume
    }

    // Handle Active Page Autoplay, Seamless Quality Switching (preserving byte-range position), Adjacent Page Pre-buffering, and Swiped-Away Release
    LaunchedEffect(directStreamUrl, isActivePage, isNextPage, isPreviousPage, retryCounter) {
        when {
            isActivePage -> {
                errorText = null
                val mediaItem = MediaItem.Builder()
                    .setUri(directStreamUrl)
                    .setCustomCacheKey(directStreamUrl)
                    .build()
                if (loadedMediaUri != directStreamUrl || exoPlayer.playbackState == Player.STATE_IDLE) {
                    val previousPositionMs = if (loadedMediaUri != null) exoPlayer.currentPosition.coerceAtLeast(0L) else 0L
                    targetStartPositionMs = previousPositionMs
                    needsInitialAvSyncSnap = true
                    hasRenderedFirstFrame = false
                    exoPlayer.volume = 0f
                    loadedMediaUri = directStreamUrl
                    exoPlayer.setMediaItem(mediaItem, previousPositionMs)
                    exoPlayer.prepare()
                }
                exoPlayer.repeatMode = Player.REPEAT_MODE_ONE
                if (!isPaused) {
                    AkashActivePlaybackCoordinator.claimActivePlayer(exoPlayer)
                    exoPlayer.playWhenReady = true
                    exoPlayer.play()
                } else {
                    exoPlayer.playWhenReady = false
                    exoPlayer.pause()
                }
            }

            isNextPage || isPreviousPage -> {
                // Keep adjacent Short [i + 1] and [i - 1] prepared in ExoPlayer with playWhenReady = false
                AkashActivePlaybackCoordinator.releasePlayer(exoPlayer)
                exoPlayer.volume = 0f
                exoPlayer.playWhenReady = false
                exoPlayer.pause()
                isExoPlaying = false
                val mediaItem = MediaItem.Builder()
                    .setUri(directStreamUrl)
                    .setCustomCacheKey(directStreamUrl)
                    .build()
                if (loadedMediaUri != directStreamUrl || exoPlayer.playbackState == Player.STATE_IDLE) {
                    targetStartPositionMs = 0L
                    needsInitialAvSyncSnap = true
                    hasRenderedFirstFrame = false
                    loadedMediaUri = directStreamUrl
                    exoPlayer.setMediaItem(mediaItem)
                    exoPlayer.prepare()
                } else if (exoPlayer.currentPosition > 0L) {
                    targetStartPositionMs = 0L
                    needsInitialAvSyncSnap = true
                    exoPlayer.seekTo(0L)
                }
            }

            else -> {
                // Immediately stop non-adjacent videos
                AkashActivePlaybackCoordinator.releasePlayer(exoPlayer)
                exoPlayer.volume = 0f
                exoPlayer.playWhenReady = false
                exoPlayer.pause()
                exoPlayer.stop()
                exoPlayer.clearMediaItems()
                loadedMediaUri = null
                targetStartPositionMs = 0L
                needsInitialAvSyncSnap = true
                hasRenderedFirstFrame = false
                isExoPlaying = false
                isBuffering = false
            }
        }
    }

    LaunchedEffect(seekTrigger) {
        if (seekTrigger > 0 && isActivePage) {
            val dur = exoPlayer.duration.takeIf { it != C.TIME_UNSET && it > 0L }
                ?: ((clip.durationSeconds.takeIf { it > 0 } ?: 15) * 1000L)
            val targetMs = (seekFraction.coerceIn(0f, 1f) * dur).toLong().coerceIn(0L, dur)
            targetStartPositionMs = targetMs
            exoPlayer.seekTo(targetMs)
        }
    }

    // React to single-tap Play / Pause toggle or swipe-away on the active page
    LaunchedEffect(isPaused, isActivePage) {
        if (isActivePage) {
            if (isPaused) {
                exoPlayer.volume = 0f
                exoPlayer.playWhenReady = false
                exoPlayer.pause()
                isExoPlaying = false
            } else {
                AkashActivePlaybackCoordinator.claimActivePlayer(exoPlayer)
                exoPlayer.playWhenReady = true
                exoPlayer.play()
                exoPlayer.volume = if (!isMuted && hasRenderedFirstFrame && !isBuffering) 1f else 0f
            }
        } else {
            AkashActivePlaybackCoordinator.releasePlayer(exoPlayer)
            exoPlayer.volume = 0f
            exoPlayer.playWhenReady = false
            exoPlayer.pause()
            isExoPlaying = false
        }
    }

    // Smooth progress polling that only emits when progress changes meaningfully
    LaunchedEffect(exoPlayer, isActivePage, isPaused, isExoPlaying, hasRenderedFirstFrame, seekTrigger) {
        if (isActivePage && !isPaused && isExoPlaying && hasRenderedFirstFrame) {
            if (seekTrigger > 0) {
                delay(50L)
            }
            var lastReportedFraction = -1f
            var lastReportedSec = -1
            while (true) {
                val dur = exoPlayer.duration
                if (dur != C.TIME_UNSET && dur > 0L) {
                    val pos = exoPlayer.currentPosition.coerceIn(0L, dur)
                    val fraction = (pos.toFloat() / dur.toFloat()).coerceIn(0f, 1f)
                    val totalSec = (dur / 1000L).toInt().coerceAtLeast(1)
                    if (abs(fraction - lastReportedFraction) >= 0.002f || totalSec != lastReportedSec) {
                        lastReportedFraction = fraction
                        lastReportedSec = totalSec
                        onProgressUpdate(fraction, totalSec)
                    }
                }
                delay(48L)
            }
        }
    }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onRenderedFirstFrame() {
                if (needsInitialAvSyncSnap) {
                    needsInitialAvSyncSnap = false
                    val currentPos = exoPlayer.currentPosition.coerceAtLeast(0L)
                    // If audio clock advanced while hardware video decoder was initializing the first frame,
                    // snap audio position back to targetStartPositionMs so audio and video start locked together.
                    if (abs(currentPos - targetStartPositionMs) > 65L) {
                        exoPlayer.seekTo(targetStartPositionMs)
                    }
                }
                hasRenderedFirstFrame = true
                isBuffering = false
                errorText = null
                isExoPlaying = exoPlayer.isPlaying
                exoPlayer.volume = if (!currentIsMuted && currentIsActivePage && !currentIsPaused) 1f else 0f
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (videoSize.width > 0 && videoSize.height > 0) {
                    val ratio = (videoSize.width * videoSize.pixelWidthHeightRatio) / videoSize.height.toFloat()
                    if (ratio.isFinite() && ratio > 0f) {
                        videoAspectRatio = ratio
                    }
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_BUFFERING -> {
                        isBuffering = true
                        // Hold audio silent while buffering so audio never runs ahead of stalled video frames
                        exoPlayer.volume = 0f
                    }
                    Player.STATE_READY -> {
                        isBuffering = false
                        errorText = null
                        if (hasRenderedFirstFrame) {
                            exoPlayer.volume = if (!currentIsMuted && currentIsActivePage && !currentIsPaused) 1f else 0f
                        }
                    }
                    Player.STATE_ENDED, Player.STATE_IDLE -> {
                        isBuffering = false
                        exoPlayer.volume = 0f
                    }
                }
                isExoPlaying = exoPlayer.isPlaying
            }

            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) {
                if (reason == Player.DISCONTINUITY_REASON_SEEK ||
                    reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION
                ) {
                    errorText = null
                    if (exoPlayer.playbackState == Player.STATE_BUFFERING) {
                        isBuffering = true
                        exoPlayer.volume = 0f
                    } else if (hasRenderedFirstFrame) {
                        exoPlayer.volume = if (!currentIsMuted && currentIsActivePage && !currentIsPaused) 1f else 0f
                    }
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                isExoPlaying = isPlaying
                if (isPlaying) {
                    isBuffering = false
                    AkashActivePlaybackCoordinator.claimActivePlayer(exoPlayer)
                    if (hasRenderedFirstFrame) {
                        exoPlayer.volume = if (!currentIsMuted && currentIsActivePage && !currentIsPaused) 1f else 0f
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                // If adaptive HLS (.m3u8) endpoint is not available for a clip on the server,
                // transparently fallback to the raw stream URL at the current playback position.
                if (loadedMediaUri != null && loadedMediaUri != highestQualityStreamUrl) {
                    val resumePos = exoPlayer.currentPosition.coerceAtLeast(targetStartPositionMs).coerceAtLeast(0L)
                    targetStartPositionMs = resumePos
                    needsInitialAvSyncSnap = true
                    hasRenderedFirstFrame = false
                    exoPlayer.volume = 0f
                    loadedMediaUri = highestQualityStreamUrl
                    errorText = null
                    val fallbackMediaItem = MediaItem.Builder()
                        .setUri(highestQualityStreamUrl)
                        .setCustomCacheKey(highestQualityStreamUrl)
                        .build()
                    exoPlayer.setMediaItem(fallbackMediaItem, resumePos)
                    exoPlayer.prepare()
                    if (currentIsActivePage && !currentIsPaused) {
                        AkashActivePlaybackCoordinator.claimActivePlayer(exoPlayer)
                        exoPlayer.playWhenReady = true
                        exoPlayer.play()
                    }
                    return
                }
                isExoPlaying = false
                isBuffering = false
                exoPlayer.volume = 0f
                errorText = error.localizedMessage ?: "Network playback error"
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
        }
    }

    DisposableEffect(lifecycleOwner, exoPlayer) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE,
                Lifecycle.Event.ON_STOP -> {
                    exoPlayer.volume = 0f
                    exoPlayer.pause()
                    isExoPlaying = false
                }
                Lifecycle.Event.ON_RESUME -> {
                    if (isActivePage && !isPaused) {
                        AkashActivePlaybackCoordinator.claimActivePlayer(exoPlayer)
                        exoPlayer.playWhenReady = true
                        exoPlayer.play()
                        if (hasRenderedFirstFrame && !isBuffering && !isMuted) {
                            exoPlayer.volume = 1f
                        }
                    }
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            AkashActivePlaybackCoordinator.releasePlayer(exoPlayer)
            exoPlayer.volume = 0f
            exoPlayer.clearVideoSurface()
            exoPlayer.stop()
            exoPlayer.clearMediaItems()
            exoPlayer.release()
        }
    }

    val thumbnailUrl = remember(fileCode, clip.thumbnailUrl) {
        ReelsLookaheadCacheManager.resolveThumbnailUrl(clip)
    }

    // Smooth crossfade between poster thumbnail and rendered TextureView video surface
    val posterAlpha by animateFloatAsState(
        targetValue = if (hasRenderedFirstFrame && errorText == null) 0f else 1f,
        animationSpec = tween(durationMillis = 220, easing = FastOutSlowInEasing),
        label = "poster_crossfade_alpha"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(NexoraColors.CanvasBase)
    ) {
        AndroidView(
            factory = { ctx ->
                FrameLayout(ctx).apply {
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    val aspectContainer = AspectRatioFrameLayout(ctx).apply {
                        this.resizeMode = resizeMode
                        setAspectRatio(videoAspectRatio)
                        layoutParams = FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            Gravity.CENTER
                        )
                    }
                    val textureView = TextureView(ctx).apply {
                        isOpaque = false
                        layoutParams = FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            Gravity.CENTER
                        )
                    }
                    aspectContainer.addView(textureView)
                    addView(aspectContainer)
                    exoPlayer.setVideoTextureView(textureView)
                    tag = AkashVideoSurfaceHolder(
                        aspectContainer = aspectContainer,
                        textureView = textureView,
                        boundPlayer = exoPlayer,
                        appliedResizeMode = resizeMode,
                        appliedAspectRatio = videoAspectRatio
                    )
                }
            },
            update = { rootContainer ->
                val holder = rootContainer.tag as? AkashVideoSurfaceHolder
                if (holder != null) {
                    if (holder.appliedResizeMode != resizeMode) {
                        holder.aspectContainer.resizeMode = resizeMode
                        holder.appliedResizeMode = resizeMode
                    }
                    if (abs(holder.appliedAspectRatio - videoAspectRatio) > 0.001f) {
                        holder.aspectContainer.setAspectRatio(videoAspectRatio)
                        holder.appliedAspectRatio = videoAspectRatio
                    }
                    // Only re-bind TextureView when the ExoPlayer instance actually changes;
                    // never re-bind on ordinary Compose recompositions, which would interrupt
                    // the hardware video surface pipeline while audio continues playing.
                    if (holder.boundPlayer !== exoPlayer) {
                        exoPlayer.setVideoTextureView(holder.textureView)
                        holder.boundPlayer = exoPlayer
                    }
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // Seamless poster placeholder crossfading out once first video frame renders
        if (posterAlpha > 0.01f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { alpha = posterAlpha }
            ) {
                ThumbnailWithFallback(
                    thumbnailUrl = thumbnailUrl,
                    video = clip,
                    contentScale = if (resizeMode == AspectRatioFrameLayout.RESIZE_MODE_FIT) {
                        ContentScale.Fit
                    } else {
                        ContentScale.Crop
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        // Sleek Instagram-style bottom buffering shimmer line (non-blocking, zero spinner clutter)
        if (isActivePage && (isBuffering || !hasRenderedFirstFrame) && errorText == null) {
            InstagramBufferingBottomBar(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(2.5.dp)
            )
        }

        if (isActivePage && errorText != null) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .liquidGlassDarkOverlay(20.dp)
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Stream unavailable",
                    style = NexoraTypography.BadgeMicro.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(NexoraColors.ElectricIndigo)
                        .clickable {
                            loadedMediaUri = null
                            errorText = null
                            hasRenderedFirstFrame = false
                            retryCounter += 1
                        }
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                        .testTag("inline_clip_retry_btn_${clip.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "Retry",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "Retry",
                            style = NexoraTypography.BadgeMicro.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp
                            )
                        )
                    }
                }
            }
        }
    }
}

@OptIn(UnstableApi::class)
private class AkashVideoSurfaceHolder(
    val aspectContainer: AspectRatioFrameLayout,
    val textureView: TextureView,
    var boundPlayer: ExoPlayer,
    var appliedResizeMode: Int,
    var appliedAspectRatio: Float
)

@Composable
private fun InstagramBufferingBottomBar(
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "ig_buffer_bar")
    val sweep by transition.animateFloat(
        initialValue = -0.6f,
        targetValue = 1.6f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 850, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "buffer_sweep"
    )
    Canvas(modifier = modifier) {
        val w = size.width.coerceAtLeast(1f)
        val h = size.height.coerceAtLeast(1f)
        drawRect(color = Color.White.copy(alpha = 0.14f))
        val startX = sweep * w
        drawRect(
            brush = Brush.horizontalGradient(
                colors = listOf(
                    Color.Transparent,
                    Color(0xFFF58529),
                    Color(0xFFDD2A7B),
                    Color(0xFF0095F6),
                    Color.Transparent
                ),
                startX = startX - w * 0.35f,
                endX = startX + w * 0.35f
            ),
            topLeft = Offset.Zero,
            size = androidx.compose.ui.geometry.Size(w, h)
        )
    }
}

@Composable
private fun ThumbnailWithFallback(
    thumbnailUrl: String?,
    video: VideoItem,
    contentScale: ContentScale = ContentScale.Crop,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    if (!thumbnailUrl.isNullOrBlank()) {
        val imageRequest = remember(context, thumbnailUrl) {
            ImageRequest.Builder(context)
                .data(thumbnailUrl)
                .addHeader(AkashMediaService.HEADER_APP_TOKEN, AkashMediaService.APP_TOKEN)
                .crossfade(180)
                .memoryCachePolicy(CachePolicy.ENABLED)
                .diskCachePolicy(CachePolicy.ENABLED)
                .build()
        }
        SubcomposeAsyncImage(
            model = imageRequest,
            contentDescription = video.title,
            contentScale = contentScale,
            modifier = modifier,
            loading = {
                InstagramDarkShimmerBox(modifier = Modifier.fillMaxSize())
            },
            error = {
                SpatialVisualCanvas(
                    preset = video.visualPreset,
                    isAnimated = false,
                    playbackPhase = video.previewProgress,
                    modifier = Modifier.fillMaxSize()
                )
            }
        )
    } else {
        SpatialVisualCanvas(
            preset = video.visualPreset,
            isAnimated = false,
            playbackPhase = video.previewProgress,
            modifier = modifier
        )
    }
}
