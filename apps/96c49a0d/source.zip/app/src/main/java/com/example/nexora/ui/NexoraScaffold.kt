package com.example.nexora.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.nexora.animation.ClickOrigin
import com.example.nexora.animation.OriginTrackerBox
import com.example.nexora.animation.StageBubbleContainer
import com.example.nexora.data.NavTab
import com.example.nexora.ui.components.FloatingHeader
import com.example.nexora.ui.components.MobileFloatingBottomNav
import com.example.nexora.ui.components.NotificationsDropdownPanel
import com.example.nexora.ui.modals.AccountCentreFullScreenStage
import com.example.nexora.ui.modals.AdminDashboardModal
import com.example.nexora.ui.modals.DedicatedLoginStage
import com.example.nexora.ui.modals.DirectMessagesModal
import com.example.nexora.ui.modals.DirectMessagesStageView
import com.example.nexora.ui.modals.EditProfileModal
import com.example.nexora.ui.modals.ExpandableSpatialCallOverlay
import com.example.nexora.ui.modals.FloatingCallMiniBar
import com.example.nexora.ui.modals.LocalSpatialCallController
import com.example.nexora.ui.modals.SovereignAuthGateView
import com.example.nexora.ui.modals.SpatialCallAudioRuntimeEffect
import com.example.nexora.ui.modals.SpatialCallController
import com.example.nexora.ui.modals.SpatialClipsStageView
import com.example.nexora.ui.modals.SpatialClipsVerticalViewerModal
import com.example.nexora.ui.modals.SpatialPulseViewerModal
import com.example.nexora.ui.modals.UploadModal
import com.example.nexora.ui.views.CreatorProfileView
import com.example.nexora.ui.views.ExploreView
import com.example.nexora.ui.views.HomeView
import com.example.nexora.ui.views.LibraryView
import com.example.nexora.ui.views.LiveView
import com.example.nexora.viewmodel.NexoraViewModel
import com.example.ui.theme.NexoraColors
import com.example.ui.theme.NexoraTypography
import com.example.ui.theme.liquidGlassAccent
import kotlinx.coroutines.delay

@Composable
fun NexoraScaffold(
    viewModel: NexoraViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val callController = remember { SpatialCallController() }

    SpatialCallAudioRuntimeEffect(controller = callController)

    LaunchedEffect(state.toastMessage) {
        if (state.toastMessage != null) {
            delay(2600L)
            viewModel.clearToast()
        }
    }

    CompositionLocalProvider(LocalSpatialCallController provides callController) {
    OriginTrackerBox(
        activeOrigin = state.stageTransitionOrigin,
        onPointerDownCapture = viewModel::capturePointerOrigin,
        modifier = modifier
            .fillMaxSize()
            .background(NexoraColors.CanvasBase)
    ) { viewportSize ->
        if (!state.isAuthenticated && !state.isGuestMode) {
            DedicatedLoginStage(
                onAuthenticated = viewModel::onFirebaseUserAuthenticated,
                onContinueAsGuest = viewModel::enableGuestMode,
                onEmailSignIn = viewModel::signInWithEmailAndPassword,
                onEmailRegister = viewModel::registerWithEmailAndPassword,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // 1. Fixed Background Layer: Cool Pearl Alabaster (#F2F5FC) + 3 Radial Ambient Mesh Orbs
            AmbientPearlBackgroundCanvas()

            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isWideScreen = maxWidth >= 768.dp
            val unreadCount = state.notifications.count { it.isUnread }
            val unreadDmCount = state.directThreads.sumOf { it.unreadCount }

            val isImmersiveShortVideo = state.activeTab == NavTab.LIVE || state.activeClipId != null
            val isChatConversationActive = (state.activeTab == NavTab.MESSAGES && state.isChatConversationOpen) || state.isDmModalOpen
            val isMessagesTab = state.activeTab == NavTab.MESSAGES
            val shouldHideTopHeader = isImmersiveShortVideo || isChatConversationActive || isMessagesTab || state.isAccountCentreModalOpen || state.isUploadModalOpen
            val shouldHideBottomNav = isImmersiveShortVideo || isChatConversationActive || state.isAccountCentreModalOpen || state.isUploadModalOpen

            Column(modifier = Modifier.fillMaxSize()) {
                // Persistent Floating Mini-Bar when a call is minimized while browsing chats or feeds
                FloatingCallMiniBar(controller = callController)

                // 2. Top Floating Pill Header (smoothly slides upward out of view in Short Video, Messages, or Chat Conversation mode)
                AnimatedVisibility(
                    visible = !shouldHideTopHeader,
                    enter = slideInVertically(
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioLowBouncy,
                            stiffness = Spring.StiffnessMediumLow
                        ),
                        initialOffsetY = { fullHeight -> -fullHeight - 40 }
                    ) + expandVertically(
                        expandFrom = Alignment.Top,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioNoBouncy,
                            stiffness = Spring.StiffnessMediumLow
                        )
                    ) + fadeIn(animationSpec = tween(260, easing = FastOutSlowInEasing)),
                    exit = slideOutVertically(
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioNoBouncy,
                            stiffness = Spring.StiffnessMediumLow
                        ),
                        targetOffsetY = { fullHeight -> -fullHeight - 40 }
                    ) + shrinkVertically(
                        shrinkTowards = Alignment.Top,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioNoBouncy,
                            stiffness = Spring.StiffnessMediumLow
                        )
                    ) + fadeOut(animationSpec = tween(200, easing = FastOutSlowInEasing))
                ) {
                    FloatingHeader(
                        activeTab = state.activeTab,
                        searchQuery = state.searchQuery,
                        unreadNotificationCount = unreadCount,
                        unreadDmCount = unreadDmCount,
                        ownStudioProfile = state.ownStudioProfile,
                        isOwnProfile = state.activeCreator.id == state.ownStudioProfile.id,
                        isWideScreen = isWideScreen,
                        onSelectTab = viewModel::selectTab,
                        onSearchQueryChange = viewModel::updateSearchQuery,
                        onOpenUploadModal = viewModel::openUploadModal,
                        onOpenDmModal = { viewModel.openDmModal() },
                        onToggleNotifications = viewModel::toggleNotificationsDropdown,
                        onOpenAdminModal = viewModel::openAdminModal,
                        onOpenAccountCentre = viewModel::openAccountCentreModal,
                        onOpenOwnProfile = { viewModel.openCreatorProfile("creator_aether") },
                        onCaptureSlotOrigin = { offset ->
                            viewModel.capturePointerOrigin(
                                ClickOrigin.fromRootCoordinates(
                                    x = offset.x,
                                    y = offset.y,
                                    viewportWidth = viewportSize.width.toFloat(),
                                    viewportHeight = viewportSize.height.toFloat(),
                                    timestamp = System.currentTimeMillis()
                                )
                            )
                        }
                    )
                }

                // 3. Primary Stage Content with Mathematical Button-Origin Homothety Transition
                StageBubbleContainer(
                    triggerKey = Pair(state.activeTab, state.activeCreator.id),
                    origin = state.stageTransitionOrigin,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    when (state.activeTab) {
                        NavTab.HOME -> {
                            HomeView(
                                videos = state.videos,
                                shortVideos = state.shortVideos,
                                selectedCategory = state.selectedCategory,
                                searchQuery = state.searchQuery,
                                savedVideoIds = state.savedVideoIds,
                                watchHistoryProgress = state.watchHistoryProgress,
                                isCatalogLoading = state.isCatalogLoading,
                                catalogError = state.catalogError,
                                onRetryCatalog = viewModel::fetchAkashCatalog,
                                spatialPulses = state.spatialPulses,
                                onSelectCategory = viewModel::selectCategory,
                                onVideoClick = viewModel::openVideoPlayer,
                                onCreatorClick = viewModel::openCreatorProfile,
                                onToggleSave = viewModel::toggleSaveVideo,
                                onShareVideo = { v ->
                                    viewModel.showToast("Shared \"${v.title}\"")
                                },
                                onToggleLike = viewModel::toggleVideoLike,
                                onDoubleTapLike = viewModel::doubleTapLikeVideo,
                                onToggleRepost = viewModel::toggleRepostVideo,
                                onAddComment = viewModel::addVideoComment,
                                onToggleCommentLike = viewModel::toggleCommentLike,
                                onActionFeedback = viewModel::showToast,
                                onOpenPulse = viewModel::openSpatialPulse,
                                onCreatePulseClick = viewModel::openUploadModal,
                                onOpenSpatialClip = viewModel::openSpatialClipsViewer,
                                isRefreshing = state.isRefreshing && state.activeTab == NavTab.HOME,
                                onRefresh = { viewModel.refreshTab(NavTab.HOME) },
                                refreshTrigger = state.tabRefreshTrigger,
                                isGlobalAudioMuted = state.isGlobalAudioMuted,
                                onToggleMute = viewModel::toggleGlobalAudioMuted,
                                isFeedVisible = state.activeTab == NavTab.HOME &&
                                    state.activeClipId == null &&
                                    state.activePulseStory == null &&
                                    !state.isUploadModalOpen &&
                                    !state.isDmModalOpen &&
                                    !state.isAccountCentreModalOpen &&
                                    !state.isEditProfileModalOpen &&
                                    !state.isAdminModalOpen
                            )
                        }

                        NavTab.EXPLORE -> {
                            ExploreView(
                                videos = state.videos,
                                shortVideos = state.shortVideos,
                                creators = state.creators,
                                subscribedCreatorIds = state.subscribedCreatorIds,
                                selectedHashtag = state.selectedHashtag,
                                sortMode = state.exploreSortMode,
                                searchQuery = state.searchQuery,
                                savedVideoIds = state.savedVideoIds,
                                onSelectHashtag = viewModel::selectExploreHashtag,
                                onSelectSortMode = viewModel::selectExploreSortMode,
                                onVideoClick = viewModel::openVideoPlayer,
                                onCreatorClick = viewModel::openCreatorProfile,
                                onToggleSubscribe = viewModel::toggleSubscribeCreator,
                                onToggleSave = viewModel::toggleSaveVideo,
                                onShareVideo = { v ->
                                    viewModel.showToast("Shared \"${v.title}\"")
                                },
                                onToggleLike = viewModel::toggleVideoLike,
                                onDoubleTapLike = viewModel::doubleTapLikeVideo,
                                onToggleRepost = viewModel::toggleRepostVideo,
                                onAddComment = viewModel::addVideoComment,
                                onToggleCommentLike = viewModel::toggleCommentLike,
                                onActionFeedback = viewModel::showToast,
                                onOpenSpatialClip = viewModel::openSpatialClipsViewer,
                                isRefreshing = state.isRefreshing && state.activeTab == NavTab.EXPLORE,
                                onRefresh = { viewModel.refreshTab(NavTab.EXPLORE) },
                                refreshTrigger = state.tabRefreshTrigger,
                                isGlobalAudioMuted = state.isGlobalAudioMuted,
                                onToggleMute = viewModel::toggleGlobalAudioMuted
                            )
                        }

                        NavTab.LIVE -> {
                            if (!state.isAuthenticated) {
                                SovereignAuthGateView(
                                    onAuthenticated = viewModel::onFirebaseUserAuthenticated,
                                    onBack = {
                                        val targetTab = if (state.previousTab == NavTab.LIVE) NavTab.HOME else state.previousTab
                                        viewModel.selectTab(targetTab)
                                    }
                                )
                            } else {
                                SpatialClipsStageView(
                                    clips = state.shortVideos,
                                    savedVideoIds = state.savedVideoIds,
                                    subscribedCreatorIds = state.subscribedCreatorIds,
                                    isLoading = state.isShortsLoading,
                                    errorMessage = state.shortsError,
                                    onRetry = viewModel::fetchShortsFeed,
                                    onCheckClipStatus = viewModel::checkReelInteractionStatus,
                                    onToggleLike = viewModel::toggleVideoLike,
                                    onDoubleTapLike = viewModel::doubleTapLikeVideo,
                                    onToggleRepost = viewModel::toggleRepostVideo,
                                    onToggleSave = viewModel::toggleSaveVideo,
                                    onToggleSubscribe = viewModel::toggleSubscribeCreator,
                                    onCreatorClick = viewModel::openCreatorProfile,
                                    onAddComment = viewModel::addVideoComment,
                                    onToggleCommentLike = viewModel::toggleCommentLike,
                                    onShareClip = { clip ->
                                        viewModel.showToast("Shared Spatial Clip \"${clip.cleanTitle}\"")
                                    },
                                    onBack = {
                                        val targetTab = if (state.previousTab == NavTab.LIVE) NavTab.HOME else state.previousTab
                                        viewModel.selectTab(targetTab)
                                    },
                                    isGlobalAudioMuted = state.isGlobalAudioMuted,
                                    onToggleMute = viewModel::toggleGlobalAudioMuted
                                )
                            }
                        }

                        NavTab.MESSAGES -> {
                            DirectMessagesStageView(
                                threads = state.directThreads,
                                activeCreatorId = state.activeDmCreatorId,
                                isConversationOpen = state.isChatConversationOpen,
                                onConversationStateChange = viewModel::setChatConversationOpen,
                                onSelectThread = viewModel::selectDmThread,
                                onSendMessage = viewModel::sendDirectMessage,
                                onOpenCreatorProfile = viewModel::openCreatorProfile,
                                onBack = { viewModel.selectTab(NavTab.HOME) }
                            )
                        }

                        NavTab.LIBRARY -> {
                            LibraryView(
                                activeSubTab = state.librarySubTab,
                                allVideos = state.videos,
                                savedVideoIds = state.savedVideoIds,
                                watchHistoryProgress = state.watchHistoryProgress,
                                playlists = state.playlists,
                                creators = state.creators,
                                subscribedCreatorIds = state.subscribedCreatorIds,
                                onSelectSubTab = viewModel::selectLibrarySubTab,
                                onOpenPlaylistModal = viewModel::openPlaylistModal,
                                onDeletePlaylist = viewModel::deletePlaylist,
                                onClearHistory = viewModel::clearWatchHistory,
                                onVideoClick = viewModel::openVideoPlayer,
                                onCreatorClick = viewModel::openCreatorProfile,
                                onToggleSave = viewModel::toggleSaveVideo,
                                onToggleSubscribe = viewModel::toggleSubscribeCreator,
                                onShareVideo = { v ->
                                    viewModel.showToast("Shared \"${v.title}\"")
                                },
                                isRefreshing = state.isRefreshing && state.activeTab == NavTab.LIBRARY,
                                onRefresh = { viewModel.refreshTab(NavTab.LIBRARY) },
                                refreshTrigger = state.tabRefreshTrigger,
                                isGlobalAudioMuted = state.isGlobalAudioMuted,
                                onToggleMute = viewModel::toggleGlobalAudioMuted
                            )
                        }

                        NavTab.PROFILE -> {
                            val profileQuery = state.searchQuery.trim()
                            fun com.example.nexora.data.VideoItem.matchesProfileQuery(q: String): Boolean {
                                if (q.isEmpty()) return true
                                return title.contains(q, ignoreCase = true) ||
                                    creatorName.contains(q, ignoreCase = true) ||
                                    creatorHandle.contains(q, ignoreCase = true) ||
                                    description.contains(q, ignoreCase = true) ||
                                    category.contains(q, ignoreCase = true) ||
                                    hashtags.any { it.contains(q, ignoreCase = true) }
                            }
                            val baseCreatorVideos = state.shortVideos.ifEmpty {
                                state.videos.filter {
                                    it.creatorId == state.activeCreator.id
                                }.ifEmpty { state.videos.take(4) }
                            }
                            val creatorVideos = baseCreatorVideos.filter { it.matchesProfileQuery(profileQuery) }
                            val savedReels = (state.savedReelsFromVault +
                                state.shortVideos.filter { it.id in state.savedVideoIds || it.effectiveFileCode in state.savedVideoIds } +
                                state.videos.filter { it.isShortVideo && (it.id in state.savedVideoIds || it.effectiveFileCode in state.savedVideoIds) })
                                .distinctBy { it.id }
                                .filter { it.matchesProfileQuery(profileQuery) }

                            val likedReels = (state.shortVideos.filter { it.isLiked } +
                                state.videos.filter { it.isShortVideo && it.isLiked })
                                .distinctBy { it.id }
                                .filter { it.matchesProfileQuery(profileQuery) }

                            CreatorProfileView(
                                creator = state.activeCreator,
                                isOwnProfile = state.activeCreator.id == "creator_aether",
                                isSubscribed = state.activeCreator.id in state.subscribedCreatorIds,
                                activeSubTab = state.profileSubTab,
                                videosFilter = state.profileVideosFilter,
                                creatorVideos = creatorVideos,
                                collections = state.collections,
                                savedVideoIds = state.savedVideoIds,
                                transitionOrigin = state.stageTransitionOrigin,
                                onBack = viewModel::navigateBackFromProfile,
                                onSelectSubTab = viewModel::selectProfileSubTab,
                                onSelectVideosFilter = viewModel::selectProfileVideosFilter,
                                onToggleSubscribe = viewModel::toggleSubscribeCreator,
                                onOpenEditProfile = viewModel::openEditProfileModal,
                                onOpenAccountCentre = viewModel::openAccountCentreModal,
                                onWatchVideo = viewModel::openVideoPlayer,
                                onEnterLiveRoom = { viewModel.selectTab(NavTab.LIVE) },
                                onToggleSave = viewModel::toggleSaveVideo,
                                onShareProfile = {
                                    viewModel.showToast("Copied link to ${state.activeCreator.name} (${state.activeCreator.website})")
                                },
                                savedReels = savedReels,
                                likedReels = likedReels,
                                isSavedReelsLoading = state.isSavedReelsLoading,
                                isAuthenticated = state.isAuthenticated,
                                onSignOut = viewModel::signOutFirebase,
                                onOpenReelsTab = { viewModel.selectTab(NavTab.LIVE) },
                                isRefreshing = state.isRefreshing && state.activeTab == NavTab.PROFILE,
                                onRefresh = { viewModel.refreshTab(NavTab.PROFILE) },
                                refreshTrigger = state.tabRefreshTrigger
                            )
                        }
                    }
                }
            }

            // 4. Mobile Floating Bottom Navigation Bar (< 768.dp, smoothly moves down off-screen in Short Video or Chat Conversation mode)
            if (!isWideScreen) {
                val navBarSlideProgress by animateFloatAsState(
                    targetValue = if (shouldHideBottomNav) 1f else 0f,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioLowBouncy,
                        stiffness = Spring.StiffnessMediumLow
                    ),
                    label = "bottom_nav_dynamic_slide"
                )

                AnimatedVisibility(
                    visible = !shouldHideBottomNav,
                    enter = slideInVertically(
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioLowBouncy,
                            stiffness = Spring.StiffnessMediumLow
                        ),
                        initialOffsetY = { fullHeight -> fullHeight + 96 }
                    ) + scaleIn(
                        initialScale = 0.92f,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioLowBouncy,
                            stiffness = Spring.StiffnessMediumLow
                        )
                    ) + fadeIn(animationSpec = tween(240, easing = FastOutSlowInEasing)),
                    exit = slideOutVertically(
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioNoBouncy,
                            stiffness = Spring.StiffnessMediumLow
                        ),
                        targetOffsetY = { fullHeight -> fullHeight + 96 }
                    ) + scaleOut(
                        targetScale = 0.92f,
                        animationSpec = tween(220, easing = FastOutSlowInEasing)
                    ) + fadeOut(animationSpec = tween(200, easing = FastOutSlowInEasing)),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .padding(bottom = 16.dp)
                        .graphicsLayer {
                            translationY = navBarSlideProgress * 140.dp.toPx()
                            alpha = (1f - navBarSlideProgress).coerceIn(0f, 1f)
                        }
                ) {
                    MobileFloatingBottomNav(
                        activeTab = state.activeTab,
                        unreadDmCount = unreadDmCount,
                        ownStudioProfile = state.ownStudioProfile,
                        onSelectTab = viewModel::selectTab,
                        onOpenOwnProfile = { viewModel.openCreatorProfile("creator_aether") },
                        onCaptureSlotOrigin = { offset ->
                            viewModel.capturePointerOrigin(
                                ClickOrigin.fromRootCoordinates(
                                    x = offset.x,
                                    y = offset.y,
                                    viewportWidth = viewportSize.width.toFloat(),
                                    viewportHeight = viewportSize.height.toFloat(),
                                    timestamp = System.currentTimeMillis()
                                )
                            )
                        }
                    )
                }
            }

            // 5. Floating Glass Notifications Dropdown anchored below Header
            AnimatedVisibility(
                visible = state.isNotificationsOpen,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 86.dp, end = if (isWideScreen) 28.dp else 14.dp, start = 14.dp)
            ) {
                NotificationsDropdownPanel(
                    notifications = state.notifications,
                    onMarkAllRead = viewModel::markAllNotificationsRead,
                    onNotificationClick = viewModel::onNotificationClicked,
                    onClose = viewModel::closeNotificationsDropdown
                )
            }

            // 6. Floating Toast Feedback Pill
            AnimatedVisibility(
                visible = state.toastMessage != null,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(bottom = if (isWideScreen || shouldHideBottomNav) 28.dp else 92.dp)
            ) {
                state.toastMessage?.let { msg ->
                    Box(
                        modifier = Modifier
                            .liquidGlassAccent(999.dp)
                            .padding(horizontal = 18.dp, vertical = 10.dp)
                            .testTag("toast_feedback_pill")
                    ) {
                        Text(
                            text = msg,
                            style = NexoraTypography.NavPillLabel.copy(color = NexoraColors.InkAccent)
                        )
                    }
                }
            }
        }

        // 7. Portaled Button-Origin Bubble Modals

        UploadModal(
            visible = state.isUploadModalOpen,
            origin = state.modalTransitionOrigin,
            viewportSize = viewportSize,
            onDismiss = viewModel::closeUploadModal,
            onPublish = viewModel::publishNewVideo,
            onPublishPulse = viewModel::publishSpatialPulse,
            onModularShortCreated = viewModel::onModularShortCreated,
            defaultAuthorName = state.ownStudioProfile.name
        )

        EditProfileModal(
            visible = state.isEditProfileModalOpen,
            profile = state.ownStudioProfile,
            origin = state.modalTransitionOrigin,
            viewportSize = viewportSize,
            onDismiss = viewModel::closeEditProfileModal,
            onOpenAccountCentre = {
                viewModel.closeEditProfileModal()
                viewModel.openAccountCentreModal()
            },
            onSave = { name, handle, category, bio, location, website, bannerPreset, avatarSeed ->
                viewModel.saveStudioProfileEdits(name, handle, category, bio, location, website, bannerPreset, avatarSeed)
            }
        )

        AccountCentreFullScreenStage(
            visible = state.isAccountCentreModalOpen,
            profile = state.ownStudioProfile,
            moderationQueueCount = state.moderationQueue.size,
            savedVideosCount = state.savedVideoIds.size,
            playlistsCount = state.playlists.size,
            onDismiss = viewModel::closeAccountCentreModal,
            onOpenEditProfile = viewModel::openEditProfileModal,
            onOpenAdminDashboard = viewModel::openAdminModal,
            onClearWatchHistory = viewModel::clearWatchHistory,
            onShowToast = viewModel::showToast
        )

        AdminDashboardModal(
            visible = state.isAdminModalOpen,
            moderationQueue = state.moderationQueue,
            origin = state.modalTransitionOrigin,
            viewportSize = viewportSize,
            onDismiss = viewModel::closeAdminModal,
            onModerateItem = viewModel::moderateFlaggedItem
        )

        SpatialPulseViewerModal(
            pulse = state.activePulseStory,
            origin = state.modalTransitionOrigin,
            viewportSize = viewportSize,
            onDismiss = viewModel::closeSpatialPulse,
            onCreatorClick = { creatorId ->
                viewModel.closeSpatialPulse()
                viewModel.openCreatorProfile(creatorId)
            },
            onSendReply = viewModel::sendPulseReaction
        )

        DirectMessagesModal(
            visible = state.isDmModalOpen,
            threads = state.directThreads,
            activeCreatorId = state.activeDmCreatorId,
            origin = state.modalTransitionOrigin,
            viewportSize = viewportSize,
            onSelectThread = viewModel::selectDmThread,
            onSendMessage = viewModel::sendDirectMessage,
            onOpenCreatorProfile = { creatorId ->
                viewModel.closeDmModal()
                viewModel.openCreatorProfile(creatorId)
            },
            onDismiss = viewModel::closeDmModal,
            isConversationOpen = state.isChatConversationOpen,
            onConversationStateChange = viewModel::setChatConversationOpen
        )

        if (state.activeClipId != null && !state.isAuthenticated) {
            SovereignAuthGateView(
                onAuthenticated = viewModel::onFirebaseUserAuthenticated,
                onBack = viewModel::closeSpatialClipsViewer
            )
        } else {
            SpatialClipsVerticalViewerModal(
                activeClipId = state.activeClipId,
                clips = state.shortVideos,
                savedVideoIds = state.savedVideoIds,
                subscribedCreatorIds = state.subscribedCreatorIds,
                origin = state.modalTransitionOrigin,
                viewportSize = viewportSize,
                onDismiss = viewModel::closeSpatialClipsViewer,
                onToggleLike = viewModel::toggleVideoLike,
                onDoubleTapLike = viewModel::doubleTapLikeVideo,
                onToggleRepost = viewModel::toggleRepostVideo,
                onToggleSave = viewModel::toggleSaveVideo,
                onToggleSubscribe = viewModel::toggleSubscribeCreator,
                onCreatorClick = viewModel::openCreatorProfile,
                onAddComment = viewModel::addVideoComment,
                onToggleCommentLike = viewModel::toggleCommentLike,
                onShareClip = { clip ->
                    viewModel.showToast("Shared Spatial Clip \"${clip.cleanTitle}\"")
                },
                onCheckClipStatus = viewModel::checkReelInteractionStatus,
                onDeleteComment = viewModel::deleteVideoComment,
                isGlobalAudioMuted = state.isGlobalAudioMuted,
                onToggleMute = viewModel::toggleGlobalAudioMuted
            )
        }

        // 8. Expandable Full-Screen Spatial Audio Call Stage Overlay
        ExpandableSpatialCallOverlay(controller = callController)
    }
}
}
}

/**
 * Fixed Background Canvas drawing NexoraColors.CanvasBase (#F2F5FC) and the 3 soft radial
 * gradient ambient orbs:
 * - MeshOrbTopLeftLav: rgba(192, 132, 252, 0.26) at (12%, 8%)
 * - MeshOrbTopRightSky: rgba(125, 211, 252, 0.30) at (88%, 14%)
 * - MeshOrbBottomCenterInd: rgba(165, 180, 252, 0.26) at (50%, 85%)
 */
@Composable
private fun AmbientPearlBackgroundCanvas() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NexoraColors.CanvasBase)
    )
}
