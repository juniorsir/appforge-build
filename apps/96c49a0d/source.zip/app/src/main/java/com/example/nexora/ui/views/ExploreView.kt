package com.example.nexora.ui.views

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nexora.data.CreatorProfile
import com.example.nexora.data.ExploreSortMode
import com.example.nexora.data.NexoraSeedData
import com.example.nexora.data.VideoItem
import com.example.nexora.ui.components.CreatorAvatarBadge
import com.example.nexora.ui.components.NexoraVideoCard
import com.example.nexora.ui.components.VerifiedBadge
import com.example.nexora.ui.modals.SpatialClipsRail
import com.example.ui.theme.NexoraColors
import com.example.ui.theme.NexoraTypography
import com.example.ui.theme.liquidGlassAccent
import com.example.ui.theme.liquidGlassCard
import com.example.ui.theme.liquidGlassWhitePill

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ExploreView(
    videos: List<VideoItem>,
    shortVideos: List<VideoItem> = emptyList(),
    creators: List<CreatorProfile>,
    subscribedCreatorIds: Set<String>,
    selectedHashtag: String?,
    sortMode: ExploreSortMode,
    searchQuery: String,
    savedVideoIds: Set<String>,
    onSelectHashtag: (String?) -> Unit,
    onSelectSortMode: (ExploreSortMode) -> Unit,
    onVideoClick: (VideoItem) -> Unit,
    onCreatorClick: (String) -> Unit,
    onToggleSubscribe: (String) -> Unit,
    onToggleSave: (String) -> Unit,
    onToggleLike: (String) -> Unit = {},
    onDoubleTapLike: (String) -> Unit = onToggleLike,
    onToggleRepost: (String) -> Unit = {},
    onAddComment: (String, String) -> Unit = { _, _ -> },
    onToggleCommentLike: (String, String) -> Unit = { _, _ -> },
    onActionFeedback: (String) -> Unit = {},
    onOpenSpatialClip: (String) -> Unit = {},
    onShareVideo: (VideoItem) -> Unit,
    isRefreshing: Boolean = false,
    onRefresh: () -> Unit = {},
    refreshTrigger: Long = 0L,
    isGlobalAudioMuted: Boolean = false,
    onToggleMute: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val nonLiveVideos = videos.filter { !it.isLiveStream }
    val q = searchQuery.trim()
    val filtered = nonLiveVideos.filter { video ->
        val matchesTag = selectedHashtag == null ||
            video.hashtags.any { it.equals(selectedHashtag, ignoreCase = true) }
        val matchesSearch = q.isEmpty() ||
            video.title.contains(q, ignoreCase = true) ||
            video.creatorName.contains(q, ignoreCase = true) ||
            video.creatorHandle.contains(q, ignoreCase = true) ||
            video.description.contains(q, ignoreCase = true) ||
            video.category.contains(q, ignoreCase = true) ||
            video.hashtags.any { it.contains(q, ignoreCase = true) }
        matchesTag && matchesSearch
    }
    val filteredShortVideos = if (q.isEmpty()) {
        shortVideos
    } else {
        shortVideos.filter { clip ->
            clip.title.contains(q, ignoreCase = true) ||
                clip.creatorName.contains(q, ignoreCase = true) ||
                clip.creatorHandle.contains(q, ignoreCase = true) ||
                clip.description.contains(q, ignoreCase = true) ||
                clip.category.contains(q, ignoreCase = true) ||
                clip.hashtags.any { it.contains(q, ignoreCase = true) }
        }
    }
    val displayedCreators = if (q.isEmpty()) {
        creators.take(3)
    } else {
        creators.filter { creator ->
            creator.name.contains(q, ignoreCase = true) ||
                creator.handle.contains(q, ignoreCase = true) ||
                creator.bio.contains(q, ignoreCase = true) ||
                creator.category.contains(q, ignoreCase = true)
        }.ifEmpty { creators.take(3) }
    }

    val sortedVideos = when (sortMode) {
        ExploreSortMode.TRENDING -> filtered
        ExploreSortMode.MOST_VIEWED -> filtered.sortedByDescending { it.rawViews }
        ExploreSortMode.NEWLY_PUBLISHED -> filtered.reversed()
        ExploreSortMode.EDITORS_PICKS -> filtered.filter { it.isEditorsPick }.ifEmpty { filtered }
    }

    val listState = rememberLazyListState()

    LaunchedEffect(refreshTrigger) {
        if (refreshTrigger > 0L) {
            listState.animateScrollToItem(0)
        }
    }

    PullToRefreshBox(
        isRefreshing = isRefreshing,
        onRefresh = onRefresh,
        modifier = modifier.fillMaxSize()
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val screenWidth = maxWidth
            val isWideBento = screenWidth >= 840.dp
            val columns = when {
                screenWidth > 1024.dp -> 3
                screenWidth >= 600.dp -> 2
                else -> 1
            }
            val chunkedVideos = sortedVideos.chunked(columns)

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("explore_view_list"),
                contentPadding = PaddingValues(
                    start = if (screenWidth >= 768.dp) 24.dp else 14.dp,
                    end = if (screenWidth >= 768.dp) 24.dp else 14.dp,
                    top = 8.dp,
                    bottom = 104.dp
                ),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
            // 1. Discovery Creators & Hashtags Header
            item(key = "discovery_bento_hero") {
                if (isWideBento) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(18.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(modifier = Modifier.weight(0.55f)) {
                            TrendingCreatorsLeaderboardCard(
                                creators = displayedCreators,
                                subscribedCreatorIds = subscribedCreatorIds,
                                onCreatorClick = onCreatorClick,
                                onToggleSubscribe = onToggleSubscribe
                            )
                        }
                        Box(modifier = Modifier.weight(0.45f)) {
                            TrendingHashtagsCard(
                                hashtags = NexoraSeedData.trendingHashtags,
                                selectedHashtag = selectedHashtag,
                                onSelectHashtag = onSelectHashtag
                            )
                        }
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        TrendingCreatorsLeaderboardCard(
                            creators = displayedCreators,
                            subscribedCreatorIds = subscribedCreatorIds,
                            onCreatorClick = onCreatorClick,
                            onToggleSubscribe = onToggleSubscribe
                        )
                        TrendingHashtagsCard(
                            hashtags = NexoraSeedData.trendingHashtags,
                            selectedHashtag = selectedHashtag,
                            onSelectHashtag = onSelectHashtag
                        )
                    }
                }
            }

            // 1.5. Spatial Clips (9:16 Vertical Short Videos Rail from dedicated /_/s7a1 API)
            if (filteredShortVideos.isNotEmpty()) {
                item(key = "explore_spatial_clips_rail") {
                    SpatialClipsRail(
                        clips = filteredShortVideos,
                        onOpenClip = onOpenSpatialClip,
                        onCreatorClick = onCreatorClick
                    )
                }
            }

            // 2. Icon-Only Sort Selector Pills
            item(key = "explore_sort_row") {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.testTag("explore_sort_pills")
                ) {
                    items(ExploreSortMode.entries, key = { it.name }) { mode ->
                        val isSelected = mode == sortMode
                        val sortIcon = when (mode) {
                            ExploreSortMode.TRENDING -> Icons.Filled.LocalFireDepartment
                            ExploreSortMode.MOST_VIEWED -> Icons.Filled.Visibility
                            ExploreSortMode.NEWLY_PUBLISHED -> Icons.Filled.Schedule
                            ExploreSortMode.EDITORS_PICKS -> Icons.Filled.Star
                        }
                        Box(
                            modifier = Modifier
                                .size(width = 48.dp, height = 36.dp)
                                .then(
                                    if (isSelected) {
                                        Modifier.liquidGlassAccent(999.dp)
                                    } else {
                                        Modifier.liquidGlassWhitePill(999.dp)
                                    }
                                )
                                .clickable { onSelectSortMode(mode) }
                                .testTag("sort_pill_${mode.name.lowercase()}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = sortIcon,
                                contentDescription = mode.label,
                                tint = if (isSelected) NexoraColors.InkAccent else NexoraColors.InkSecondary,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                    }
                }
            }

            // 3. Curated Discovery Grid using Unified Aspect-Ratio Post Cards
            items(
                items = chunkedVideos,
                key = { row -> "exp_" + row.joinToString("_") { it.id } }
            ) { rowItems ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    rowItems.forEach { video ->
                        Box(modifier = Modifier.weight(1f)) {
                            NexoraVideoCard(
                                video = video,
                                isSaved = video.id in savedVideoIds,
                                onVideoClick = onVideoClick,
                                onCreatorClick = onCreatorClick,
                                onToggleSave = onToggleSave,
                                onShareClick = onShareVideo,
                                onToggleLike = onToggleLike,
                                onDoubleTapLike = onDoubleTapLike,
                                onToggleRepost = onToggleRepost,
                                onAddComment = onAddComment,
                                onToggleCommentLike = onToggleCommentLike,
                                onActionFeedback = onActionFeedback,
                                isMuted = isGlobalAudioMuted,
                                onToggleMute = onToggleMute
                            )
                        }
                    }
                    repeat(columns - rowItems.size) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }

            if (chunkedVideos.isEmpty() && filteredShortVideos.isEmpty() && q.isNotEmpty()) {
                item(key = "explore_empty_search_state") {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .liquidGlassCard(cornerRadius = 22.dp)
                            .padding(horizontal = 20.dp, vertical = 32.dp)
                            .testTag("explore_empty_search_state"),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "No results found for \"$q\"",
                            style = NexoraTypography.CardTitle.copy(
                                fontSize = 15.sp,
                                color = NexoraColors.InkPrimary
                            )
                        )
                        Text(
                            text = "Try searching for another video title, creator, or hashtag.",
                            style = NexoraTypography.MetaCaption.copy(
                                color = NexoraColors.InkSecondary
                            )
                        )
                    }
                }
            }
        }
    }
}
}

@Composable
private fun TrendingCreatorsLeaderboardCard(
    creators: List<CreatorProfile>,
    subscribedCreatorIds: Set<String>,
    onCreatorClick: (String) -> Unit,
    onToggleSubscribe: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .liquidGlassCard(cornerRadius = 24.dp)
            .padding(12.dp)
            .testTag("trending_creators_card"),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = Icons.Filled.TrendingUp,
            contentDescription = "Top Creators",
            tint = NexoraColors.Lavender500,
            modifier = Modifier.size(18.dp)
        )

        creators.forEach { creator ->
            val isSubscribed = creator.id in subscribedCreatorIds
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(NexoraColors.Pearl200)
                    .clickable { onCreatorClick(creator.id) }
                    .padding(horizontal = 10.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    CreatorAvatarBadge(
                        name = creator.name,
                        seed = creator.avatarSeed,
                        size = 32.dp,
                        showOnlineDot = creator.isOnline
                    )
                    Text(
                        text = creator.name,
                        style = NexoraTypography.NavPillLabel.copy(
                            fontWeight = FontWeight.Bold,
                            color = NexoraColors.InkPrimary
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    VerifiedBadge(size = 13.dp)
                }

                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .then(
                            if (isSubscribed) {
                                Modifier.liquidGlassAccent(999.dp)
                            } else {
                                Modifier.liquidGlassWhitePill(999.dp)
                            }
                        )
                        .clickable { onToggleSubscribe(creator.id) }
                        .testTag("leaderboard_follow_${creator.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isSubscribed) Icons.Filled.Check else Icons.Filled.PersonAdd,
                        contentDescription = if (isSubscribed) "Following" else "Follow",
                        tint = if (isSubscribed) NexoraColors.InkAccent else NexoraColors.InkSecondary,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TrendingHashtagsCard(
    hashtags: List<String>,
    selectedHashtag: String?,
    onSelectHashtag: (String?) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .liquidGlassCard(cornerRadius = 24.dp)
            .padding(12.dp)
            .testTag("trending_hashtags_card"),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = Icons.Filled.Tag,
            contentDescription = "Topics",
            tint = NexoraColors.InkSecondary,
            modifier = Modifier.size(17.dp)
        )
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            hashtags.forEach { tag ->
                val isSelected = tag.equals(selectedHashtag, ignoreCase = true)
                Box(
                    modifier = Modifier
                        .height(30.dp)
                        .then(
                            if (isSelected) {
                                Modifier.liquidGlassAccent(999.dp)
                            } else {
                                Modifier.liquidGlassWhitePill(999.dp)
                            }
                        )
                        .clickable { onSelectHashtag(tag) }
                        .padding(horizontal = 11.dp)
                        .testTag("hashtag_pill_${tag.removePrefix("#").lowercase()}"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tag,
                        style = NexoraTypography.BadgeMicro.copy(
                            color = if (isSelected) NexoraColors.InkAccent else NexoraColors.InkSecondary
                        )
                    )
                }
            }
        }
    }
}
