package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NexoraDarkColorScheme = darkColorScheme(
    primary = NexoraColors.ElectricIndigo,
    onPrimary = Color.White,
    primaryContainer = NexoraColors.Sky100,
    onPrimaryContainer = NexoraColors.InkPrimary,
    secondary = NexoraColors.Lavender500,
    onSecondary = Color.White,
    secondaryContainer = NexoraColors.Lavender200,
    onSecondaryContainer = NexoraColors.InkPrimary,
    tertiary = NexoraColors.InstagramSunsetAmber,
    background = NexoraColors.CanvasBase,
    onBackground = NexoraColors.InkPrimary,
    surface = NexoraColors.Pearl100,
    onSurface = NexoraColors.InkPrimary,
    surfaceVariant = NexoraColors.Pearl200,
    onSurfaceVariant = NexoraColors.InkSecondary,
    outline = NexoraColors.SpecularBorderStrong,
    outlineVariant = NexoraColors.SpecularBorderSubtle,
    error = NexoraColors.LiveRose,
    onError = Color.White
)

@Composable
fun NexoraTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = NexoraDarkColorScheme,
        typography = NexoraTypography.MaterialTypography,
        content = content
    )
}
