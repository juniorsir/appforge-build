package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.example.R

val PlusJakartaSansFamily = FontFamily(
    Font(R.font.plus_jakarta_sans, FontWeight.Normal),
    Font(R.font.plus_jakarta_sans, FontWeight.Medium),
    Font(R.font.plus_jakarta_sans, FontWeight.SemiBold),
    Font(R.font.plus_jakarta_sans, FontWeight.Bold),
    Font(R.font.plus_jakarta_sans, FontWeight.ExtraBold)
)

val InterFamily = FontFamily(
    Font(R.font.inter, FontWeight.Normal),
    Font(R.font.inter, FontWeight.Medium),
    Font(R.font.inter, FontWeight.SemiBold),
    Font(R.font.inter, FontWeight.Bold),
    Font(R.font.inter, FontWeight.ExtraBold)
)

val GrandHotelFamily = FontFamily(
    Font(R.font.grand_hotel, FontWeight.Normal)
)

object NexoraTypography {
    // 1. Display & Headings (Plus Jakarta Sans)
    val HeroDisplay = TextStyle(
        fontFamily = PlusJakartaSansFamily,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 32.sp,
        lineHeight = 38.sp,
        letterSpacing = (-0.025).em,
        color = NexoraColors.InkPrimary
    )

    val HeroDisplayMobile = TextStyle(
        fontFamily = PlusJakartaSansFamily,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 24.sp,
        lineHeight = 30.sp,
        letterSpacing = (-0.025).em,
        color = NexoraColors.InkPrimary
    )

    val SectionTitle = TextStyle(
        fontFamily = PlusJakartaSansFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
        lineHeight = 26.sp,
        letterSpacing = (-0.02).em,
        color = NexoraColors.InkPrimary
    )

    val CardTitle = TextStyle(
        fontFamily = PlusJakartaSansFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 15.sp,
        lineHeight = 20.sp,
        letterSpacing = (-0.015).em,
        color = NexoraColors.InkPrimary
    )

    // 2. UI Controls, Body & Numeric Telemetry (Inter)
    val NavPillLabel = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        letterSpacing = (-0.01).em,
        color = NexoraColors.InkSecondary
    )

    val BodyRegular = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 21.sp,
        color = NexoraColors.InkBody
    )

    val MetaCaption = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        fontFeatureSettings = "tnum",
        color = NexoraColors.InkMuted
    )

    val CreatorSubtitle = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 12.5.sp,
        lineHeight = 17.sp,
        fontFeatureSettings = "tnum",
        color = NexoraColors.InkSecondary
    )

    val BadgeMicro = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        lineHeight = 14.sp,
        letterSpacing = 0.02.em,
        fontFeatureSettings = "tnum",
        color = NexoraColors.InkAccent
    )

    val TelemetryValue = TextStyle(
        fontFamily = InterFamily,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 22.sp,
        lineHeight = 28.sp,
        fontFeatureSettings = "tnum",
        color = NexoraColors.InkPrimary
    )

    val MaterialTypography = Typography(
        displayLarge = HeroDisplay,
        displayMedium = HeroDisplayMobile,
        headlineMedium = SectionTitle,
        titleMedium = CardTitle,
        bodyLarge = BodyRegular,
        bodyMedium = BodyRegular,
        labelLarge = NavPillLabel,
        labelMedium = MetaCaption,
        labelSmall = BadgeMicro
    )
}
