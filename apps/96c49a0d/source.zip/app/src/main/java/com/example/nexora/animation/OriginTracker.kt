package com.example.nexora.animation

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.example.ui.theme.NexoraColors

/**
 * Root wrapper that intercepts pointer down coordinates in the Initial pass
 * (before button onClick handlers run) and draws the 440ms tactile specular
 * bubble ring whenever a transition trigger occurs.
 */
@Composable
fun OriginTrackerBox(
    activeOrigin: ClickOrigin,
    onPointerDownCapture: (ClickOrigin) -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable (viewportSize: IntSize) -> Unit
) {
    var viewportSize by remember { mutableStateOf(IntSize(1080, 2400)) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .onSizeChanged { size ->
                if (size.width > 0 && size.height > 0) {
                    viewportSize = size
                }
            }
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        val firstDown = event.changes.firstOrNull { it.pressed && !it.previousPressed }
                        if (firstDown != null) {
                            val pos = firstDown.position
                            val captured = ClickOrigin.fromRootCoordinates(
                                x = pos.x,
                                y = pos.y,
                                viewportWidth = size.width.toFloat(),
                                viewportHeight = size.height.toFloat(),
                                timestamp = System.currentTimeMillis()
                            )
                            onPointerDownCapture(captured)
                        }
                    }
                }
            }
    ) {
        content(viewportSize)
        BubbleClickRippleOverlay(origin = activeOrigin)
    }
}

/**
 * Tactile Specular Bubble Ring on Click:
 * Whenever the user taps a button that triggers a transition, spawns a 440ms
 * GPU-drawn expanding specular ring centered at (O_x, O_y):
 * - Radius animates from 6.dp to 120.dp with cubic-bezier ease-out.
 * - Alpha animates from 0.75f to 0f.
 * - Drawn with a radial gradient stroke (Lavender400 -> Sky300 -> White).
 */
@Composable
fun BubbleClickRippleOverlay(
    origin: ClickOrigin,
    modifier: Modifier = Modifier
) {
    val rippleProgress = remember { Animatable(1f) }
    val easeOutCubic = remember { CubicBezierEasing(0.16f, 1f, 0.3f, 1f) }

    LaunchedEffect(origin.timestamp) {
        if (origin.timestamp > 0L) {
            rippleProgress.snapTo(0f)
            rippleProgress.animateTo(
                targetValue = 1f,
                animationSpec = tween(
                    durationMillis = 440,
                    easing = easeOutCubic
                )
            )
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val p = rippleProgress.value
        if (p < 0.995f && origin.timestamp > 0L) {
            val minRadiusPx = 6.dp.toPx()
            val maxRadiusPx = 120.dp.toPx()
            val currentRadius = minRadiusPx + (maxRadiusPx - minRadiusPx) * p
            val currentAlpha = (0.75f * (1f - p)).coerceIn(0f, 0.75f)
            val centerOffset = Offset(origin.x, origin.y)

            val strokeBrush = Brush.radialGradient(
                colors = listOf(
                    NexoraColors.Lavender400.copy(alpha = currentAlpha),
                    NexoraColors.Sky300.copy(alpha = currentAlpha * 0.9f),
                    Color.White.copy(alpha = currentAlpha)
                ),
                center = centerOffset,
                radius = currentRadius.coerceAtLeast(10f)
            )

            drawCircle(
                brush = strokeBrush,
                radius = currentRadius,
                center = centerOffset,
                style = Stroke(width = (3.5f * (1f - p * 0.55f)).dp.toPx())
            )

            // Inner soft iridescent core pulse
            drawCircle(
                color = Color.White.copy(alpha = currentAlpha * 0.35f),
                radius = currentRadius * 0.45f,
                center = centerOffset
            )
        }
    }
}
