package com.example.nexora.data

enum class NavTab(val label: String) {
    HOME("Home"),
    EXPLORE("Explore"),
    LIVE("Live"),
    MESSAGES("Messages"),
    LIBRARY("Library"),
    PROFILE("Profile")
}

enum class ExploreSortMode(val label: String) {
    TRENDING("Trending Now"),
    MOST_VIEWED("Most Viewed"),
    NEWLY_PUBLISHED("Newly Published"),
    EDITORS_PICKS("Editor's Picks")
}

enum class LibrarySubTab(val label: String) {
    SAVED_VIDEOS("Saved Videos"),
    WATCH_HISTORY("Watch History"),
    CUSTOM_PLAYLISTS("Custom Playlists"),
    SUBSCRIBED_STUDIOS("Subscribed Studios")
}

enum class ProfileSubTab(val label: String) {
    OVERVIEW("Reels"),
    SAVED_REELS("Saved Reels"),
    LIKED_REELS("Liked Reels")
}

enum class VisualThemePreset(val label: String) {
    NORDIC_PAVILION("Nordic Glass Pavilion"),
    CYBER_LIGHTFIELD("Cybernetic Light Field"),
    FJORD_AURORA("Bioluminescent Fjord"),
    ANALOG_SYNTH("Analog Modular Synth"),
    BRUTALIST_MONOLITH("Brutalist Water Monolith"),
    ORBITAL_RING("Orbital Dyson Horizon"),
    KYOTO_COURTYARD("Minimalist Kyoto Rain"),
    CLOUD_ATRIUM("Volumetric Cloud Atrium")
}

data class VideoComment(
    val id: String,
    val authorName: String,
    val authorHandle: String,
    val avatarSeed: Int,
    val text: String,
    val timestamp: String,
    val likes: Int,
    val isLiked: Boolean = false,
    val avatarUrl: String? = null,
    val isDeletable: Boolean = false
)

data class CreatorProfile(
    val id: String,
    val name: String,
    val handle: String,
    val category: String,
    val bio: String,
    val fullBiography: String,
    val equipmentSpecs: List<String>,
    val location: String,
    val country: String = "United States",
    val website: String,
    val subscribersText: String,
    val totalViewsText: String,
    val publishedWorksCount: Int,
    val postsCount: Int = 142,
    val followersCount: String = "14.2K",
    val followingCount: String = "892",
    val memberSince: String,
    val growthPercent: String,
    val isOnline: Boolean = true,
    val isVerified: Boolean = true,
    val isPremium: Boolean = true,
    val avatarSeed: Int = 0,
    val avatarUrl: String? = null,
    val bannerPreset: VisualThemePreset = VisualThemePreset.NORDIC_PAVILION
)

data class VideoItem(
    val id: String,
    val title: String,
    val description: String,
    val creatorId: String,
    val creatorName: String,
    val creatorHandle: String,
    val creatorAvatarSeed: Int,
    val creatorAvatarUrl: String? = null,
    val viewsText: String,
    val rawViews: Long,
    val relativeTime: String,
    val duration: String,
    val durationSeconds: Int,
    val category: String,
    val hashtags: List<String>,
    val topBadge: String? = "4K HDR",
    val isFeaturedPremiere: Boolean = false,
    val isEditorsPick: Boolean = false,
    val isLiveStream: Boolean = false,
    val liveCategory: String = "3D & Design",
    val concurrentViewers: Int = 0,
    val visualPreset: VisualThemePreset = VisualThemePreset.NORDIC_PAVILION,
    val carouselSlides: List<VisualThemePreset> = emptyList(),
    val previewProgress: Float = 0.35f,
    val likesCount: Int = 0,
    val isLiked: Boolean = false,
    val isReposted: Boolean = false,
    val repostsCount: Int = 0,
    val comments: List<VideoComment> = emptyList(),
    val aspectRatio: Float = 16f / 9f,
    val musicTrack: String = "Original Spatial Audio · 7.1.4 Ambisonic",
    val fileCode: String? = null,
    val mediaType: String = "long_video", // "short" or "long_video"
    val thumbnailUrl: String? = null,
    val streamUrl: String? = null,
    val directStreamUrl: String? = null,
    val adaptiveStreamUrl: String? = streamUrl,
    val highestQualityStreamUrl: String? = directStreamUrl ?: streamUrl,
    val simulatedViews: Long = rawViews.coerceAtLeast(0L),
    val formattedViews: String = if (viewsText.isNotBlank()) {
        viewsText
    } else {
        com.example.nexora.network.AkashMediaService.formatViewsCount(rawViews.coerceAtLeast(0L), id)
    },
    val uploadedAt: String = "",
    val qualityMode: String = "single_toggle",
    val hasHighestQualityToggle: Boolean = true,
    val availableQualities: List<String> = emptyList(),
    val qualityStreams: Map<String, String> = emptyMap(),
    val rawDurationSeconds: Double = durationSeconds.toDouble()
) {
    val isShortVideo: Boolean
        get() = mediaType.equals("short", ignoreCase = true) || aspectRatio < 1.0f

    val isPhotoPost: Boolean
        get() = mediaType.equals("photo", ignoreCase = true) ||
            mediaType.equals("image", ignoreCase = true) ||
            (fileCode.isNullOrBlank() && streamUrl.isNullOrBlank() && (carouselSlides.size > 1 || durationSeconds <= 0))

    val isVideoPost: Boolean
        get() = !isPhotoPost && !isLiveStream

    val effectiveFileCode: String
        get() = fileCode?.takeIf { it.isNotBlank() } ?: id

    val effectiveThumbnailUrl: String?
        get() = thumbnailUrl?.takeIf { it.isNotBlank() }
            ?: fileCode?.takeIf { it.isNotBlank() }?.let { "https://akashbox.duckdns.org/_/t9b2c4/$it" }

    val effectiveAdaptiveStreamUrl: String
        get() {
            val code = effectiveFileCode
            return adaptiveStreamUrl?.takeIf { it.isNotBlank() }?.let { com.example.nexora.network.AkashMediaService.ensureStreamToken(it) }
                ?: streamUrl?.takeIf { it.isNotBlank() }?.let { com.example.nexora.network.AkashMediaService.ensureStreamToken(it) }
                ?: com.example.nexora.network.AkashMediaService.adaptiveHlsStreamUrl(code)
        }

    val effectiveHighestQualityStreamUrl: String
        get() {
            val code = effectiveFileCode
            return highestQualityStreamUrl?.takeIf { it.isNotBlank() }?.let { com.example.nexora.network.AkashMediaService.ensureStreamToken(it) }
                ?: directStreamUrl?.takeIf { it.isNotBlank() }?.let { com.example.nexora.network.AkashMediaService.ensureStreamToken(it) }
                ?: com.example.nexora.network.AkashMediaService.highestQualityStreamUrl(code)
        }

    val formattedCreatorHandle: String
        get() {
            val sanitizedHandle = com.example.nexora.network.AkashMediaService.cleanEmojis(creatorHandle)
            val sanitizedName = com.example.nexora.network.AkashMediaService.cleanEmojis(creatorName)
            val clean = sanitizedHandle.trim().ifBlank { sanitizedName.trim().lowercase().replace(" ", "_") }
            return if (clean.startsWith("@")) clean else "@$clean"
        }

    val cleanTitle: String
        get() = com.example.nexora.network.AkashMediaService.cleanEmojis(title).ifBlank { "Untitled Video" }

    val cleanCreatorName: String
        get() = com.example.nexora.network.AkashMediaService.cleanEmojis(creatorName).ifBlank { "Creator" }

    val effectiveCreatorAvatarUrl: String
        get() = creatorAvatarUrl?.takeIf { it.isNotBlank() }
            ?: run {
                val handleKey = formattedCreatorHandle.removePrefix("@").lowercase()
                val imgIdx = ((handleKey.hashCode().ushr(1) + creatorAvatarSeed) % 68) + 1
                "https://i.pravatar.cc/150?img=$imgIdx"
            }
}

fun formatCatalogDuration(durationSec: Double): String {
    if (durationSec <= 0.0 || durationSec.isNaN()) return "0:00"
    val totalSeconds = kotlin.math.round(durationSec).toInt().coerceAtLeast(1)
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        String.format(java.util.Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format(java.util.Locale.US, "%d:%02d", minutes, seconds)
    }
}

data class SpatialPulseSlide(
    val id: String,
    val caption: String,
    val preset: VisualThemePreset,
    val timestamp: String
)

data class SpatialPulseStory(
    val id: String,
    val creatorId: String,
    val creatorName: String,
    val creatorHandle: String,
    val avatarSeed: Int,
    val slides: List<SpatialPulseSlide>,
    val isViewed: Boolean = false
)

data class DirectChatMessage(
    val id: String,
    val senderId: String,
    val senderName: String,
    val text: String,
    val timestamp: String,
    val isFromMe: Boolean,
    val sharedPreset: VisualThemePreset? = null
)

data class DirectMessageThread(
    val creatorId: String,
    val creatorName: String,
    val creatorHandle: String,
    val avatarSeed: Int,
    val isOnline: Boolean,
    val unreadCount: Int,
    val messages: List<DirectChatMessage>,
    val hasMissedCall: Boolean = false
)

data class CuratedCollection(
    val id: String,
    val title: String,
    val description: String,
    val creatorId: String,
    val episodeCount: Int,
    val visualPreset: VisualThemePreset,
    val videoIds: List<String>
)

data class Playlist(
    val id: String,
    val title: String,
    val description: String,
    val isPublic: Boolean,
    val videoIds: List<String>,
    val createdAt: Long = System.currentTimeMillis()
)

data class ChatMessage(
    val id: String,
    val username: String,
    val avatarSeed: Int,
    val badge: String? = null, // "MOD", "SUB", "VIP"
    val message: String,
    val timestamp: String
)

data class NotificationItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val timestamp: String,
    val isUnread: Boolean,
    val relatedVideoId: String? = null,
    val relatedCreatorId: String? = null
)

data class FlaggedContentItem(
    val id: String,
    val videoTitle: String,
    val creatorName: String,
    val reason: String,
    val confidenceScore: String,
    val status: String = "Pending Review"
)

object NexoraSeedData {
    val categories = listOf(
        "For You", "Movies", "Series", "Music", "Gaming",
        "Learning", "Travel", "Nature", "Architecture", "Sci-Fi"
    )

    val trendingHashtags = listOf(
        "#SpatialComputing",
        "#NordicLight",
        "#UnrealEngine5",
        "#AnalogSynth",
        "#MinimalistLiving",
        "#AtmosphericCinema"
    )

    val liveCategories = listOf(
        "All Live", "3D & Design", "Music Sessions", "Game Dev", "IRL & Travel"
    )

    val creators = listOf(
        CreatorProfile(
            id = "creator_aether",
            name = "Aether Visuals",
            handle = "@aethervisuals",
            category = "Spatial Design & Cinema",
            bio = "Architectural light fields, Nordic glass pavilions, and 8K spatial cinema captured in pure natural acoustics.",
            fullBiography = "Founded in Zurich, Aether Visuals explores the quiet intersection of Nordic glass architecture, volumetric atmospheric lighting, and spatial soundscapes. Every piece is mastered in 4K 60fps HDR with binaural ambisonic audio to bring tranquil architectural spaces into living rooms and spatial headsets worldwide.",
            equipmentSpecs = listOf(
                "RED V-Raptor XL 8K VV + Panavision Primo 70 Anamorphic",
                "Sennheiser AMBEO VR Spatial Microphone Array",
                "Custom Unreal Engine 5.5 Path-Tracing & DaVinci Resolve HDR Pipeline",
                "Dolby Atmos 7.1.4 Mastering Suite (Zurich Studio)"
            ),
            location = "Zurich, Switzerland",
            website = "aethervisuals.studio",
            subscribersText = "184.2K",
            totalViewsText = "14.8M",
            publishedWorksCount = 42,
            memberSince = "Oct 2022",
            growthPercent = "+18.4%",
            isOnline = true,
            isVerified = true,
            avatarSeed = 1,
            bannerPreset = VisualThemePreset.NORDIC_PAVILION
        ),
        CreatorProfile(
            id = "creator_kurogane",
            name = "Kurogane Studio",
            handle = "@kuroganestudio",
            category = "Real-Time 3D & Sci-Fi",
            bio = "Procedural megastructures, Unreal Engine 5 path-tracing showcases, and futuristic industrial design.",
            fullBiography = "Kurogane Studio is a Tokyo-based real-time visual collective building futuristic orbital environments, procedural shaders, and interactive sci-fi short films powered by Unreal Engine 5 and Houdini.",
            equipmentSpecs = listOf(
                "Dual NVIDIA RTX 6000 Ada Workstation Cluster",
                "Houdini FX 20.5 + Unreal Engine 5.5 Lumen & Nanite",
                "Sony Venice 2 Digital Cinema Camera"
            ),
            location = "Tokyo, Japan",
            website = "kurogane.design",
            subscribersText = "312.5K",
            totalViewsText = "28.4M",
            publishedWorksCount = 67,
            memberSince = "Jan 2022",
            growthPercent = "+14.2%",
            isOnline = true,
            isVerified = true,
            avatarSeed = 2,
            bannerPreset = VisualThemePreset.ORBITAL_RING
        ),
        CreatorProfile(
            id = "creator_vespera",
            name = "Vespera Sound",
            handle = "@vesperasound",
            category = "Analog Synth & Acoustics",
            bio = "Late-night Buchla & Eurorack modular performances filmed inside resonant architectural chambers.",
            fullBiography = "Vespera Sound crafts hypnotic polyrhythmic modular synthesizer performances inside acoustic glass conservatories and alpine chapels across Northern Europe.",
            equipmentSpecs = listOf(
                "Buchla 200e & Custom 18U Eurorack Modular System",
                "Neumann KU 100 Binaural Head Microphone",
                "ARRI Alexa Mini LF + Atlas Orion Anamorphics"
            ),
            location = "Reykjavik, Iceland",
            website = "vesperasound.fm",
            subscribersText = "146.9K",
            totalViewsText = "9.6M",
            publishedWorksCount = 31,
            memberSince = "May 2023",
            growthPercent = "+12.8%",
            isOnline = true,
            isVerified = true,
            avatarSeed = 3,
            bannerPreset = VisualThemePreset.ANALOG_SYNTH
        ),
        CreatorProfile(
            id = "creator_lumina",
            name = "Lumina Labs",
            handle = "@luminalabs",
            category = "Spatial Computing & UI",
            bio = "Fluid physics, glassmorphic shader math, and next-gen human-computer interaction prototypes.",
            fullBiography = "Lumina Labs researches tactile spatial interfaces, homothety geometry, and real-time optical refraction shaders for next-generation mobile and spatial operating systems.",
            equipmentSpecs = listOf(
                "Custom Kotlin & AGSL / Metal Shader Pipeline",
                "120Hz Reference OLED Mastering Monitors",
                "High-Speed Phantom Flex4K Macro Rig"
            ),
            location = "Stockholm, Sweden",
            website = "luminalabs.io",
            subscribersText = "98.4K",
            totalViewsText = "6.2M",
            publishedWorksCount = 29,
            memberSince = "Aug 2023",
            growthPercent = "+21.6%",
            isOnline = true,
            isVerified = true,
            avatarSeed = 4,
            bannerPreset = VisualThemePreset.CYBER_LIGHTFIELD
        ),
        CreatorProfile(
            id = "creator_sora",
            name = "Sora Borealis",
            handle = "@soraborealis",
            category = "Nordic Nature & Travel",
            bio = "Silent aerial expeditions over Lofoten fjords, glacial ice caves, and minimalist Kyoto gardens.",
            fullBiography = "Capturing Earth's quietest sanctuaries in uncompressed 4K HDR. Sora Borealis blends custom low-noise cine-lifter drones with long-take contemplative cinematography.",
            equipmentSpecs = listOf(
                "Custom Heavy-Lift Octocopter + DJI Ronin 4D 8K",
                "Leica Summilux-C Prime Lenses",
                "Zoom F8n Pro Field Recorder + Hydrophones"
            ),
            location = "Tromsø, Norway",
            website = "soraborealis.earth",
            subscribersText = "229.0K",
            totalViewsText = "19.1M",
            publishedWorksCount = 54,
            memberSince = "Nov 2021",
            growthPercent = "+10.9%",
            isOnline = false,
            isVerified = true,
            avatarSeed = 5,
            bannerPreset = VisualThemePreset.FJORD_AURORA
        )
    )

    private val defaultComments = listOf(
        VideoComment(
            id = "c1",
            authorName = "Lumina Labs",
            authorHandle = "@luminalabs",
            avatarSeed = 4,
            text = "The refraction caustic transitions across the cantilevered glass atrium at 06:14 are breathtaking. Pure spatial reference material.",
            timestamp = "2 hours ago",
            likes = 342
        ),
        VideoComment(
            id = "c2",
            authorName = "Kurogane Studio",
            authorHandle = "@kuroganestudio",
            avatarSeed = 2,
            text = "Incredible dynamic range in the highlights and twilight reflections. Listening on studio monitors and the binaural rain layer feels completely real.",
            timestamp = "5 hours ago",
            likes = 189
        ),
        VideoComment(
            id = "c3",
            authorName = "Elena Rostova",
            authorHandle = "@elena_arch",
            avatarSeed = 6,
            text = "Saved this directly to my Spatial Reference playlist. The concentric pacing and typography overlays set a whole new bar.",
            timestamp = "1 day ago",
            likes = 94
        )
    )

    val initialVideos = listOf(
        VideoItem(
            id = "vid_nordic_glass",
            title = "Echoes of Silent Architecture: Nordic Glass Pavilions",
            description = "An immersive 4K 60fps spatial journey through cantilevered glass pavilions nestled across the Norwegian fjords and Swiss Alps, exploring how natural twilight refracts through structural minimalism.",
            creatorId = "creator_aether",
            creatorName = "Aether Visuals",
            creatorHandle = "@aethervisuals",
            creatorAvatarSeed = 1,
            viewsText = "142K views",
            rawViews = 142000L,
            relativeTime = "2d ago",
            duration = "18:42",
            durationSeconds = 1122,
            category = "Architecture",
            hashtags = listOf("#NordicLight", "#MinimalistLiving", "#SpatialComputing", "#AtmosphericCinema"),
            topBadge = "4K HDR",
            isFeaturedPremiere = true,
            isEditorsPick = true,
            visualPreset = VisualThemePreset.NORDIC_PAVILION,
            carouselSlides = listOf(
                VisualThemePreset.NORDIC_PAVILION,
                VisualThemePreset.CLOUD_ATRIUM,
                VisualThemePreset.BRUTALIST_MONOLITH
            ),
            previewProgress = 0.34f,
            likesCount = 18420,
            comments = defaultComments,
            aspectRatio = 16f / 9f,
            musicTrack = "Aether Visuals · Fjord Twilight (7.1.4 Binaural)"
        ),
        VideoItem(
            id = "vid_orbital_dyson",
            title = "Helios Ring: Procedural Megastructures in Unreal Engine 5.5",
            description = "Real-time Lumen and Nanite path-traced exploration of an orbital solar collector ring suspended above a pale cerulean gas giant.",
            creatorId = "creator_kurogane",
            creatorName = "Kurogane Studio",
            creatorHandle = "@kuroganestudio",
            creatorAvatarSeed = 2,
            viewsText = "289K views",
            rawViews = 289000L,
            relativeTime = "4d ago",
            duration = "24:15",
            durationSeconds = 1455,
            category = "Sci-Fi",
            hashtags = listOf("#UnrealEngine5", "#SpatialComputing", "#AtmosphericCinema"),
            topBadge = "4K HDR",
            isEditorsPick = true,
            visualPreset = VisualThemePreset.ORBITAL_RING,
            carouselSlides = listOf(
                VisualThemePreset.ORBITAL_RING,
                VisualThemePreset.CYBER_LIGHTFIELD
            ),
            previewProgress = 0.62f,
            likesCount = 29400,
            comments = defaultComments,
            aspectRatio = 4f / 5f,
            musicTrack = "Kurogane Soundworks · Helios Sub-Orbital Pulse"
        ),
        VideoItem(
            id = "vid_buchla_conservatory",
            title = "Glass Harmonics: Live Modular Synth in an Alpine Conservatory",
            description = "Performed live at dawn inside a frosted botanical conservatory using a custom Buchla 200e system and acoustic tape loops.",
            creatorId = "creator_vespera",
            creatorName = "Vespera Sound",
            creatorHandle = "@vesperasound",
            creatorAvatarSeed = 3,
            viewsText = "96K views",
            rawViews = 96000L,
            relativeTime = "18h ago",
            duration = "41:08",
            durationSeconds = 2468,
            category = "Music",
            hashtags = listOf("#AnalogSynth", "#NordicLight", "#AtmosphericCinema"),
            topBadge = "NEW",
            isEditorsPick = true,
            visualPreset = VisualThemePreset.ANALOG_SYNTH,
            previewProgress = 0.45f,
            likesCount = 11200,
            comments = defaultComments,
            aspectRatio = 1f / 1f,
            musicTrack = "Vespera Sound · Buchla 200e Tape Harmonics (Live)"
        ),
        VideoItem(
            id = "vid_liquid_glass_math",
            title = "Designing Concentric Liquid Glass & Homothety Bubble Physics",
            description = "Deep dive into the mathematical foundations of concentric curvature, critically damped springs, and GPU shader refraction for modern spatial UI.",
            creatorId = "creator_lumina",
            creatorName = "Lumina Labs",
            creatorHandle = "@luminalabs",
            creatorAvatarSeed = 4,
            viewsText = "178K views",
            rawViews = 178000L,
            relativeTime = "1w ago",
            duration = "15:30",
            durationSeconds = 930,
            category = "Learning",
            hashtags = listOf("#SpatialComputing", "#MinimalistLiving"),
            topBadge = "4K HDR",
            isEditorsPick = true,
            visualPreset = VisualThemePreset.CYBER_LIGHTFIELD,
            previewProgress = 0.78f,
            likesCount = 24100,
            comments = defaultComments,
            aspectRatio = 16f / 10f,
            musicTrack = "Lumina Labs · Crystalline UI Resonance"
        ),
        VideoItem(
            id = "vid_lofoten_aurora",
            title = "Silent Latitude 68°N: Bioluminescent Fjords & Arctic Twilight",
            description = "Uncompressed aerial cinema gliding across mirror-still Lofoten waters under pastel violet and cyan polar airglow.",
            creatorId = "creator_sora",
            creatorName = "Sora Borealis",
            creatorHandle = "@soraborealis",
            creatorAvatarSeed = 5,
            viewsText = "412K views",
            rawViews = 412000L,
            relativeTime = "3w ago",
            duration = "32:50",
            durationSeconds = 1970,
            category = "Nature",
            hashtags = listOf("#NordicLight", "#AtmosphericCinema"),
            topBadge = "4K HDR",
            isEditorsPick = false,
            visualPreset = VisualThemePreset.FJORD_AURORA,
            carouselSlides = listOf(
                VisualThemePreset.FJORD_AURORA,
                VisualThemePreset.KYOTO_COURTYARD,
                VisualThemePreset.NORDIC_PAVILION
            ),
            previewProgress = 0.25f,
            likesCount = 38900,
            comments = defaultComments,
            aspectRatio = 4f / 5f,
            musicTrack = "Sora Borealis · Arctic Hydrophone & Wind Study"
        ),
        VideoItem(
            id = "vid_brutalist_water",
            title = "Monolith & Mist: Tadao Ando's Water Temple in Early Spring",
            description = "A study of board-formed architectural concrete, lotus reflection pools, and subterranean geometry in Awaji Island.",
            creatorId = "creator_aether",
            creatorName = "Aether Visuals",
            creatorHandle = "@aethervisuals",
            creatorAvatarSeed = 1,
            viewsText = "205K views",
            rawViews = 205000L,
            relativeTime = "2w ago",
            duration = "21:19",
            durationSeconds = 1279,
            category = "Travel",
            hashtags = listOf("#MinimalistLiving", "#AtmosphericCinema"),
            topBadge = "4K HDR",
            isEditorsPick = true,
            visualPreset = VisualThemePreset.BRUTALIST_MONOLITH,
            previewProgress = 0.52f,
            likesCount = 19300,
            comments = defaultComments,
            aspectRatio = 16f / 9f,
            musicTrack = "Aether Visuals · Awaji Subterranean Water Echoes"
        ),
        VideoItem(
            id = "vid_kyoto_courtyard",
            title = "Moss & Cedar: 60 Minutes of Spatial Rain in a Kyoto Machiya",
            description = "Recorded with an ambisonic sphere array inside a 140-year-old cedar courtyard in Higashiyama during a gentle afternoon shower.",
            creatorId = "creator_sora",
            creatorName = "Sora Borealis",
            creatorHandle = "@soraborealis",
            creatorAvatarSeed = 5,
            viewsText = "330K views",
            rawViews = 330000L,
            relativeTime = "1mo ago",
            duration = "58:00",
            durationSeconds = 3480,
            category = "Movies",
            hashtags = listOf("#MinimalistLiving", "#AtmosphericCinema"),
            topBadge = "4K HDR",
            isEditorsPick = false,
            visualPreset = VisualThemePreset.KYOTO_COURTYARD,
            previewProgress = 0.19f,
            likesCount = 31500,
            comments = defaultComments,
            aspectRatio = 1f / 1f,
            musicTrack = "Sora Borealis · Higashiyama Cedar Rain (Ambisonic)"
        ),
        VideoItem(
            id = "vid_cloud_atrium",
            title = "Chronicles of Aether Ep. 4: The Floating Cloud Observatory",
            description = "Episode 4 of our spatial anthology series exploring speculative climate-positive sky habitats suspended at 4,000 meters.",
            creatorId = "creator_aether",
            creatorName = "Aether Visuals",
            creatorHandle = "@aethervisuals",
            creatorAvatarSeed = 1,
            viewsText = "118K views",
            rawViews = 118000L,
            relativeTime = "5d ago",
            duration = "27:44",
            durationSeconds = 1664,
            category = "Series",
            hashtags = listOf("#SpatialComputing", "#NordicLight", "#UnrealEngine5"),
            topBadge = "NEW",
            isEditorsPick = true,
            visualPreset = VisualThemePreset.CLOUD_ATRIUM,
            previewProgress = 0.67f,
            likesCount = 15600,
            comments = defaultComments,
            aspectRatio = 16f / 9f,
            musicTrack = "Aether Visuals · Stratosphere Glass Ensemble"
        ),
        VideoItem(
            id = "vid_shader_combat",
            title = "Starlight Protocol: Building a 120FPS Ray-Traced Space Sim",
            description = "Behind the scenes of our custom Vulkan & Unreal Engine 5 orbital flight physics and volumetric nebula rendering pipeline.",
            creatorId = "creator_kurogane",
            creatorName = "Kurogane Studio",
            creatorHandle = "@kuroganestudio",
            creatorAvatarSeed = 2,
            viewsText = "164K views",
            rawViews = 164000L,
            relativeTime = "6d ago",
            duration = "19:55",
            durationSeconds = 1195,
            category = "Gaming",
            hashtags = listOf("#UnrealEngine5", "#SpatialComputing"),
            topBadge = "4K HDR",
            isEditorsPick = false,
            visualPreset = VisualThemePreset.ORBITAL_RING,
            previewProgress = 0.41f,
            likesCount = 17800,
            comments = defaultComments,
            aspectRatio = 16f / 10f,
            musicTrack = "Kurogane Soundworks · Vulkan Orbital Drive"
        ),
        // Live Stream Channels
        VideoItem(
            id = "live_aether_studio",
            title = "LIVE: Color Grading & Spatial Audio Mixing — Alpine Glass House III",
            description = "Join our Zurich mastering suite live as we grade 8K RAW plates from our winter expedition in Davos and sculpt the 7.1.4 ambient bed.",
            creatorId = "creator_aether",
            creatorName = "Aether Visuals",
            creatorHandle = "@aethervisuals",
            creatorAvatarSeed = 1,
            viewsText = "18.4K watching",
            rawViews = 18420L,
            relativeTime = "LIVE NOW",
            duration = "02:14:08",
            durationSeconds = 8048,
            category = "Architecture",
            hashtags = listOf("#NordicLight", "#SpatialComputing"),
            topBadge = "LIVE",
            isLiveStream = true,
            liveCategory = "3D & Design",
            concurrentViewers = 18420,
            visualPreset = VisualThemePreset.NORDIC_PAVILION,
            previewProgress = 1.0f,
            likesCount = 9420,
            comments = defaultComments
        ),
        VideoItem(
            id = "live_vespera_synth",
            title = "LIVE: Midnight Sub-Harmonic Patch Session (Buchla 200e + Tape)",
            description = "Improvised ambient modular synthesis transmitted in lossless stereo from Reykjavik.",
            creatorId = "creator_vespera",
            creatorName = "Vespera Sound",
            creatorHandle = "@vesperasound",
            creatorAvatarSeed = 3,
            viewsText = "6.8K watching",
            rawViews = 6840L,
            relativeTime = "LIVE NOW",
            duration = "01:42:19",
            durationSeconds = 6139,
            category = "Music",
            hashtags = listOf("#AnalogSynth"),
            topBadge = "LIVE",
            isLiveStream = true,
            liveCategory = "Music Sessions",
            concurrentViewers = 6840,
            visualPreset = VisualThemePreset.ANALOG_SYNTH,
            previewProgress = 1.0f
        ),
        VideoItem(
            id = "live_kurogane_ue5",
            title = "LIVE: Procedural Cyberpunk Megacity Shader Coding in UE 5.5",
            description = "Writing custom HLSL rain-ripple and neon glass refraction materials from scratch.",
            creatorId = "creator_kurogane",
            creatorName = "Kurogane Studio",
            creatorHandle = "@kuroganestudio",
            creatorAvatarSeed = 2,
            viewsText = "11.2K watching",
            rawViews = 11250L,
            relativeTime = "LIVE NOW",
            duration = "03:05:44",
            durationSeconds = 11144,
            category = "Gaming",
            hashtags = listOf("#UnrealEngine5", "#SpatialComputing"),
            topBadge = "LIVE",
            isLiveStream = true,
            liveCategory = "Game Dev",
            concurrentViewers = 11250,
            visualPreset = VisualThemePreset.CYBER_LIGHTFIELD,
            previewProgress = 1.0f
        ),
        VideoItem(
            id = "live_sora_expedition",
            title = "LIVE: Dawn Drone Reconnaissance — Abisko Polar Sky Station",
            description = "Live telemetry feed from our Arctic camp overlooking Torneträsk.",
            creatorId = "creator_sora",
            creatorName = "Sora Borealis",
            creatorHandle = "@soraborealis",
            creatorAvatarSeed = 5,
            viewsText = "4.9K watching",
            rawViews = 4910L,
            relativeTime = "LIVE NOW",
            duration = "00:54:12",
            durationSeconds = 3252,
            category = "Travel",
            hashtags = listOf("#NordicLight", "#AtmosphericCinema"),
            topBadge = "LIVE",
            isLiveStream = true,
            liveCategory = "IRL & Travel",
            concurrentViewers = 4910,
            visualPreset = VisualThemePreset.FJORD_AURORA,
            previewProgress = 1.0f
        )
    )

    val curatedCollections = listOf(
        CuratedCollection(
            id = "col_nordic_glass",
            title = "Silent Architecture & Glass Monographs",
            description = "Six architectural films exploring light, glass, and structural serenity across Scandinavia and Switzerland.",
            creatorId = "creator_aether",
            episodeCount = 6,
            visualPreset = VisualThemePreset.NORDIC_PAVILION,
            videoIds = listOf("vid_nordic_glass", "vid_brutalist_water", "vid_cloud_atrium", "vid_kyoto_courtyard")
        ),
        CuratedCollection(
            id = "col_spatial_shaders",
            title = "Spatial Computing & Optical Shaders",
            description = "Mathematical UI choreography, homothety transitions, and real-time ray-traced glass materials.",
            creatorId = "creator_aether",
            episodeCount = 4,
            visualPreset = VisualThemePreset.CYBER_LIGHTFIELD,
            videoIds = listOf("vid_liquid_glass_math", "vid_orbital_dyson", "vid_shader_combat")
        ),
        CuratedCollection(
            id = "col_acoustic_sanctuaries",
            title = "Acoustic Sanctuaries & Modular Tones",
            description = "Binaural field recordings and analog modular performances in resonant spaces.",
            creatorId = "creator_aether",
            episodeCount = 5,
            visualPreset = VisualThemePreset.ANALOG_SYNTH,
            videoIds = listOf("vid_buchla_conservatory", "vid_lofoten_aurora", "vid_kyoto_courtyard")
        )
    )

    val initialPlaylists = listOf(
        Playlist(
            id = "pl_spatial_ref",
            title = "Spatial Architecture Reference 4K",
            description = "Curated daylight glass pavilions, concrete reflections, and atmospheric lighting studies.",
            isPublic = true,
            videoIds = listOf("vid_nordic_glass", "vid_brutalist_water", "vid_cloud_atrium", "vid_lofoten_aurora")
        ),
        Playlist(
            id = "pl_late_night_focus",
            title = "Deep Focus: Modular & Rain",
            description = "Binaural Kyoto rainscapes and Buchla 200e conservatory sessions for late-night engineering.",
            isPublic = true,
            videoIds = listOf("vid_buchla_conservatory", "vid_kyoto_courtyard", "vid_liquid_glass_math", "vid_orbital_dyson")
        )
    )

    val initialLiveChat = listOf(
        ChatMessage(
            id = "m1",
            username = "Lumina Labs",
            avatarSeed = 4,
            badge = "MOD",
            message = "Welcome everyone to the Zurich mastering suite! Ask your questions about the 8K HDR pipeline.",
            timestamp = "12:04"
        ),
        ChatMessage(
            id = "m2",
            username = "Sora_N",
            avatarSeed = 5,
            badge = "SUB",
            message = "That specular highlight roll-off on the snow reflections looks so clean!",
            timestamp = "12:05"
        ),
        ChatMessage(
            id = "m3",
            username = "Kurogane_3D",
            avatarSeed = 2,
            badge = "SUB",
            message = "Are you using a custom film LUT before the Rec.2020 PQ output transform?",
            timestamp = "12:06"
        ),
        ChatMessage(
            id = "m4",
            username = "Mikael_V",
            avatarSeed = 6,
            badge = null,
            message = "Listening with spatial headphones right now—the wind across the glass ridge is unreal.",
            timestamp = "12:07"
        ),
        ChatMessage(
            id = "m5",
            username = "Vespera Sound",
            avatarSeed = 3,
            badge = "MOD",
            message = "The sub-bass reverb tail in that atrium blends effortlessly with the visual pacing.",
            timestamp = "12:08"
        )
    )

    val initialNotifications = listOf(
        NotificationItem(
            id = "n1",
            title = "Kurogane Studio published a 4K Premiere",
            subtitle = "Helios Ring: Procedural Megastructures in Unreal Engine 5.5",
            timestamp = "14m ago",
            isUnread = true,
            relatedVideoId = "vid_orbital_dyson",
            relatedCreatorId = "creator_kurogane"
        ),
        NotificationItem(
            id = "n2",
            title = "Vespera Sound went LIVE",
            subtitle = "Midnight Sub-Harmonic Patch Session (Buchla 200e + Tape)",
            timestamp = "42m ago",
            isUnread = true,
            relatedVideoId = "live_vespera_synth",
            relatedCreatorId = "creator_vespera"
        ),
        NotificationItem(
            id = "n3",
            title = "Lumina Labs commented on your Premiere",
            subtitle = "\"The refraction caustic transitions across the cantilevered glass atrium...\"",
            timestamp = "2h ago",
            isUnread = false,
            relatedVideoId = "vid_nordic_glass",
            relatedCreatorId = "creator_lumina"
        )
    )

    val initialModerationQueue = listOf(
        FlaggedContentItem(
            id = "flag_1",
            videoTitle = "Uncompressed 120fps Shader Stress Test #09",
            creatorName = "Nyx Realtime",
            reason = "High Bitrate Peak Warning (148 Mbps > 120 Mbps threshold)",
            confidenceScore = "96.4% Automated Telemetry"
        ),
        FlaggedContentItem(
            id = "flag_2",
            videoTitle = "Ambient Drones in Brutalist Subway Station",
            creatorName = "Echo Field",
            reason = "Spatial Audio Track Metadata Mismatch (5.1 labeled as 7.1.4)",
            confidenceScore = "89.1% Audio Inspector"
        ),
        FlaggedContentItem(
            id = "flag_3",
            videoTitle = "Neo-Tokyo Rain Reflection Study",
            creatorName = "SynthWave_JP",
            reason = "Automated Music Licensing Fingerprint Check",
            confidenceScore = "91.8% Rights Engine"
        )
    )

    val initialSpatialPulses = listOf(
        SpatialPulseStory(
            id = "pulse_aether",
            creatorId = "creator_aether",
            creatorName = "Aether Visuals",
            creatorHandle = "@aethervisuals",
            avatarSeed = 1,
            slides = listOf(
                SpatialPulseSlide(
                    id = "ps_aether_1",
                    caption = "Morning refraction test inside the Zurich glass pavilion — 8K RAW plate",
                    preset = VisualThemePreset.NORDIC_PAVILION,
                    timestamp = "18m ago"
                ),
                SpatialPulseSlide(
                    id = "ps_aether_2",
                    caption = "Volumetric cloud atrium lighting study at 4,000m elevation",
                    preset = VisualThemePreset.CLOUD_ATRIUM,
                    timestamp = "12m ago"
                )
            ),
            isViewed = false
        ),
        SpatialPulseStory(
            id = "pulse_kurogane",
            creatorId = "creator_kurogane",
            creatorName = "Kurogane Studio",
            creatorHandle = "@kuroganestudio",
            avatarSeed = 2,
            slides = listOf(
                SpatialPulseSlide(
                    id = "ps_kuro_1",
                    caption = "Real-time UE 5.5 orbital ring shader pass — 120fps lock achieved",
                    preset = VisualThemePreset.ORBITAL_RING,
                    timestamp = "34m ago"
                ),
                SpatialPulseSlide(
                    id = "ps_kuro_2",
                    caption = "Cybernetic lightfield caustic dispersion prototype",
                    preset = VisualThemePreset.CYBER_LIGHTFIELD,
                    timestamp = "21m ago"
                )
            ),
            isViewed = false
        ),
        SpatialPulseStory(
            id = "pulse_vespera",
            creatorId = "creator_vespera",
            creatorName = "Vespera Sound",
            creatorHandle = "@vesperasound",
            avatarSeed = 3,
            slides = listOf(
                SpatialPulseSlide(
                    id = "ps_vesp_1",
                    caption = "Warming up the Buchla 200e oscillators in Reykjavik conservatory",
                    preset = VisualThemePreset.ANALOG_SYNTH,
                    timestamp = "1h ago"
                )
            ),
            isViewed = false
        ),
        SpatialPulseStory(
            id = "pulse_lumina",
            creatorId = "creator_lumina",
            creatorName = "Lumina Labs",
            creatorHandle = "@luminalabs",
            avatarSeed = 4,
            slides = listOf(
                SpatialPulseSlide(
                    id = "ps_lum_1",
                    caption = "Testing homothety bubble spring curves on 120Hz OLED reference rig",
                    preset = VisualThemePreset.CYBER_LIGHTFIELD,
                    timestamp = "2h ago"
                )
            ),
            isViewed = false
        ),
        SpatialPulseStory(
            id = "pulse_sora",
            creatorId = "creator_sora",
            creatorName = "Sora Borealis",
            creatorHandle = "@soraborealis",
            avatarSeed = 5,
            slides = listOf(
                SpatialPulseSlide(
                    id = "ps_sora_1",
                    caption = "Arctic twilight over mirror-still Lofoten fjord waters",
                    preset = VisualThemePreset.FJORD_AURORA,
                    timestamp = "3h ago"
                ),
                SpatialPulseSlide(
                    id = "ps_sora_2",
                    caption = "Midnight cedar rain ambience in Kyoto machiya courtyard",
                    preset = VisualThemePreset.KYOTO_COURTYARD,
                    timestamp = "2h ago"
                )
            ),
            isViewed = false
        )
    )

    val initialDirectThreads = listOf(
        DirectMessageThread(
            creatorId = "creator_kurogane",
            creatorName = "Kurogane Studio",
            creatorHandle = "@kuroganestudio",
            avatarSeed = 2,
            isOnline = true,
            unreadCount = 2,
            messages = listOf(
                DirectChatMessage(
                    id = "dm_1",
                    senderId = "creator_kurogane",
                    senderName = "Kurogane Studio",
                    text = "Loved your latest Nordic Glass Pavilion study! The twilight specular roll-off is pristine.",
                    timestamp = "10:14",
                    isFromMe = false
                ),
                DirectChatMessage(
                    id = "dm_2",
                    senderId = "creator_aether",
                    senderName = "Aether Visuals",
                    text = "Thank you! Your Helios Ring UE5 path-tracing showcase inspired our volumetric pass.",
                    timestamp = "10:16",
                    isFromMe = true
                ),
                DirectChatMessage(
                    id = "dm_3",
                    senderId = "creator_kurogane",
                    senderName = "Kurogane Studio",
                    text = "Want to collaborate on a shared spatial lightfield anthology next week?",
                    timestamp = "10:18",
                    isFromMe = false,
                    sharedPreset = VisualThemePreset.ORBITAL_RING
                )
            )
        ),
        DirectMessageThread(
            creatorId = "creator_lumina",
            creatorName = "Lumina Labs",
            creatorHandle = "@luminalabs",
            avatarSeed = 4,
            isOnline = true,
            unreadCount = 1,
            hasMissedCall = true,
            messages = listOf(
                DirectChatMessage(
                    id = "dm_4",
                    senderId = "creator_lumina",
                    senderName = "Lumina Labs",
                    text = "We just benchmarked your concentric glass shader math at 120fps—zero frame drops!",
                    timestamp = "Yesterday",
                    isFromMe = false,
                    sharedPreset = VisualThemePreset.CYBER_LIGHTFIELD
                ),
                DirectChatMessage(
                    id = "dm_4_missed_call",
                    senderId = "creator_lumina",
                    senderName = "Lumina Labs",
                    text = "Missed audio call",
                    timestamp = "12m ago",
                    isFromMe = false
                )
            )
        ),
        DirectMessageThread(
            creatorId = "creator_vespera",
            creatorName = "Vespera Sound",
            creatorHandle = "@vesperasound",
            avatarSeed = 3,
            isOnline = true,
            unreadCount = 0,
            messages = listOf(
                DirectChatMessage(
                    id = "dm_5",
                    senderId = "creator_vespera",
                    senderName = "Vespera Sound",
                    text = "[VOICE:0:18] Sending over the 7.1.4 binaural Buchla stems for the Cloud Atrium episode.",
                    timestamp = "Tue",
                    isFromMe = false
                ),
                DirectChatMessage(
                    id = "dm_6",
                    senderId = "creator_aether",
                    senderName = "Aether Visuals",
                    text = "Received! Dropping them into DaVinci Fairlight right now.",
                    timestamp = "Tue",
                    isFromMe = true
                )
            )
        ),
        DirectMessageThread(
            creatorId = "creator_sora",
            creatorName = "Sora Borealis",
            creatorHandle = "@soraborealis",
            avatarSeed = 5,
            isOnline = false,
            unreadCount = 0,
            messages = listOf(
                DirectChatMessage(
                    id = "dm_7",
                    senderId = "creator_sora",
                    senderName = "Sora Borealis",
                    text = "Clear polar skies above Tromsø tonight—capturing 8K aurora plates!",
                    timestamp = "Mon",
                    isFromMe = false,
                    sharedPreset = VisualThemePreset.FJORD_AURORA
                )
            )
        ),
        DirectMessageThread(
            creatorId = "creator_zephyr",
            creatorName = "Zephyr Architecture",
            creatorHandle = "@zephyrarch",
            avatarSeed = 1,
            isOnline = true,
            unreadCount = 1,
            messages = listOf(
                DirectChatMessage(
                    id = "dm_8",
                    senderId = "creator_zephyr",
                    senderName = "Zephyr Architecture",
                    text = "Here is the updated Cloud Atrium glass refraction study for your review.",
                    timestamp = "11:42",
                    isFromMe = false,
                    sharedPreset = VisualThemePreset.CLOUD_ATRIUM
                )
            )
        )
    )
}
