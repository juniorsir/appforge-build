package com.example.nexora.animation

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.lerp

/**
 * Stage container that expands from the exact tapped button origin (Ox, Oy)
 * using Homothety Translation Formula (scale 0.055 -> 1.0, TransformOrigin,
 * residual translation tx0/ty0, and dynamic pill-to-stage corner radius morph)
 * on the GPU via Modifier.graphicsLayer.
 */
@Composable
fun StageBubbleContainer(
    triggerKey: Any,
    origin: ClickOrigin,
    modifier: Modifier = Modifier,
    targetCornerRadius: Dp = 0.dp,
    content: @Composable () -> Unit
) {
    val progress = remember { Animatable(1f) }
    var containerPos by remember { mutableStateOf(Offset.Zero) }
    var containerSize by remember { mutableStateOf(Size(1080f, 1920f)) }

    LaunchedEffect(triggerKey) {
        progress.snapTo(0f)
        progress.animateTo(
            targetValue = 1f,
            animationSpec = spring(
                dampingRatio = 0.88f,
                stiffness = 380f
            )
        )
    }

    val geom = remember(origin, containerPos, containerSize) {
        BubbleMath.computeStageBubbleGeometry(
            originX = origin.x,
            originY = origin.y,
            containerLeft = containerPos.x,
            containerTop = containerPos.y,
            containerWidth = containerSize.width,
            containerHeight = containerSize.height
        )
    }

    Box(
        modifier = modifier
            .onGloballyPositioned { coords ->
                containerPos = coords.positionInRoot()
                containerSize = Size(
                    coords.size.width.toFloat().coerceAtLeast(1f),
                    coords.size.height.toFloat().coerceAtLeast(1f)
                )
            }
            .graphicsLayer {
                val p = progress.value.coerceIn(0f, 1f)
                val scale = geom.scaleAt(p, initialScale = 0.055f)
                val tx = geom.translationXAt(p)
                val ty = geom.translationYAt(p)
                val dynamicCorner = lerp(
                    start = 240.dp,
                    stop = targetCornerRadius,
                    fraction = (p * 1.2f).coerceIn(0f, 1f)
                )
                val alphaVal = (p * 3.0f).coerceIn(0f, 1f)

                this.transformOrigin = TransformOrigin(geom.pivotFractionX, geom.pivotFractionY)
                this.scaleX = scale
                this.scaleY = scale
                this.translationX = tx
                this.translationY = ty
                this.alpha = alphaVal
                if (p < 0.99f || targetCornerRadius > 0.dp) {
                    this.shape = RoundedCornerShape(dynamicCorner)
                    this.clip = true
                }
            }
    ) {
        content()
    }
}

/**
 * Centered modal dialog overlay that expands from the exact tapped button origin
 * using Center-to-Center Vector Formula (Delta_x = O_x - M_cx, Delta_y = O_y - M_cy)
 * over a frosted slate backdrop.
 */
@Composable
fun BubbleModalPanel(
    visible: Boolean,
    origin: ClickOrigin,
    viewportSize: IntSize,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    targetCornerRadius: Dp = 28.dp,
    content: @Composable () -> Unit
) {
    if (!visible) return

    val progress = remember { Animatable(0f) }
    LaunchedEffect(origin.timestamp, visible) {
        progress.snapTo(0f)
        progress.animateTo(
            targetValue = 1f,
            animationSpec = spring(
                dampingRatio = 0.88f,
                stiffness = 380f
            )
        )
    }

    val modalGeom = remember(origin, viewportSize) {
        BubbleMath.computeModalBubbleGeometry(
            originX = origin.x,
            originY = origin.y,
            viewportWidth = viewportSize.width.toFloat().coerceAtLeast(1f),
            viewportHeight = viewportSize.height.toFloat().coerceAtLeast(1f)
        )
    }

    val dismissInteraction = remember { MutableInteractionSource() }
    val cardInteraction = remember { MutableInteractionSource() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer {
                val p = progress.value.coerceIn(0f, 1f)
                this.alpha = (p * 2.2f).coerceIn(0f, 1f)
            }
            .background(Color(0x590F172A))
            .clickable(
                interactionSource = dismissInteraction,
                indication = null,
                onClick = onDismiss
            ),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = modifier
                .clickable(
                    interactionSource = cardInteraction,
                    indication = null,
                    onClick = { /* consume click inside modal */ }
                )
                .graphicsLayer {
                    val p = progress.value.coerceIn(0f, 1f)
                    val scale = modalGeom.scaleAt(p, initialScale = 0.04f)
                    val tx = modalGeom.translationXAt(p)
                    val ty = modalGeom.translationYAt(p)
                    val dynamicCornerRadius = lerp(
                        start = 220.dp,
                        stop = targetCornerRadius,
                        fraction = (p * 1.25f).coerceIn(0f, 1f)
                    )
                    val alpha = (p * 3.2f).coerceIn(0f, 1f)

                    this.scaleX = scale
                    this.scaleY = scale
                    this.translationX = tx
                    this.translationY = ty
                    this.alpha = alpha
                    this.shape = RoundedCornerShape(dynamicCornerRadius)
                    this.clip = true
                }
        ) {
            content()
        }
    }
}
