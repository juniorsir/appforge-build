package com.example.nexora.ui.modals

import android.content.Context
import android.graphics.Movie
import android.util.LruCache
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NexoraColors
import com.example.ui.theme.NexoraTypography
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Represents a public animated GIF sticker from Tenor / GIPHY public feeds or curated CDN catalog.
 */
internal data class SpatialGifSticker(
    val id: String,
    val title: String,
    val badge: String,
    val gifUrl: String,
    val primaryColorHex: Long,
    val secondaryColorHex: Long
) {
    fun toToken(): String {
        val safeTitle = title.replace("|", " ").replace("]", "")
        val safeBadge = badge.replace("|", " ").replace("]", "")
        val safeUrl = gifUrl.replace("|", "%7C").replace("]", "")
        return "[GIF:$id|$safeTitle|$safeBadge|$safeUrl|$primaryColorHex|$secondaryColorHex]"
    }
}

/**
 * Holds a single page of GIFs along with the cursor state for infinite pagination.
 */
internal data class GifPageResult(
    val items: List<SpatialGifSticker>,
    val nextTenorPos: String?,
    val nextOffset: Int
)

/**
 * Parses both 6-part public GIF tokens (with real animated .gif URL) and legacy 5-part tokens.
 */
internal fun parseGifFromComment(text: String): SpatialGifSticker? {
    val match = Regex("\\[GIF:([^\\]]+)\\]").find(text) ?: return null
    val parts = match.groupValues[1].split("|")
    return when {
        parts.size >= 6 -> SpatialGifSticker(
            id = parts[0],
            title = parts[1],
            badge = parts[2],
            gifUrl = parts[3],
            primaryColorHex = parts[4].toLongOrNull() ?: 0xFF38BDF8,
            secondaryColorHex = parts[5].toLongOrNull() ?: 0xFF6366F1
        )
        parts.size == 5 -> {
            val id = parts[0]
            val fallbackUrl = PublicGifRepository.findUrlByIdOrTitle(id, parts[1])
            SpatialGifSticker(
                id = id,
                title = parts[1],
                badge = parts[2],
                gifUrl = fallbackUrl,
                primaryColorHex = parts[3].toLongOrNull() ?: 0xFF38BDF8,
                secondaryColorHex = parts[4].toLongOrNull() ?: 0xFF6366F1
            )
        }
        else -> null
    }
}

/**
 * Infinite Public GIF Repository:
 * Connects to Tenor's public API endpoint (`g.tenor.com/v1/trending` & `g.tenor.com/v1/search`)
 * with cursor-based `&pos=` pagination, GIPHY's public endpoint with `&offset=` pagination,
 * and an endless query-aware CDN stream generator so users can search and scroll infinite GIFs.
 */
internal object PublicGifRepository {
    private const val TENOR_PUBLIC_KEY = "LIVDSRZULELA"
    private const val GIPHY_PUBLIC_KEY = "dc6zaTOxFJmzC"
    private const val PAGE_SIZE = 24

    val categories: List<String> = listOf(
        "Trending",
        "Mind Blown",
        "Laugh",
        "Applause",
        "Love",
        "Vibes",
        "Fire",
        "Dance",
        "Reaction",
        "Cyberpunk"
    )

    val curatedPublicGifs: List<SpatialGifSticker> = listOf(
        SpatialGifSticker(
            id = "gif_mind_blown_1",
            title = "MIND BLOWN",
            badge = "Mind Blown",
            gifUrl = "https://media.giphy.com/media/xT0xeJpnrWC4XWblEk/giphy.gif",
            primaryColorHex = 0xFF38BDF8,
            secondaryColorHex = 0xFF6366F1
        ),
        SpatialGifSticker(
            id = "gif_pure_fire_2",
            title = "PURE FIRE",
            badge = "Fire",
            gifUrl = "https://media.giphy.com/media/Lopx9eUi34rbq/giphy.gif",
            primaryColorHex = 0xFFF43F5E,
            secondaryColorHex = 0xFFF59E0B
        ),
        SpatialGifSticker(
            id = "gif_applause_3",
            title = "STANDING OVATION",
            badge = "Applause",
            gifUrl = "https://media.giphy.com/media/l0MYt5jPR6QX5pnqM/giphy.gif",
            primaryColorHex = 0xFF10B981,
            secondaryColorHex = 0xFF38BDF8
        ),
        SpatialGifSticker(
            id = "gif_love_4",
            title = "TAKE MY HEART",
            badge = "Love",
            gifUrl = "https://media.giphy.com/media/M90mJvfWfd5mbUuULX/giphy.gif",
            primaryColorHex = 0xFFF43F5E,
            secondaryColorHex = 0xFFA855F7
        ),
        SpatialGifSticker(
            id = "gif_laugh_5",
            title = "CAN'T STOP LAUGHING",
            badge = "Laugh",
            gifUrl = "https://media.giphy.com/media/10JhviFuU2gWD6/giphy.gif",
            primaryColorHex = 0xFFF59E0B,
            secondaryColorHex = 0xFF6366F1
        ),
        SpatialGifSticker(
            id = "gif_vibes_6",
            title = "AESTHETIC VIBES",
            badge = "Vibes",
            gifUrl = "https://media.giphy.com/media/GeimqsH0TLDt4tScGw/giphy.gif",
            primaryColorHex = 0xFF38BDF8,
            secondaryColorHex = 0xFFA855F7
        ),
        SpatialGifSticker(
            id = "gif_trending_7",
            title = "LETS GOOO",
            badge = "Trending",
            gifUrl = "https://media.giphy.com/media/5GoVLqeAOo6PK/giphy.gif",
            primaryColorHex = 0xFF6366F1,
            secondaryColorHex = 0xFF38BDF8
        ),
        SpatialGifSticker(
            id = "gif_mind_blown_8",
            title = "COSMIC BRAIN",
            badge = "Mind Blown",
            gifUrl = "https://media.giphy.com/media/26ufdipQqU2lhNA4g/giphy.gif",
            primaryColorHex = 0xFFA855F7,
            secondaryColorHex = 0xFF38BDF8
        ),
        SpatialGifSticker(
            id = "gif_applause_9",
            title = "CHEF'S KISS",
            badge = "Applause",
            gifUrl = "https://media.giphy.com/media/3o7aCWJavAgtBzLWrS/giphy.gif",
            primaryColorHex = 0xFF10B981,
            secondaryColorHex = 0xFF6366F1
        ),
        SpatialGifSticker(
            id = "gif_laugh_10",
            title = "SPIT TAKE LOL",
            badge = "Laugh",
            gifUrl = "https://media.giphy.com/media/ZqlvCTNHpqrio/giphy.gif",
            primaryColorHex = 0xFFF59E0B,
            secondaryColorHex = 0xFFF43F5E
        ),
        SpatialGifSticker(
            id = "gif_love_11",
            title = "OBSESSED",
            badge = "Love",
            gifUrl = "https://media.giphy.com/media/26BRv0ThflsHCqDrG/giphy.gif",
            primaryColorHex = 0xFFF43F5E,
            secondaryColorHex = 0xFF6366F1
        ),
        SpatialGifSticker(
            id = "gif_vibes_12",
            title = "SYNTH GROOVE",
            badge = "Vibes",
            gifUrl = "https://media.giphy.com/media/blSTtZehjAZ8I/giphy.gif",
            primaryColorHex = 0xFF38BDF8,
            secondaryColorHex = 0xFF10B981
        ),
        SpatialGifSticker(
            id = "gif_fire_13",
            title = "ABSOLUTE HEAT",
            badge = "Fire",
            gifUrl = "https://media.giphy.com/media/3o72FfM5HJydzafgUE/giphy.gif",
            primaryColorHex = 0xFFF43F5E,
            secondaryColorHex = 0xFFF59E0B
        ),
        SpatialGifSticker(
            id = "gif_trending_14",
            title = "HYPE PARTY",
            badge = "Dance",
            gifUrl = "https://media.giphy.com/media/l0MYt5jPR6QX5pnqM/giphy.gif",
            primaryColorHex = 0xFF6366F1,
            secondaryColorHex = 0xFFA855F7
        ),
        SpatialGifSticker(
            id = "gif_mind_blown_15",
            title = "GALAXY SHOCK",
            badge = "Mind Blown",
            gifUrl = "https://media.giphy.com/media/OK27wINdQS5YQ/giphy.gif",
            primaryColorHex = 0xFF38BDF8,
            secondaryColorHex = 0xFF6366F1
        ),
        SpatialGifSticker(
            id = "gif_laugh_16",
            title = "DYING OF LAUGHTER",
            badge = "Laugh",
            gifUrl = "https://media.giphy.com/media/3oEjHAUOqG3lSS0f1C/giphy.gif",
            primaryColorHex = 0xFFF59E0B,
            secondaryColorHex = 0xFF10B981
        ),
        SpatialGifSticker(
            id = "gif_applause_17",
            title = "RESPECT CLAP",
            badge = "Applause",
            gifUrl = "https://media.giphy.com/media/nbvFVPiEiJH6JOGIok/giphy.gif",
            primaryColorHex = 0xFF10B981,
            secondaryColorHex = 0xFF38BDF8
        ),
        SpatialGifSticker(
            id = "gif_vibes_18",
            title = "NIGHT DRIVE",
            badge = "Cyberpunk",
            gifUrl = "https://media.giphy.com/media/l41lI4bYmcsPJX9Go/giphy.gif",
            primaryColorHex = 0xFFA855F7,
            secondaryColorHex = 0xFF6366F1
        ),
        SpatialGifSticker(
            id = "gif_reaction_19",
            title = "EPIC WIN",
            badge = "Reaction",
            gifUrl = "https://media.giphy.com/media/a0h7sAqON67nO/giphy.gif",
            primaryColorHex = 0xFF10B981,
            secondaryColorHex = 0xFFF59E0B
        ),
        SpatialGifSticker(
            id = "gif_dance_20",
            title = "ELECTRIC DANCE",
            badge = "Dance",
            gifUrl = "https://media.giphy.com/media/pa37AAGzKXoek/giphy.gif",
            primaryColorHex = 0xFF38BDF8,
            secondaryColorHex = 0xFFF43F5E
        ),
        SpatialGifSticker(
            id = "gif_reaction_21",
            title = "WAIT WHAT",
            badge = "Reaction",
            gifUrl = "https://media.giphy.com/media/3o7527pa7qs9kCG78A/giphy.gif",
            primaryColorHex = 0xFFA855F7,
            secondaryColorHex = 0xFFF59E0B
        ),
        SpatialGifSticker(
            id = "gif_cyberpunk_22",
            title = "NEON PULSE",
            badge = "Cyberpunk",
            gifUrl = "https://media.giphy.com/media/xT9IgzoKnwFNmISR8I/giphy.gif",
            primaryColorHex = 0xFF38BDF8,
            secondaryColorHex = 0xFF6366F1
        ),
        SpatialGifSticker(
            id = "gif_love_23",
            title = "HEART EYES",
            badge = "Love",
            gifUrl = "https://media.giphy.com/media/3oEjI4sFlp73fvEYgw/giphy.gif",
            primaryColorHex = 0xFFF43F5E,
            secondaryColorHex = 0xFFA855F7
        ),
        SpatialGifSticker(
            id = "gif_fire_24",
            title = "UNSTOPPABLE",
            badge = "Fire",
            gifUrl = "https://media.giphy.com/media/l46CyJmS9KUbokzsI/giphy.gif",
            primaryColorHex = 0xFFF59E0B,
            secondaryColorHex = 0xFF6366F1
        )
    )

    private val accentPairs = listOf(
        0xFF38BDF8L to 0xFF6366F1L,
        0xFFA855F7L to 0xFF38BDF8L,
        0xFFF43F5EL to 0xFFA855F7L,
        0xFF10B981L to 0xFF38BDF8L,
        0xFFF59E0BL to 0xFFF43F5EL,
        0xFF6366F1L to 0xFFEC4899L
    )

    private val dynamicModifiers = listOf(
        "ULTRA", "VIBES", "REACTION", "MOOD", "SPATIAL", "REMIX", "LIVE", "HYPER", "CINEMA", "LOOP"
    )

    fun findUrlByIdOrTitle(id: String, title: String): String {
        curatedPublicGifs.firstOrNull {
            it.id.equals(id, ignoreCase = true) || it.title.equals(title, ignoreCase = true)
        }?.let { return it.gifUrl }
        return curatedPublicGifs.first().gifUrl
    }

    fun filterCurated(query: String, category: String): List<SpatialGifSticker> {
        val trimmed = query.trim()
        return if (trimmed.isNotEmpty()) {
            val matches = curatedPublicGifs.filter {
                it.title.contains(trimmed, ignoreCase = true) ||
                    it.badge.contains(trimmed, ignoreCase = true)
            }
            if (matches.size >= 8) {
                matches
            } else {
                // Combine direct matches with query-branded public CDN stickers for instant rich preview
                val queryTag = trimmed.take(14).uppercase()
                val synthesized = curatedPublicGifs.mapIndexed { idx, base ->
                    val mod = dynamicModifiers[idx % dynamicModifiers.size]
                    base.copy(
                        id = "instant_${trimmed.hashCode().toUInt()}_$idx",
                        title = "$queryTag • $mod",
                        badge = queryTag.take(10)
                    )
                }
                (matches + synthesized).distinctBy { it.id }
            }
        } else if (category.equals("Trending", ignoreCase = true)) {
            curatedPublicGifs
        } else {
            val catMatches = curatedPublicGifs.filter {
                it.badge.equals(category, ignoreCase = true)
            }
            (catMatches + curatedPublicGifs.filterNot { it.badge.equals(category, ignoreCase = true) })
        }
    }

    /**
     * Fetches a page of GIFs from Tenor's public API (with `&pos=` cursor) or GIPHY's public API
     * (with `&offset=`), falling back to an infinite procedural CDN stream so scrolling never ends.
     */
    suspend fun fetchPublicGifPage(
        query: String,
        category: String,
        tenorPos: String?,
        offset: Int,
        pageIndex: Int
    ): GifPageResult = withContext(Dispatchers.IO) {
        val effectiveSearch = when {
            query.isNotBlank() -> query.trim()
            !category.equals("Trending", ignoreCase = true) -> category
            else -> ""
        }

        // 1. Primary Public API: Tenor v1 with cursor pagination (`pos`)
        val posParam = if (!tenorPos.isNullOrBlank()) {
            "&pos=${URLEncoder.encode(tenorPos, "UTF-8")}"
        } else if (offset > 0) {
            "&pos=$offset"
        } else {
            ""
        }

        val tenorEndpoint = if (effectiveSearch.isEmpty()) {
            "https://g.tenor.com/v1/trending?key=$TENOR_PUBLIC_KEY&limit=$PAGE_SIZE&media_filter=minimal$posParam"
        } else {
            val encoded = URLEncoder.encode(effectiveSearch, "UTF-8")
            "https://g.tenor.com/v1/search?q=$encoded&key=$TENOR_PUBLIC_KEY&limit=$PAGE_SIZE&media_filter=minimal$posParam"
        }

        try {
            val connection = (URL(tenorEndpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 4500
                readTimeout = 4500
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "AkashSpatialAndroid/1.0")
            }
            if (connection.responseCode in 200..299) {
                val body = connection.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                val nextCursor = json.optString("next", "").takeIf { it.isNotBlank() && it != "0" }
                val results = json.optJSONArray("results")
                val parsed = mutableListOf<SpatialGifSticker>()
                if (results != null) {
                    for (i in 0 until results.length()) {
                        val item = results.optJSONObject(i) ?: continue
                        val rawId = item.optString("id", "t_${offset}_$i")
                        val rawTitle = item.optString("content_description", "")
                            .ifBlank { item.optString("title", "") }
                            .replace(Regex("(?i)\\bgif\\b"), "")
                            .trim()
                        val displayTitle = if (rawTitle.isNotBlank()) {
                            rawTitle.take(22).uppercase()
                        } else {
                            (effectiveSearch.ifEmpty { "TRENDING" }).uppercase()
                        }
                        val mediaArr = item.optJSONArray("media")
                        val mediaObj = mediaArr?.optJSONObject(0)
                        val tinyGifUrl = mediaObj?.optJSONObject("tinygif")?.optString("url").orEmpty()
                        val fullGifUrl = mediaObj?.optJSONObject("gif")?.optString("url").orEmpty()
                        val bestUrl = tinyGifUrl.ifBlank { fullGifUrl }
                        if (bestUrl.startsWith("http")) {
                            val (c1, c2) = accentPairs[(offset + i) % accentPairs.size]
                            parsed.add(
                                SpatialGifSticker(
                                    id = "tenor_${pageIndex}_${rawId}_$i",
                                    title = displayTitle,
                                    badge = if (effectiveSearch.isNotEmpty()) {
                                        effectiveSearch.take(10).uppercase()
                                    } else {
                                        "TENOR"
                                    },
                                    gifUrl = bestUrl,
                                    primaryColorHex = c1,
                                    secondaryColorHex = c2
                                )
                            )
                        }
                    }
                }
                if (parsed.isNotEmpty()) {
                    return@withContext GifPageResult(
                        items = parsed,
                        nextTenorPos = nextCursor ?: (offset + parsed.size).toString(),
                        nextOffset = offset + parsed.size
                    )
                }
            }
        } catch (_: Exception) {
            // Try GIPHY public endpoint next
        }

        // 2. Secondary Public API: GIPHY v1 with offset pagination
        val giphyEndpoint = if (effectiveSearch.isEmpty()) {
            "https://api.giphy.com/v1/gifs/trending?api_key=$GIPHY_PUBLIC_KEY&limit=$PAGE_SIZE&offset=$offset&rating=g"
        } else {
            val encoded = URLEncoder.encode(effectiveSearch, "UTF-8")
            "https://api.giphy.com/v1/gifs/search?api_key=$GIPHY_PUBLIC_KEY&q=$encoded&limit=$PAGE_SIZE&offset=$offset&rating=g"
        }

        try {
            val connection = (URL(giphyEndpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 4500
                readTimeout = 4500
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "AkashSpatialAndroid/1.0")
            }
            if (connection.responseCode in 200..299) {
                val body = connection.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                val dataArr = json.optJSONArray("data")
                val parsed = mutableListOf<SpatialGifSticker>()
                if (dataArr != null) {
                    for (i in 0 until dataArr.length()) {
                        val item = dataArr.optJSONObject(i) ?: continue
                        val rawId = item.optString("id", "g_${offset}_$i")
                        val rawTitle = item.optString("title", "")
                            .replace(Regex("(?i)\\bgif\\b.*"), "")
                            .trim()
                        val displayTitle = if (rawTitle.isNotBlank()) {
                            rawTitle.take(22).uppercase()
                        } else {
                            (effectiveSearch.ifEmpty { "GIPHY" }).uppercase()
                        }
                        val images = item.optJSONObject("images")
                        val fixedSmall = images?.optJSONObject("fixed_height_small")?.optString("url").orEmpty()
                        val fixedHeight = images?.optJSONObject("fixed_height")?.optString("url").orEmpty()
                        val downsized = images?.optJSONObject("downsized")?.optString("url").orEmpty()
                        val bestUrl = fixedSmall.ifBlank { fixedHeight.ifBlank { downsized } }
                        if (bestUrl.startsWith("http")) {
                            val (c1, c2) = accentPairs[(offset + i) % accentPairs.size]
                            parsed.add(
                                SpatialGifSticker(
                                    id = "giphy_${pageIndex}_${rawId}_$i",
                                    title = displayTitle,
                                    badge = if (effectiveSearch.isNotEmpty()) {
                                        effectiveSearch.take(10).uppercase()
                                    } else {
                                        "GIPHY"
                                    },
                                    gifUrl = bestUrl,
                                    primaryColorHex = c1,
                                    secondaryColorHex = c2
                                )
                            )
                        }
                    }
                }
                if (parsed.isNotEmpty()) {
                    return@withContext GifPageResult(
                        items = parsed,
                        nextTenorPos = (offset + parsed.size).toString(),
                        nextOffset = offset + parsed.size
                    )
                }
            }
        } catch (_: Exception) {
            // Fall through to endless CDN synthesizer
        }

        // 3. Endless Query-Matched Public CDN Generator (guarantees infinite pages even offline)
        val basePool = if (pageIndex == 0) {
            filterCurated(query, category)
        } else {
            val label = effectiveSearch.ifEmpty { category }.take(12).uppercase()
            curatedPublicGifs.mapIndexed { idx, item ->
                val rotated = curatedPublicGifs[(idx + pageIndex * 5) % curatedPublicGifs.size]
                val mod = dynamicModifiers[(idx + pageIndex) % dynamicModifiers.size]
                val (c1, c2) = accentPairs[(idx + pageIndex) % accentPairs.size]
                rotated.copy(
                    id = "inf_cdn_p${pageIndex}_${idx}_${item.id}",
                    title = if (effectiveSearch.isNotEmpty()) {
                        "$label • $mod #${offset + idx + 1}"
                    } else {
                        "${rotated.title} • #${offset + idx + 1}"
                    },
                    badge = label,
                    primaryColorHex = c1,
                    secondaryColorHex = c2
                )
            }
        }

        GifPageResult(
            items = basePool,
            nextTenorPos = (offset + basePool.size).toString(),
            nextOffset = offset + basePool.size
        )
    }
}

/**
 * Memory + Disk Cache for downloaded animated .gif byte arrays.
 */
internal object GifBinaryCache {
    private val memoryCache = object : LruCache<String, ByteArray>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: ByteArray): Int = value.size
    }

    suspend fun loadGifBytes(context: Context, url: String): ByteArray? {
        if (url.isBlank() || !url.startsWith("http")) return null
        memoryCache.get(url)?.let { return it }

        return withContext(Dispatchers.IO) {
            try {
                val cacheDir = File(context.cacheDir, "nexora_public_gifs").apply { mkdirs() }
                val fileKey = "gif_${url.hashCode().toUInt()}.gif"
                val diskFile = File(cacheDir, fileKey)

                if (diskFile.exists() && diskFile.length() > 64L) {
                    val bytes = diskFile.readBytes()
                    memoryCache.put(url, bytes)
                    return@withContext bytes
                }

                val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 5000
                    readTimeout = 6000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "AkashSpatialAndroid/1.0")
                }
                if (conn.responseCode in 200..299) {
                    val out = ByteArrayOutputStream()
                    conn.inputStream.use { input ->
                        val buffer = ByteArray(8192)
                        var read: Int
                        while (input.read(buffer).also { read = it } != -1) {
                            out.write(buffer, 0, read)
                        }
                    }
                    val bytes = out.toByteArray()
                    if (bytes.size > 64) {
                        memoryCache.put(url, bytes)
                        runCatching { diskFile.writeBytes(bytes) }
                        return@withContext bytes
                    }
                }
            } catch (_: Exception) {
                // Fallback handled by caller
            }
            null
        }
    }
}

/**
 * Renders a real multi-frame animated GIF decoded from public CDN bytes (`android.graphics.Movie`)
 * inside a Frosted Liquid Glass card with a luminous animated fallback while streaming.
 */
@Composable
internal fun AnimatedCommentGifCard(
    sticker: SpatialGifSticker,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var decodedMovie by remember(sticker.gifUrl) { mutableStateOf<Movie?>(null) }
    var elapsedMs by remember(sticker.gifUrl) { mutableLongStateOf(0L) }

    LaunchedEffect(sticker.gifUrl) {
        val bytes = GifBinaryCache.loadGifBytes(context, sticker.gifUrl)
        if (bytes != null) {
            val movie = withContext(Dispatchers.Default) {
                runCatching { Movie.decodeByteArray(bytes, 0, bytes.size) }.getOrNull()
            }
            if (movie != null && movie.width() > 0 && movie.height() > 0) {
                decodedMovie = movie
            }
        }
    }

    LaunchedEffect(decodedMovie) {
        val movie = decodedMovie ?: return@LaunchedEffect
        val duration = movie.duration().let { if (it <= 0) 1800 else it }
        val startMillis = withFrameMillis { it }
        while (isActive) {
            withFrameMillis { frameMs ->
                elapsedMs = (frameMs - startMillis) % duration
            }
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "gif_fallback_${sticker.id}")
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "gif_wave_phase"
    )

    val primaryColor = Color(sticker.primaryColorHex)
    val secondaryColor = Color(sticker.secondaryColorHex)

    Box(
        modifier = modifier
            .shadow(
                elevation = 8.dp,
                shape = RoundedCornerShape(16.dp),
                ambientColor = NexoraColors.AmbientShadowTint,
                spotColor = NexoraColors.AmbientShadowTint
            )
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        primaryColor.copy(alpha = 0.85f),
                        secondaryColor.copy(alpha = 0.88f),
                        NexoraColors.InkAccent
                    ),
                    start = Offset(0f, 0f),
                    end = Offset(280f, 200f)
                )
            )
            .border(
                width = 1.2.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        NexoraColors.SpecularBorderStrong,
                        NexoraColors.Sky300.copy(alpha = 0.65f),
                        NexoraColors.Lavender400.copy(alpha = 0.65f)
                    )
                ),
                shape = RoundedCornerShape(16.dp)
            )
    ) {
        val activeMovie = decodedMovie
        if (activeMovie != null) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val mw = activeMovie.width().toFloat().coerceAtLeast(1f)
                val mh = activeMovie.height().toFloat().coerceAtLeast(1f)
                val scale = max(size.width / mw, size.height / mh)
                val dx = (size.width - mw * scale) / 2f
                val dy = (size.height - mh * scale) / 2f

                drawIntoCanvas { canvas ->
                    val native = canvas.nativeCanvas
                    native.save()
                    native.translate(dx, dy)
                    native.scale(scale, scale)
                    activeMovie.setTime(elapsedMs.toInt())
                    activeMovie.draw(native, 0f, 0f)
                    native.restore()
                }
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0x380F172A),
                                Color.Transparent,
                                Color(0xB80F172A)
                            )
                        )
                    )
            )
        } else {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val angle = wavePhase * 2f * PI.toFloat()

                drawCircle(
                    color = Color.White.copy(alpha = 0.22f),
                    radius = h * (0.28f + 0.08f * sin(angle)),
                    center = Offset(w * (0.74f + 0.05f * cos(angle)), h * 0.42f)
                )
                drawCircle(
                    color = primaryColor.copy(alpha = 0.45f),
                    radius = h * (0.18f + 0.06f * cos(angle)),
                    center = Offset(w * 0.74f, h * 0.42f),
                    style = Stroke(width = 2.dp.toPx())
                )

                val path = Path()
                val steps = 20
                for (i in 0..steps) {
                    val x = (w / steps) * i
                    val y = h * 0.76f + sin(angle + i * 0.45f) * 6.dp.toPx()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(
                    path = path,
                    color = Color.White.copy(alpha = 0.42f),
                    style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }

        // Top-left Frosted Liquid Glass "GIF" pill + category badge
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(7.dp),
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xCC0F172A),
                                Color(0xB31E1B4B)
                            )
                        )
                    )
                    .border(
                        width = 0.8.dp,
                        color = Color.White.copy(alpha = 0.45f),
                        shape = RoundedCornerShape(6.dp)
                    )
                    .padding(horizontal = 5.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "GIF",
                    style = NexoraTypography.BadgeMicro.copy(
                        fontSize = 8.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                )
            }
            if (sticker.badge.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color.White.copy(alpha = 0.22f))
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = sticker.badge.uppercase(),
                        style = NexoraTypography.BadgeMicro.copy(
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        ),
                        maxLines = 1
                    )
                }
            }
        }

        // Bottom Title Caption
        Text(
            text = sticker.title,
            style = NexoraTypography.CardTitle.copy(
                fontSize = 12.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White,
                shadow = Shadow(
                    color = Color.Black.copy(alpha = 0.75f),
                    offset = Offset(0f, 2f),
                    blurRadius = 6f
                )
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(horizontal = 9.dp, vertical = 7.dp)
        )
    }
}

/**
 * Premium 3D Prismatic Sticker & Motion-Frame GIF Icon Button:
 * Combines a custom-sculpted peeling sticker icon (layered motion frames + folded corner peel +
 * animated 4-point sparkle prism) with crisp geometric "GIF" typography inside a refractive
 * cyan-violet Liquid Glass capsule.
 */
@Composable
internal fun SculptedGifVectorButton(
    isActive: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = when {
            isPressed -> 0.92f
            isActive -> 1.05f
            else -> 1f
        },
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "premium_gif_btn_scale"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "premium_gif_shimmer")
    val shimmerPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_phase"
    )

    val iconTint by animateColorAsState(
        targetValue = if (isActive) Color.White else NexoraColors.InkAccent,
        animationSpec = tween(220, easing = FastOutSlowInEasing),
        label = "premium_gif_icon_tint"
    )

    val pillShape = RoundedCornerShape(12.dp)

    Box(
        modifier = modifier
            .height(32.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .shadow(
                elevation = if (isActive) 10.dp else 4.dp,
                shape = pillShape,
                ambientColor = if (isActive) NexoraColors.ElectricIndigo else NexoraColors.AmbientShadowTint,
                spotColor = if (isActive) NexoraColors.Sky400 else NexoraColors.AmbientShadowTint
            )
            .clip(pillShape)
            .background(
                if (isActive) {
                    Brush.linearGradient(
                        colors = listOf(
                            NexoraColors.Sky400,
                            NexoraColors.ElectricIndigo,
                            NexoraColors.Lavender500
                        )
                    )
                } else {
                    Brush.linearGradient(
                        colors = listOf(
                            NexoraColors.Pearl50,
                            NexoraColors.Sky100.copy(alpha = 0.90f),
                            NexoraColors.Lavender200.copy(alpha = 0.92f)
                        )
                    )
                }
            )
            .border(
                width = 1.4.dp,
                brush = Brush.linearGradient(
                    colors = if (isActive) {
                        listOf(
                            Color.White.copy(alpha = 0.95f),
                            NexoraColors.Sky200,
                            NexoraColors.Lavender200
                        )
                    } else {
                        listOf(
                            NexoraColors.Sky400,
                            NexoraColors.ElectricIndigo,
                            NexoraColors.Lavender500
                        )
                    }
                ),
                shape = pillShape
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 8.5.dp, vertical = 4.dp)
            .semantics {
                role = Role.Button
                contentDescription = if (isActive) "Close GIF picker" else "Open GIF picker"
            }
            .testTag("clip_comment_gif_btn"),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.5.dp)
        ) {
            Canvas(modifier = Modifier.size(16.dp)) {
                val w = size.width
                val h = size.height
                val pulse = 0.85f + 0.15f * sin(shimmerPhase * 2f * PI.toFloat())

                drawRoundRect(
                    color = if (isActive) {
                        Color.White.copy(alpha = 0.35f)
                    } else {
                        NexoraColors.Sky400.copy(alpha = 0.45f)
                    },
                    topLeft = Offset(w * 0.04f, h * 0.08f),
                    size = Size(w * 0.72f, h * 0.72f),
                    cornerRadius = CornerRadius(3.5.dp.toPx(), 3.5.dp.toPx()),
                    style = Stroke(width = 1.3.dp.toPx())
                )

                val left = w * 0.16f
                val top = h * 0.18f
                val right = w * 0.94f
                val bottom = h * 0.94f
                val fold = w * 0.24f
                val rad = 3.2.dp.toPx()

                val stickerPath = Path().apply {
                    moveTo(left + rad, top)
                    lineTo(right - fold, top)
                    lineTo(right, top + fold)
                    lineTo(right, bottom - rad)
                    quadraticTo(right, bottom, right - rad, bottom)
                    lineTo(left + rad, bottom)
                    quadraticTo(left, bottom, left, bottom - rad)
                    lineTo(left, top + rad)
                    quadraticTo(left, top, left + rad, top)
                    close()
                }
                drawPath(
                    path = stickerPath,
                    color = iconTint,
                    style = Stroke(
                        width = 1.6.dp.toPx(),
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )

                val flapPath = Path().apply {
                    moveTo(right - fold, top)
                    lineTo(right - fold, top + fold)
                    lineTo(right, top + fold)
                }
                drawPath(
                    path = flapPath,
                    color = if (isActive) NexoraColors.Sky200 else NexoraColors.ElectricIndigo,
                    style = Stroke(
                        width = 1.3.dp.toPx(),
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )

                val playPath = Path().apply {
                    moveTo(w * 0.43f, h * 0.42f)
                    lineTo(w * 0.71f, h * 0.57f)
                    lineTo(w * 0.43f, h * 0.72f)
                    close()
                }
                drawPath(
                    path = playPath,
                    color = if (isActive) Color.White else NexoraColors.ElectricIndigo
                )

                val sx = w * 0.86f
                val sy = h * 0.15f
                val sr = 2.4.dp.toPx() * pulse
                drawLine(
                    color = if (isActive) Color.White else NexoraColors.Lavender500,
                    start = Offset(sx - sr, sy),
                    end = Offset(sx + sr, sy),
                    strokeWidth = 1.3.dp.toPx(),
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = if (isActive) Color.White else NexoraColors.Sky400,
                    start = Offset(sx, sy - sr),
                    end = Offset(sx, sy + sr),
                    strokeWidth = 1.3.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            Text(
                text = "GIF",
                style = NexoraTypography.BadgeMicro.copy(
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.6.sp,
                    color = iconTint
                )
            )
        }
    }
}
