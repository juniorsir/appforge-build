# Master Prompt: Build the "Nexora" Spatial Video & Live Streaming Platform in Kotlin (Jetpack Compose / Compose Multiplatform)

Copy and paste the prompt below into an AI coding assistant or use it as a complete engineering specification to build **Nexora** in **Kotlin** with **Jetpack Compose** (Android / Compose Multiplatform Desktop & iOS) with 1:1 visual, mathematical, and interactive fidelity.

---

## Prompt Instructions

You are a Principal Android / Kotlin Multiplatform UI Engineer and Spatial Design Architect. Build **Nexora**, a next-generation spatial video streaming, creator studio, and live broadcast application in **Kotlin** using **Jetpack Compose** (Material 3 custom design system + `androidx.compose.animation.core` + `GraphicsLayer` / `RenderEffect` blur).

The application must strictly implement the **"Cool Pearl Alabaster & Frosted Liquid Glass"** aesthetic, **Mathematical Spatial Grid & Concentric Radii**, **Custom Diamond Starburst Verified Badges**, and **Exact Button-Origin Mathematical Bubble Transitions** detailed below.

---

## 1. Visual Direction & Theme System ("Cool Pearl Alabaster & Frosted Liquid Glass")

### 1.1 Color Palette & Exact Hex Tokens (`NexoraColors.kt`)
Never use generic dark mode or flat white backgrounds. The entire app sits on a luminous **Cool Pearl Alabaster** canvas with GPU-rendered ambient pastel mesh orbs and multi-layered frosted glass surfaces.

```kotlin
package com.nexora.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset

object NexoraColors {
    // Base Canvas & Pearl Alabaster Scale
    val CanvasBase = Color(0xFFF2F5FC)
    val Pearl50    = Color(0xFFFAFBFD)
    val Pearl100   = Color(0xFFF6F8FD)
    val Pearl200   = Color(0xFFEDF2FA)
    val Pearl300   = Color(0xFFE2E9F6)

    // Ambient Radial Mesh Orb Colors (Fixed Background Canvas)
    val MeshOrbTopLeftLav      = Color(0x42C084FC) // rgba(192, 132, 252, 0.26) at (12%, 8%)
    val MeshOrbTopRightSky     = Color(0x4D7DD3FC) // rgba(125, 211, 252, 0.30) at (88%, 14%)
    val MeshOrbBottomCenterInd = Color(0x42A5B4FC) // rgba(165, 180, 252, 0.26) at (50%, 85%)

    // Iridescent Pastel Lavender Scale
    val Lavender100 = Color(0xFFF3E8FF)
    val Lavender200 = Color(0xFFE9D5FF)
    val Lavender300 = Color(0xFFD8B4FE)
    val Lavender400 = Color(0xFFC084FC)
    val Lavender500 = Color(0xFFA855F7)

    // Icy Sky Blue Scale
    val Sky100 = Color(0xFFE0F2FE)
    val Sky200 = Color(0xFFBAE6FD)
    val Sky300 = Color(0xFF7DD3FC)
    val Sky400 = Color(0xFF38BDF8)

    // Deep Slate Ink Typography Hierarchy (High-Contrast Daylight Legibility)
    val InkPrimary   = Color(0xFF0F172A) // Slate 900 - Primary titles & headings
    val InkAccent    = Color(0xFF1E1B4B) // Indigo 950 - Active pill labels & deep accents
    val InkSecondary = Color(0xFF334155) // Slate 700 - Subtitles & active metadata
    val InkBody      = Color(0xFF475569) // Slate 600 - Descriptions & body copy
    val InkMuted     = Color(0xFF64748B) // Slate 500 - Timestamps, view counts, inactive tabs

    // Semantic Status Accents
    val LiveRose     = Color(0xFFF43F5E) // Live indicator dot & badge
    val EmeraldLive  = Color(0xFF10B981) // Verified / Online status dot
    val AmberStar    = Color(0xFFF59E0B) // Featured / Rating accent

    // Specular Borders & Glass Strokes
    val SpecularBorderStrong = Color(0xF0FFFFFF) // rgba(255, 255, 255, 0.94)
    val SpecularBorderNav    = Color(0xEBFFFFFF) // rgba(255, 255, 255, 0.92)
    val SpecularBorderSubtle = Color(0xD9FFFFFF) // rgba(255, 255, 255, 0.85)
    val AmbientShadowTint    = Color(0x241E1B4B) // rgba(30, 27, 75, 0.14)
}
```

### 1.2 Liquid Glass Surface Modifiers (`LiquidGlassModifiers.kt`)
Create reusable `Modifier` extensions that replicate the exact multi-stop linear gradients, specular white borders (`1.5.dp`), inner top highlights, and ambient indigo-slate drop shadows:

1. **`Modifier.liquidGlassNav(cornerRadius: Dp = 999.dp)`** (Floating Header & Navigation Bars):
   - Fill Brush: `Brush.verticalGradient(listOf(Color(0xDBECF1F9), Color(0xC7D8E1EF)))` (`rgba(236,241,249,0.86)` to `rgba(216,225,239,0.78)`)
   - Border: `1.5.dp` solid `Color(0xEBFFFFFF)`
   - Backdrop Blur: `24.dp` (via `Modifier.blur` / Android 12+ `RenderEffect.createBlurEffect` on underlying layer)
   - Elevation Shadow: `12.dp` ambient shadow tinted with `Color(0x1F1E1B4B)`

2. **`Modifier.liquidGlassCard(cornerRadius: Dp)`** (Video Cards, Bento Panels, Hero Containers):
   - Fill Brush: `Brush.verticalGradient(listOf(Color(0xE0EEF2FA), Color(0xC7D8E1EF)))` (`rgba(238,242,250,0.88)` to `rgba(216,225,239,0.78)`)
   - Border: `1.5.dp` solid `Color(0xF0FFFFFF)`
   - Elevation Shadow: `20.dp` blur, `8.dp` Y-offset, color `Color(0x241E1B4B)`

3. **`Modifier.liquidGlassAccent(cornerRadius: Dp = 999.dp)`** (Primary CTA Buttons, Active Filter Pills, Verified Studio Badges):
   - Fill Brush: `Brush.linearGradient(colors = listOf(Color(0xADD8B4FE), Color(0xA3C4B5FD), Color(0xB8BAE6FD)))` (`135deg` Lavender-to-Periwinkle-to-Icy-Sky)
   - Border: `1.dp` solid `Color(0xD9FFFFFF)`
   - Content Text Color: `NexoraColors.InkAccent` (`#1E1B4B`)
   - Shadow: `8.dp` soft glow `Color(0x3893C5FD)`

4. **`Modifier.liquidGlassWhitePill(cornerRadius: Dp = 999.dp)`** (Secondary Action Pills, Inactive Category Chips, Stat Pills):
   - Fill Brush: `Brush.verticalGradient(listOf(Color(0xE6EAEFF8), Color(0xD6D5DEEC)))`
   - Border: `1.5.dp` solid `Color(0xF0FFFFFF)`
   - Content Text Color: `NexoraColors.InkSecondary` (`#334155`)

5. **`Modifier.liquidGlassDarkOverlay(cornerRadius: Dp = 999.dp)`** (Badges over Video Thumbnails & Hero Banners):
   - Fill Color: `Color(0x8C0F172A)` (`rgba(15, 23, 42, 0.55)`)
   - Border: `1.dp` solid `Color(0x47FFFFFF)` (`rgba(255, 255, 255, 0.28)`)
   - Content Text Color: `Color.White`

---

## 2. Typography Hierarchy (`NexoraTypography.kt`)

Use two font families with strict optical alignment and tabular numerals (`fontFeatureSettings = "tnum"`):
1. **Display & Headings (`Plus Jakarta Sans`)**:
   - `HeroDisplay`: `32.sp` (Mobile `24.sp`), `FontWeight.ExtraBold (800)`, `lineHeight = 38.sp`, `letterSpacing = (-0.025).em`
   - `SectionTitle`: `20.sp`, `FontWeight.Bold (700)`, `lineHeight = 26.sp`, `letterSpacing = (-0.02).em`
   - `CardTitle`: `15.sp`, `FontWeight.Bold (700)`, `lineHeight = 20.sp`, `letterSpacing = (-0.015).em`, maxLines = 2, `TextOverflow.Ellipsis`
2. **UI Controls, Body & Numeric Telemetry (`Inter`)**:
   - `NavPillLabel`: `13.sp`, `FontWeight.SemiBold (600)`, `letterSpacing = (-0.01).em`
   - `BodyRegular`: `14.sp`, `FontWeight.Normal (400)`, `lineHeight = 21.sp`, color `InkBody`
   - `MetaCaption`: `12.sp`, `FontWeight.Medium (500)`, `fontFeatureSettings = "tnum"`, color `InkMuted`
   - `BadgeMicro`: `11.sp`, `FontWeight.Bold (700)`, `fontFeatureSettings = "tnum"`, `letterSpacing = 0.02.em`
   - `TelemetryValue`: `22.sp`, `FontWeight.ExtraBold (800)`, `fontFeatureSettings = "tnum"`, color `InkPrimary`

---

## 3. Mathematical Spatial Grid & Concentric Radii System

### 3.1 Base Spatial Unit & Concentric Curvature Formula
- **Base Spatial Unit**: `1u = 8.dp` (`0.5u = 4.dp`, `1.5u = 12.dp`, `2u = 16.dp`, `3u = 24.dp`, `4u = 32.dp`).
- **Concentric Corner Radius Law**: Whenever a rounded inner element (such as a video thumbnail or banner image) is nested inside a padded glass card container, its inner corner radius MUST follow:
  $$R_{\text{inner}} = \max(R_{\text{outer}} - P, 8\text{dp})$$
  where $R_{\text{outer}}$ is the outer container radius and $P$ is the padding between them:
  - `RadiusOuterXL = 28.dp` $\rightarrow$ with `8.dp` padding $\rightarrow$ `RadiusInnerXL = 20.dp`
  - `RadiusOuterLG = 24.dp` $\rightarrow$ with `8.dp` padding $\rightarrow$ `RadiusInnerLG = 16.dp`
  - `RadiusOuterMD = 20.dp` $\rightarrow$ with `8.dp` padding $\rightarrow$ `RadiusInnerMD = 12.dp`

### 3.2 Mathematical Video Card Specification (`NexoraVideoCard.kt`)
Every video card in the feed, discovery grid, and profile page must compute its geometry from its measured card width $W$ using `BoxWithConstraints`:
- **Outer Card Corner Radius**: $r = \min(0.055 \times W, 24\text{dp})$
- **Outer Card Padding**: $P = 10\text{dp}$ on all sides
- **Inner Thumbnail Corner Radius**: $r_{\text{thumb}} = \max(r - 4\text{dp}, 12\text{dp})$
- **Thumbnail Container Height**: $H_t = 0.64 \times W$ (exact `100:64` aspect ratio = `1.5625f`)
- **Thumbnail Overlays**:
  - **Top-Left Optional Badge**: `4K HDR` or `NEW` pill (`liquidGlassDarkOverlay`, `padding(horizontal = 8.dp, vertical = 4.dp)`)
  - **Top-Right Action Cluster**: Two circular `32.dp` frosted dark glass icon buttons (`Share` and `Bookmark / Save to Library`) spaced by `6.dp`. Clicking `Bookmark` toggles saved state with spring scale bounce.
  - **Bottom-Right Duration Pill**: `liquidGlassDarkOverlay`, `11.sp` bold `tabular-nums` (e.g., `18:42`).
  - **Hover / Press Preview Progress Bar**: `3.dp` bottom track with lavender-to-sky gradient fill.
- **Bottom Metadata Bar**:
  - Minimum height $H_m \ge 0.165 \times W$, top padding `10.dp`, horizontal padding `4.dp`.
  - **Left Creator Avatar**: Circular avatar diameter $D_a = \text{clamp}(34\text{dp}, 0.115 \times W, 44\text{dp})$ with `1.5.dp` white border. Clicking the avatar or creator name opens `CreatorProfileView` for that creator using the exact button-origin bubble transition.
  - **Center Text Column**:
    - Video Title (`CardTitle`, `15.sp` Bold `Plus Jakarta Sans`, `InkPrimary`, max 2 lines).
    - Subtitle Row: Creator Name (`12.5.sp` SemiBold `InkSecondary`) + `VerifiedBadge(size = 14.dp)` + `" · "` + Views (`"142K views"`, `tabular-nums`) + `" · "` + Relative Time (`"2 days ago"`).

### 3.3 Custom Premium Verified Badge (`VerifiedBadge.kt`)
Do NOT use a standard checkmark icon. Draw a custom `Canvas` / `ImageVector` **8-Point Faceted Diamond Starburst Seal**:
- **Outer Scalloped 8-Point Starburst Path**: Filled with a `135deg` linear gradient (`#A855F7` Deep Lavender $\rightarrow$ `#6366F1` Electric Indigo $\rightarrow$ `#38BDF8` Icy Cyan) and a `1.2.dp` white specular border.
- **Inner Faceted Octagon Glow**: Subtle inner highlight overlay `rgba(255,255,255,0.28)`.
- **Center Precision Checkmark**: Crisp white vector stroke (`strokeWidth = 2.dp`, `StrokeCap.Round`, `StrokeJoin.Round`) with a tiny 4-point sparkle accent at the top-right vertex.

---

## 4. Application Architecture & Screen Layouts

### 4.1 Global Shell & Floating Pill Header (`NexoraScaffold.kt` & `FloatingHeader.kt`)
- **Background Layer**: Fixed `Canvas` drawing `NexoraColors.CanvasBase` (`#F2F5FC`) and the 3 soft radial gradient ambient orbs (`MeshOrbTopLeftLav`, `MeshOrbTopRightSky`, `MeshOrbBottomCenterInd`).
- **Top Floating Pill Header** (`sticky`, top padding `16.dp`, horizontal margin `24.dp`, max width `1440.dp`, height `58.dp`, `liquidGlassNav(999.dp)`):
  - **Left Brand Identity**: Custom `36.dp` rounded-squircle Nexora prism logo (iridescent violet-to-sky gradient with white play-prism glyph) + `"Nexora"` wordmark (`18.sp` ExtraBold `Plus Jakarta Sans`, tight tracking). Clicking returns to `Home`.
  - **Center Navigation Pill Tabs** (Desktop/Tablet $\ge 768\text{dp}$):
    - 4 primary tabs: `Home`, `Explore`, `Live` (with pulsing rose dot), `Library`.
    - Active tab background slides smoothly between tabs via `animateDpAsState` / `Modifier.sharedBounds` using a frosted white capsule (`liquid-glass-pill-indicator`) with `InkAccent` text and bold icon.
  - **Right Action Cluster**:
    - **Expandable Search Pill**: Compact glass pill (`"Search videos, creators, #tags..."` + `⌘K` badge) that smoothly expands on focus and filters the active feed in real time, with a clear (`X`) button.
    - **Publish / Upload Button**: `liquidGlassAccent` pill with `+` icon and `"Create"` label $\rightarrow$ opens `UploadModal` from button origin.
    - **Notifications Bell Button**: `38.dp` circular glass button with unread count badge (`LiveRose`) $\rightarrow$ opens a floating glass `NotificationsDropdown` anchored to the bell button (with "Mark all read" and interactive notification items).
    - **Admin Telemetry Shield Button**: `38.dp` circular glass button $\rightarrow$ opens `AdminDashboard` modal from button origin.
    - **User Profile Avatar Pill**: Circular `38.dp` avatar (`Aether Visuals`) with iridescent ring and online status dot $\rightarrow$ clicking opens `CreatorProfileView` expanding mathematically from the avatar's exact screen coordinates.
- **Mobile Floating Bottom Navigation Bar** (`< 768.dp`):
  - Anchored `16.dp` above the bottom safe-area inset, `height = 64.dp`, `liquidGlassNav(999.dp)`, containing the 4 primary tabs (`Home`, `Explore`, `Live`, `Library`).

---

### 4.2 View 1: `HomeView.kt` (Spatial Stream & Curated Feed)
1. **Sticky Category Filter Bar**:
   - Horizontally scrollable `LazyRow` of tactile pill chips: `For You`, `Movies`, `Series`, `Music`, `Gaming`, `Learning`, `Travel`, `Nature`, `Architecture`, `Sci-Fi`.
   - Active chip uses `Modifier.liquidGlassAccent()`, inactive chips use `Modifier.liquidGlassWhitePill()`.
2. **Featured Hero Showcase Card** (Shown when `For You` is selected and search is empty):
   - Outer container: `liquidGlassCard(cornerRadius = 28.dp)`, padding `10.dp`.
   - Inner `16:9` / `21:9` wide visual stage (`cornerRadius = 20.dp`, height `380.dp` desktop / `260.dp` mobile):
     - High-resolution cinema backdrop image with bottom-up dark slate gradient scrim (`rgba(15,23,42,0.85)` to transparent).
     - Top-Left Badge Row: `FEATURED PREMIERE` iridescent pill + `4K 60FPS · SPATIAL AUDIO` glass pill.
     - Bottom-Left Content Stack:
       - Creator Identity Row: Avatar (`36.dp`) + `"Aether Visuals"` + `VerifiedBadge` + `"2.4M subscribers"`.
       - Hero Title: `"Echoes of Silent Architecture: Nordic Glass Pavilions"` (`HeroDisplay`).
       - Synopsis: 2-line description in crisp translucent white (`rgba(255,255,255,0.88)`).
       - CTA Row: Primary `"Watch Premiere"` pill button (`White` surface with `InkPrimary` text and Play icon) + Secondary `"Save to Library"` frosted glass pill + `"View Studio"` pill.
3. **Continue Watching Rail** (If user has watch history/progress):
   - Section header with `"Continue Watching"` title + item count badge.
   - Horizontal `LazyRow` of compact `280.dp`-wide glass cards showing thumbnail, resume timestamp (`"12:08 left"`), and an iridescent bottom progress bar (`0f..1f`).
4. **Primary Adaptive Video Grid**:
   - Responsive `LazyVerticalGrid`: `1` column on compact mobile (`<600.dp`), `2` columns on tablet/medium (`600.dp..1024.dp`), `3` columns on desktop (`>1024.dp`), `horizontalArrangement = Arrangement.spacedBy(20.dp)`, `verticalArrangement = Arrangement.spacedBy(20.dp)`.
   - Renders `NexoraVideoCard` items filtered by selected category and search query.

---

### 4.3 View 2: `ExploreView.kt` (Discovery Bento & Trending Pulse)
1. **Discovery Bento Hero Grid** (2-column asymmetric Bento layout):
   - **Left Primary Spotlight Card (`60%` width)**: Curated Editorial Collection (`"Spatial Design & Minimalist Architecture 2025"`) with multi-avatar creator stack, collection video count, and `"Explore Collection"` CTA.
   - **Right Stacked Pulse Cards (`40%` width)**:
     - Top Card: **Trending Creators Leaderboard** (Top 3 creators with avatar, `VerifiedBadge`, subscriber growth `+14.2%`, and quick `Follow` pill).
     - Bottom Card: **Trending Topics & Hashtags** (`#SpatialComputing`, `#NordicLight`, `#UnrealEngine5`, `#AnalogSynth`, `#MinimalistLiving`, `#AtmosphericCinema`) — clicking any hashtag filters the discovery grid below.
2. **Curated Discovery Grid**:
   - Sort selector pills (`Trending Now`, `Most Viewed`, `Newly Published`, `Editor's Picks`) + 3-column `NexoraVideoCard` grid.

---

### 4.4 View 3: `LiveView.kt` (Real-Time Broadcast Stage & Interactive Chat)
1. **Top Live Broadcast Stage (Split 70% Player Stage / 30% Live Glass Chat on Desktop)**:
   - **Left Broadcast Stage (`liquidGlassCard(28.dp)`)**:
     - Live video canvas (`16:9`) with pulsing `LIVE` rose pill (`#F43F5E`), concurrent viewer telemetry pill (`"18,420 watching"`, `tabular-nums`), stream uptime (`"02:14:08"`), and bottom-right quick controls (Mute, Theater, Fullscreen).
     - Below-stage streamer bar: Streamer Avatar + Name + `VerifiedBadge` + Category pill + `"Follow"` CTA + `"Share Stream"` button.
   - **Right Interactive Live Chat Panel (`liquidGlassCard(28.dp)`)**:
     - Header: `"Live Studio Chat"` + active participant indicator.
     - Auto-scrolling `LazyColumn` of chat messages (Avatar, username, optional `MOD` / `SUB` badge, message text, timestamp).
     - Quick Reaction Bar: Floating emoji reaction pills (`🔥`, `✨`, `👏`, `💜`, `🚀`) that spawn floating particle reactions.
     - Bottom Input Bar: Rounded glass text field `"Send a message to studio..."` + iridescent Send icon button (appends user's live message immediately).
2. **Active Live Channels Grid**:
   - Filterable by live category (`All Live`, `3D & Design`, `Music Sessions`, `Game Dev`, `IRL & Travel`) displaying live stream cards with real-time viewer badges.

---

### 4.5 View 4: `LibraryView.kt` (Personal Vault, History & Custom Playlists)
1. **Library Sub-Navigation Tabs**:
   - `Saved Videos`, `Watch History`, `Custom Playlists`, `Subscribed Studios`.
2. **Custom Playlists Section**:
   - `"New Playlist"` CTA button (`liquidGlassAccent`) $\rightarrow$ opens `PlaylistModal` from button origin to create a named playlist with description, privacy toggle (`Public` / `Private`), and video selection checkboxes.
   - Grid of Playlist Cards showing a 2x2 mosaic of video thumbnails, playlist title, video count, and delete/play actions.
3. **Saved Videos & Watch History Grids**:
   - Renders saved or watched `NexoraVideoCard` items with an optional `"Clear History"` or `"Remove from Saved"` quick action.

---

### 4.6 View 5: `CreatorProfileView.kt` (Unified Banner Studio Card & Labeled Liquid-Glass Tabs)
Accessible by clicking the top-right user avatar in the Header or any creator avatar/name across the app.
1. **Sticky Sub-Navigation Bar**:
   - Left: `"Back"` pill button (`ArrowLeft` + `"Back"`) that collapses the profile view back into its origin button.
   - Center: Labeled liquid-glass tab bar (`Overview`, `Videos`, `Collections`, `Live`, `About`) with video count badge on `Videos` and green pulsing dot on `Live`.
   - Right: Quick studio links (`Website` globe pill + `Share` icon button).
2. **Unified Hero Banner Card (`liquidGlassCard(28.dp)`, padding `8.dp`)**:
   - Inner Banner Box (`cornerRadius = 20.dp`, height `240.dp` mobile / `300.dp` desktop):
     - Full-bleed studio cover artwork + dark slate gradient scrim (`from-[#0F172A]/90 via-[#0F172A]/45 to-transparent`).
     - **Top Overlay Bar**:
       - Top-Left: `"Verified Studio"` glass pill (with `Sparkles` icon) + Location pill (`"Zurich, Switzerland"`).
       - Top-Right: If viewing own profile, `"Edit Profile"` glass pill button (opens `EditProfileModal` from button coordinates) + `"Share"` button.
     - **Bottom Overlaid Identity & Actions**:
       - `72.dp` (or `80.dp` desktop) Rounded-Squircle Avatar (`cornerRadius = 20.dp`) with `2.dp` white border and bottom-right green online indicator dot.
       - Studio Name (`28.sp` ExtraBold White) + `VerifiedBadge(size = 22.dp)` + Handle pill (`"@aethervisuals"`) + Category pill (`"Spatial Design & Cinema"`).
       - Studio Bio (max 2 lines, translucent white `rgba(255,255,255,0.85)`).
       - Action Buttons: `"Watch Live"` frosted glass button (with rose pulsing dot, switches to `Live` tab) + `"Following" / "Subscribe"` toggle pill button (`liquidGlassAccent` when subscribed, white when unsubscribed).
3. **4-Column Channel Telemetry Strip** (`grid-cols-2 lg:grid-cols-4`, gap `12.dp`):
   - 4 `liquidGlassCard(20.dp)` metric cards:
     1. **Subscribers**: e.g. `184.2K` (`Users` icon)
     2. **Total Views**: e.g. `14.8M` (`Eye` icon)
     3. **Published Works**: e.g. `42` (`Film` icon)
     4. **Member Since**: e.g. `Oct 2022` (`Calendar` icon)
4. **Tab Content Panels** (Animated with `BubbleTransition` from the clicked tab button):
   - **`Overview` Tab**:
     - **Featured Release Spotlight**: 2-column horizontal glass card (`16:9` thumbnail on left with `FEATURED RELEASE` badge, title, full description, stats, and `"Watch Featured Film"` + `"Save"` buttons on right).
     - **Recent Uploads Header + 3-Column Video Grid**.
     - **Curated Series Preview** (3 collection cards with cover art, episode count badge, and series description).
   - **`Videos` Tab**: Filter pills (`Latest`, `Popular`) + full 3-column creator video grid.
   - **`Collections` Tab**: Full grid of Curated Series & Playlists; clicking a collection opens the first episode in `VideoPlayerOverlay`.
   - **`Live` Tab**: Large Live Studio Stage preview with `"Enter Live Broadcast Room"` CTA button.
   - **`About` Tab**: 3-column layout with full Studio Biography & Equipment/Specs on the left (2 cols) and Links & Press Inquiries card on the right (1 col).
5. **Inline `EditProfileModal` (Portaled Bubble Modal)**:
   - Allows editing Display Name, Handle (`@handle`), Category / Tagline, Studio Bio, Location, Website URL, and Cover Banner preset or URL, saving state immediately to the active profile.

---

### 4.7 Modals & Overlays (`VideoPlayerOverlay`, `UploadModal`, `AdminDashboard`)
All modals render over a frosted backdrop (`Color(0x590F172A)` with `16.dp` blur) and expand from the exact clicked button via `BubbleModalPanel`:
1. **`VideoPlayerOverlay.kt`**:
   - Supports **Standard Modal Mode** and **Expanded Theater Mode**.
   - Interactive playback canvas with custom glass transport controls (Play/Pause, Seek bar with buffered & played gradient track, Timecode `04:12 / 18:42`, Volume slider, Quality selector `4K60` / `1080p`, Playback speed `1x` / `1.25x` / `1.5x`, Theater toggle, Close button).
   - Below Player: Video Title, Creator Info bar with Subscribe toggle, Like / Share / Save to Playlist / Download action pills, expandable description card, Interactive Comments Section (add new comment, like comments), and right-hand **Up Next Queue** rail.
2. **`UploadModal.kt`**:
   - Interactive drag-and-drop / file picker zone, Video Title, Description, Category selector dropdown, Thumbnail URL / preset selector, `4K HDR` toggle, and simulated upload progress bar that publishes the new video directly into the live feed.
3. **`AdminDashboard.kt`**:
   - Platform telemetry cards (Active Streams, Bandwidth, Total Creators, Flagged Content), Content Moderation queue (Approve / Remove actions), and System Health metrics.

---

## 5. Mathematical Button-Origin Bubble Transition Engine (`BubbleMath.kt` & `BubbleTransition.kt`)

### 5.1 Core Mathematical Formulation
Every view switch, tab change, profile open, video launch, and modal open MUST originate from the exact screen-space center $(O_x, O_y)$ of the button the user clicked—never from an arbitrary corner or generic fade.

#### A. Global Pointer / Button Coordinate Capture (`OriginTracker.kt`)
Attach a global pointer tracker or `Modifier.onGloballyPositioned` + pointer press interceptor at the root `Box` so whenever any interactive button is tapped, its exact geometric center in root window coordinates is recorded:
$$O_x = \text{boundsInRoot.center.x}, \quad O_y = \text{boundsInRoot.center.y}$$
Also normalize $(O_x, O_y)$ against the viewport size $(W_v, H_v)$:
$$u = \text{clamp}\left(\frac{O_x}{W_v}, 0.05, 0.95\right), \quad v = \text{clamp}\left(\frac{O_y}{H_v}, 0.05, 0.95\right)$$

#### B. Homothety Translation Formula for Stage & Tab Views (`computeStageBubbleGeometry`)
When a stage container (with top-left $(L, T)$ and dimensions $(W, H)$) expands from initial scale $s_0 = 0.055$ to final scale $s_1 = 1.0$:
1. Compute the local transform pivot inside the container:
   $$A_x = \text{clamp}(O_x - L, 0, W), \quad A_y = \text{clamp}(O_y - T, 0, H)$$
   $$\text{TransformOrigin} = \text{TransformOrigin}\left(\frac{A_x}{W}, \frac{A_y}{H}\right)$$
2. Compute the residual initial translation $(tx_0, ty_0)$ so that at $t = 0$, the container's pivot point coincides with the exact button center $(O_x, O_y)$ even if $(O_x, O_y)$ lies outside the container bounds (such as a header button above the content stage):
   $$\text{targetAtOrigin}_x = L + A_x, \quad \text{targetAtOrigin}_y = T + A_y$$
   $$tx_0 = O_x - \text{targetAtOrigin}_x, \quad ty_0 = O_y - \text{targetAtOrigin}_y$$
3. Compute the maximum Euclidean distance $R_{\max}$ from $(A_x, A_y)$ to the 4 corners of the container $(0,0), (W,0), (0,H), (W,H)$:
   $$R_{\max} = \max_{(cx, cy)} \sqrt{(cx - A_x)^2 + (cy - A_y)^2}$$
   Use $R_{\max}$ to drive a circular clip / rounded-corner morph from pill radius ($999\text{dp}$) at $p = 0$ down to `0.dp` (or the card's native corner radius) as progress $p \to 1$.

#### C. Center-to-Center Vector Formula for Centered Modals (`computeModalBubbleGeometry`)
When a centered modal dialog of width $W_m$ and height $H_m$ is centered in the viewport at $(M_{cx}, M_{cy}) = (W_v / 2, H_v / 2)$:
1. The exact translation offset from the modal center to the clicked button center is:
   $$\Delta_x = O_x - M_{cx}, \quad \Delta_y = O_y - M_{cy}$$
2. Animate progress $p \in [0, 1]$ using a critically damped spring:
   ```kotlin
   val progress = remember { Animatable(0f) }
   LaunchedEffect(triggerKey) {
       progress.snapTo(0f)
       progress.animateTo(
           targetValue = 1f,
           animationSpec = spring(
               dampingRatio = 0.88f, // Critically damped, zero harsh oscillation
               stiffness = 380f
           )
       )
   }
   ```
3. Apply the interpolated affine transform on the GPU via `Modifier.graphicsLayer`:
   ```kotlin
   val p = progress.value
   val scale = lerp(0.04f, 1f, p)
   val translationX = lerp(deltaX, 0f, p)
   val translationY = lerp(deltaY, 0f, p)
   val dynamicCornerRadius = lerp(220.dp, 28.dp, (p * 1.25f).coerceIn(0f, 1f))
   val alpha = (p * 3.2f).coerceIn(0f, 1f)

   Modifier.graphicsLayer {
       this.scaleX = scale
       this.scaleY = scale
       this.translationX = translationX
       this.translationY = translationY
       this.alpha = alpha
       this.shape = RoundedCornerShape(dynamicCornerRadius)
       this.clip = true
   }
   ```

#### D. Tactile Specular Bubble Ring on Click (`BubbleClickRippleOverlay.kt`)
Whenever the user taps a button that triggers a transition, spawn a short-lived (`440ms`) GPU-drawn expanding specular ring centered at $(O_x, O_y)$:
- Radius animates from `6.dp` to `120.dp` with cubic-bezier ease-out.
- Alpha animates from `0.75f` to `0f`.
- Drawn with a radial gradient stroke (`Lavender400` $\rightarrow$ `Sky300` $\rightarrow$ `White`).

---

## 6. Performance & Engineering Constraints
1. **Zero Main-Thread Jank (60/120 FPS Target)**:
   - Always read animated state (`progress.value`) inside `Modifier.graphicsLayer { ... }` or `Modifier.drawWithContent { ... }` lambdas so animations execute entirely in the Draw/RenderNode phase without triggering Compose layout or recomposition.
   - Provide stable keys (`key = { video.id }`) in all `LazyVerticalGrid`, `LazyRow`, and `LazyColumn` lists.
2. **State Management (`NexoraViewModel.kt`)**:
   - Maintain a single immutable `NexoraUiState` via `StateFlow` holding:
     - `activeTab: NavTab` (`HOME`, `EXPLORE`, `LIVE`, `LIBRARY`, `PROFILE`)
     - `selectedCategory: String`
     - `searchQuery: String`
     - `lastClickOrigin: ClickOrigin` (`x`, `y`, `u`, `v`, `timestamp`)
     - `videos: List<VideoItem>` (with rich realistic 4K architectural, spatial design, sci-fi, nature, and music streams)
     - `activeVideo: VideoItem?` (for `VideoPlayerOverlay`)
     - `activeCreator: CreatorProfile` (supports viewing own studio profile or any video creator's studio profile, plus live profile editing)
     - `savedVideoIds: Set<String>`, `watchHistoryIds: List<String>`, `playlists: List<Playlist>`
     - `notifications: List<NotificationItem>`
     - `isUploadModalOpen: Boolean`, `isAdminModalOpen: Boolean`, `isPlaylistModalOpen: Boolean`, `isEditProfileModalOpen: Boolean`
3. **Unit Testing (`BubbleMathTest.kt`)**:
   - Include pure Kotlin unit tests verifying:
     - `computeStageBubbleGeometry` places the scaled element's pivot at $(O_x, O_y)$ at $p = 0$ and converges to $(0, 0)$ offset with scale `1.0f` at $p = 1$.
     - `computeModalBubbleGeometry` translates the modal center by $(\Delta_x, \Delta_y) = (O_x - W_v/2, O_y - H_v/2)$ at $p = 0$.
     - Concentric radii helper enforces $R_{\text{inner}} = \max(R_{\text{outer}} - P, 8\text{dp})$.
