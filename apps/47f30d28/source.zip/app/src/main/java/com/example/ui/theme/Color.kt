package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val KeyboardBackground = Color(0xFF4E4646)
val KeyCaps = Color(0xFF706A6A)
val KeyText = Color(0xFFFFFFFF)
val AccentOrange = Color(0xFFD26F42)

val SecondaryText = Color(0xFFE0E0E0)
val SubduedCaps = Color(0xFF5A5454)
