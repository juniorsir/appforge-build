package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Environment
import android.util.Log
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.DownloadEntity
import com.example.data.DownloadRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import java.nio.ByteBuffer
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import com.yausername.youtubedl_android.YoutubeDLResponse

data class CodecUi(
    val videoCodec: String?,
    val audioCodec: String?
)

data class VideoFormatUi(
    val formatId: Int, // Position or index in the list
    val type: String,   // "combined" / "audio"
    val quality: String, // "720p", "360p", "128kbps" etc
    val ext: String,     // "mp4", "m4a", etc
    val sizeText: String,
    val downloadUrl: String,
    val sizeBytes: Long,
    val userAgent: String = "",
    val height: Int? = null,
    val hasAudio: Boolean = false,
    val tbr: Double? = null
)

data class AnalyzedVideo(
    val id: String,
    val title: String,
    val author: String,
    val durationText: String,
    val thumbnailUrl: String,
    val formats: List<VideoFormatUi>,
    val originalUrl: String = ""
)

enum class DownloadStatus {
    PENDING, DOWNLOADING, COMPLETED, FAILED
}

data class ActiveDownloadTask(
    val id: String, // videoId
    val title: String,
    val progress: Float, // 0f to 1f
    val speedText: String,
    val downloadedBytes: Long,
    val totalBytes: Long,
    val status: DownloadStatus,
    val ext: String,
    val error: String? = null
)

/**
 * Robust help-class to manage detection, permissions, CPU compatibility,
 * and high-fidelity ProcessBuilder execution of modern yt-dlp binary units.
 */
object YtdlpBinaryHelper {
    const val TAG = "YtdlpBinaryHelper"

    data class ExecutionResult(
        val exitCode: Int,
        val stdout: String,
        val stderr: String,
        val isSupported: Boolean,
        val logs: List<String>
    )

    fun checkExecutableRestrictions(context: Context): String {
        val sdkInt = android.os.Build.VERSION.SDK_INT
        val targetSdk = context.applicationInfo.targetSdkVersion
        val isRestricted = sdkInt >= 29 && targetSdk >= 29
        return buildString {
            append("==================================================\n")
            append("🛡️ SYSTEM DIAGNOSTICS: ANDROID OS ENGINE BOUNDS\n")
            append("==================================================\n")
            append("✔ Android OS API Level: $sdkInt (${android.os.Build.VERSION.RELEASE})\n")
            append("✔ Application Target SDK: $targetSdk\n")
            append("✔ Binary Sandbox Path: codeCacheDir/bin\n")
            append("✔ CPU Architecture: ${getCpuArchitecture()}\n")
            append("✔ Modern W^X Restrictions: ${if (isRestricted) "ACTIVE (SELinux actively blocks raw binary execution on writable mount-paths)" else "INACTIVE"}\n")
            if (isRestricted) {
                append("\n📢 EXPLANATION:\n")
                append("Modern Android OS versions (Android 10 to 15+) enforce Write-XOR-Execute security boundaries. ")
                append("To prevent dynamic malware injection, executable code must only be loaded from packaged read-only native directories (lib/). ")
                append("Executing dynamically downloaded custom binary CLI utilities will trigger kernel 'Permission Denied / error=13' blocks on standard device builds.\n\n")
                append("🌟 FAILSAFE RECOVERY AUTOMATED:\n")
                append("This application is fully responsive! When W^X is restricted, we gracefully route downloads and metadata searches to our beautifully integrated native stream player-scraper bypass, ensuring offline downloads continue to operate flawlessly!")
            } else {
                append("\n⚡ SUCCESS:\nYour system is architecture-eligible to run native command-line executables.")
            }
        }
    }

    fun getCpuArchitecture(): String {
        val supportedAbis = android.os.Build.SUPPORTED_ABIS.joinToString(", ")
        val primaryAbi = android.os.Build.SUPPORTED_ABIS.firstOrNull() ?: android.os.Build.CPU_ABI
        return "ABI: $primaryAbi [Supported ABIs: $supportedAbis]"
    }

    fun getBinaryFile(context: Context): File {
        val binDir = File(context.codeCacheDir, "bin")
        if (!binDir.exists()) {
            binDir.mkdirs()
        }
        return File(binDir, "yt-dlp")
    }

    fun setupPermissions(context: Context, logCallback: (String) -> Unit): Boolean {
        val targetFile = getBinaryFile(context)
        if (!targetFile.exists()) {
            logCallback("Permission abort: Binary file does not exist.")
            return false
        }
        logCallback("Resolving binary path: ${targetFile.absolutePath}")
        val readable = targetFile.setReadable(true, false)
        val executable = targetFile.setExecutable(true, false)
        logCallback("Java standard file attributes: setReadable=$readable, setExecutable=$executable")

        try {
            logCallback("Executing supplementary permission reinforcement: chmod 755")
            val pb = ProcessBuilder("chmod", "755", targetFile.absolutePath)
            val process = pb.start()
            val chmodExit = process.waitFor()
            logCallback("Chmod return response: $chmodExit")
        } catch (e: Exception) {
            logCallback("Warning: Supplementary chmod exception: ${e.localizedMessage}")
        }
        return targetFile.canExecute()
    }

    fun executeCommand(context: Context, arguments: List<String>, logCallback: (String) -> Unit): ExecutionResult {
        val logs = mutableListOf<String>()
        val addLogLocal = { msg: String ->
            logs.add(msg)
            logCallback(msg)
        }

        val targetFile = getBinaryFile(context)
        val sdkInt = android.os.Build.VERSION.SDK_INT
        val targetSdk = context.applicationInfo.targetSdkVersion

        addLogLocal("Executing Command: ./yt-dlp ${arguments.joinToString(" ")}")
        addLogLocal("Path: ${targetFile.absolutePath}")
        addLogLocal("Physical states: exists=${targetFile.exists()}, canRead=${targetFile.canRead()}, canExecute=${targetFile.canExecute()}")
        addLogLocal("Device Signature: SDK $sdkInt, CPU: ${getCpuArchitecture()}")

        if (!targetFile.exists()) {
            addLogLocal("Execution Cancelled: Executable is not present.")
            return ExecutionResult(-1, "", "Executable not found", false, logs)
        }

        try {
            val commandList = mutableListOf<String>()
            commandList.add(targetFile.absolutePath)
            commandList.addAll(arguments)

            val pb = ProcessBuilder(commandList)
            pb.directory(targetFile.parentFile)
            
            // Inject standard environment variables for localized sandbox operations
            val env = pb.environment()
            env["HOME"] = context.codeCacheDir.absolutePath
            env["TMPDIR"] = context.codeCacheDir.absolutePath

            addLogLocal("Initializing ProcessBuilder pipeline...")
            val process = pb.start()

            val stdoutBuilder = java.lang.StringBuilder()
            val stderrBuilder = java.lang.StringBuilder()

            // Read pipelines concurrently in background buffers to prevent process blocks or deadlocks
            val stdoutThread = Thread {
                try {
                    process.inputStream.bufferedReader().use { br ->
                        var line: String?
                        while (br.readLine().also { line = it } != null) {
                            synchronized(stdoutBuilder) {
                                stdoutBuilder.append(line).append("\n")
                            }
                        }
                    }
                } catch (e: Exception) {
                    addLogLocal("Stdout consumer exception: ${e.localizedMessage}")
                }
            }

            val stderrThread = Thread {
                try {
                    process.errorStream.bufferedReader().use { br ->
                        var line: String?
                        while (br.readLine().also { line = it } != null) {
                            synchronized(stderrBuilder) {
                                stderrBuilder.append(line).append("\n")
                            }
                        }
                    }
                } catch (e: Exception) {
                    addLogLocal("Stderr consumer exception: ${e.localizedMessage}")
                }
            }

            stdoutThread.start()
            stderrThread.start()

            val exitCode = process.waitFor()
            stdoutThread.join(2500)
            stderrThread.join(2500)

            val stdoutString = synchronized(stdoutBuilder) { stdoutBuilder.toString().trim() }
            val stderrString = synchronized(stderrBuilder) { stderrBuilder.toString().trim() }

            addLogLocal("Process exited with code: $exitCode")

            val isPermDenied = exitCode == 13 || stderrString.contains("Permission denied", ignoreCase = true)
            val isSupported = !isPermDenied

            return ExecutionResult(exitCode, stdoutString, stderrString, isSupported, logs)

        } catch (e: Exception) {
            val errorMsg = e.localizedMessage ?: e.toString()
            addLogLocal("ProcessBuilder crash warning: $errorMsg")
            
            val hasSecBlock = errorMsg.contains("Permission denied", ignoreCase = true) || errorMsg.contains("error=13")
            return ExecutionResult(-1, "", errorMsg, !hasSecBlock, logs)
        }
    }
}

class VideoDownloaderViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val repository = DownloadRepository(database.downloadDao())

    // Search history and Browsing history Flow
    val searchHistory: StateFlow<List<com.example.data.SearchHistoryEntity>> = database.historyDao().getSearchHistory()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val browsingHistory: StateFlow<List<com.example.data.BrowsingHistoryEntity>> = database.historyDao().getBrowsingHistory()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _personalizedVideos = MutableStateFlow<List<YtdlpPipelineManager.SearchResult>>(emptyList())
    val personalizedVideos: StateFlow<List<YtdlpPipelineManager.SearchResult>> = _personalizedVideos.asStateFlow()

    private var lastObservedSearchQuery = ""

    init {
        // Collect search history to automatically fetch recommendations for the latest query
        viewModelScope.launch(Dispatchers.IO) {
            searchHistory.collect { history ->
                val latestQuery = history.firstOrNull()?.query
                if (latestQuery != null && latestQuery != lastObservedSearchQuery) {
                    lastObservedSearchQuery = latestQuery
                    try {
                        val results = com.example.data.YoutubeRepository.fetchSearchVideos(getApplication(), latestQuery)
                        val mapped = results.take(10).map {
                            YtdlpPipelineManager.SearchResult(
                                id = it.id,
                                title = it.title,
                                author = it.author,
                                duration = it.durationText,
                                thumbnailUrl = it.thumbnailUrl,
                                originalUrl = it.originalUrl
                            )
                        }
                        _personalizedVideos.value = mapped
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                } else if (latestQuery == null) {
                    lastObservedSearchQuery = ""
                    _personalizedVideos.value = emptyList()
                }
            }
        }
    }

    fun recordSearchQuery(query: String) {
        if (query.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                database.historyDao().insertSearch(com.example.data.SearchHistoryEntity(query = query.trim()))
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun deleteSearchQuery(query: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                database.historyDao().deleteSearchByQuery(query)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun clearAllSearchHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                database.historyDao().clearSearchHistory()
                _personalizedVideos.value = emptyList()
                lastObservedSearchQuery = ""
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun recordBrowsingVideo(video: YtdlpPipelineManager.SearchResult) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                database.historyDao().insertBrowsingRecord(
                    com.example.data.BrowsingHistoryEntity(
                        id = video.id,
                        title = video.title,
                        author = video.author,
                        durationText = video.duration,
                        thumbnailUrl = video.thumbnailUrl,
                        originalUrl = video.originalUrl
                    )
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun recordBrowsingVideo(video: com.example.data.YtVideo) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                database.historyDao().insertBrowsingRecord(
                    com.example.data.BrowsingHistoryEntity(
                        id = video.id,
                        title = video.title,
                        author = video.author,
                        durationText = video.durationText,
                        thumbnailUrl = video.thumbnailUrl,
                        originalUrl = video.originalUrl
                    )
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun recordBrowsingVideo(download: DownloadEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Stripping live stream prefixes if any
                val cleanTitle = download.title.replace("[Live Stream] ", "").replace("[Streaming Video] ", "").replace("[Streaming Audio] ", "")
                database.historyDao().insertBrowsingRecord(
                    com.example.data.BrowsingHistoryEntity(
                        id = download.id,
                        title = cleanTitle,
                        author = download.author,
                        durationText = download.durationText,
                        thumbnailUrl = download.thumbnailUrl,
                        originalUrl = download.localPath
                    )
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun deleteBrowsingRecord(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                database.historyDao().deleteBrowsingRecordById(id)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun clearAllBrowsingHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                database.historyDao().clearBrowsingHistory()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Initialization block moved to avoid NPEs

    // Expose download history from Room
    val downloadHistory: StateFlow<List<DownloadEntity>> = repository.allDownloads
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _deviceMedia = MutableStateFlow<List<DownloadEntity>>(emptyList())
    val deviceMedia: StateFlow<List<DownloadEntity>> = _deviceMedia.asStateFlow()

    fun loadDeviceMedia(context: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            val mediaList = mutableListOf<DownloadEntity>()
            try {
                // Videos
                val videoUri = android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                val videoProjection = arrayOf(
                    android.provider.MediaStore.Video.Media._ID,
                    android.provider.MediaStore.Video.Media.DISPLAY_NAME,
                    android.provider.MediaStore.Video.Media.DURATION,
                    android.provider.MediaStore.Video.Media.DATA,
                    android.provider.MediaStore.Video.Media.SIZE,
                    android.provider.MediaStore.Video.Media.DATE_ADDED
                )
                context.contentResolver.query(videoUri, videoProjection, null, null, "${android.provider.MediaStore.Video.Media.DATE_ADDED} DESC")?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Video.Media._ID)
                    val nameCol = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Video.Media.DISPLAY_NAME)
                    val durCol = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Video.Media.DURATION)
                    val dataCol = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Video.Media.DATA)
                    val sizeCol = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Video.Media.SIZE)
                    val dateCol = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Video.Media.DATE_ADDED)
                    
                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idCol)
                        val name = cursor.getString(nameCol) ?: "Unknown Video"
                        val durMs = cursor.getLong(durCol)
                        val data = cursor.getString(dataCol) ?: continue
                        val size = cursor.getLong(sizeCol)
                        val date = cursor.getLong(dateCol) * 1000
                        val mins = durMs / 60000
                        val secs = (durMs % 60000) / 1000
                        val durText = String.format("%02d:%02d", mins, secs)
                        
                        mediaList.add(DownloadEntity(
                            id = "device_video_$id",
                            title = name,
                            author = "Device Media",
                            durationText = durText,
                            thumbnailUrl = data, // coil can handle video paths
                            localPath = data,
                            fileSize = size,
                            downloadedAt = date
                        ))
                    }
                }

                // Audio
                val audioUri = android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                val audioProjection = arrayOf(
                    android.provider.MediaStore.Audio.Media._ID,
                    android.provider.MediaStore.Audio.Media.DISPLAY_NAME,
                    android.provider.MediaStore.Audio.Media.DURATION,
                    android.provider.MediaStore.Audio.Media.DATA,
                    android.provider.MediaStore.Audio.Media.SIZE,
                    android.provider.MediaStore.Audio.Media.DATE_ADDED,
                    android.provider.MediaStore.Audio.Media.ARTIST
                )
                
                val selection = "${android.provider.MediaStore.Audio.Media.IS_MUSIC} != 0"
                context.contentResolver.query(audioUri, audioProjection, selection, null, "${android.provider.MediaStore.Audio.Media.DATE_ADDED} DESC")?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media._ID)
                    val nameCol = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.DISPLAY_NAME)
                    val artistCol = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.ARTIST)
                    val durCol = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.DURATION)
                    val dataCol = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.DATA)
                    val sizeCol = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.SIZE)
                    val dateCol = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Audio.Media.DATE_ADDED)
                    
                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idCol)
                        val name = cursor.getString(nameCol) ?: "Unknown Audio"
                        val author = cursor.getString(artistCol) ?: "Device Media"
                        val durMs = cursor.getLong(durCol)
                        val data = cursor.getString(dataCol) ?: continue
                        val size = cursor.getLong(sizeCol)
                        val date = cursor.getLong(dateCol) * 1000
                        val mins = durMs / 60000
                        val secs = (durMs % 60000) / 1000
                        val durText = String.format("%02d:%02d", mins, secs)
                        
                        mediaList.add(DownloadEntity(
                            id = "device_audio_$id",
                            title = name,
                            author = author,
                            durationText = durText,
                            thumbnailUrl = "", // handled in UI for audio
                            localPath = data,
                            fileSize = size,
                            downloadedAt = date
                        ))
                    }
                }

                _deviceMedia.value = mediaList.sortedByDescending { it.downloadedAt }
            } catch (e: Exception) {
                Log.e("VideoDownloader", "Failed to load device media", e)
            }
        }
    }

    private val _videoUrlInput = MutableStateFlow("")
    val videoUrlInput: StateFlow<String> = _videoUrlInput.asStateFlow()

    // YouTube Player Page specific state flows using YouTube Data API or high quality prototype simulation fallback
    private val _videoDetails = MutableStateFlow<com.example.data.YtVideoDetails?>(null)
    val videoDetails: StateFlow<com.example.data.YtVideoDetails?> = _videoDetails.asStateFlow()

    private val _videoComments = MutableStateFlow<List<com.example.data.YtComment>>(emptyList())
    val videoComments: StateFlow<List<com.example.data.YtComment>> = _videoComments.asStateFlow()

    private val _relatedVideos = MutableStateFlow<List<com.example.data.YtVideo>>(emptyList())
    val relatedVideos: StateFlow<List<com.example.data.YtVideo>> = _relatedVideos.asStateFlow()

    private val _isLoadingDetails = MutableStateFlow(false)
    val isLoadingDetails: StateFlow<Boolean> = _isLoadingDetails.asStateFlow()

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _analyzedVideo = MutableStateFlow<AnalyzedVideo?>(null)
    val analyzedVideo: StateFlow<AnalyzedVideo?> = _analyzedVideo.asStateFlow()

    private val _analysisError = MutableStateFlow<String?>(null)
    val analysisError: StateFlow<String?> = _analysisError.asStateFlow()

    private val prefs: SharedPreferences = application.getSharedPreferences("TubeStreamPrefs", Context.MODE_PRIVATE)

    private val _usePublicDownloads = MutableStateFlow(prefs.getBoolean("usePublicDownloads", false))
    val usePublicDownloads: StateFlow<Boolean> = _usePublicDownloads.asStateFlow()

    private val _showAdvancedFormats = MutableStateFlow(prefs.getBoolean("showAdvancedFormats", false))
    val showAdvancedFormats: StateFlow<Boolean> = _showAdvancedFormats.asStateFlow()

    fun updateShowAdvancedFormats(show: Boolean) {
        prefs.edit().putBoolean("showAdvancedFormats", show).apply()
        _showAdvancedFormats.value = show
    }

    private val _themeMode = MutableStateFlow(prefs.getString("themeMode", "System Default") ?: "System Default")
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    fun updateThemeMode(mode: String) {
        prefs.edit().putString("themeMode", mode).apply()
        _themeMode.value = mode
    }

    private val _defaultDownloadQuality = MutableStateFlow(prefs.getString("defaultDownloadQuality", "Ask Every Time") ?: "Ask Every Time")
    val defaultDownloadQuality: StateFlow<String> = _defaultDownloadQuality.asStateFlow()

    private val _urlHistory = MutableStateFlow<List<String>>(
        prefs.getString("urlHistory", "")?.split(",")?.filter { it.isNotBlank() } ?: emptyList()
    )
    val urlHistory: StateFlow<List<String>> = _urlHistory.asStateFlow()

    fun updateDefaultDownloadQuality(quality: String) {
        prefs.edit().putString("defaultDownloadQuality", quality).apply()
        _defaultDownloadQuality.value = quality
    }

    fun clearUrlHistory() {
        prefs.edit().remove("urlHistory").apply()
        _urlHistory.value = emptyList()
    }

    private val _isAudioOnlyMode = MutableStateFlow(false)
    val isAudioOnlyMode: StateFlow<Boolean> = _isAudioOnlyMode.asStateFlow()

    fun toggleAudioOnlyMode() {
        _isAudioOnlyMode.value = !_isAudioOnlyMode.value
    }

    fun updateUsePublicDownloads(usePublic: Boolean) {
        prefs.edit().putBoolean("usePublicDownloads", usePublic).apply()
        _usePublicDownloads.value = usePublic
    }

    private val _showFloatingWidget = MutableStateFlow(false)
    val showFloatingWidget: StateFlow<Boolean> = _showFloatingWidget.asStateFlow()

    fun triggerFloatingWidget(show: Boolean) {
        _showFloatingWidget.value = show
    }

    val activeDownloadsOnUi: StateFlow<Map<String, ActiveDownloadTask>> = com.example.DownloadManager.activeDownloads
    val activeDownloads: StateFlow<Map<String, ActiveDownloadTask>> = com.example.DownloadManager.activeDownloads

    private val _searchResults = MutableStateFlow<List<YtdlpPipelineManager.SearchResult>>(emptyList())
    val searchResults: StateFlow<List<YtdlpPipelineManager.SearchResult>> = _searchResults.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    // Home Screen specific state flows with highly premium, organic pre-cached video metadata
    private val _homeVideos = MutableStateFlow<List<YtdlpPipelineManager.SearchResult>>(
        listOf(
            YtdlpPipelineManager.SearchResult(
                id = "dQw4w9WgXcQ",
                title = "Rick Astley - Never Gonna Give You Up (Official Music Video)",
                author = "Rick Astley",
                duration = "03:32",
                thumbnailUrl = "https://img.youtube.com/vi/dQw4w9WgXcQ/mqdefault.jpg",
                originalUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
            ),
            YtdlpPipelineManager.SearchResult(
                id = "hHW1oY26kxQ",
                title = "The Weeknd - Blinding Lights (Official Audio)",
                author = "The Weeknd",
                duration = "03:21",
                thumbnailUrl = "https://img.youtube.com/vi/hHW1oY26kxQ/mqdefault.jpg",
                originalUrl = "https://www.youtube.com/watch?v=hHW1oY26kxQ"
            ),
            YtdlpPipelineManager.SearchResult(
                id = "9bZkp7q19f0",
                title = "PSY - GANGNAM STYLE(강남스타일) M/V",
                author = "officialpsy",
                duration = "04:12",
                thumbnailUrl = "https://img.youtube.com/vi/9bZkp7q19f0/mqdefault.jpg",
                originalUrl = "https://www.youtube.com/watch?v=9bZkp7q19f0"
            ),
            YtdlpPipelineManager.SearchResult(
                id = "L_LUpnjgPso",
                title = "lofi hip hop radio 📚 beats to relax/study to",
                author = "Lofi Girl",
                duration = "LIVE",
                thumbnailUrl = "https://img.youtube.com/vi/L_LUpnjgPso/mqdefault.jpg",
                originalUrl = "https://www.youtube.com/watch?v=L_LUpnjgPso"
            ),
            YtdlpPipelineManager.SearchResult(
                id = "kJQP7kiw5Fk",
                title = "Luis Fonsi - Despacito ft. Daddy Yankee",
                author = "LuisFonsiVEVO",
                duration = "04:41",
                thumbnailUrl = "https://img.youtube.com/vi/kJQP7kiw5Fk/mqdefault.jpg",
                originalUrl = "https://www.youtube.com/watch?v=kJQP7kiw5Fk"
            ),
            YtdlpPipelineManager.SearchResult(
                id = "V-_O7nl0Ii0",
                title = "Billie Eilish - Ocean Eyes (Official Music Video)",
                author = "Billie Eilish",
                duration = "03:15",
                thumbnailUrl = "https://img.youtube.com/vi/V-_O7nl0Ii0/mqdefault.jpg",
                originalUrl = "https://www.youtube.com/watch?v=V-_O7nl0Ii0"
            )
        )
    )
    val homeVideos: StateFlow<List<YtdlpPipelineManager.SearchResult>> = _homeVideos.asStateFlow()

    private val _isHomeSearching = MutableStateFlow(false)
    val isHomeSearching: StateFlow<Boolean> = _isHomeSearching.asStateFlow()

    private val _homeSelectedCategory = MutableStateFlow("Trending")
    val homeSelectedCategory: StateFlow<String> = _homeSelectedCategory.asStateFlow()

    private val _homeError = MutableStateFlow<String?>(null)
    val homeError: StateFlow<String?> = _homeError.asStateFlow()

    fun selectHomeCategory(category: String) {
        _homeSelectedCategory.value = category
        fetchHomeVideos(category)
    }

    fun fetchHomeVideos(query: String) {
        _isHomeSearching.value = true
        _homeError.value = null
        val staticCategories = listOf("Trending", "Music", "Gaming", "Tech & AI", "Nature & Space", "Lo-Fi Beats")
        if (query !in staticCategories) {
            recordSearchQuery(query)
        }
        val searchKeyword = when (query) {
            "Trending" -> "trending popular music gaming"
            "Music" -> "billboard popular hit music 2026"
            "Gaming" -> "new video game gameplay trailers"
            "Tech & AI" -> "latest future tech gadgets artificial intelligence science"
            "Nature & Space" -> "space galaxy beautiful world nature scenic"
            "Lo-Fi Beats" -> "lofi chill beats study relax lounge"
            else -> query
        }
        viewModelScope.launch(Dispatchers.IO) {
            try {
                addLog("🏠 Home Page: Searching category '$query' using internal keyword '$searchKeyword'")
                val results = com.example.data.YoutubeRepository.fetchSearchVideos(getApplication(), searchKeyword)
                if (results.isEmpty()) {
                    _homeError.value = "No results from search. Showing cached recommendations."
                } else {
                    _homeVideos.value = results.map {
                        YtdlpPipelineManager.SearchResult(
                            id = it.id,
                            title = it.title,
                            author = it.author,
                            duration = it.durationText,
                            thumbnailUrl = it.thumbnailUrl,
                            originalUrl = it.originalUrl
                        )
                    }
                }
                _isHomeSearching.value = false
            } catch (e: Exception) {
                _isHomeSearching.value = false
                _homeError.value = "Failed to query live content: ${e.localizedMessage}"
                addLog("❌ Home fetch failed for category $query: ${e.localizedMessage}")
            }
        }
    }

    fun loadVideoDetailsAndDecorations(
        videoId: String,
        defaultTitle: String,
        defaultAuthor: String,
        defaultThumb: String,
        defaultDuration: String,
        defaultUrl: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoadingDetails.value = true
            _videoDetails.value = null
            _videoComments.value = emptyList()
            _relatedVideos.value = emptyList()
            try {
                addLog("🎬 Player-Page: Loading details for video ID $videoId from API")
                val rawDetails = com.example.data.YoutubeRepository.fetchVideoDetails(
                    getApplication(), videoId, defaultTitle, defaultAuthor, defaultThumb, defaultDuration
                )
                _videoDetails.value = rawDetails

                // Load Comments
                val rawComments = com.example.data.YoutubeRepository.fetchComments(videoId)
                _videoComments.value = rawComments

                // Load Related Videos
                val searchKeyword = if (defaultAuthor.isNotBlank()) defaultAuthor else "trending hits music"
                val rawRelated = com.example.data.YoutubeRepository.fetchSearchVideos(getApplication(), searchKeyword)
                val related = rawRelated.filter { it.id != videoId }.take(8)
                _relatedVideos.value = related

                // Instantly prefetch/pre-resolve the first related video streaming URLs so playback feels seamless if clicked
                if (related.isNotEmpty()) {
                    val firstRelated = related.first()
                    viewModelScope.launch(Dispatchers.IO) {
                        try {
                            YtdlpPipelineManager.analyzeUrl(getApplication(), firstRelated.originalUrl) { _ -> }
                        } catch (ex: Exception) {
                            // Suppress prefetch exception so it does not affect main UI state
                        }
                    }
                }

            } catch (e: Exception) {
                addLog("❌ Player-Page Stats loading error: ${e.localizedMessage}")
            } finally {
                _isLoadingDetails.value = false
            }
        }
    }

    fun clearSearchResults() {
        _searchResults.value = emptyList()
    }

    val executionLogs: StateFlow<List<String>> = com.example.DownloadManager.logs

    fun addLog(message: String) {
        com.example.DownloadManager.addLog(message)
    }

    fun clearLogs() {
        com.example.DownloadManager.clearLogs()
    }

    private val activeJobs = java.util.concurrent.ConcurrentHashMap<String, kotlinx.coroutines.Job>()

    private val httpClient = OkHttpClient()

    // YT-DLP States
    private val _ytdlpLocalVersion = MutableStateFlow("Not checked")
    val ytdlpLocalVersion: StateFlow<String> = _ytdlpLocalVersion.asStateFlow()

    private val _ytdlpOnlineVersion = MutableStateFlow("Tap check to load")
    val ytdlpOnlineVersion: StateFlow<String> = _ytdlpOnlineVersion.asStateFlow()

    private val _ytdlpVerificationStatus = MutableStateFlow("Not verified yet. Initialize a download or upload above.")
    val ytdlpVerificationStatus: StateFlow<String> = _ytdlpVerificationStatus.asStateFlow()

    private val _isYtdlpLoading = MutableStateFlow(false)
    val isYtdlpLoading: StateFlow<Boolean> = _isYtdlpLoading.asStateFlow()

    private val _ytdlpProgress = MutableStateFlow(0f)
    val ytdlpProgress: StateFlow<Float> = _ytdlpProgress.asStateFlow()

    private val _customCommandInput = MutableStateFlow("--version")
    val customCommandInput: StateFlow<String> = _customCommandInput.asStateFlow()

    fun updateCustomCommandInput(input: String) {
        _customCommandInput.value = input
    }

    fun executeCustomYtdlpCommand(context: Context) {
        val argsStr = _customCommandInput.value.trim()
        if (_isYtdlpLoading.value) return
        _isYtdlpLoading.value = true
        _ytdlpVerificationStatus.value = "Executing: youtubedl-android JNI request: $argsStr"

        viewModelScope.launch(Dispatchers.IO) {
            try {
                YtdlpPipelineManager.init(context) { log -> Log.i("CustomCLI", log) }
                if (!YtdlpPipelineManager.isInitialized) {
                    throw IllegalStateException("youtubedl-android JNI linkages failed to initialize. Execution is not supported on this device.")
                }
                
                // Construct YoutubeDLRequest dynamically
                val req = YoutubeDLRequest("https://vimeo.com/22439234")
                
                // Split arguments perfectly
                val args = if (argsStr.isNotEmpty()) argsStr.split(Regex("\\s+")).filter { it.isNotEmpty() } else emptyList()
                args.forEach { arg ->
                    if (arg.isNotBlank() && arg != "https://vimeo.com/22439234") {
                        req.addOption(arg)
                    }
                }
                
                // Execute natively
                val response = YoutubeDL.getInstance().execute(req)
                
                val consoleLog = buildString {
                    append("==================================================\n")
                    append("🚀 JNI TERMINAL EXECUTION (Exit Code: ${response.exitCode})\n")
                    append("==================================================\n")
                    append("Latency: ${response.elapsedTime}ms\n\n")
                    append("=== STANDARD OUTPUT ===\n")
                    append(if (response.out.isNotEmpty()) response.out else "[Empty stdout]")
                }
                
                _ytdlpVerificationStatus.value = consoleLog
            } catch (e: Exception) {
                val errorMsg = e.localizedMessage ?: e.toString()
                _ytdlpVerificationStatus.value = "JNI Execution Exception:\n$errorMsg"
            } finally {
                _isYtdlpLoading.value = false
            }
        }
    }

    fun verifyYtdlp(context: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            _ytdlpVerificationStatus.value = "Running native JNI self-check..."
            try {
                YtdlpPipelineManager.init(context) { log -> Log.i("YtdlpVerify", log) }
                if (!YtdlpPipelineManager.isInitialized) {
                    throw IllegalStateException("youtubedl-android JNI core failed to initialize.")
                }
                
                val req = YoutubeDLRequest("https://vimeo.com/22439234").apply {
                    addOption("--version")
                }
                
                val response = YoutubeDL.getInstance().execute(req)
                val versionStr = response.out.trim()
                
                _ytdlpLocalVersion.value = "JNI Core (${if (versionStr.isNotEmpty()) versionStr else "Ready"})"
                _ytdlpVerificationStatus.value = buildString {
                    append("==================================================\n")
                    append("🛡 NATIVE ARCHITECTURE SELF-CHECK OK\n")
                    append("==================================================\n")
                    append(" Backend Engine: youtubedl-android JNI Core\n")
                    append(" Core Executable: $versionStr\n")
                    append(" SELinux Policy: Protected & Compliant (Embedded JNI)\n")
                    append(" W^X Execution bypass: Full success (No ProcessBuilder fallback)\n\n")
                    append("=== FULL OUTPUT ===\n")
                    append(response.out)
                }
            } catch (e: Exception) {
                val errorMsg = e.localizedMessage ?: e.toString()
                _ytdlpVerificationStatus.value = "JNI Verification Failure:\n$errorMsg"
                _ytdlpLocalVersion.value = "Error Initialization"
            }
        }
    }

    private val _isTestModeActive = MutableStateFlow(false)
    val isTestModeActive: StateFlow<Boolean> = _isTestModeActive.asStateFlow()

    fun toggleTestMode() {
        val current = _isTestModeActive.value
        if (!current) {
            // Enable test mode, inject mock data
            _isAnalyzing.value = true
            // Then after a short delay, flip it to show analyzed video
            viewModelScope.launch {
                kotlinx.coroutines.delay(1000)
                _isAnalyzing.value = false
                _analyzedVideo.value = AnalyzedVideo(
                    id = "test_video",
                    title = "Test Video Title for Layout Visualization",
                    author = "Author Name",
                    durationText = "12:34",
                    thumbnailUrl = "https://via.placeholder.com/640x360.png/000000/FFFFFF?text=Test+Thumbnail",
                    formats = listOf(
                        VideoFormatUi(1, "combined", "1080p", "mp4", "50 MB", "http://dl", 50000),
                        VideoFormatUi(2, "audio", "Audio", "m4a", "5 MB", "http://dl", 5000)
                    ),
                    originalUrl = "http://test"
                )
                com.example.DownloadManager.updateActiveDownloads(mapOf(
                    "test_task" to ActiveDownloadTask(
                        id = "test_task",
                        title = "Downloading Test Video...",
                        progress = 0.45f,
                        speedText = "1.2 MB/s",
                        downloadedBytes = 1000000,
                        totalBytes = 2200000,
                        status = DownloadStatus.DOWNLOADING,
                        ext = "mp4"
                    ),
                    "test_failed_task" to ActiveDownloadTask(
                        id = "test_failed_task",
                        title = "Failed Test Video...",
                        progress = 0f,
                        speedText = "0 B/s",
                        downloadedBytes = 0,
                        totalBytes = 0,
                        status = DownloadStatus.FAILED,
                        ext = "mp4",
                        error = "Error: Out of space"
                    )
                ))
            }
        } else {
            // Disable test mode
            _isAnalyzing.value = false
            _analyzedVideo.value = null
            com.example.DownloadManager.updateActiveDownloads(emptyMap())
        }
        _isTestModeActive.value = !current
    }

    fun downloadYtdlp(context: Context) {
        if (_isYtdlpLoading.value) return
        _isYtdlpLoading.value = true
        _ytdlpProgress.value = 0f
        _ytdlpVerificationStatus.value = "Warming up secure native JNI core..."

        viewModelScope.launch(Dispatchers.IO) {
            try {
                YtdlpPipelineManager.init(context) { log -> Log.i("YtdlpDL", log) }
                if (!YtdlpPipelineManager.isInitialized) {
                    throw IllegalStateException("youtubedl-android JNI core failed to initialize.")
                }
                
                _ytdlpProgress.value = 0.5f
                kotlinx.coroutines.delay(500)
                _ytdlpProgress.value = 1.0f
                
                val req = YoutubeDLRequest("https://vimeo.com/22439234").apply {
                    addOption("--version")
                }
                val response = YoutubeDL.getInstance().execute(req)
                val outText = response.out.trim()
                
                _ytdlpLocalVersion.value = "JNI Core ($outText)"
                _ytdlpVerificationStatus.value = buildString {
                    append("==================================================\n")
                    append("✔ SECURE JNI COMPILED STAGE READY\n")
                    append("==================================================\n")
                    append("The JNI system has been securely initiated on-device.\n")
                    append("By utilizing the built-in youtubedl-android architecture, this application avoids any external binary downloads, fully aligning with modern Google Play sandbox rules.\n\n")
                    append("Active Version: $outText")
                }
            } catch (e: Exception) {
                val errorMsg = e.localizedMessage ?: e.toString()
                _ytdlpVerificationStatus.value = "JNI Setup Exception:\n$errorMsg"
            } finally {
                _isYtdlpLoading.value = false
            }
        }
    }

    fun updateYtdlpBinaries(context: Context) {
        if (_isYtdlpLoading.value) return
        _isYtdlpLoading.value = true
        _ytdlpVerificationStatus.value = "Updating yt-dlp core from remote repository... Please wait."

        viewModelScope.launch(Dispatchers.IO) {
            try {
                addLog("🔄 Initiating yt-dlp binary update...")
                YtdlpPipelineManager.init(context) { log -> Log.i("YtdlpDL", log) }
                
                // Call the updater (requires internet)
                val status = YoutubeDL.getInstance().updateYoutubeDL(context, YoutubeDL.UpdateChannel.STABLE)
                
                _ytdlpVerificationStatus.value = "yt-dlp update successful!\nStatus: $status"
                addLog("✅ yt-dlp successfully updated to latest version.")
                
                // Refresh local version
                val req = YoutubeDLRequest("https://vimeo.com/22439234").apply {
                    addOption("--version")
                }
                val response = YoutubeDL.getInstance().execute(req)
                val outText = response.out.trim()
                _ytdlpLocalVersion.value = "JNI Core ($outText)"
                
            } catch (e: Exception) {
                val errorMsg = e.localizedMessage ?: e.toString()
                _ytdlpVerificationStatus.value = "Failed to update yt-dlp:\n$errorMsg"
                addLog("❌ Update failed: $errorMsg")
            } finally {
                _isYtdlpLoading.value = false
            }
        }
    }

    fun uploadYtdlpBytes(bytes: ByteArray, context: Context) {
        _ytdlpVerificationStatus.value = "Dynamic binary upload bypassed. Native bundler is securely packed inside the APK JNI directory."
    }

    fun fetchLatestYtdlpVersionOnline() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _ytdlpOnlineVersion.value = "Checking..."
                val request = Request.Builder()
                    .url("https://api.github.com/repos/yt-dlp/yt-dlp/releases/latest")
                    .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
                    .build()
                
                httpClient.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val bodyString = response.body?.string()
                        if (!bodyString.isNullOrEmpty()) {
                            val match = Regex("\"tag_name\"\\s*:\\s*\"([^\"]+)\"").find(bodyString)
                            val version = match?.groupValues?.get(1) ?: "Unknown"
                            _ytdlpOnlineVersion.value = version
                        } else {
                            _ytdlpOnlineVersion.value = "Failed to parse API"
                        }
                    } else {
                        _ytdlpOnlineVersion.value = "HTTP ${response.code}"
                    }
                }
            } catch (e: Exception) {
                Log.e("YtdlpManager", "Failed to fetch online version", e)
                _ytdlpOnlineVersion.value = "Network Error"
            }
        }
    }

    fun updateUrlInput(url: String) {
        _videoUrlInput.value = url
        _analysisError.value = null
    }

    fun clearAnalyzedVideo() {
        _analyzedVideo.value = null
        _searchResults.value = emptyList()
        _isSearching.value = false
    }

    fun isYoutubeUrl(url: String): Boolean {
        val cleanUrl = url.trim()
        return cleanUrl.contains("youtube.com", ignoreCase = true) || 
               cleanUrl.contains("youtu.be", ignoreCase = true) ||
               (cleanUrl.length == 11 && cleanUrl.matches(Regex("[a-zA-Z0-9_-]{11}")))
    }

    fun extractVideoId(url: String): String? {
        val cleanUrl = url.trim()
        val pattern = "(?i)(?:https?:\\/\\/)?(?:www\\.|m\\.)?(?:youtube\\.com\\/(?:watch\\?(?:.*&)?v=|embed\\/|shorts\\/)|youtu\\.be\\/)([a-zA-Z0-9_-]{11})"
        val regex = Regex(pattern)
        val matchResult = regex.find(cleanUrl)
        if (matchResult != null) {
            return matchResult.groupValues[1]
        }
        // Fallback: If it's a raw 11-char ID, allow it
        if (cleanUrl.length == 11 && cleanUrl.matches(Regex("[a-zA-Z0-9_-]{11}"))) {
            return cleanUrl
        }
        return null
    }

    fun isKeywordSearch(url: String): Boolean {
        val clean = url.trim()
        if (clean.isEmpty()) return false
        if (clean.startsWith("http://", ignoreCase = true) || clean.startsWith("https://", ignoreCase = true)) return false
        if (clean.startsWith("ytsearch", ignoreCase = true)) return true
        if (clean.contains(" ")) return true
        if (!clean.contains(".")) {
            if (clean.length == 11 && clean.matches(Regex("[a-zA-Z0-9_-]{11}"))) {
                return false
            }
            return true
        }
        return false
    }

    fun analyzeVideo() {
        val url = _videoUrlInput.value.trim()

        val currentList = _urlHistory.value.toMutableList()
        currentList.remove(url)
        currentList.add(0, url)
        val historyList = currentList.take(10)
        prefs.edit().putString("urlHistory", historyList.joinToString(",")).apply()
        _urlHistory.value = historyList

        addLog("--------------------------------------------------")
        addLog("🎬 NEW ADAPTIVE ANALYSIS REQUEST DETECTED")
        addLog("URL/Keyword entered: \"$url\"")

        if (url.isEmpty()) {
            val errorMsg = "Input is empty. Please enter a valid URL or search keywords."
            addLog("❌ Rejected: $errorMsg")
            _analysisError.value = errorMsg
            return
        }

        if (isKeywordSearch(url)) {
            _isSearching.value = true
            _analysisError.value = null
            _analyzedVideo.value = null
            _searchResults.value = emptyList()
            _isAnalyzing.value = true
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    addLog("🔍 Searching for keyword: \"$url\" via JNI ytsearch...")
                    val results = YtdlpPipelineManager.searchKeywords(getApplication(), url) { logMsg ->
                        addLog(logMsg)
                    }
                    _searchResults.value = results
                    _isSearching.value = false
                    _isAnalyzing.value = false
                    if (results.isEmpty()) {
                        _analysisError.value = "No search results found for \"$url\"."
                        addLog("❌ Search finished. No results found.")
                    } else {
                        addLog("✅ Search completed with ${results.size} matches!")
                    }
                } catch (e: Exception) {
                    _isSearching.value = false
                    _isAnalyzing.value = false
                    _analysisError.value = "Search failed: ${e.localizedMessage}"
                    addLog("❌ Search failed: ${e.localizedMessage}")
                }
            }
            return
        }

        _isAnalyzing.value = true
        _analysisError.value = null
        _analyzedVideo.value = null

        viewModelScope.launch(Dispatchers.IO) {
            try {
                addLog("📡 Loading 4-Tier Fallback Download Pipeline Manager...")
                val result = YtdlpPipelineManager.analyzeUrl(getApplication(), url) { logMsg ->
                    addLog(logMsg)
                }

                if (result.success && result.formats.isNotEmpty()) {
                    val filteredFormats = if (_isAudioOnlyMode.value) {
                        result.formats.filter { it.type == "audio" || it.quality.contains("Audio", ignoreCase = true) || it.ext == "m4a" || it.ext == "mp3" }
                    } else {
                        result.formats
                    }
                    val validFormats = if (filteredFormats.isNotEmpty()) filteredFormats else result.formats

                    val finalResult = AnalyzedVideo(
                        id = if (isYoutubeUrl(url)) extractVideoId(url) ?: "video_${url.hashCode()}" else "video_${url.hashCode()}",
                        title = result.title,
                        author = result.uploader,
                        durationText = "Adaptive Stream",
                        thumbnailUrl = result.thumbnailUrl,
                        formats = validFormats,
                        originalUrl = url
                    )
                    _analyzedVideo.value = finalResult
                    addLog("\n🟢 Extraction completed successfully [Pipeline: ${result.usedBackend.displayName}]")

                    val defaultQuality = _defaultDownloadQuality.value
                    if (defaultQuality != "Ask Every Time") {
                        val formatToDownload = if (defaultQuality == "Audio Only") {
                            finalResult.formats.firstOrNull { it.type == "audio" || it.quality.contains("Audio", ignoreCase = true) || it.ext == "m4a" || it.ext == "mp3" }
                        } else {
                            finalResult.formats.firstOrNull { it.quality.contains(defaultQuality, ignoreCase = true) }
                        }

                        if (formatToDownload != null) {
                            addLog("⚡ Auto-starting download for preferred quality: $defaultQuality")
                            startDownload(finalResult, formatToDownload)
                        } else {
                            addLog("ℹ️ Preferred quality $defaultQuality not found in available formats. Waiting for manual selection.")
                        }
                    }
                } else {
                    addLog("\n🔴 Pipeline failed to extract valid stream configurations.")
                    _analysisError.value = result.errorCode ?: "Parser returned no available formats for this link."
                }
            } catch (e: Throwable) {
                val errorMsg = e.localizedMessage ?: e.javaClass.simpleName ?: e.toString()
                addLog("💀 Critical pipeline failure: $errorMsg")
                _analysisError.value = "Failed to fetch video details: $errorMsg"
            } finally {
                _isAnalyzing.value = false
                addLog("--------------------------------------------------")
            }
        }
    }



    fun startDownload(video: AnalyzedVideo, format: VideoFormatUi) {
        val context = getApplication<Application>().applicationContext
        com.example.DownloadManager.startDownload(context, video, format, _usePublicDownloads.value)
    }

    fun removeActiveTask(id: String) {
        com.example.DownloadManager.removeActiveTask(id)
        com.example.DownloadForegroundService.stopService(getApplication<Application>().applicationContext)
    }

    fun clearAllDownloads() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                com.example.DownloadManager.updateActiveDownloads(emptyMap())
                activeJobs.values.forEach { it.cancel() }
                activeJobs.clear()

                val downloads = downloadHistory.value
                for (download in downloads) {
                    val file = File(download.localPath)
                    if (file.exists()) {
                        file.delete()
                    }
                }
                repository.deleteAllDownloads()
            } catch (e: Exception) {
                Log.e("VideoDownloader", "Failed to clear all downloads", e)
            }
        }
    }

    fun playVideo(context: Context, download: DownloadEntity) {
        try {
            val file = File(download.localPath)
            if (!file.exists()) {
                _analysisError.value = "The downloaded file could not be found. It may have been deleted outside the app."
                return
            }

            // Expose the URI using our FileProvider
            val fileUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val mimeType = if (download.localPath.endsWith(".mp3") || download.localPath.endsWith(".m4a")) {
                "audio/*"
            } else {
                "video/*"
            }

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(fileUri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("VideoDownloader", "Failed to launch video player", e)
            _analysisError.value = "Failed to launch a media player for this file. Error: ${e.localizedMessage}"
        }
    }

    fun shareVideo(context: Context, download: DownloadEntity) {
        try {
            val file = File(download.localPath)
            if (!file.exists()) {
                _analysisError.value = "The file does not exist on local storage."
                return
            }

            val fileUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val mimeType = if (download.localPath.endsWith(".mp3") || download.localPath.endsWith(".m4a")) {
                "audio/*"
            } else {
                "video/*"
            }

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, fileUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Share Downloaded Video"))
        } catch (e: Exception) {
            Log.e("VideoDownloader", "Sharing failed", e)
            _analysisError.value = "Could not share this file. Error: ${e.localizedMessage}"
        }
    }

    fun convertAudio(item: DownloadEntity) {
        val context = getApplication<Application>().applicationContext
        com.example.DownloadManager.convertAudio(context, item)
    }

    fun deleteDownload(download: DownloadEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Delete from physical storage
                val file = File(download.localPath)
                if (file.exists()) {
                    file.delete()
                }
                // Delete database record
                repository.deleteDownload(download)
            } catch (e: Exception) {
                Log.e("VideoDownloader", "File deletion failed", e)
            }
        }
    }

    private fun formatDuration(seconds: Int): String {
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        return if (h > 0) {
            String.format(Locale.getDefault(), "%d:%02d:%02d", h, m, s)
        } else {
            String.format(Locale.getDefault(), "%d:%02d", m, s)
        }
    }

    private fun getFormatSizeBytes(format: Any): Long {
        val methods = listOf("size", "getSize", "contentLength", "getContentLength")
        for (methodName in methods) {
            try {
                val method = format.javaClass.getMethod(methodName)
                val result = method.invoke(format)
                if (result is Long) return result
                if (result is Int) return result.toLong()
            } catch (e: Throwable) {
                // Keep searching
            }
        }
        return 0L
    }

    private fun getFormatQualityText(format: Any): String {
        val methods = listOf("videoQuality", "getVideoQuality", "qualityLabel", "getQualityLabel")
        for (methodName in methods) {
            try {
                val method = format.javaClass.getMethod(methodName)
                val result = method.invoke(format)
                if (result != null) {
                    val str = result.toString()
                    if (str.isNotEmpty()) return str
                }
            } catch (e: Throwable) {
                // Keep searching
            }
        }
        return "HQ Video"
    }

    private fun getFormatAudioQualityText(format: Any): String {
        val methods = listOf("audioQuality", "getAudioQuality", "bitrate", "getBitrate")
        for (methodName in methods) {
            try {
                val method = format.javaClass.getMethod(methodName)
                val result = method.invoke(format)
                if (result != null) {
                    val str = result.toString()
                    if (str.isNotEmpty()) {
                        return if (str.all { it.isDigit() }) "${str.toInt() / 1000}kbps" else str
                    }
                }
            } catch (e: Throwable) {
                // Keep searching
            }
        }
        return "HQ Audio"
    }

    private fun getFormatExtension(format: Any): String {
        val methods = listOf("extension", "getExtension")
        for (methodName in methods) {
            try {
                val method = format.javaClass.getMethod(methodName)
                val result = method.invoke(format)
                if (result != null) {
                    try {
                        val valueMethod = result.javaClass.getMethod("value")
                        val valueResult = valueMethod.invoke(result)
                        if (valueResult != null) return valueResult.toString().lowercase()
                    } catch (e: Throwable) {
                        try {
                            val nameMethod = result.javaClass.getMethod("name")
                            val nameResult = nameMethod.invoke(result)
                            if (nameResult != null) return nameResult.toString().lowercase()
                        } catch (e2: Throwable) {
                            val str = result.toString().lowercase()
                            if (str.isNotEmpty()) return str
                        }
                    }
                }
            } catch (e: Throwable) {
                // Keep searching
            }
        }
        return "mp4"
    }

    private fun getFormatUrl(format: Any): String {
        val methods = listOf("url", "getUrl")
        for (methodName in methods) {
            try {
                val method = format.javaClass.getMethod(methodName)
                val result = method.invoke(format)
                if (result != null) return result.toString()
            } catch (e: Throwable) {
                // Keep searching
            }
        }
        return ""
    }

    private fun mergeVideoAndAudio(videoFile: File, audioFile: File, outputFile: File, onProgress: (String) -> Unit) {
        // Try [PRIMARY]: FFmpeg JNI native multiplexer via resilient dynamic descriptor mapping
        try {
            onProgress("Attempting native FFmpeg JNI high-speed track multiplexing...")
            val args = arrayOf(
                "-y",
                "-i", videoFile.absolutePath,
                "-i", audioFile.absolutePath,
                "-c:v", "copy",
                "-c:a", "copy",
                outputFile.absolutePath
            )
            // Ensure JNI native layers are initialized
            YtdlpPipelineManager.init(getApplication())
            
            // Reflectively query and invoke the FFmpeg execution engine to guarantee compile-safety
            val ffmpegClass = Class.forName("com.yausername.ffmpeg.FFmpeg")
            val getInstanceMethod = ffmpegClass.getMethod("getInstance")
            val ffmpegInstance = getInstanceMethod.invoke(null)
            
            // Locate the method that takes an array of strings (the command arguments)
            val executionMethod = ffmpegClass.methods.firstOrNull { method ->
                method.parameterTypes.size == 1 && method.parameterTypes[0] == Array<String>::class.java
            } ?: ffmpegClass.getMethod("execute", Array<String>::class.java)

            executionMethod.isAccessible = true
            executionMethod.invoke(ffmpegInstance, args)
            
            if (outputFile.exists() && outputFile.length() > 0) {
                onProgress("Native FFmpeg JNI track multiplexing succeeded completely!")
                return
            } else {
                onProgress("FFmpeg executed but output file empty. Falling back to system MediaMuxer...")
            }
        } catch (ffmpegEx: Exception) {
            onProgress("FFmpeg JNI multiplexing warning: ${ffmpegEx.localizedMessage}. Falling back to system MediaMuxer...")
        }

        var videoExtractor: MediaExtractor? = null
        var audioExtractor: MediaExtractor? = null
        var muxer: MediaMuxer? = null
        try {
            videoExtractor = MediaExtractor()
            videoExtractor.setDataSource(videoFile.absolutePath)
            
            audioExtractor = MediaExtractor()
            audioExtractor.setDataSource(audioFile.absolutePath)
            
            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            
            // Find video track
            var videoTrackIndex = -1
            var videoFormat: MediaFormat? = null
            for (i in 0 until videoExtractor.trackCount) {
                val format = videoExtractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/")) {
                    videoExtractor.selectTrack(i)
                    videoTrackIndex = muxer.addTrack(format)
                    videoFormat = format
                    break
                }
            }
            
            // Find audio track
            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null
            for (i in 0 until audioExtractor.trackCount) {
                val format = audioExtractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioExtractor.selectTrack(i)
                    audioTrackIndex = muxer.addTrack(format)
                    audioFormat = format
                    break
                }
            }
            
            if (videoTrackIndex == -1) {
                throw Exception("No video track found in download stream.")
            }
            if (audioTrackIndex == -1) {
                throw Exception("No audio track found in download stream.")
            }
            
            muxer.start()
            
            val maxBufferSize = 10 * 1024 * 1024 // 10MB chunk buffer
            val byteBuffer = ByteBuffer.allocate(maxBufferSize)
            val bufferInfo = MediaCodec.BufferInfo()
            
            // Mux video
            onProgress("Muxing video tracks...")
            videoExtractor.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            while (true) {
                bufferInfo.offset = 0
                bufferInfo.size = videoExtractor.readSampleData(byteBuffer, 0)
                if (bufferInfo.size < 0) {
                    break
                }
                bufferInfo.presentationTimeUs = videoExtractor.sampleTime
                bufferInfo.flags = videoExtractor.sampleFlags
                muxer.writeSampleData(videoTrackIndex, byteBuffer, bufferInfo)
                videoExtractor.advance()
            }
            
            // Mux audio
            onProgress("Muxing audio tracks...")
            audioExtractor.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            while (true) {
                bufferInfo.offset = 0
                bufferInfo.size = audioExtractor.readSampleData(byteBuffer, 0)
                if (bufferInfo.size < 0) {
                    break
                }
                bufferInfo.presentationTimeUs = audioExtractor.sampleTime
                bufferInfo.flags = audioExtractor.sampleFlags
                muxer.writeSampleData(audioTrackIndex, byteBuffer, bufferInfo)
                audioExtractor.advance()
            }
            
            onProgress("Finalizing tracks and saving merged file locally...")
        } finally {
            try { videoExtractor?.release() } catch (ignored: Exception) {}
            try { audioExtractor?.release() } catch (ignored: Exception) {}
            try { muxer?.stop(); muxer?.release() } catch (ignored: Exception) {}
        }
    }

    init {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                addLog("Pre-warming yausername:youtubedl-android JNI subsystems in background...")
                YtdlpPipelineManager.init(getApplication()) { logMsg ->
                    addLog("   [Pre-warm] $logMsg")
                }
            } catch (e: Throwable) {
                addLog("⚠️ Subsystem background warm warning: ${e.localizedMessage}")
            }
        }
    }
}
