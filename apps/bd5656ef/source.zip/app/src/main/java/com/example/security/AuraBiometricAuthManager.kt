package com.example.security

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.DialogInterface
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal
import android.util.Log

/**
 * Manager for Biometric (Face Unlock / Fingerprint) Authentication.
 *
 * STRICT SECURITY POLICY:
 * Does NOT permit device credential fallback (PIN, Pattern, Password).
 * Only strong biometric sensors (Face / Biometrics) are accepted.
 */
class AuraBiometricAuthManager(private val context: Context) {

    private val TAG = "AuraBiometricAuth"
    private var cancellationSignal: CancellationSignal? = null

    /**
     * Checks if biometric hardware (Face / Fingerprint) is available and enrolled.
     */
    fun isBiometricAvailable(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val biometricManager = context.getSystemService(BiometricManager::class.java)
                val canAuth = biometricManager?.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                canAuth == BiometricManager.BIOMETRIC_SUCCESS
            } else {
                val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
                keyguardManager?.isDeviceSecure ?: false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to check biometric availability", e)
            false
        }
    }

    /**
     * Checks if biometric hardware and security credentials are configured.
     */
    fun isBiometricOrDeviceCredentialAvailable(): Boolean {
        return try {
            val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
            keyguardManager?.isDeviceSecure ?: false
        } catch (e: Exception) {
            Log.e(TAG, "Failed to check device security status", e)
            false
        }
    }

    /**
     * Prompts user for Face / Biometric authentication.
     * CRITICAL: Screen lock fallback (PIN/Pattern) is STRICTLY DISABLED.
     */
    fun authenticateFaceOnly(
        activity: Activity,
        title: String = "Face Authentication Required",
        subtitle: String = "Authorize Bridge Connection",
        description: String = "Scan your Face to verify identity and allow Termux bridge access. (PIN/Pattern fallback disabled)",
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                cancellationSignal?.cancel()
                val signal = CancellationSignal()
                cancellationSignal = signal

                val prompt = BiometricPrompt.Builder(activity)
                    .setTitle(title)
                    .setSubtitle(subtitle)
                    .setDescription(description)
                    // Note: We deliberately do NOT call setDeviceCredentialAllowed(true).
                    // This strictly enforces biometric sensor validation (no PIN or pattern bypass).
                    .setNegativeButton("Cancel", activity.mainExecutor, DialogInterface.OnClickListener { _, _ ->
                        onError("Face authentication cancelled by user")
                    })
                    .build()

                val callback = object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                        super.onAuthenticationSucceeded(result)
                        Log.i(TAG, "Biometric Face authentication succeeded!")
                        activity.runOnUiThread {
                            onSuccess()
                        }
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                        super.onAuthenticationError(errorCode, errString)
                        Log.w(TAG, "Biometric authentication error ($errorCode): $errString")
                        activity.runOnUiThread {
                            onError(errString?.toString() ?: "Biometric error: $errorCode")
                        }
                    }

                    override fun onAuthenticationFailed() {
                        super.onAuthenticationFailed()
                        Log.w(TAG, "Biometric Face authentication failed (Face not recognized)")
                    }
                }

                prompt.authenticate(signal, activity.mainExecutor, callback)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to launch native BiometricPrompt: ${e.message}", e)
                onError(e.message ?: "Failed to launch Face BiometricPrompt")
            }
        } else {
            onError("Biometric authentication requires Android 9.0+ (API 28)")
        }
    }

    fun cancelAuthentication() {
        try {
            cancellationSignal?.cancel()
            cancellationSignal = null
        } catch (ignored: Exception) {}
    }

    /**
     * Retrieves the biometric & authentication capability status of the device.
     */
    fun getBiometricStatus(): Map<String, Any> {
        val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        val isSecure = keyguardManager?.isDeviceSecure ?: false
        val isLocked = keyguardManager?.isKeyguardLocked ?: false

        return mapOf(
            "isDeviceSecure" to isSecure,
            "isKeyguardLocked" to isLocked,
            "isBiometricAvailable" to isBiometricAvailable(),
            "supportedTypes" to listOf("FACE_AUTHENTICATION", "BIOMETRIC_STRONG"),
            "pinPatternAllowed" to false,
            "sdkVersion" to Build.VERSION.SDK_INT
        )
    }
}

