import 'package:flutter/material.dart';

class GhostTheme {
  // Colors
  static const Color background = Color(0xFF040609);
  static const Color surface = Color(0xFF12141C);
  static const Color accentNeon = Color(0xFF00F2FF); // Cyan
  static const Color accentGhost = Color(0xFF8B5CF6); // Violet
  static const Color textPrimary = Colors.white;
  static const Color textSecondary = Colors.white60;

  // Glassmorphic Decoration
  static BoxDecoration glassDecoration = BoxDecoration(
    color: Colors.white.withOpacity(0.05),
    borderRadius: BorderRadius.circular(24),
    border: Border.all(color: Colors.white.withOpacity(0.1), width: 1.5),
  );

  // Text Styles
  static const TextStyle headingStyle = TextStyle(
    color: textPrimary,
    fontSize: 28,
    fontWeight: FontWeight.w900,
    letterSpacing: 1.5,
  );

  static const TextStyle subheadingStyle = TextStyle(
    color: accentNeon,
    fontSize: 12,
    fontWeight: FontWeight.bold,
    letterSpacing: 2,
  );
}
