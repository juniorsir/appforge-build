import 'package:flutter/material.dart';
import 'package:sendx/ui/home_screen.dart';
import 'package:sendx/ui/host_screen.dart';
import 'package:sendx/ui/join_screen.dart';

void main() {
  runApp(const GhostVaultApp());
}

class GhostVaultApp extends StatelessWidget {
  const GhostVaultApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GhostVault',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => HomeScreen(),
        '/host': (context) => HostScreen(),
        '/join': (context) => JoinScreen(),
      },
    );
  }
}
