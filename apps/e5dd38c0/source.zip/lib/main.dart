import 'package:flutter/material.dart';
import 'ui/home_screen.dart';
import 'ui/host_screen.dart';
import 'ui/join_screen.dart';
import 'core/theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const GhostVaultApp());
}

class GhostVaultApp extends StatelessWidget {
  const GhostVaultApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GhostVault',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        // FIXED: Explicitly named ColorScheme
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF00F2FF),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF040609),
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => HomeScreen(),
        '/host': (context) => HostScreen(),
        '/join': (context) => JoinScreen(),
      },
    );
  }
}
