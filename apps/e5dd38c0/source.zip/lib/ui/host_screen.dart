import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../core/theme.dart';

class HostScreen extends StatelessWidget {
  final String connectionCode = "738 291"; // This would be generated dynamically

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GhostTheme.background,
      appBar: AppBar(
        title: const Text("HOSTING VAULT", style: TextStyle(fontSize: 14, letterSpacing: 2)),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              child: QrImageView(
                data: "http://ghostvault.local/$connectionCode",
                version: QrVersions.auto,
                size: 200.0,
              ),
            ),
            const SizedBox(height: 40),
            Text("YOUR 6-DIGIT CODE", style: TextStyle(color: GhostTheme.textSecondary, letterSpacing: 2)),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
              decoration: GhostTheme.glassDecoration,
              child: Text(
                connectionCode,
                style: const TextStyle(
                  color: GhostTheme.accentNeon,
                  fontSize: 42,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 10,
                ),
              ),
            ),
            const SizedBox(height: 50),
            const CircularProgressIndicator(color: GhostTheme.accentNeon),
            const SizedBox(height: 20),
            Text("Waiting for peers to join...", style: TextStyle(color: GhostTheme.textSecondary)),
          ],
        ),
      ),
    );
  }
}
