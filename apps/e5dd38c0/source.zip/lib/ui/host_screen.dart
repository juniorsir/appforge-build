import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:sendx/services/connection_manager.dart';
import '../core/theme.dart';

class HostScreen extends StatefulWidget {
  @override
  _HostScreenState createState() => _HostScreenState();
}

class _HostScreenState extends State<HostScreen> {
  String code = "738291"; // Usually generated randomly
  bool isLive = false;

  @override
  void initState() {
    super.initState();
    _activateServer();
  }

  void _activateServer() async {
    // In a real app, use file_picker to get a path
    await ConnectionManager.startHosting(code, "/storage/emulated/0/Download/video.mp4");
    setState(() => isLive = true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GhostTheme.background,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (isLive) ...[
              QrImageView(
                data: "ghostvault://connect?code=$code", // DEEP LINK
                version: QrVersions.auto,
                size: 200.0,
                eyeStyle: const QrEyeStyle(eyeShape: QrEyeShape.square, color: Colors.white),
                dataModuleStyle: const QrDataModuleStyle(dataModuleShape: QrDataModuleShape.square, color: GhostTheme.accentNeon),
              ),
              const SizedBox(height: 20),
              Text("CODE: $code", style: GhostTheme.headingStyle),
              const Text("Server is Live on LAN", style: TextStyle(color: GhostTheme.accentNeon)),
            ] else 
              const CircularProgressIndicator()
          ],
        ),
      ),
    );
  }
}
