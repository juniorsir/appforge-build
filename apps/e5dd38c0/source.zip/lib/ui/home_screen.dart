import 'package:flutter/material.dart';
import 'package:sendx/core/theme.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GhostTheme.background,
      body: Stack(
        children: [
          _buildMeshGradient(),
          SafeArea(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("GHOSTVAULT", style: GhostTheme.headingStyle),
                  Text("SECURE HYBRID STORAGE", style: GhostTheme.subheadingStyle),
                  SizedBox(height: 40),
                  _buildActionCard(
                    context,
                    "Host local Vault",
                    "Share files offline via LAN",
                    Icons.wifi_tethering,
                    GhostTheme.accentNeon,
                    () => Navigator.pushNamed(context, '/host'),
                  ),
                  _buildActionCard(
                    context,
                    "Join Vault",
                    "Connect using 6-digit code",
                    Icons.qr_code_scanner,
                    Colors.white,
                    () => Navigator.pushNamed(context, '/join'),
                  ),
                  _buildActionCard(
                    context,
                    "Cloud Sync",
                    "Upload to GhostVault API",
                    Icons.cloud_done_outlined,
                    GhostTheme.accentGhost,
                    () => Navigator.pushNamed(context, '/upload'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionCard(BuildContext context, String title, String sub, IconData icon, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.only(bottom: 20),
        padding: EdgeInsets.all(24),
        decoration: GhostTheme.glassDecoration,
        child: Row(
          children: [
            Icon(icon, color: color, size: 32),
            SizedBox(width: 20),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
              Text(sub, style: TextStyle(color: Colors.white54, fontSize: 12)),
            ]),
            Spacer(),
            Icon(Icons.chevron_right, color: Colors.white24),
          ],
        ),
      ),
    );
  }

  Widget _buildMeshGradient() {
    return Container(
      decoration: BoxDecoration(
        gradient: RadialGradient(
          center: Alignment(-0.8, -0.6),
          colors: [GhostTheme.accentGhost.withOpacity(0.15), Colors.transparent],
          radius: 1.5,
        ),
      ),
    );
  }
}
