import 'package:flutter/material.dart';
import 'package:sendx/core/theme.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GhostTheme.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("GHOSTVAULT", style: GhostTheme.headingStyle),
              const Text("HYBRID P2P STORAGE", style: GhostTheme.subheadingStyle),
              const SizedBox(height: 40),
              _buildCard(context, "Host Vault", "Share files via LAN/P2P", Icons.wifi_tethering, GhostTheme.accentNeon, '/host'),
              _buildCard(context, "Join Vault", "Connect to a peer", Icons.qr_code_scanner, Colors.white, '/join'),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCard(BuildContext context, String title, String sub, IconData icon, Color color, String route) {
    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, route),
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(20),
        decoration: GhostTheme.glassDecoration,
        child: Row(
          children: [
            Icon(icon, color: color, size: 30),
            const SizedBox(width: 20),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
              Text(sub, style: const TextStyle(color: Colors.white54, fontSize: 12)),
            ]),
          ],
        ),
      ),
    );
  }
}
