import 'package:flutter/material.dart';
import 'package:sendx/core/theme.dart';
import 'package:sendx/ui/widgets/discovery_radar.dart';
import 'package:sendx/services/connection_manager.dart'; // ✅ Fixed Import
import 'package:sendx/ui/player_screen.dart';          // ✅ Fixed Import

class JoinScreen extends StatefulWidget {
  @override
  _JoinScreenState createState() => _JoinScreenState();
}

class _JoinScreenState extends State<JoinScreen> {
  bool isSearching = false;

  void _onCodeEntered(String enteredCode) async {
    if (enteredCode.length == 6) {
      FocusScope.of(context).unfocus();
      setState(() => isSearching = true);

      try {
        // Look for the IP address associated with this 6-digit code
        String? hostAddress = await ConnectionManager.findHost(enteredCode);

        if (hostAddress != null) {
          // 🚀 SUCCESS: Navigate to Player
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => PlayerScreen(
                url: "http://$hostAddress/stream",
              ),
            ),
          );
        } else {
          _showError("No Vault found with this code on your network.");
        }
      } catch (e) {
        _showError("Connection failed. Check your Wi-Fi.");
      } finally {
        setState(() => isSearching = false);
      }
    }
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GhostTheme.background,
      appBar: AppBar(
        title: const Text("SEARCHING VAULTS"),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 40),
            DiscoveryRadar(),
            const SizedBox(height: 40),
            Text(
              isSearching ? "Authenticating Code..." : "Scanning for nearby devices...",
              style: const TextStyle(color: GhostTheme.textSecondary),
            ),
            const SizedBox(height: 30),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: TextField(
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontSize: 24, letterSpacing: 8),
                decoration: InputDecoration(
                  hintText: "ENTER CODE",
                  hintStyle: const TextStyle(color: Colors.white24, letterSpacing: 2),
                  filled: true,
                  fillColor: Colors.white.withOpacity(0.05),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none),
                  counterText: "",
                ),
                keyboardType: TextInputType.number,
                maxLength: 6,
                onChanged: (value) {
                  if (value.length == 6) _onCodeEntered(value);
                },
              ),
            ),
            if (isSearching) const Padding(
              padding: EdgeInsets.only(top: 20),
              child: CircularProgressIndicator(color: GhostTheme.accentNeon),
            ),
          ],
        ),
      ),
    );
  }
}
