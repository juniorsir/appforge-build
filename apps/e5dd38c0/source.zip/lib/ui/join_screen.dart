import 'package:flutter/material.dart';
import 'package:sendx/core/theme.dart';
import 'package:sendx/ui/widgets/discovery_radar.dart';

class JoinScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GhostTheme.background,
      appBar: AppBar(
        title: const Text("SEARCHING VAULTS"), 
        backgroundColor: Colors.transparent,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 40),
            DiscoveryRadar(), 
            const SizedBox(height: 40),
            const Text(
              "Scanning for nearby devices...",
              style: TextStyle(color: GhostTheme.textSecondary),
            ),
            const SizedBox(height: 30),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: TextField(
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontSize: 24, letterSpacing: 8),
                decoration: InputDecoration(
                  hintText: "ENTER CODE",
                  hintStyle: const TextStyle(color: Colors.white24, letterSpacing: 2),
                  filled: true,
                  fillColor: Colors.white.withOpacity(0.05),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide.none,
                  ),
                ),
                keyboardType: TextInputType.number,
                maxLength: 6,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
