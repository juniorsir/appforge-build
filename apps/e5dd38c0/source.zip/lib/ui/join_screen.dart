import 'widgets/discovery_radar.dart'; // Import the radar
import 'package:sendx/core/theme.dart';

class JoinScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GhostTheme.background,
      appBar: AppBar(title: Text("SEARCHING VAULTS"), backgroundColor: Colors.transparent),
      body: Column(
        children: [
          const SizedBox(height: 40),
          // 1. ADD THE RADAR HERE
          DiscoveryRadar(), 
          
          const SizedBox(height: 40),
          Text(
            "Scanning for nearby devices...",
            style: TextStyle(color: GhostTheme.textSecondary),
          ),
          
          const SizedBox(height: 20),
          // 2. Input for 6-digit code
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: TextField(
              style: TextStyle(color: Colors.white, fontSize: 24, letterSpacing: 8),
              decoration: GhostTheme.glassDecoration.copyWith(
                hintText: "ENTER CODE",
                hintStyle: TextStyle(color: Colors.white24, letterSpacing: 2),
              ),
              keyboardType: TextInputType.number,
              maxLength: 6,
            ),
          ),
        ],
      ),
    );
  }
}
