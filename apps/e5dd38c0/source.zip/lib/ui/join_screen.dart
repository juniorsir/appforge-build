import 'package:flutter/material.dart';
import 'package:sendx/core/theme.dart';
import 'package:sendx/ui/widgets/discovery_radar.dart';

// ⚠️ Make sure this exists in your project
// import 'package:sendx/core/connection_manager.dart';
// import 'package:sendx/ui/screens/player_screen.dart';

class JoinScreen extends StatefulWidget {
  @override
  _JoinScreenState createState() => _JoinScreenState();
}

class _JoinScreenState extends State<JoinScreen> {

  // 🔥 Function to handle code input
  void _onCodeEntered(String enteredCode) async {
    if (enteredCode.length == 6) {
      FocusScope.of(context).unfocus(); // Hide keyboard

      print("Searching for host...");

      try {
        String? hostAddress =
            await ConnectionManager.findHost(enteredCode);

        if (hostAddress != null) {
          print("Found Host at $hostAddress");

          // 🚀 Navigate to Player Screen
          // Uncomment when PlayerScreen is ready
          /*
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => PlayerScreen(
                url: "http://$hostAddress/stream",
              ),
            ),
          );
          */
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                  "No Vault found with this code on your network."),
            ),
          );
        }
      } catch (e) {
        print("Error: $e");
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("Something went wrong while searching."),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: GhostTheme.background,
      appBar: AppBar(
        title: const Text("SEARCHING VAULTS"),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 40),

            // 🔍 Radar Animation
            DiscoveryRadar(),

            const SizedBox(height: 40),

            const Text(
              "Scanning for nearby devices...",
              style: TextStyle(
                color: GhostTheme.textSecondary,
                fontSize: 14,
              ),
            ),

            const SizedBox(height: 30),

            // 🔢 Code Input
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: TextField(
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  letterSpacing: 8,
                ),
                decoration: InputDecoration(
                  hintText: "ENTER CODE",
                  hintStyle: const TextStyle(
                    color: Colors.white24,
                    letterSpacing: 2,
                  ),
                  filled: true,
                  fillColor: Colors.white.withOpacity(0.05),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide.none,
                  ),
                  counterText: "", // ❌ hides 0/6 counter
                ),
                keyboardType: TextInputType.number,
                maxLength: 6,

                // ✅ Trigger when user types
                onChanged: (value) {
                  if (value.length == 6) {
                    _onCodeEntered(value);
                  }
                },

                // ✅ Optional: trigger on enter key
                onSubmitted: _onCodeEntered,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
