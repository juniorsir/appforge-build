import 'package:flutter/material.dart';
import 'package:sendx/core/theme.dart';

class DiscoveryRadar extends StatefulWidget {
  @override
  _DiscoveryRadarState createState() => _DiscoveryRadarState();
}

class _DiscoveryRadarState extends State<DiscoveryRadar> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this, 
      duration: const Duration(seconds: 3), // Slower, more "premium" feel
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose(); // CRITICAL: Stop animation when screen closes
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 300, // Fixed size for the radar area
      width: double.infinity,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Pulsing Circles
          ...[1, 2, 3].map((i) => AnimatedBuilder(
                animation: _controller,
                builder: (context, child) {
                  // Use a non-linear curve for a more natural pulse
                  final progress = _controller.value;
                  return Container(
                    width: 100 * i * progress,
                    height: 100 * i * progress,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: GhostTheme.accentNeon.withOpacity((1 - progress).clamp(0, 1)),
                        width: 2,
                      ),
                    ),
                  );
                },
              )),
          // Central Glowing Icon
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: GhostTheme.accentNeon,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: GhostTheme.accentNeon.withOpacity(0.5),
                  blurRadius: 20,
                  spreadRadius: 5,
                )
              ],
            ),
            child: const Icon(Icons.radar, color: Colors.black, size: 40),
          ),
        ],
      ),
    );
  }
}
