import 'package:nearby_connections/nearby_connections.dart';

class P2PService {
  final Strategy strategy = Strategy.P2P_STAR; // One-to-many (Hotspot style)
  String? connectedEndpointId;

  // STEP 1: Host starts advertising (The 6-Digit Code is the Name)
  Future<void> startHosting(String code) async {
    try {
      bool a = await Nearby().startAdvertising(
        code, // This is our 6-digit code
        strategy,
        onConnectionInitiated: (id, info) => _onConnectionInitiated(id, info),
        onConnectionResult: (id, status) => print("Status: $status"),
        onDisconnected: (id) => print("Disconnected: $id"),
      );
    } catch (e) { print(e); }
  }

  // STEP 2: Client starts looking for the 6-digit code
  Future<void> startDiscovery() async {
    try {
      await Nearby().startDiscovery(
        "ghostvault_service",
        strategy,
        onEndpointFound: (id, name, serviceId) {
          // If 'name' matches our 6-digit code, request connection
          Nearby().requestConnection(name, id, 
            onConnectionInitiated: (id, info) => _onConnectionInitiated(id, info),
            onConnectionResult: (id, status) => print(status), 
            onDisconnected: (id) => print(id)
          );
        },
        onEndpointLost: (id) {},
      );
    } catch (e) { print(e); }
  }

  void _onConnectionInitiated(String id, ConnectionInfo info) {
    // Show a dialog to the user: "Accept connection from ${info.endpointName}?"
    Nearby().acceptConnection(id, onPayLoadRecieved: (endpointId, payload) {
      // Handle file or stream data here
    });
  }
}
