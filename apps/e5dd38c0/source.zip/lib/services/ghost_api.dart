import 'package:dio/dio.dart';
import 'dart:io';

class GhostVaultAPI {
  final Dio _dio = Dio(BaseOptions(baseUrl: "https://jstore.2bd.net"));

  Future<void> uploadWithProgress(File file, String apiKey, Function(double) onProgress) async {
    final formData = FormData.fromMap({
      'file': await MultipartFile.fromFile(file.path),
    });

    await _dio.post(
      '/api/upload',
      data: formData,
      options: Options(headers: {'x-api-key': apiKey}),
      onSendProgress: (sent, total) {
        onProgress(sent / total);
      },
    );
  }
}
