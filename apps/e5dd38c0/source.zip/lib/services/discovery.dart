import 'dart:convert';
import 'dart:io';
import 'dart:async';

class DiscoveryService {
  static const int udpPort = 8888;
  RawDatagramSocket? _socket;

  // Broadcasts presence: "I am Code 123456"
  void startBroadcasting(String code, int serverPort) async {
    _socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
    _socket?.broadcastEnabled = true;

    Timer.periodic(const Duration(seconds: 2), (timer) {
      final data = jsonEncode({"code": code, "port": serverPort});
      _socket?.send(utf8.encode(data), InternetAddress("255.255.255.255"), udpPort);
    });
  }

  // Listens for a specific 6-digit code
  Future<String?> searchForCode(String targetCode) async {
    final receiver = await RawDatagramSocket.bind(InternetAddress.anyIPv4, udpPort);
    receiver.timeout(Duration(seconds: 10));

    await for (RawSocketEvent event in receiver) {
      if (event == RawSocketEvent.read) {
        Datagram? dg = receiver.receive();
        if (dg != null) {
          final data = jsonDecode(utf8.decode(dg.data));
          if (data['code'] == targetCode) {
            receiver.close();
            return "${dg.address.address}:${data['port']}";
          }
        }
      }
    }
    return null;
  }
}
