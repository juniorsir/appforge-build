import 'package:network_info_plus/network_info_plus.dart';
import 'discovery.dart';
import 'local_server.dart';

class ConnectionManager {
  static final DiscoveryService _discovery = DiscoveryService();
  static final LocalVaultServer _server = LocalVaultServer();
  
  // HOSTING LOGIC
  static Future<String> startHosting(String code, String filePath) async {
    final info = NetworkInfo();
    String? ip = await info.getWifiIP();
    
    // Start Local HTTP Server
    int port = await _server.start(filePath);
    
    // Start UDP Broadcast so others can find this IP via the 6-digit code
    _discovery.startBroadcasting(code, port);
    
    return ip ?? "127.0.0.1";
  }

  // JOINING LOGIC
  static Future<String?> findHost(String code) async {
    // Search the air for a UDP packet matching this code
    return await _discovery.searchForCode(code);
  }
}
