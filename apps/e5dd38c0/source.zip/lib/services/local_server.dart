import 'package:shelf/shelf.dart';
import 'package:shelf/shelf_io.dart' as io;
import 'package:shelf_router/shelf_router.dart';
import 'dart:io';

class LocalVaultServer {
  HttpServer? _server;

  Future<int> start(String filePath) async {
    final router = Router();
    final file = File(filePath);

    // Endpoint for peers to download/stream
    router.get('/stream', (Request request) {
      return Response.ok(
        file.openRead(),
        headers: {
          'Content-Type': 'video/mp4',
          'Content-Length': file.lengthSync().toString(),
          'Accept-Ranges': 'bytes',
        },
      );
    });

    final handler = const Pipeline().addMiddleware(logRequests()).addHandler(router);
    _server = await io.serve(handler, InternetAddress.anyIPv4, 0); // Random port
    return _server!.port;
  }

  void stop() => _server?.close();
}
