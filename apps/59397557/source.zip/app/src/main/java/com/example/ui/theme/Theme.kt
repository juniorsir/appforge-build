package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    secondary = TechEmerald,
    tertiary = LaserOrange,
    background = SlateBg,
    surface = SlateSurface,
    surfaceVariant = SlateSurfaceVariant,
    onPrimary = SlateBg,
    onSecondary = SlateBg,
    onBackground = WhiteText,
    onSurface = WhiteText,
    onSurfaceVariant = MutedText
)

private val LightColorScheme = lightColorScheme(
    primary = NeonCyanDim,
    secondary = TechEmerald,
    tertiary = LaserOrange,
    background = SlateBg,
    surface = SlateSurface,
    onPrimary = SlateBg,
    onSecondary = SlateBg,
    onBackground = WhiteText,
    onSurface = WhiteText
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Sleek, specialized dark mode by default
    content: @Composable () -> Unit,
) {
    val colorScheme = DarkColorScheme // Pin to DarkColorScheme for modern technical vibe

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
