package com.example.network

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TechEmerald
import com.example.ui.theme.WhiteText
import com.example.ui.theme.MutedText
import com.google.zxing.*
import com.google.zxing.common.HybridBinarizer
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

@Composable
fun QrCodeScannerView(
    onCodeScanned: (String) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { isGranted ->
            hasCameraPermission = isGranted
            if (!isGranted) {
                Toast.makeText(context, "Camera permission is required to scan QR codes.", Toast.LENGTH_LONG).show()
            }
        }
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0C1017))
            .testTag("qr_scanner_container"),
        contentAlignment = Alignment.Center
    ) {
        if (hasCameraPermission) {
            CameraScannerCore(
                onCodeScanned = onCodeScanned,
                onClose = onClose
            )
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .background(Color(0xFF1D2433), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CameraAlt,
                        contentDescription = "Camera Permission Needed",
                        tint = NeonCyan,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Text(
                    text = "Camera Permission Required",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "AeroShare uses the device camera to read session QR codes for instant direct peer connection.",
                    fontSize = 13.sp,
                    color = Color(0xFF94A3B8),
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth(0.8f)
                        .height(48.dp)
                        .testTag("request_camera_permission_button")
                ) {
                    Text(
                        text = "Grant Camera Access",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                TextButton(onClick = onClose) {
                    Text(
                        text = "Cancel Scanner",
                        color = Color(0xFF64748B),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
fun CameraScannerCore(
    onCodeScanned: (String) -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var isFlashEnabled by remember { mutableStateOf(false) }
    var qrDecodedValue by remember { mutableStateOf<String?>(null) }
    
    val cameraExecutor: ExecutorService = remember { Executors.newSingleThreadExecutor() }
    var cameraControl: CameraControl? by remember { mutableStateOf(null) }

    // Floating moving laser animation coordinates
    val transition = rememberInfiniteTransition(label = "laser")
    val laserOffsetPercent by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_offset"
    )

    // Trigger scanned value only once
    LaunchedEffect(qrDecodedValue) {
        val finalVal = qrDecodedValue
        if (finalVal != null) {
            onCodeScanned(finalVal)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            cameraExecutor.shutdown()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // CameraX Preview and Analysis Bind
        AndroidView(
            factory = { ctx ->
                PreviewView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                }
            },
            modifier = Modifier.fillMaxSize(),
            update = { previewView ->
                val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
                cameraProviderFuture.addListener({
                    val cameraProvider = cameraProviderFuture.get()
                    
                    val preview = Preview.Builder().build().also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }

                    val imageAnalysis = ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()

                    imageAnalysis.setAnalyzer(cameraExecutor, QrCodeAnalyzer { result ->
                        if (qrDecodedValue == null) {
                            qrDecodedValue = result
                        }
                    })

                    val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

                    try {
                        cameraProvider.unbindAll()
                        val camera = cameraProvider.bindToLifecycle(
                            lifecycleOwner,
                            cameraSelector,
                            preview,
                            imageAnalysis
                        )
                        cameraControl = camera.cameraControl
                        cameraControl?.enableTorch(isFlashEnabled)
                    } catch (exc: Exception) {
                        Toast.makeText(context, "Failed to start camera preview", Toast.LENGTH_SHORT).show()
                    }
                }, ContextCompat.getMainExecutor(context))
            }
        )

        // Flash Light Toggle synchronization
        LaunchedEffect(isFlashEnabled) {
            cameraControl?.enableTorch(isFlashEnabled)
        }

        // HUD View Overlays
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val boxSize = 250.dp.toPx()
            val left = (width - boxSize) / 2f
            val top = (height - boxSize) / 2f
            val right = left + boxSize
            val bottom = top + boxSize

            // Semi-transparent shade bounds
            // Top Block
            drawRect(color = Color.Black.copy(alpha = 0.65f), topLeft = Offset(0f, 0f), size = Size(width, top))
            // Left Block
            drawRect(color = Color.Black.copy(alpha = 0.65f), topLeft = Offset(0f, top), size = Size(left, boxSize))
            // Right Block
            drawRect(color = Color.Black.copy(alpha = 0.65f), topLeft = Offset(right, top), size = Size(width - right, boxSize))
            // Bottom Block
            drawRect(color = Color.Black.copy(alpha = 0.65f), topLeft = Offset(0f, bottom), size = Size(width, height - bottom))

            // Reticle Frame Corner Brackets of Neon Cyan
            val cornerLength = 24.dp.toPx()
            val strokeWidth = 3.dp.toPx()

            // Top-Left corner
            drawLine(color = NeonCyan, start = Offset(left, top), end = Offset(left + cornerLength, top), strokeWidth = strokeWidth, cap = StrokeCap.Round)
            drawLine(color = NeonCyan, start = Offset(left, top), end = Offset(left, top + cornerLength), strokeWidth = strokeWidth, cap = StrokeCap.Round)

            // Top-Right corner
            drawLine(color = NeonCyan, start = Offset(right, top), end = Offset(right - cornerLength, top), strokeWidth = strokeWidth, cap = StrokeCap.Round)
            drawLine(color = NeonCyan, start = Offset(right, top), end = Offset(right, top + cornerLength), strokeWidth = strokeWidth, cap = StrokeCap.Round)

            // Bottom-Left corner
            drawLine(color = NeonCyan, start = Offset(left, bottom), end = Offset(left + cornerLength, bottom), strokeWidth = strokeWidth, cap = StrokeCap.Round)
            drawLine(color = NeonCyan, start = Offset(left, bottom), end = Offset(left, bottom - cornerLength), strokeWidth = strokeWidth, cap = StrokeCap.Round)

            // Bottom-Right corner
            drawLine(color = NeonCyan, start = Offset(right, bottom), end = Offset(right - cornerLength, bottom), strokeWidth = strokeWidth, cap = StrokeCap.Round)
            drawLine(color = NeonCyan, start = Offset(right, bottom), end = Offset(right, bottom - cornerLength), strokeWidth = strokeWidth, cap = StrokeCap.Round)

            // Dynamic Scanning Laser Line
            val laserY = top + (boxSize * laserOffsetPercent)
            drawLine(
                color = TechEmerald,
                start = Offset(left + 8.dp.toPx(), laserY),
                end = Offset(right - 8.dp.toPx(), laserY),
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )
        }

        // Foreground UI Elements (Instructional texts and overlay controls)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
                .statusBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Nav
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .background(Color.Black.copy(0.5f), CircleShape)
                        .testTag("scanner_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Cancel Scanning",
                        tint = Color.White
                    )
                }

                Text(
                    text = "CAMERA QR KEY SCAN",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonCyan,
                    letterSpacing = 1.sp,
                    modifier = Modifier
                        .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                )

                IconButton(
                    onClick = { isFlashEnabled = !isFlashEnabled },
                    modifier = Modifier
                        .background(Color.Black.copy(0.5f), CircleShape)
                        .testTag("scanner_flash_button")
                ) {
                    Icon(
                        imageVector = if (isFlashEnabled) Icons.Default.FlashOff else Icons.Default.FlashOn,
                        contentDescription = "Toggle Torch",
                        tint = if (isFlashEnabled) TechEmerald else Color.White
                    )
                }
            }

            // Central reticle informational banner
            Text(
                text = "Center the receiver's pairing QR box to scan",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .background(Color.Black.copy(0.6f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            )

            // Bottom Spaced Buffer
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

private class QrCodeAnalyzer(
    private val onQrCodeScanned: (String) -> Unit
) : ImageAnalysis.Analyzer {

    private val reader = MultiFormatReader().apply {
        val hints = EnumMap<DecodeHintType, Any>(DecodeHintType::class.java)
        hints[DecodeHintType.POSSIBLE_FORMATS] = listOf(BarcodeFormat.QR_CODE)
        setHints(hints)
    }

    override fun analyze(image: ImageProxy) {
        val buffer = image.planes[0].buffer
        val data = ByteArray(buffer.remaining())
        buffer.get(data)
        
        val width = image.width
        val height = image.height

        try {
            // Decodes standard portrait or rotated stream frames
            // First try decoding directly
            val source = PlanarYUVLuminanceSource(
                data, width, height,
                0, 0, width, height,
                false
            )
            var bitmap = BinaryBitmap(HybridBinarizer(source))
            try {
                val result = reader.decodeWithState(bitmap)
                onQrCodeScanned(result.text)
            } catch (e: Exception) {
                // Try with rotated source data if standard doesn't parse (portrait scanner rotated view)
                val rotatedData = rotateYuv90(data, width, height)
                val rotatedSource = PlanarYUVLuminanceSource(
                    rotatedData, height, width,
                    0, 0, height, width,
                    false
                )
                bitmap = BinaryBitmap(HybridBinarizer(rotatedSource))
                val result = reader.decodeWithState(bitmap)
                onQrCodeScanned(result.text)
            }
        } catch (e: Exception) {
            // Under steady scan stream, decode failures are expected until image frame covers clean QR code.
        } finally {
            image.close()
        }
    }

    // Rotates byte grid 90 degrees clockwise to handle vertical aspect stream orientation transformations
    private fun rotateYuv90(data: ByteArray, width: Int, height: Int): ByteArray {
        val rotated = ByteArray(data.size)
        var i = 0
        for (x in 0 until width) {
            for (y in height - 1 downTo 0) {
                rotated[i++] = data[y * width + x]
            }
        }
        return rotated
    }
}
