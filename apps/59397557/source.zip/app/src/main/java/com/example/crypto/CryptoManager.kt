package com.example.crypto

import android.util.Base64
import java.security.SecureRandom
import java.nio.ByteBuffer
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

object CryptoManager {
    private const val AES_GCM_ALGORITHM = "AES/GCM/NoPadding"
    private const val GCM_TAG_LENGTH_BITS = 128
    private const val KEY_SIZE_BITS = 256
    private const val IV_SIZE_BYTES = 12

    val secureRandom: SecureRandom by lazy { SecureRandom() }

    /**
     * Generate an unpredictable, secure 256-bit AES secret key.
     */
    fun generateAESKey(): SecretKey {
        val keyGenerator = KeyGenerator.getInstance("AES")
        keyGenerator.init(KEY_SIZE_BITS)
        return keyGenerator.generateKey()
    }

    /**
     * Converts a secret key into string for QR codes and pincodes.
     */
    fun keyToBase64(key: SecretKey): String {
        return Base64.encodeToString(key.encoded, Base64.NO_WRAP or Base64.URL_SAFE)
    }

    /**
     * Reconstructs an AES secret key from string.
     */
    fun base64ToKey(base64Str: String): SecretKey {
        val decoded = Base64.decode(base64Str, Base64.NO_WRAP or Base64.URL_SAFE)
        return SecretKeySpec(decoded, "AES")
    }

    /**
     * Generates a 12-byte initialization vector, with the first 8 bytes randomized 
     * and the last 4 bytes set to represent the chunk index to avoid repetitions.
     */
    fun generateChunkIV(sessionRandomBytes: ByteArray, chunkIndex: Int): ByteArray {
        val iv = ByteArray(IV_SIZE_BYTES)
        System.arraycopy(sessionRandomBytes, 0, iv, 0, 8)
        
        val buffer = ByteBuffer.allocate(4)
        buffer.putInt(chunkIndex)
        System.arraycopy(buffer.array(), 0, iv, 8, 4)
        return iv
    }

    /**
     * Performs direct AES-GCM block encryption.
     */
    fun encryptChunk(data: ByteArray, key: SecretKey, iv: ByteArray): ByteArray {
        val cipher = Cipher.getInstance(AES_GCM_ALGORITHM)
        val spec = GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv)
        cipher.init(Cipher.ENCRYPT_MODE, key, spec)
        return cipher.doFinal(data)
    }

    /**
     * Performs direct AES-GCM block decryption.
     */
    fun decryptChunk(data: ByteArray, key: SecretKey, iv: ByteArray): ByteArray {
        val cipher = Cipher.getInstance(AES_GCM_ALGORITHM)
        val spec = GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv)
        cipher.init(Cipher.DECRYPT_MODE, key, spec)
        return cipher.doFinal(data)
    }

    /**
     * Quick encrypt utility for single strings (like headers or metadata).
     */
    fun encryptText(text: String, key: SecretKey): String {
        val bytes = text.toByteArray(Charsets.UTF_8)
        val iv = ByteArray(IV_SIZE_BYTES).apply { secureRandom.nextBytes(this) }
        val cipherText = encryptChunk(bytes, key, iv)
        
        val combined = ByteArray(IV_SIZE_BYTES + cipherText.size)
        System.arraycopy(iv, 0, combined, 0, IV_SIZE_BYTES)
        System.arraycopy(cipherText, 0, combined, IV_SIZE_BYTES, cipherText.size)
        
        return Base64.encodeToString(combined, Base64.NO_WRAP or Base64.URL_SAFE)
    }

    /**
     * Quick decrypt utility for single strings.
     */
    fun decryptText(base64Text: String, key: SecretKey): String {
        val combined = Base64.decode(base64Text, Base64.NO_WRAP or Base64.URL_SAFE)
        val iv = ByteArray(IV_SIZE_BYTES)
        System.arraycopy(combined, 0, iv, 0, IV_SIZE_BYTES)
        
        val cipherText = ByteArray(combined.size - IV_SIZE_BYTES)
        System.arraycopy(combined, IV_SIZE_BYTES, cipherText, 0, cipherText.size)
        
        val decryptedBytes = decryptChunk(cipherText, key, iv)
        return String(decryptedBytes, Charsets.UTF_8)
    }
}
