package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transfer_events")
data class TransferEvent(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fileName: String,
    val fileSize: Long,
    val isSender: Boolean,
    val speedMBs: Double,
    val status: String, // "COMPLETED", "FAILED", "IN_PROGRESS"
    val timestamp: Long = System.currentTimeMillis(),
    val peerIp: String
)
