package com.example.network

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.crypto.CryptoManager
import com.example.ui.ChosenFile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.ServerSocket
import java.net.Socket
import javax.crypto.SecretKey

object StreamManager {
    private const val TAG = "StreamManager"
    const val STREAM_PORT = 9993

    sealed class StreamState {
        object Idle : StreamState()
        data class Hosting(val ip: String, val port: Int, val pairingCode: String, val filesCount: Int) : StreamState()
        data class ClientConnected(val hostIp: String, val files: List<StreamFile>) : StreamState()
        data class Loading(val message: String) : StreamState()
        data class Error(val message: String) : StreamState()
    }

    data class StreamFile(
        val index: Int,
        val name: String,
        val size: Long
    )

    private val _streamState = MutableStateFlow<StreamState>(StreamState.Idle)
    val streamState = _streamState.asStateFlow()

    private var hostServerSocket: ServerSocket? = null
    private var clientSocket: Socket? = null
    private var activeSecretKey: SecretKey? = null
    private var hostedFiles: List<ChosenFile> = emptyList()

    // Status / Progress updates for streaming action
    private val _streamingProgress = MutableStateFlow<String?>(null)
    val streamingProgress = _streamingProgress.asStateFlow()

    fun hostStreamSession(context: Context, files: List<ChosenFile>) {
        if (files.isEmpty()) {
            _streamState.value = StreamState.Error("No files selected to host stream")
            return
        }
        _streamState.value = StreamState.Loading("Initializing streaming host...")
        hostedFiles = files

        CoroutineScope(Dispatchers.IO).launch {
            try {
                hostServerSocket?.close()
                val ip = NetworkManager.getLocalIpAddress()
                if (ip == "127.0.0.1") {
                    _streamState.value = StreamState.Error("Wi-Fi network not detected. Please connect to a hotspot/Wi-Fi.")
                    return@launch
                }

                val server = ServerSocket(STREAM_PORT)
                hostServerSocket = server
                val key = CryptoManager.generateAESKey()
                activeSecretKey = key
                val base64Key = CryptoManager.keyToBase64(key)
                val streamCode = "AEROSHARE_STREAM|$ip|$STREAM_PORT|$base64Key"

                _streamState.value = StreamState.Hosting(ip, STREAM_PORT, streamCode, files.size)
                Log.d(TAG, "Streaming server running on $ip:$STREAM_PORT")

                while (!server.isClosed) {
                    val client = try {
                        server.accept()
                    } catch (e: Exception) {
                        break
                    }
                    Log.d(TAG, "Stream client connected from ${client.inetAddress.hostAddress}")
                    handleHostClient(context, client, key)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error in streaming server", e)
                _streamState.value = StreamState.Error("Failed to start server: ${e.localizedMessage}")
                com.example.notification.NotificationHelper.showNotification(
                    title = "Stream Server Error",
                    message = e.localizedMessage ?: "Unknown error",
                    isError = true
                )
            }
        }
    }

    private fun handleHostClient(context: Context, client: Socket, key: SecretKey) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                client.tcpNoDelay = true
                val br = BufferedReader(InputStreamReader(client.getInputStream(), Charsets.UTF_8))
                val bos = BufferedOutputStream(client.getOutputStream())

                while (!client.isClosed) {
                    val requestLineEnc = br.readLine() ?: break
                    val requestLine = try {
                        CryptoManager.decryptText(requestLineEnc, key)
                    } catch (e: Exception) {
                        Log.e(TAG, "Decryption of request failed", e)
                        break
                    }

                    Log.d(TAG, "Stream Request: $requestLine")
                    val parts = requestLine.split("|")
                    val cmd = parts[0]

                    when (cmd) {
                        "LIST" -> {
                            // build files list metadata
                            // format: INDEX;NAME;SIZE||INDEX;NAME;SIZE
                            val listStr = hostedFiles.mapIndexed { idx, f ->
                                "$idx;${f.name};${f.size}"
                            }.joinToString("||")
                            val responseEnc = CryptoManager.encryptText(listStr, key)
                            bos.write((responseEnc + "\n").toByteArray(Charsets.UTF_8))
                            bos.flush()
                        }
                        "STREAM_CHUNK" -> {
                            val fIdx = parts[1].toInt()
                            val offset = parts[2].toLong()
                            val length = parts[3].toInt()

                            if (fIdx in hostedFiles.indices) {
                                val file = hostedFiles[fIdx]
                                val chunkData = readChunk(context, file.uri, offset, length)
                                val encryptedChunk = CryptoManager.encryptChunk(chunkData.first, key, CryptoManager.generateChunkIV(ByteArray(8), fIdx))
                                
                                // send size header (4 bytes) + encrypted bytes
                                val lenBuf = java.nio.ByteBuffer.allocate(4).putInt(encryptedChunk.size).array()
                                bos.write(lenBuf)
                                bos.write(encryptedChunk)
                                bos.flush()
                            } else {
                                Log.e(TAG, "Invalid file index requested: $fIdx")
                                break
                            }
                        }
                        "STREAM_FULL" -> {
                            val fIdx = parts[1].toInt()
                            if (fIdx in hostedFiles.indices) {
                                val file = hostedFiles[fIdx]
                                Log.d(TAG, "Streaming full file bytes on demand: ${file.name}")
                                streamFullFile(context, file.uri, bos, key, fIdx)
                            } else {
                                Log.e(TAG, "Invalid full stream file index: $fIdx")
                                break
                            }
                        }
                        else -> {
                            Log.w(TAG, "Unknown stream command: $cmd")
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error handling host client", e)
            } finally {
                try { client.close() } catch (_: Exception) {}
            }
        }
    }

    private fun readChunk(context: Context, uri: Uri, offset: Long, length: Int): Pair<ByteArray, Int> {
        return try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                val buffered = BufferedInputStream(inputStream)
                var totalSkipped = 0L
                while (totalSkipped < offset) {
                    val skipped = buffered.skip(offset - totalSkipped)
                    if (skipped <= 0) {
                        // fallback custom skip
                        val skipBuf = ByteArray(8192)
                        val remain = offset - totalSkipped
                        val lenToRead = minOf(remain, skipBuf.size.toLong()).toInt()
                        val r = buffered.read(skipBuf, 0, lenToRead)
                        if (r == -1) break
                        totalSkipped += r
                    } else {
                        totalSkipped += skipped
                    }
                }
                val resultBuf = ByteArray(length)
                var bytesReadTotal = 0
                while (bytesReadTotal < length) {
                    val r = buffered.read(resultBuf, bytesReadTotal, length - bytesReadTotal)
                    if (r == -1) break
                    bytesReadTotal += r
                }
                val trimmedResult = if (bytesReadTotal < length) {
                    val temp = ByteArray(bytesReadTotal)
                    System.arraycopy(resultBuf, 0, temp, 0, bytesReadTotal)
                    temp
                } else {
                    resultBuf
                }
                trimmedResult to bytesReadTotal
            } ?: (ByteArray(0) to 0)
        } catch (e: Exception) {
            Log.e(TAG, "readChunk error at offset $offset size $length", e)
            ByteArray(0) to 0
        }
    }

    private fun streamFullFile(context: Context, uri: Uri, bos: BufferedOutputStream, key: SecretKey, fileIndex: Int) {
        try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                val buffered = BufferedInputStream(inputStream)
                val buffer = ByteArray(128 * 1024) // 128KB buffer chunks
                var read: Int
                var chunkIndex = 0

                while (buffered.read(buffer).also { read = it } != -1) {
                    val pieceBytes = if (read < buffer.size) {
                        val slice = ByteArray(read)
                        System.arraycopy(buffer, 0, slice, 0, read)
                        slice
                    } else {
                        buffer
                    }

                    // Encrypt piece
                    val iv = CryptoManager.generateChunkIV(ByteArray(8), chunkIndex)
                    val encrypted = CryptoManager.encryptChunk(pieceBytes, key, iv)

                    // Write prefix size + encrypted block
                    val lenBuf = java.nio.ByteBuffer.allocate(4).putInt(encrypted.size).array()
                    bos.write(lenBuf)
                    bos.write(encrypted)
                    bos.flush()
                    chunkIndex++
                }
                
                // Write EOF indicator (size = -1) to cleanly denote finished stream
                val finishIndicator = java.nio.ByteBuffer.allocate(4).putInt(-1).array()
                bos.write(finishIndicator)
                bos.flush()
            }
        } catch (e: Exception) {
            Log.e(TAG, "streamFullFile failed", e)
            // Send EOF indicator on error
            try {
                val errIndicator = java.nio.ByteBuffer.allocate(4).putInt(-1).array()
                bos.write(errIndicator)
                bos.flush()
            } catch (_: Exception) {}
        }
    }

    // ================= CLIENT SIDE (RECEIVER) =================

    fun connectToStreamHost(pairingCode: String) {
        _streamState.value = StreamState.Loading("Parsing stream credentials...")
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val parts = pairingCode.split("|")
                if (parts.size < 4 || parts[0] != "AEROSHARE_STREAM") {
                    _streamState.value = StreamState.Error("Invalid streaming pairing credentials")
                    return@launch
                }
                val ip = parts[1]
                val port = parts[2].toInt()
                val keyBase64 = parts[3]
                val key = CryptoManager.base64ToKey(keyBase64)
                activeSecretKey = key

                _streamState.value = StreamState.Loading("Bridging direct connection...")
                val socket = Socket(ip, port)
                clientSocket = socket
                socket.tcpNoDelay = true

                _streamState.value = StreamState.Loading("Synchronizing file inventories...")
                val bos = BufferedOutputStream(socket.getOutputStream())
                val br = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))

                // Request file list
                val reqEnc = CryptoManager.encryptText("LIST", key)
                bos.write((reqEnc + "\n").toByteArray(Charsets.UTF_8))
                bos.flush()

                val responseEnc = br.readLine()
                if (responseEnc == null) {
                    _streamState.value = StreamState.Error("Stream host terminated handshake connection prematurely.")
                    return@launch
                }

                val response = CryptoManager.decryptText(responseEnc, key)
                val files = if (response.isBlank()) {
                    emptyList()
                } else {
                    response.split("||").map { fileSpec ->
                        val specParts = fileSpec.split(";")
                        StreamFile(
                            index = specParts[0].toInt(),
                            name = specParts[1],
                            size = specParts[2].toLong()
                        )
                    }
                }

                _streamState.value = StreamState.ClientConnected(ip, files)
            } catch (e: Exception) {
                Log.e(TAG, "Failed stream client connection", e)
                _streamState.value = StreamState.Error("Unable to connect to stream host: ${e.localizedMessage}")
                com.example.notification.NotificationHelper.showNotification(
                    title = "Stream Connection Error",
                    message = e.localizedMessage ?: "Unknown connection error",
                    isError = true
                )
            }
        }
    }

    /**
     * Streams entire file on demand from the streaming server and yields decrypted byte chunks.
     */
    suspend fun streamFileOnDemand(fileIndex: Int, onProgress: (Float) -> Unit): ByteArray? = withContext(Dispatchers.IO) {
        val socket = clientSocket ?: return@withContext null
        val key = activeSecretKey ?: return@withContext null
        _streamingProgress.value = "Streaming starting..."

        try {
            val bos = BufferedOutputStream(socket.getOutputStream())
            val req = CryptoManager.encryptText("STREAM_FULL|$fileIndex", key)
            bos.write((req + "\n").toByteArray(Charsets.UTF_8))
            bos.flush()

            val bis = BufferedInputStream(socket.getInputStream())
            val byteAccumulator = java.io.ByteArrayOutputStream()
            val sizeHeader = ByteArray(4)
            var chunkIndex = 0

            while (true) {
                // Read 4 bytes size prefix
                var readH = 0
                while (readH < 4) {
                    val rh = bis.read(sizeHeader, readH, 4 - readH)
                    if (rh == -1) break
                    readH += rh
                }
                if (readH != 4) break

                val chunkSize = java.nio.ByteBuffer.wrap(sizeHeader).int
                if (chunkSize == -1) {
                    // Cleaner EOF reached
                    break
                }

                val encBlock = ByteArray(chunkSize)
                var readB = 0
                while (readB < chunkSize) {
                    val rb = bis.read(encBlock, readB, chunkSize - readB)
                    if (rb == -1) break
                    readB += rb
                }
                if (readB != chunkSize) throw Exception("Stream packet corruption")

                val iv = CryptoManager.generateChunkIV(ByteArray(8), chunkIndex)
                val decPiece = CryptoManager.decryptChunk(encBlock, key, iv)
                byteAccumulator.write(decPiece)

                chunkIndex++
                _streamingProgress.value = "Processed chunk #$chunkIndex (${decPiece.size} bytes streamed)"
            }

            _streamingProgress.value = null
            byteAccumulator.toByteArray()
        } catch (e: Exception) {
            Log.e(TAG, "Error in on-demand streaming", e)
            _streamingProgress.value = null
            null
        }
    }

    /**
     * Fetch a small chunk of a file specifically (e.g. for previewing text files or small thumbnail buffers)
     */
    suspend fun fetchFileChunkOnDemand(fileIndex: Int, offset: Long, length: Int): ByteArray? = withContext(Dispatchers.IO) {
        val socket = clientSocket ?: return@withContext null
        val key = activeSecretKey ?: return@withContext null

        try {
            val bos = BufferedOutputStream(socket.getOutputStream())
            val req = CryptoManager.encryptText("STREAM_CHUNK|$fileIndex|$offset|$length", key)
            bos.write((req + "\n").toByteArray(Charsets.UTF_8))
            bos.flush()

            val bis = BufferedInputStream(socket.getInputStream())
            val sizeHeader = ByteArray(4)
            var readH = 0
            while (readH < 4) {
                val rh = bis.read(sizeHeader, readH, 4 - readH)
                if (rh == -1) break
                readH += rh
            }
            if (readH != 4) return@withContext null

            val chunkSize = java.nio.ByteBuffer.wrap(sizeHeader).int
            val encBlock = ByteArray(chunkSize)
            var readB = 0
            while (readB < chunkSize) {
                val rb = bis.read(encBlock, readB, chunkSize - readB)
                if (rb == -1) break
                readB += rb
            }
            if (readB != chunkSize) return@withContext null

            val iv = CryptoManager.generateChunkIV(ByteArray(8), fileIndex)
            CryptoManager.decryptChunk(encBlock, key, iv)
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching stream chunk on demand", e)
            null
        }
    }

    fun stopStreamSession() {
        try {
            hostServerSocket?.close()
        } catch (_: Exception) {}
        try {
            clientSocket?.close()
        } catch (_: Exception) {}
        hostServerSocket = null
        clientSocket = null
        activeSecretKey = null
        hostedFiles = emptyList()
        _streamState.value = StreamState.Idle
        _streamingProgress.value = null
    }
}
