package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Professional Polish Palette (Material 3 Lilac/Purple Scheme)
val SlateBg = Color(0xFFFEF7FF)              // Ultra light lavender white background
val SlateSurface = Color(0xFFFFFFFF)         // White surface cards
val SlateSurfaceVariant = Color(0xFFF3EDF7)  // Soft purple-tinted container background
val NeonCyan = Color(0xFF6750A4)             // Majesty Purple (Primary brand color)
val NeonCyanDim = Color(0xFF21005D)          // Deep midnight purple accent
val TechEmerald = Color(0xFF006874)          // Polished professional teal (Active / Verified)
val SecureRed = Color(0xFFB3261E)            // Modern material alert red
val LaserOrange = Color(0xFF8B5000)          // Warm transition amber orange
val WhiteText = Color(0xFF1D1B20)            // Dark charcoal body/text
val MutedText = Color(0xFF49454F)            // Material 3 gray secondary text

// Theme-specific accent additions from Professional Polish reference
val PolishedPairBg = Color(0xFFE8DEF8)       // Ready-to-pair card fill
val PolishedPairBorder = Color(0xFFD0BCFF)   // Material outline variant soft purple border
val PolishedBadgeBg = Color(0xFFC2E7FF)      // Active connection badge background style
val PolishedBadgeText = Color(0xFF001D35)    // Active connection badge text color element
val PolishedBorder = Color(0xFFCAC4D0)       // Standard thin card contour stroke border

