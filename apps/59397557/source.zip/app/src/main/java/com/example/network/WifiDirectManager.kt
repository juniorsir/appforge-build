package com.example.network

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

object WifiDirectManager {
    private const val TAG = "WifiDirectManager"

    private var manager: WifiP2pManager? = null
    private var channel: WifiP2pManager.Channel? = null
    private var receiver: BroadcastReceiver? = null
    private var isRegistered = false

    sealed class ConnectionState {
        object Disconnected : ConnectionState()
        object Discovering : ConnectionState()
        object Connecting : ConnectionState()
        data class Connected(val groupOwnerAddress: String, val isGroupOwner: Boolean) : ConnectionState()
    }

    private val _p2pEnabled = MutableStateFlow(false)
    val p2pEnabled = _p2pEnabled.asStateFlow()

    private val _discoveredPeers = MutableStateFlow<List<WifiP2pDevice>>(emptyList())
    val discoveredPeers = _discoveredPeers.asStateFlow()

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val connectionState = _connectionState.asStateFlow()

    private val _statusMessage = MutableStateFlow<String>("Wi-Fi Direct Ready")
    val statusMessage = _statusMessage.asStateFlow()

    fun init(context: Context) {
        try {
            manager = context.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
            manager?.let { p2pMgr ->
                channel = p2pMgr.initialize(context, context.mainLooper, null)
                registerReceiver(context)
                Log.d(TAG, "Wi-Fi Direct initialized successfully")
            } ?: run {
                _statusMessage.value = "Wi-Fi Direct not supported on this device"
                Log.w(TAG, "WifiP2pManager not available")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing Wi-Fi Direct", e)
            _statusMessage.value = "Init error: ${e.localizedMessage}"
        }
    }

    private fun registerReceiver(context: Context) {
        if (isRegistered) return
        val intentFilter = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION)
        }

        val p2pReceiver = object : BroadcastReceiver() {
            @SuppressLint("MissingPermission")
            override fun onReceive(context: Context, intent: Intent) {
                when (intent.action) {
                    WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> {
                        val state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1)
                        val isEnabled = state == WifiP2pManager.WIFI_P2P_STATE_ENABLED
                        _p2pEnabled.value = isEnabled
                        _statusMessage.value = if (isEnabled) "Wi-Fi Direct Enabled" else "Wi-Fi Direct Disabled"
                        Log.d(TAG, "P2P state changed: $isEnabled")
                    }
                    WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> {
                        manager?.requestPeers(channel) { peerList ->
                            val peers = peerList.deviceList.toList()
                            _discoveredPeers.value = peers
                            Log.d(TAG, "Discovered ${peers.size} Wi-Fi Direct peers")
                        }
                    }
                    WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> {
                        val networkInfo = intent.getParcelableExtra<android.net.NetworkInfo>(WifiP2pManager.EXTRA_NETWORK_INFO)
                        if (networkInfo?.isConnected == true) {
                            manager?.requestConnectionInfo(channel) { info ->
                                if (info.groupFormed) {
                                    val goAddress = info.groupOwnerAddress?.hostAddress ?: "192.168.49.1"
                                    _connectionState.value = ConnectionState.Connected(goAddress, info.isGroupOwner)
                                    _statusMessage.value = if (info.isGroupOwner) "Connected as Group Owner" else "Connected to Group Owner"
                                    Log.d(TAG, "P2P Connected! GO Address: $goAddress, IsGO: ${info.isGroupOwner}")
                                }
                            }
                        } else {
                            _connectionState.value = ConnectionState.Disconnected
                            _statusMessage.value = "Wi-Fi Direct Disconnected"
                            Log.d(TAG, "P2P Disconnected")
                        }
                    }
                    WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION -> {
                        val device = intent.getParcelableExtra<WifiP2pDevice>(WifiP2pManager.EXTRA_WIFI_P2P_DEVICE)
                        Log.d(TAG, "This device state changed: ${device?.deviceName}")
                    }
                }
            }
        }

        context.registerReceiver(p2pReceiver, intentFilter)
        receiver = p2pReceiver
        isRegistered = true
    }

    @SuppressLint("MissingPermission")
    fun startDiscovery() {
        val mgr = manager ?: return
        val ch = channel ?: return
        _connectionState.value = ConnectionState.Discovering
        _statusMessage.value = "Scanning for Wi-Fi Direct recipients..."

        mgr.discoverPeers(ch, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                Log.d(TAG, "Peer discovery initiated successfully")
            }

            override fun onFailure(reasonCode: Int) {
                val reasonText = when (reasonCode) {
                    WifiP2pManager.P2P_UNSUPPORTED -> "P2P Unsupported"
                    WifiP2pManager.ERROR -> "Internal Error"
                    WifiP2pManager.BUSY -> "System Busy"
                    else -> "Unknown error"
                }
                _connectionState.value = ConnectionState.Disconnected
                _statusMessage.value = "Discovery initiation failed: $reasonText"
                Log.e(TAG, "Peer discovery failed: $reasonText")
            }
        })
    }

    @SuppressLint("MissingPermission")
    fun connectToDevice(device: WifiP2pDevice, onSuccessAction: (() -> Unit)? = null) {
        val mgr = manager ?: return
        val ch = channel ?: return
        _connectionState.value = ConnectionState.Connecting
        _statusMessage.value = "Connecting to ${device.deviceName}..."

        val config = WifiP2pConfig().apply {
            deviceAddress = device.deviceAddress
        }

        mgr.connect(ch, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                _statusMessage.value = "Connection handshake initiated with ${device.deviceName}"
                onSuccessAction?.invoke()
                Log.d(TAG, "Connection handshake initiated with ${device.deviceName}")
            }

            override fun onFailure(reason: Int) {
                _connectionState.value = ConnectionState.Disconnected
                _statusMessage.value = "Failed to initiate connection to ${device.deviceName}"
                Log.e(TAG, "Connection initiation failed: $reason")
            }
        })
    }

    fun disconnect() {
        val mgr = manager ?: return
        val ch = channel ?: return

        mgr.removeGroup(ch, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                _connectionState.value = ConnectionState.Disconnected
                _statusMessage.value = "Group removed/Disconnected"
                Log.d(TAG, "Disconnect/Group removal success")
            }

            override fun onFailure(reason: Int) {
                Log.e(TAG, "Failed to remove group: $reason")
            }
        })
    }

    fun cleanup(context: Context) {
        if (isRegistered) {
            receiver?.let { context.unregisterReceiver(it) }
            isRegistered = false
            receiver = null
        }
    }
}
