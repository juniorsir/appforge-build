package com.example.network

import androidx.compose.foundation.Canvas
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

@Composable
fun QrCodeView(pairingCode: String, modifier: Modifier = Modifier) {
    val matrix = remember(pairingCode) {
        QrCodeGenerator.generateQrMatrix(pairingCode, 40)
    }

    if (matrix != null) {
        val size = matrix.size
        Canvas(modifier = modifier) {
            val cellWidth = this.size.width / size
            val cellHeight = this.size.height / size
            
            // Draw background white for classic QR contrast
            drawRect(color = Color.White)
            
            for (y in 0 until size) {
                for (x in 0 until size) {
                    if (matrix[y][x]) {
                        drawRect(
                            color = Color(0xFF0C1017), // Deep slate black
                            topLeft = androidx.compose.ui.geometry.Offset(x * cellWidth, y * cellHeight),
                            size = androidx.compose.ui.geometry.Size(cellWidth + 0.51f, cellHeight + 0.51f)
                        )
                    }
                }
            }
        }
    } else {
        Text("Preparing Secure QR Code...")
    }
}
