package com.example

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.QrCodeScanner
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.TransferEvent
import com.example.network.NetworkManager
import com.example.network.QrCodeView
import com.example.network.QrCodeScannerView
import com.example.network.WifiDirectManager
import com.example.ui.TransferViewModel
import com.example.ui.StreamPage
import com.example.ui.theme.*
import androidx.compose.ui.text.font.FontStyle

import android.os.Build
import android.content.pm.PackageManager

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        // Initialize local notification manager channel
        com.example.notification.NotificationHelper.init(this)

        // Initialize mDNS Local Discovery Manager
        com.example.network.MdnsDiscoveryManager.init(this)

        // Initialize Wi-Fi Direct Manager
        com.example.network.WifiDirectManager.init(this)

        // Request runtime permissions on opening application (Camera, Notifications, Location, and Nearby Devices)
        val permissionsToRequest = mutableListOf(
            android.Manifest.permission.CAMERA,
            android.Manifest.permission.ACCESS_FINE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionsToRequest.add(android.Manifest.permission.POST_NOTIFICATIONS)
            permissionsToRequest.add("android.permission.NEARBY_WIFI_DEVICES")
        }

        val requestPermissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { permissions ->
            val cameraGranted = permissions[android.Manifest.permission.CAMERA] ?: false
            val notificationsGranted = permissions[android.Manifest.permission.POST_NOTIFICATIONS] ?: true
            val locationGranted = permissions[android.Manifest.permission.ACCESS_FINE_LOCATION] ?: false
            val nearbyGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                permissions["android.permission.NEARBY_WIFI_DEVICES"] ?: false
            } else {
                true
            }
            if (!cameraGranted) {
                Toast.makeText(this, "Camera permission optional: enable in settings to scan QR.", Toast.LENGTH_SHORT).show()
            }
            if (!locationGranted || !nearbyGranted) {
                Toast.makeText(this, "Location and Nearby WiFi permissions are required for offline Wi-Fi Direct transfer.", Toast.LENGTH_LONG).show()
            }
        }
        
        requestPermissionLauncher.launch(permissionsToRequest.toTypedArray())

        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = SlateBg
                ) { innerPadding ->
                    AeroShareApp(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .windowInsetsPadding(WindowInsets.safeDrawing)
                    )
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        com.example.notification.NotificationHelper.isAppInForeground = true
    }

    override fun onStop() {
        super.onStop()
        com.example.notification.NotificationHelper.isAppInForeground = false
    }

    override fun onDestroy() {
        super.onDestroy()
        com.example.network.WifiDirectManager.cleanup(this)
    }
}

@Composable
fun AeroShareApp(
    modifier: Modifier = Modifier,
    viewModel: TransferViewModel = viewModel(factory = TransferViewModel.Factory(LocalContext.current))
) {
    val context = LocalContext.current
    val currentSessionState by viewModel.sessionState.collectAsStateWithLifecycle()
    val transferHistory by viewModel.transferHistory.collectAsStateWithLifecycle()
    val discoveredPeers by viewModel.discoveredPeers.collectAsStateWithLifecycle()
    val chosenFiles by viewModel.chosenFiles.collectAsStateWithLifecycle()
    val chosenUri by viewModel.chosenFileUri.collectAsStateWithLifecycle()
    val chosenName by viewModel.chosenFileName.collectAsStateWithLifecycle()
    val chosenSize by viewModel.chosenFileSize.collectAsStateWithLifecycle()
    val speedHistory by viewModel.transferSpeedHistory.collectAsStateWithLifecycle()
    val activeFingerprint by viewModel.activeSessionFingerprint.collectAsStateWithLifecycle()
    val encryptionStrength by viewModel.encryptionStrength.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableStateOf(0) }
    val themeColorName by viewModel.appThemeColorName.collectAsStateWithLifecycle()

    var hostPairingCodeInput by remember { mutableStateOf("") }
    var showQrScanner by remember { mutableStateOf(false) }
    var showMyQrDialog by remember { mutableStateOf(false) }
    val clipboardManager = remember { context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager }

    var pendingActionAfterToggle by remember { mutableStateOf<(() -> Unit)?>(null) }
    var togglePromptMessage by remember { mutableStateOf("") }
    var showToggleAndContinueDialog by remember { mutableStateOf(false) }

    val activeColor = when (themeColorName) {
        "Tech Emerald" -> Color(0xFF006874)
        "Stealth Onyx" -> Color(0xFF111827)
        else -> Color(0xFF6750A4)
    }

    val checkAndRunAction: (() -> Unit, String) -> Unit = { action, actionName ->
        val isReceiverActive = currentSessionState is NetworkManager.SessionState.Listening
        if (!isReceiverActive) {
            togglePromptMessage = when (actionName) {
                "get_qr" -> "generate and view your pairing QR code so another device can scan it."
                "scan_qr" -> "scan peer QR codes safely with established port listening."
                "select_file" -> "select and prepare files for secure local transfer."
                else -> "perform this network-related operation."
            }
            pendingActionAfterToggle = action
            showToggleAndContinueDialog = true
        } else {
            action()
        }
    }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            viewModel.selectMultipleFiles(context, uris)
        }
    }

    if (showQrScanner) {
        QrCodeScannerView(
            onCodeScanned = { scanned ->
                hostPairingCodeInput = scanned
                showQrScanner = false
                if (chosenFiles.isNotEmpty() || chosenUri != null) {
                    Toast.makeText(context, "Credentials scanned; beaming active stream...", Toast.LENGTH_SHORT).show()
                    viewModel.sendSession(context, scanned)
                } else {
                    Toast.makeText(context, "Receiver Paired! Pick files to beam.", Toast.LENGTH_SHORT).show()
                }
            },
            onClose = {
                showQrScanner = false
            },
            modifier = modifier.fillMaxSize()
        )
    } else {
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(SlateBg)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
        // 1. Sleek Secure Lock Header
        HeaderBar(
            viewModel = viewModel,
            onScanQrClick = { showQrScanner = true },
            onMyQrClick = { checkAndRunAction({ showMyQrDialog = true }, "get_qr") },
            isReceiverActive = currentSessionState is NetworkManager.SessionState.Listening
        )

        Spacer(modifier = Modifier.height(16.dp))

        // 2. Network Beacon Status Badge
        NetworkStatusBadge(
            ipAddress = NetworkManager.getLocalIpAddress(),
            peerCount = discoveredPeers.size
        )

        Spacer(modifier = Modifier.height(20.dp))

        // 3. Central Dynamic Card UI based on Transfer States & Active Tab
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.TopCenter
        ) {
            AnimatedContent(
                targetState = Pair(currentSessionState, selectedTab),
                transitionSpec = {
                    val slideIn = slideInHorizontally(
                        initialOffsetX = { if (targetState.second > initialState.second) it else -it },
                        animationSpec = tween(300)
                    ) + fadeIn(tween(300))
                    val slideOut = slideOutHorizontally(
                        targetOffsetX = { if (targetState.second > initialState.second) -it else it },
                        animationSpec = tween(300)
                    ) + fadeOut(tween(300))
                    slideIn togetherWith slideOut
                },
                label = "SessionAndTabTransition"
            ) { (state, tab) ->
                when (state) {
                    is NetworkManager.SessionState.Idle, is NetworkManager.SessionState.Listening -> {
                        when (tab) {
                            1 -> {
                                SecurityPage(viewModel = viewModel)
                            }
                            2 -> {
                                SettingsPage(viewModel = viewModel)
                            }
                            3 -> {
                                StreamPage(viewModel = viewModel)
                            }
                            else -> {
                                IdleDashboard(
                                    chosenFiles = chosenFiles,
                                    onPickFile = { filePicker.launch("*/*") },
                                    onClearFile = { viewModel.clearChosenFile() },
                                    onRemoveFile = { viewModel.removeChosenFile(it) },
                                    pairingCodeText = hostPairingCodeInput,
                                    onPairingCodeChange = { hostPairingCodeInput = it },
                                    onScanQrCode = { showQrScanner = true },
                                    onBeginSend = {
                                        if (chosenFiles.isEmpty() && chosenUri == null) {
                                            Toast.makeText(context, "Please select at least one file to send", Toast.LENGTH_SHORT).show()
                                        } else if (hostPairingCodeInput.isBlank()) {
                                            Toast.makeText(context, "Enter or paste receiver pairing code", Toast.LENGTH_SHORT).show()
                                        } else {
                                            viewModel.sendSession(context, hostPairingCodeInput)
                                        }
                                    },
                                    onStartReceiver = {
                                        viewModel.hostSession(context)
                                    },
                                    onPasteCode = {
                                        val clip = clipboardManager.primaryClip
                                        if (clip != null && clip.itemCount > 0) {
                                            hostPairingCodeInput = clip.getItemAt(0).text.toString()
                                            Toast.makeText(context, "Pairing code pasted!", Toast.LENGTH_SHORT).show()
                                        } else {
                                            Toast.makeText(context, "Clipboard empty", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    history = transferHistory,
                                    discoveredPeers = discoveredPeers,
                                    onSelectPeer = { peer ->
                                        hostPairingCodeInput = peer.pairingCode
                                        Toast.makeText(context, "Auto-paired with ${peer.deviceName}!", Toast.LENGTH_SHORT).show()
                                    },
                                    viewModel = viewModel,
                                    onShowMyQr = { checkAndRunAction({ showMyQrDialog = true }, "get_qr") }
                                )
                            }
                        }
                    }

                    is NetworkManager.SessionState.Connected -> {
                        NegotiatingHandshakeScreen(
                            peerIp = state.peerIp,
                            fingerprint = activeFingerprint,
                            encryptionStrength = encryptionStrength
                        )
                    }

                    is NetworkManager.SessionState.Transferring -> {
                        TransferringScreen(
                            fileName = state.fileName,
                            totalSizeText = viewModel.formatBytes(state.fileSize),
                            transferredSizeText = viewModel.formatBytes(state.bytesTransferred),
                            progress = state.progress,
                            speedMBs = state.speedMBs,
                            isSending = state.isSending,
                            onAbort = { viewModel.cancelSession() },
                            speedHistory = speedHistory,
                            fingerprint = activeFingerprint,
                            encryptionStrength = encryptionStrength
                        )
                    }

                    is NetworkManager.SessionState.Completed -> {
                        SuccessCompleteScreen(
                            fileName = state.fileName,
                            sizeText = viewModel.formatBytes(state.fileSize),
                            speedText = String.format("%.2f MB/s", state.speedMBs),
                            localPath = state.localPath,
                            onDismiss = {
                                viewModel.cancelSession()
                                hostPairingCodeInput = ""
                            }
                        )
                    }

                    is NetworkManager.SessionState.Failed -> {
                        FailedErrorScreen(
                            reason = state.reason,
                            onDismiss = {
                                viewModel.cancelSession()
                                hostPairingCodeInput = ""
                            }
                        )
                    }
                }
            }
        }

        // Bottom Navigation Bar - only show when idly browsing
        if (currentSessionState is NetworkManager.SessionState.Idle || currentSessionState is NetworkManager.SessionState.Listening) {
            Spacer(modifier = Modifier.height(14.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(SlateSurface)
                    .border(1.dp, PolishedBorder, RoundedCornerShape(20.dp))
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val menuItems = listOf(
                    Triple("Share", Icons.Default.SwapHoriz, 0),
                    Triple("Stream", Icons.Default.CloudQueue, 3),
                    Triple("Security", Icons.Default.Security, 1),
                    Triple("Settings", Icons.Default.Settings, 2)
                )
                val activeColor = when (themeColorName) {
                    "Tech Emerald" -> Color(0xFF006874)
                    "Stealth Onyx" -> Color(0xFF111827)
                    else -> Color(0xFF6750A4)
                }

                menuItems.forEach { (label, icon, index) ->
                    val isSelected = selectedTab == index
                    val contentColor = if (isSelected) activeColor else MutedText
                    val bgTint = if (isSelected) activeColor.copy(alpha = 0.12f) else Color.Transparent

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(bgTint)
                            .clickable { selectedTab = index }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .testTag("tab_${label.lowercase()}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = "$label Navigation Tab",
                                tint = contentColor,
                                modifier = Modifier.size(20.dp)
                            )
                            if (isSelected) {
                                Text(
                                    text = label,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = contentColor
                                )
                            }
                        }
                    }
                }
            }
        }
        }
    }

    if (showMyQrDialog) {
        val themeColorName by viewModel.appThemeColorName.collectAsStateWithLifecycle()
        val activeColor = when (themeColorName) {
            "Tech Emerald" -> Color(0xFF006874)
            "Stealth Onyx" -> Color(0xFF111827)
            else -> Color(0xFF6750A4)
        }
        val listenState = currentSessionState as? NetworkManager.SessionState.Listening
        val isActive = listenState != null

        ReceivePortDialog(
            isActive = isActive,
            pairingCode = listenState?.pairingCode,
            onDismiss = { showMyQrDialog = false },
            onToggle = { activate ->
                if (activate) {
                    viewModel.setSimultaneousModeEnabled(true, null)
                    viewModel.hostSession(context)
                } else {
                    viewModel.setSimultaneousModeEnabled(false, null)
                    viewModel.cancelSession()
                }
            },
            activeColor = activeColor
        )
    }

    if (showToggleAndContinueDialog) {
        AlertDialog(
            onDismissRequest = { 
                showToggleAndContinueDialog = false 
                pendingActionAfterToggle = null
            },
            title = {
                Text(
                    text = "Enable 'Receive Port'?",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = WhiteText
                )
            },
            text = {
                Text(
                    text = "To $togglePromptMessage, we must activate the custom server's Receive Port first. This allocates local sockets and prepares for peer-to-peer beams.",
                    fontSize = 14.sp,
                    color = MutedText
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        // Toggle Receive Port ON
                        viewModel.setSimultaneousModeEnabled(true, null)
                        viewModel.hostSession(context)
                        // Perform the pending action
                        pendingActionAfterToggle?.invoke()
                        // Clear state
                        showToggleAndContinueDialog = false
                        pendingActionAfterToggle = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = activeColor),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Turn On & Proceed", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showToggleAndContinueDialog = false
                        pendingActionAfterToggle = null
                    }
                ) {
                    Text("Cancel", color = MutedText)
                }
            },
            containerColor = SlateSurface,
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.border(1.dp, PolishedBorder, RoundedCornerShape(28.dp))
        )
    }
}

// ==================== UI COMPONENTS ====================

@Composable
fun HeaderBar(
    viewModel: TransferViewModel,
    onScanQrClick: () -> Unit,
    onMyQrClick: () -> Unit,
    isReceiverActive: Boolean
) {
    val context = LocalContext.current
    val themeColorName by viewModel.appThemeColorName.collectAsStateWithLifecycle()
    val activeColor = when (themeColorName) {
        "Tech Emerald" -> Color(0xFF006874)
        "Stealth Onyx" -> Color(0xFF111827)
        else -> Color(0xFF6750A4)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .testTag("header_bar"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(Color(0xFF6750A4), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Bolt,
                    contentDescription = "Bolt Pattern Logo",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
            Column {
                Text(
                    text = "AeroShare",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Medium,
                    color = WhiteText,
                    letterSpacing = (-0.5).sp
                )
                Text(
                    text = "Secure local P2P transfer",
                    fontSize = 11.sp,
                    color = MutedText,
                    fontWeight = FontWeight.Normal
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Scanner button
            IconButton(
                onClick = onScanQrClick,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(SlateSurface)
                    .testTag("top_bar_scan_qr")
            ) {
                Icon(
                    imageVector = Icons.Outlined.QrCodeScanner,
                    contentDescription = "Scan QR Code",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }

            // My QR code presentation button
            IconButton(
                onClick = onMyQrClick,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(SlateSurface)
                    .testTag("top_bar_my_qr")
            ) {
                Icon(
                    imageVector = Icons.Default.QrCode,
                    contentDescription = "My QR Code",
                    tint = if (isReceiverActive) activeColor else MutedText,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Server active/receive port switch
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(SlateSurface)
                    .padding(start = 10.dp, end = 2.dp)
                    .height(36.dp)
                    .testTag("top_bar_receive_port_toggle")
            ) {
                Text(
                    text = "Receive Port",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isReceiverActive) WhiteText else MutedText
                )
                Switch(
                    checked = isReceiverActive,
                    onCheckedChange = { 
                        if (it) {
                            viewModel.setSimultaneousModeEnabled(true, null)
                            viewModel.hostSession(context)
                        } else {
                            viewModel.setSimultaneousModeEnabled(false, null)
                            viewModel.cancelSession()
                        }
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = activeColor,
                        uncheckedThumbColor = MutedText,
                        uncheckedTrackColor = SlateBg
                    ),
                    modifier = Modifier
                        .scale(0.65f)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NetworkStatusBadge(ipAddress: String, peerCount: Int) {
    val isLocal = ipAddress != "127.0.0.1"

    val statusColor = when {
        !isLocal -> SecureRed
        isLocal && peerCount > 0 -> NeonCyan
        else -> Color(0xFF6750A4)
    }

    val bgColor = when {
        !isLocal -> SecureRed.copy(0.12f)
        isLocal && peerCount > 0 -> NeonCyan.copy(0.12f)
        else -> PolishedBadgeBg
    }

    val statusText = when {
        !isLocal -> "OFFLINE"
        isLocal && peerCount > 0 -> "PEERS FOUND"
        else -> "P2P ACTIVE"
    }

    val tooltipText = when {
        !isLocal -> "No local network detected. Connect to Wi-Fi/Hotspot."
        isLocal && peerCount > 0 -> "$peerCount peer(s) verified nearby. Ready for AirDrop."
        else -> "Local network available ($ipAddress). Scanning for local AirDrop receivers..."
    }

    val iconData = when {
        !isLocal -> Icons.Default.SignalWifiOff
        isLocal && peerCount > 0 -> Icons.Default.Sensors
        else -> Icons.Default.Wifi
    }

    TooltipBox(
        positionProvider = TooltipDefaults.rememberPlainTooltipPositionProvider(),
        tooltip = {
            PlainTooltip(
                containerColor = SlateSurfaceVariant,
                contentColor = WhiteText
            ) {
                Text(tooltipText, fontSize = 12.sp)
            }
        },
        state = rememberTooltipState()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(SlateSurface)
                .border(1.dp, PolishedBorder, RoundedCornerShape(28.dp))
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(SlateSurfaceVariant, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = iconData,
                        contentDescription = "Wifi Status",
                        tint = statusColor,
                        modifier = Modifier.size(24.dp).animateContentSize()
                    )
                }
                Column {
                    Text(
                        text = "Network Status",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = WhiteText
                    )
                    Text(
                        text = if (isLocal) "Local IP: $ipAddress" else "No local network detected",
                        fontSize = 11.sp,
                        color = MutedText
                    )
                }
            }

            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(bgColor)
                    .padding(horizontal = 12.dp, vertical = 4.dp)
                    .animateContentSize()
            ) {
                Text(
                    text = statusText,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = statusColor
                )
            }
        }
    }
}

// ==================== DASHBOARD DETAILS ====================

@Composable
fun IdleDashboard(
    chosenFiles: List<com.example.ui.ChosenFile>,
    onPickFile: () -> Unit,
    onClearFile: () -> Unit,
    onRemoveFile: (Int) -> Unit,
    pairingCodeText: String,
    onPairingCodeChange: (String) -> Unit,
    onScanQrCode: () -> Unit,
    onBeginSend: () -> Unit,
    onStartReceiver: () -> Unit,
    onPasteCode: () -> Unit,
    history: List<TransferEvent>,
    discoveredPeers: List<com.example.network.MdnsDiscoveryManager.DiscoveredPeer>,
    onSelectPeer: (com.example.network.MdnsDiscoveryManager.DiscoveredPeer) -> Unit,
    viewModel: TransferViewModel,
    onShowMyQr: () -> Unit
) {
    val enableAutoZip by viewModel.enableAutoZip.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // A. SENDER CONSOLE CARD
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, PolishedBorder, RoundedCornerShape(28.dp))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "TRANSFER STATION",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF6750A4),
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    if (chosenFiles.isEmpty()) {
                        // File picker empty trigger area
                        SelectDashedArea(onClick = onPickFile)
                    } else {
                        AnimatedVisibility(
                            visible = chosenFiles.isNotEmpty(),
                            enter = fadeIn() + expandVertically(),
                            exit = fadeOut() + shrinkVertically()
                        ) {
                            Column {
                                // Batch selected files preview display queue
                                BatchSelectedQueue(
                                    files = chosenFiles,
                                    onRemoveFile = onRemoveFile,
                                    onMoveUp = { viewModel.moveChosenFileUp(it) },
                                    onMoveDown = { viewModel.moveChosenFileDown(it) },
                                    enableAutoZip = enableAutoZip,
                                    onToggleAutoZip = { viewModel.setEnableAutoZip(it) },
                                    onAddMore = onPickFile,
                                    onClearAll = onClearFile,
                                    formatBytes = { viewModel.formatBytes(it) }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Connect parameters
                    Text(
                        text = "Receiver Pairing Key",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = WhiteText
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = pairingCodeText,
                            onValueChange = onPairingCodeChange,
                            placeholder = { Text("Paste pairing key or select spotted receiver...", fontSize = 13.sp, color = MutedText) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("pairing_code_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyan,
                                unfocusedBorderColor = PolishedBorder,
                                focusedContainerColor = SlateBg,
                                unfocusedContainerColor = SlateBg,
                                focusedTextColor = WhiteText,
                                unfocusedTextColor = WhiteText
                            ),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            trailingIcon = {
                                IconButton(onClick = onPasteCode) {
                                    Icon(
                                        imageVector = Icons.Outlined.ContentCopy,
                                        contentDescription = "Paste Code",
                                        tint = NeonCyan
                                    )
                                }
                            },
                            keyboardOptions = KeyboardOptions(
                                imeAction = ImeAction.Done
                            )
                        )

                        // Unified Material 3 layout Camera QR Scanner Icon button styled inside Slate Theme
                        IconButton(
                            onClick = onScanQrCode,
                            modifier = Modifier
                                .size(54.dp)
                                .background(NeonCyan.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                                .border(1.dp, NeonCyan.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                .testTag("scan_qr_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.QrCodeScanner,
                                contentDescription = "Scan Pairing QR Code",
                                tint = NeonCyan,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    if (chosenFiles.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = onBeginSend,
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("send_button")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
                                Text("Engage Cryptographic Transfer", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                        }
                    }
                }
            }
        }

        item {
            WifiDirectConsoleCard()
        }

        item {
            NearbyDiscoveryCard(
                discoveredPeers = discoveredPeers,
                onSelectPeer = onSelectPeer,
                chosenFileSelected = chosenFiles.isNotEmpty(),
                onDirectBeam = { peer ->
                    onSelectPeer(peer)
                    onBeginSend()
                }
            )
        }



        // AEROSHARE CONNECTION SETTINGS CARD
        item {
            val autoReconnect by viewModel.autoReconnect.collectAsStateWithLifecycle()
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, PolishedBorder, RoundedCornerShape(28.dp))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(Color(0xFF6750A4), CircleShape)
                        )
                        Text(
                            text = "AEROSHARE SETTINGS",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF6750A4),
                            letterSpacing = 1.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(SlateBg)
                            .border(1.dp, PolishedBorder, RoundedCornerShape(16.dp))
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Auto Reconnection",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = WhiteText
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Attempt reconnecting up to 3 times if a secure local transfer is disrupted.",
                                fontSize = 11.sp,
                                color = MutedText,
                                lineHeight = 16.sp
                            )
                        }
                        Switch(
                            checked = autoReconnect,
                            onCheckedChange = { viewModel.setAutoReconnect(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = NeonCyan,
                                uncheckedThumbColor = MutedText,
                                uncheckedTrackColor = SlateSurfaceVariant
                            ),
                            modifier = Modifier.testTag("auto_reconnect_switch")
                        )
                    }
                }
            }
        }

        // C. TRANSFER HISTORY LOGS MODULE
        item {
            HistoryLogsHeader(
                onClear = { viewModel.clearAllLogs() },
                hasLogs = history.isNotEmpty()
            )
        }

        if (history.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Outlined.Lock,
                            contentDescription = "Empty History",
                            tint = SlateSurfaceVariant,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No prior secure transfers.",
                            fontSize = 12.sp,
                            color = MutedText,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        } else {
            items(history) { event ->
                HistoryRow(event, viewModel)
            }
        }
    }
}

@Composable
fun SelectDashedArea(onClick: () -> Unit) {
    val bColor = Color(0xFF6750A4)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(110.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(SlateBg)
            .clickable { onClick() }
            .drawBehind {
                drawRoundRect(
                    color = bColor.copy(0.4f),
                    style = Stroke(
                        width = 2.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 15f), 0f)
                    ),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(16.dp.toPx())
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.CloudUpload,
                contentDescription = "Upload",
                tint = Color(0xFF6750A4),
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text("Select File to Encrypt & Beam", color = WhiteText, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text("Supports photos, videos, ZIP, documents", color = MutedText, fontSize = 11.sp)
        }
    }
}

fun getFileIconAndColor(fileName: String): Pair<androidx.compose.ui.graphics.vector.ImageVector, Color> {
    val extension = fileName.substringAfterLast('.', "").lowercase()
    return when (extension) {
        "pdf" -> Icons.Default.PictureAsPdf to Color(0xFFE53935) // Elegant PDF Red
        "png", "jpg", "jpeg", "gif", "webp", "bmp", "svg" -> Icons.Default.Image to Color(0xFF1E88E5) // Image Blue
        "mp4", "mkv", "avi", "mov", "flv", "webm", "3gp" -> Icons.Default.VideoFile to Color(0xFF8E24AA) // Video Purple
        "mp3", "wav", "ogg", "flac", "m4a", "aac" -> Icons.Default.AudioFile to Color(0xFF00ACC1) // Audio Teal
        "txt", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "rtf", "md" -> Icons.Default.Description to Color(0xFF43A047) // Document Green
        "zip", "rar", "7z", "tar", "gz" -> Icons.Default.FolderZip to Color(0xFFFDD835) // Archive Gold/Yellow
        "js", "ts", "html", "css", "json", "xml", "kt", "kts", "java", "py", "cpp", "c", "sh" -> Icons.Default.Code to Color(0xFFF4511E) // Code Orange
        else -> Icons.Default.InsertDriveFile to Color(0xFF9E9E9E) // Default Grey
    }
}

@Composable
fun FileSelectedPreview(name: String, size: String, onClear: () -> Unit) {
    val (icon, tintColor) = getFileIconAndColor(name)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(SlateSurfaceVariant)
            .border(1.dp, PolishedPairBorder, RoundedCornerShape(16.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(tintColor.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = "File Ready",
                    tint = tintColor
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = name,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = WhiteText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Ready to Crypt-Beam • Size: $size",
                    fontSize = 11.sp,
                    color = TechEmerald,
                    fontWeight = FontWeight.Medium
                )
            }
        }
        
        IconButton(onClick = onClear) {
            Icon(
                imageVector = Icons.Outlined.DeleteOutline,
                contentDescription = "Clear File Selection",
                tint = SecureRed
            )
        }
    }
}

@Composable
fun HistoryLogsHeader(onClear: () -> Unit, hasLogs: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = "SECURE HISTORY LOGS",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MutedText,
            letterSpacing = 1.sp
        )
        if (hasLogs) {
            Text(
                text = "Wipe Logs",
                color = SecureRed,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clickable { onClear() }
                    .padding(4.dp)
            )
        }
    }
}

@Composable
fun HistoryRow(event: TransferEvent, viewModel: TransferViewModel) {
    val isSender = event.isSender
    val isCompleted = event.status == "COMPLETED"

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFFF7F2FA))
            .border(1.dp, PolishedBorder.copy(0.5f), RoundedCornerShape(16.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(
                        if (isCompleted) Color(0xFFE8DEF8) else SecureRed.copy(0.12f),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isSender) Icons.Default.Upload else Icons.Default.Download,
                    contentDescription = if (isSender) "Sent" else "Received",
                    tint = if (isCompleted) {
                        if (isSender) Color(0xFF6750A4) else TechEmerald
                    } else SecureRed,
                    modifier = Modifier.size(18.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = event.fileName,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = WhiteText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = viewModel.formatBytes(event.fileSize),
                        fontSize = 11.sp,
                        color = MutedText
                    )
                    Text(
                        text = "•",
                        fontSize = 11.sp,
                        color = PolishedBorder
                    )
                    Text(
                        text = if (isCompleted) String.format("%.1f MB/s", event.speedMBs) else "Aborted",
                        fontSize = 11.sp,
                        color = if (isCompleted) TechEmerald else SecureRed,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        
        Icon(
            imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.ErrorOutline,
            contentDescription = event.status,
            tint = if (isCompleted) TechEmerald else SecureRed,
            modifier = Modifier.size(18.dp)
        )
    }
}

// ==================== WAITING BEACON PORT ====================

@Composable
fun BeaconWaitingScreen(
    pairingCode: String,
    onCancel: () -> Unit,
    onCopyCode: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = PolishedPairBg),
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier
            .fillMaxSize()
            .border(1.dp, PolishedPairBorder, RoundedCornerShape(28.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Pulsing Lock Circle animation
            val transition = rememberInfiniteTransition(label = "pulse")
            val pulseSize by transition.animateFloat(
                initialValue = 54f,
                targetValue = 66f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1200, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "pulseSize"
            )

            Box(
                modifier = Modifier
                    .size(80.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(pulseSize.dp)
                        .background(Color(0xFF6750A4).copy(0.15f), CircleShape)
                )
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .background(Color(0xFF6750A4), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = "Ready Beacon Logo",
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "READY TO PAIR",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF49454F),
                letterSpacing = 1.sp
            )

            Text(
                text = pairingCode,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF21005D),
                fontFamily = FontFamily.Monospace,
                letterSpacing = 0.5.sp,
                modifier = Modifier.padding(vertical = 4.dp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(16.dp))

            // LOCAL QR MATRIX NATIVE VIEW with white shadow glow border
            Box(
                modifier = Modifier
                    .size(192.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White)
                    .border(4.dp, Color(0xFF6750A4).copy(0.1f), RoundedCornerShape(16.dp))
                    .padding(14.dp),
                contentAlignment = Alignment.Center
            ) {
                QrCodeView(
                    pairingCode = pairingCode,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Scan the QR or enter the code on another device for instant P2P transfer.",
                fontSize = 12.sp,
                color = Color(0xFF49454F),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                modifier = Modifier.padding(horizontal = 12.dp),
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(20.dp))

            // COPY PIN TEXT
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(SlateSurface)
                    .clickable { onCopyCode() }
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .border(1.dp, PolishedBorder, RoundedCornerShape(12.dp)),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Aero Pairing Code (Touch to Copy)",
                    fontSize = 11.sp,
                    color = Color(0xFF49454F),
                    fontWeight = FontWeight.Medium
                )
                Icon(
                    imageVector = Icons.Outlined.ContentCopy,
                    contentDescription = "Copy code parameter",
                    tint = Color(0xFF6750A4),
                    modifier = Modifier.size(14.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = onCancel,
                colors = ButtonDefaults.buttonColors(containerColor = SlateSurface),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .width(180.dp)
                    .height(44.dp)
                    .border(1.dp, PolishedBorder, RoundedCornerShape(14.dp))
            ) {
                Text("Deactivate Beacon", color = Color(0xFF1D1B20), fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}

// ==================== CONNECTING/HANDSHAKE ====================

@Composable
fun NegotiatingHandshakeScreen(
    peerIp: String,
    fingerprint: String?,
    encryptionStrength: String
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SlateSurface),
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier
            .fillMaxSize()
            .border(1.dp, PolishedBorder, RoundedCornerShape(28.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(140.dp)
            ) {
                val infiniteTransition = rememberInfiniteTransition(label = "airdropRipple")
                
                // 3 rings animating outward
                for (i in 0 until 3) {
                    val scale by infiniteTransition.animateFloat(
                        initialValue = 0.3f,
                        targetValue = 1.0f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(2000, delayMillis = i * 600, easing = LinearEasing),
                            repeatMode = RepeatMode.Restart
                        ),
                        label = "scale_$i"
                    )
                    
                    val alpha by infiniteTransition.animateFloat(
                        initialValue = 0.8f,
                        targetValue = 0.0f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(2000, delayMillis = i * 600, easing = LinearEasing),
                            repeatMode = RepeatMode.Restart
                        ),
                        label = "alpha_$i"
                    )
                    
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawCircle(
                            color = NeonCyan.copy(alpha = alpha),
                            radius = (size.minDimension / 2) * scale,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 6f)
                        )
                    }
                }
                
                // Center node
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(NeonCyan.copy(alpha = 0.15f), androidx.compose.foundation.shape.CircleShape)
                        .border(1.dp, NeonCyan, androidx.compose.foundation.shape.CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Securing",
                        tint = NeonCyan,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
            Text(
                text = "Securing Session Link...",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = WhiteText
            )
            Text(
                text = "Peered with $peerIp • Handshaking credentials...",
                fontSize = 12.sp,
                color = MutedText,
                modifier = Modifier.padding(top = 8.dp)
            )
            Spacer(modifier = Modifier.height(24.dp))
            SecureConnectionIndicator(
                fingerprint = fingerprint,
                encryptionStrength = encryptionStrength,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// ==================== ACTIVE PROGRESS BAR ====================

@Composable
fun PolishedTransferProgressIndicator(
    progress: Float,
    speedMBs: Double,
    isSending: Boolean,
    modifier: Modifier = Modifier
) {
    val animatedProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 300, easing = LinearEasing),
        label = "fileProgress"
    )
    val animatedSpeed by animateFloatAsState(
        targetValue = speedMBs.toFloat(),
        animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing),
        label = "transferSpeed"
    )

    val targetSpeed = 100f
    val speedRatio = (animatedSpeed / targetSpeed).coerceIn(0f, 1f)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(SlateSurfaceVariant)
            .border(1.dp, PolishedPairBorder, RoundedCornerShape(24.dp))
            .padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Nested Visual Rings Box
        Box(
            modifier = Modifier.size(170.dp),
            contentAlignment = Alignment.Center
        ) {
            val fileColor = if (isSending) NeonCyan else Color(0xFF006874)
            val speedColor = LaserOrange

            // Draw Arcs via Canvas for maximum precision & responsiveness
            Canvas(modifier = Modifier.fillMaxSize()) {
                // Outer Arc track: File Progress
                drawArc(
                    color = Color.White.copy(0.6f),
                    startAngle = 135f,
                    sweepAngle = 270f,
                    useCenter = false,
                    style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                )
                // Outer Arc Fill: File Progress
                drawArc(
                    color = fileColor,
                    startAngle = 135f,
                    sweepAngle = 270f * animatedProgress,
                    useCenter = false,
                    style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                )

                // Inner Arc track: Speed-to-Goal (100 MB/s target)
                drawArc(
                    color = Color.White.copy(0.35f),
                    startAngle = 135f,
                    sweepAngle = 270f,
                    useCenter = false,
                    style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round),
                    topLeft = Offset(16.dp.toPx(), 16.dp.toPx()),
                    size = this.size.copy(
                        width = this.size.width - 32.dp.toPx(),
                        height = this.size.height - 32.dp.toPx()
                    )
                )
                // Inner Arc Fill: Speed-to-Goal
                drawArc(
                    color = speedColor,
                    startAngle = 135f,
                    sweepAngle = 270f * speedRatio,
                    useCenter = false,
                    style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round),
                    topLeft = Offset(16.dp.toPx(), 16.dp.toPx()),
                    size = this.size.copy(
                        width = this.size.width - 32.dp.toPx(),
                        height = this.size.height - 32.dp.toPx()
                    )
                )
            }

            // Central status readout
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = String.format("%.1f", speedMBs),
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    color = WhiteText
                )
                Text(
                    text = "MB / s",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = fileColor
                )
                Spacer(modifier = Modifier.height(4.dp))
                // Progress percentage pill
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(fileColor.copy(0.12f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${(progress * 100).toInt()}% Done",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = fileColor
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Target progress bar readouts
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Bolt,
                    contentDescription = "Target icon",
                    tint = if (speedMBs >= 100.0) TechEmerald else LaserOrange,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "Speed Goal Target (100 MB/s)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = MutedText
                )
            }
            Text(
                text = "${(speedMBs.coerceIn(0.0, 100.0)).toInt()}% Hit",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (speedMBs >= 100.0) TechEmerald else LaserOrange
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Linear Speed progress indicator toward goal!
        LinearProgressIndicator(
            progress = { speedRatio },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(CircleShape),
            color = if (speedMBs >= 100.0) TechEmerald else LaserOrange,
            trackColor = Color.White
        )
        
        Spacer(modifier = Modifier.height(8.dp))

        val promptText = if (speedMBs >= 100.0) {
            "⚡ Speed limit reached (Accelerated Transfer active)"
        } else if (speedMBs >= 80) {
            "🚀 Approaching 100MB/s velocity target capacity..."
        } else {
            "📱 P2P Direct Tunnel active"
        }

        Text(
            text = promptText,
            fontSize = 11.sp,
            color = if (speedMBs >= 100.0) TechEmerald else MutedText,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

@Composable
fun TransferringScreen(
    fileName: String,
    totalSizeText: String,
    transferredSizeText: String,
    progress: Float,
    speedMBs: Double,
    isSending: Boolean,
    onAbort: () -> Unit,
    speedHistory: List<Double>,
    fingerprint: String?,
    encryptionStrength: String
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SlateSurface),
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier
            .fillMaxSize()
            .border(1.dp, PolishedBorder, RoundedCornerShape(28.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Top Type Label
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSending) Color(0xFFE8DEF8) else Color(0xFFC2E7FF))
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = if (isSending) "SECURE TRANSMISSION ACTIVE" else "RECEIVING SECURE DATA STREAM",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isSending) Color(0xFF21005D) else Color(0xFF001D35)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
                
                Text(
                    text = fileName,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = WhiteText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "$transferredSizeText of $totalSizeText",
                    fontSize = 12.sp,
                    color = MutedText,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            // Secure connection indicator showing handshake visual verify fingerprint
            SecureConnectionIndicator(
                fingerprint = fingerprint,
                encryptionStrength = encryptionStrength,
                modifier = Modifier.fillMaxWidth()
            )

            // Real-time speed and percentage of the file transfer to hit the 100MB/s target component
            PolishedTransferProgressIndicator(
                progress = progress,
                speedMBs = speedMBs,
                isSending = isSending,
                modifier = Modifier.fillMaxWidth()
            )

            // Speed Analytics Charts over time
            SpeedAnalyticsChart(
                speedHistory = speedHistory,
                modifier = Modifier.fillMaxWidth()
            )

            // Bottom cancel/abort triggers
            Button(
                onClick = onAbort,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFAD8D8)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .width(180.dp)
                    .height(44.dp)
                    .border(1.dp, SecureRed.copy(0.4f), RoundedCornerShape(14.dp))
            ) {
                Text("Emergency Abort", color = SecureRed, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun SpeedAnalyticsChart(
    speedHistory: List<Double>,
    modifier: Modifier = Modifier
) {
    val targetSpeed = 100.0
    val paddedHistory = remember(speedHistory) {
        if (speedHistory.isEmpty()) listOf(0.0) else speedHistory
    }
    val maxSpeed = remember(paddedHistory) {
        maxOf(paddedHistory.maxOrNull() ?: 0.0, 120.0)
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(160.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(SlateBg)
            .border(1.dp, PolishedBorder, RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TRANSFER SPEED ANALYTICS (D3 STYLE)",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MutedText,
                    letterSpacing = 1.sp
                )
                val currentSpeed = paddedHistory.last()
                Text(
                    text = String.format("%.2f MB/s", currentSpeed),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (currentSpeed >= targetSpeed) NeonCyan else Color.White
                )
            }
            Spacer(modifier = Modifier.height(8.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("speed_canvas")
            ) {
                val width = size.width
                val height = size.height

                // Draw horizontal target line (100 MB/s)
                val targetY = height - (targetSpeed.toFloat() / maxSpeed.toFloat() * height)
                drawLine(
                    color = Color(0xFFFFB300), // Target warning amber
                    start = Offset(0f, targetY),
                    end = Offset(width, targetY),
                    strokeWidth = 2f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                )

                // Grid line at 50 MB/s
                val gridY50 = height - (50f / maxSpeed.toFloat() * height)
                drawLine(
                    color = PolishedBorder.copy(alpha = 0.4f),
                    start = Offset(0f, gridY50),
                    end = Offset(width, gridY50),
                    strokeWidth = 1f
                )

                if (paddedHistory.size > 1) {
                    val path = androidx.compose.ui.graphics.Path()
                    val xStep = width / (paddedHistory.size - 1)

                    paddedHistory.forEachIndexed { index, speed ->
                        val x = index * xStep
                        val y = height - (speed.toFloat() / maxSpeed.toFloat() * height)
                        if (index == 0) {
                            path.moveTo(x, y)
                        } else {
                            path.lineTo(x, y)
                        }
                    }

                    // Stroke Path
                    drawPath(
                        path = path,
                        color = NeonCyan,
                        style = Stroke(
                            width = 4f,
                            cap = StrokeCap.Round,
                            join = androidx.compose.ui.graphics.StrokeJoin.Round
                        )
                    )

                    // Gradient fill underneath
                    val fillPath = androidx.compose.ui.graphics.Path().apply {
                        addPath(path)
                        lineTo(width, height)
                        lineTo(0f, height)
                        close()
                    }
                    drawPath(
                        path = fillPath,
                        brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                            colors = listOf(NeonCyan.copy(alpha = 0.25f), Color.Transparent)
                            // Linear gradient to represent the glowing D3 dynamic fill
                        )
                    )
                }
            }
            
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("0 MB/s", fontSize = 8.sp, color = MutedText)
                Text("Target: 100 MB/s", fontSize = 8.sp, color = Color(0xFFFFB300), fontWeight = FontWeight.Bold)
                Text(String.format("Max: %.0f MB/s", maxSpeed), fontSize = 8.sp, color = MutedText)
            }
        }
    }
}

// ==================== SUCCESS COMPREHENSION ====================

@Composable
fun SuccessCompleteScreen(
    fileName: String,
    sizeText: String,
    speedText: String,
    localPath: String?,
    onDismiss: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SlateSurface),
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier
            .fillMaxSize()
            .border(1.dp, PolishedBorder, RoundedCornerShape(28.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .background(Color(0xFFD1E7DD), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Success",
                    tint = Color(0xFF0F5132),
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = "Transfer Verified!",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = WhiteText
            )
            
            Text(
                text = "Cryptographic integrity checked natively",
                fontSize = 11.sp,
                color = TechEmerald,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            // File Information Details
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(SlateBg)
                    .border(1.dp, PolishedPairBorder, RoundedCornerShape(16.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                InfoDetailsRow(label = "Filename", value = fileName)
                InfoDetailsRow(label = "File size", value = sizeText)
                InfoDetailsRow(label = "Overall Rate", value = speedText)
                if (localPath != null) {
                    InfoDetailsRow(
                        label = "Saved to Downloads", 
                        value = "Downloads/AeroShare"
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6750A4)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .width(180.dp)
                    .height(44.dp)
            ) {
                Text("Return to Station", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun InfoDetailsRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = MutedText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Text(
            text = value,
            color = WhiteText,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false).padding(start = 12.dp)
        )
    }
}

// ==================== FAILED DISPLAY ====================

@Composable
fun FailedErrorScreen(
    reason: String,
    onDismiss: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SlateSurface),
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier
            .fillMaxSize()
            .border(1.dp, PolishedBorder, RoundedCornerShape(28.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(SlateBg, CircleShape)
                    .border(1.dp, PolishedBorder, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CloudOff,
                    contentDescription = "Disconnected",
                    tint = LaserOrange,
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Transfer Aborted",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = WhiteText,
                letterSpacing = 0.5.sp
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "The connection could not be maintained.",
                fontSize = 12.sp,
                color = MutedText,
                textAlign = TextAlign.Center
            )

            if (reason.isNotBlank()) {
                Spacer(modifier = Modifier.height(16.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black.copy(alpha = 0.2f))
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = reason,
                        fontSize = 11.sp,
                        color = Color(0xFFFFB4AB),
                        textAlign = TextAlign.Center,
                        lineHeight = 16.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = LaserOrange),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth(0.6f)
                    .height(48.dp)
            ) {
                Text("Return to Hub", color = SlateBg, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}

// ==================== mDNS NEARBY DISCOVERY UI ====================

@Composable
fun NearbyDiscoveryCard(
    discoveredPeers: List<com.example.network.MdnsDiscoveryManager.DiscoveredPeer>,
    onSelectPeer: (com.example.network.MdnsDiscoveryManager.DiscoveredPeer) -> Unit,
    chosenFileSelected: Boolean,
    onDirectBeam: (com.example.network.MdnsDiscoveryManager.DiscoveredPeer) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SlateSurface),
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, PolishedBorder, RoundedCornerShape(28.dp))
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(Color(0xFF6750A4), CircleShape)
                    )
                    Text(
                        text = "NEARBY SPOTTED RECEIVERS",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF6750A4),
                        letterSpacing = 1.sp
                    )
                }

                // Active rotating/pulsating radar indicator representing live scanning
                RadarPulseIndicator()
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (discoveredPeers.isEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(SlateBg)
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = Color(0xFF6750A4)
                    )
                    Text(
                        text = "Scanning for active AeroShare recipients over local mDNS subnet...",
                        fontSize = 12.sp,
                        color = MutedText,
                        lineHeight = 16.sp
                    )
                }
            } else {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    discoveredPeers.forEach { peer ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(SlateBg)
                                .border(1.dp, PolishedBorder, RoundedCornerShape(16.dp))
                                .clickable { onSelectPeer(peer) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(Color(0xFFEADDFF), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Devices,
                                        contentDescription = "Device Details",
                                        tint = Color(0xFF21005D),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        text = peer.deviceName,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = WhiteText
                                    )
                                    Text(
                                        text = "IP: ${peer.ipAddress}",
                                        fontSize = 11.sp,
                                        color = MutedText
                                    )
                                }
                            }

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (chosenFileSelected) {
                                    Button(
                                        onClick = { onDirectBeam(peer) },
                                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                        modifier = Modifier.height(34.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Bolt,
                                            contentDescription = "Direct Beam",
                                            tint = Color.White,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Direct Beam",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFF6750A4).copy(0.12f))
                                            .border(1.dp, Color(0xFF6750A4).copy(0.3f), RoundedCornerShape(8.dp))
                                            .clickable { onSelectPeer(peer) }
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = "Pair Key",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFEADDFF)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RadarPulseIndicator() {
    val infiniteTransition = rememberInfiniteTransition(label = "radarPulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "scale"
    )
    val alpha by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "alpha"
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.size(24.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                color = Color(0xFF6750A4).copy(alpha = alpha),
                radius = (size.minDimension / 2) * scale
            )
            drawCircle(
                color = Color(0xFF6750A4),
                radius = size.minDimension / 4
            )
        }
    }
}

@Composable
fun BatchSelectedQueue(
    files: List<com.example.ui.ChosenFile>,
    onRemoveFile: (Int) -> Unit,
    onMoveUp: (Int) -> Unit,
    onMoveDown: (Int) -> Unit,
    enableAutoZip: Boolean,
    onToggleAutoZip: (Boolean) -> Unit,
    onAddMore: () -> Unit,
    onClearAll: () -> Unit,
    formatBytes: (Long) -> String
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(SlateSurfaceVariant)
            .border(1.dp, PolishedBorder, RoundedCornerShape(24.dp))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${files.size} FILES READY",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = NeonCyan,
                letterSpacing = 1.sp
            )
            TextButton(
                onClick = onClearAll,
                colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFE53935)),
                modifier = Modifier.height(28.dp)
            ) {
                Text("Clear All", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        
        Spacer(modifier = Modifier.height(10.dp))
        
        Column(
            modifier = Modifier.animateContentSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            files.forEachIndexed { index, file ->
                val (icon, tintColor) = getFileIconAndColor(file.name)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(SlateBg)
                        .border(1.dp, PolishedBorder, RoundedCornerShape(12.dp))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .background(tintColor.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = "File Icon",
                                tint = tintColor,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = file.name,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = WhiteText,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                            )
                            Text(
                                text = formatBytes(file.size),
                                fontSize = 10.sp,
                                color = MutedText
                            )
                        }
                    }
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        // Move Up
                        if (index > 0) {
                            IconButton(
                                onClick = { onMoveUp(index) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.KeyboardArrowUp,
                                    contentDescription = "Move Up",
                                    tint = NeonCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        // Move Down
                        if (index < files.size - 1) {
                            IconButton(
                                onClick = { onMoveDown(index) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.KeyboardArrowDown,
                                    contentDescription = "Move Down",
                                    tint = NeonCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        // Drag Grip Visual Cue
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Drag Grip handle",
                            tint = MutedText.copy(alpha = 0.4f),
                            modifier = Modifier.size(14.dp)
                        )
                        
                        Spacer(modifier = Modifier.width(4.dp))

                        IconButton(
                            onClick = { onRemoveFile(index) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Remove File",
                                tint = MutedText,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }

        // Automatic Zip toggle row if multiple files ready
        if (files.size > 1) {
            Spacer(modifier = Modifier.height(14.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(PolishedBorder.copy(alpha = 0.5f))
            )
            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(SlateBg)
                    .border(1.dp, PolishedBorder, RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .background(Color(0xFFFFB300).copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Zip compression",
                            tint = Color(0xFFFFB300),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Auto-Zip Batch Elements",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = WhiteText
                        )
                        Text(
                            text = "Combines elements into a single compressed transport zip",
                            fontSize = 9.sp,
                            color = MutedText
                        )
                    }
                }
                Switch(
                    checked = enableAutoZip,
                    onCheckedChange = onToggleAutoZip,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = NeonCyan,
                        uncheckedThumbColor = MutedText,
                        uncheckedTrackColor = SlateBg
                    )
                )
            }
        }
        
        Spacer(modifier = Modifier.height(14.dp))
        
        val totalBytes = files.sumOf { it.size }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Total Queue Size", fontSize = 10.sp, color = MutedText)
                Text(formatBytes(totalBytes), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = WhiteText)
            }
            
            OutlinedButton(
                onClick = onAddMore,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.5f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonCyan)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Files", modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Files", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun SecurityPage(
    viewModel: TransferViewModel,
    modifier: Modifier = Modifier
) {
    val encryptionStrength by viewModel.encryptionStrength.collectAsStateWithLifecycle()
    val enforceTls13 by viewModel.enforceTls13.collectAsStateWithLifecycle()
    val strictFileIntegrity by viewModel.strictFileIntegrity.collectAsStateWithLifecycle()
    val requirePairingCode by viewModel.requirePairingCode.collectAsStateWithLifecycle()
    val themeColorName by viewModel.appThemeColorName.collectAsStateWithLifecycle()

    val activeColor = when (themeColorName) {
        "Tech Emerald" -> Color(0xFF006874)
        "Stealth Onyx" -> Color(0xFF111827)
        else -> Color(0xFF6750A4)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Cryptography Status Banner
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateSurface),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, PolishedBorder, RoundedCornerShape(24.dp))
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(TechEmerald.copy(0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = "Shield Locked",
                        tint = TechEmerald,
                        modifier = Modifier.size(26.dp)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "AERO-CRYPT HIGH TUNNEL ACTIVE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TechEmerald,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "End-to-end symmetric cipher locks prevent packet interception. Socket handshakes leverage decentralized peer credentials.",
                    fontSize = 11.sp,
                    color = MutedText,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    lineHeight = 15.sp
                )
            }
        }

        // Cipher Strength Card
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateSurface),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, PolishedBorder, RoundedCornerShape(24.dp))
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "Cipher Strength Standard",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = WhiteText
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Set key bits for session negotiation",
                    fontSize = 11.sp,
                    color = MutedText
                )
                Spacer(modifier = Modifier.height(14.dp))

                listOf("AES-256", "AES-128").forEach { strength ->
                    val isChosen = encryptionStrength == strength
                    val optionBg = if (isChosen) activeColor.copy(alpha = 0.08f) else Color.Transparent
                    val optionBorder = if (isChosen) activeColor else PolishedBorder

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(optionBg)
                            .border(1.dp, optionBorder, RoundedCornerShape(12.dp))
                            .clickable { viewModel.setEncryptionStrength(strength) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = if (strength == "AES-256") "AES-256-GCM (Quantum Resilient)" else "AES-128-GCM (Ultra Balanced)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = WhiteText
                            )
                            Text(
                                text = if (strength == "AES-256") "Highest protection. Slightly higher compute overhead." else "Standard encryption. Fast on low-end units.",
                                fontSize = 10.sp,
                                color = MutedText
                            )
                        }
                        RadioButton(
                            selected = isChosen,
                            onClick = { viewModel.setEncryptionStrength(strength) },
                            colors = RadioButtonDefaults.colors(selectedColor = activeColor, unselectedColor = MutedText)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }

        // Security Policies Card
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateSurface),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, PolishedBorder, RoundedCornerShape(24.dp))
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "Shield Transport Policies",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = WhiteText
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Switch row 1
                SecuritySwitchRow(
                    title = "Enforce TLS 1.3 Negotiation",
                    description = "Restricts peers to mutual socket verification protocols, blocking payload injection.",
                    checked = enforceTls13,
                    activeColor = activeColor,
                    onCheckedChange = { viewModel.setEnforceTls13(it) }
                )

                Spacer(modifier = Modifier.height(12.dp))
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(PolishedBorder.copy(alpha = 0.4f)))
                Spacer(modifier = Modifier.height(12.dp))

                // Switch row 2
                SecuritySwitchRow(
                    title = "Strict SHA-256 Verification",
                    description = "Verifies matching hash signatures after beamed payloads are reconstructed.",
                    checked = strictFileIntegrity,
                    activeColor = activeColor,
                    onCheckedChange = { viewModel.setStrictFileIntegrity(it) }
                )

                Spacer(modifier = Modifier.height(12.dp))
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(PolishedBorder.copy(alpha = 0.4f)))
                Spacer(modifier = Modifier.height(12.dp))

                // Switch row 3
                SecuritySwitchRow(
                    title = "Pairing Code Pin Requirement",
                    description = "Generates decentralized secret numeric passkeys for every connection.",
                    checked = requirePairingCode,
                    activeColor = activeColor,
                    onCheckedChange = { viewModel.setRequirePairingCode(it) }
                )
            }
        }
    }
}

@Composable
fun SecuritySwitchRow(
    title: String,
    description: String,
    checked: Boolean,
    activeColor: Color,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = WhiteText
            )
            Text(
                text = description,
                fontSize = 10.sp,
                color = MutedText,
                lineHeight = 13.sp
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = activeColor,
                uncheckedThumbColor = MutedText,
                uncheckedTrackColor = SlateBg
            ),
            modifier = Modifier.testTag("security_switch_${title.replace(" ", "_").lowercase()}")
        )
    }
}

@Composable
fun SettingsPage(
    viewModel: TransferViewModel,
    modifier: Modifier = Modifier
) {
    val autoReconnect by viewModel.autoReconnect.collectAsStateWithLifecycle()
    val enableAutoZip by viewModel.enableAutoZip.collectAsStateWithLifecycle()
    val speedThreshold by viewModel.speedAlertThreshold.collectAsStateWithLifecycle()
    val themeColorName by viewModel.appThemeColorName.collectAsStateWithLifecycle()
    val historyLogs by viewModel.transferHistory.collectAsStateWithLifecycle()

    val activeColor = when (themeColorName) {
        "Tech Emerald" -> Color(0xFF006874)
        "Stealth Onyx" -> Color(0xFF111827)
        else -> Color(0xFF6750A4)
    }

    val context = LocalContext.current
    var isCameraGranted by remember {
        mutableStateOf(
            androidx.core.content.ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.CAMERA
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        )
    }

    var isNotificationGranted by remember {
        mutableStateOf(
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                androidx.core.content.ContextCompat.checkSelfPermission(
                    context,
                    android.Manifest.permission.POST_NOTIFICATIONS
                ) == android.content.pm.PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        )
    }

    val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                isCameraGranted = androidx.core.content.ContextCompat.checkSelfPermission(
                    context,
                    android.Manifest.permission.CAMERA
                ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                isNotificationGranted = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                    androidx.core.content.ContextCompat.checkSelfPermission(
                        context,
                        android.Manifest.permission.POST_NOTIFICATIONS
                    ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                } else {
                    true
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    var showWipeConfirm by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title card
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateSurface),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, PolishedBorder, RoundedCornerShape(24.dp))
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "General Preferences",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = WhiteText
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Auto Reconnect
                SecuritySwitchRow(
                    title = "Auto-Reconnect Network Sockets",
                    description = "Attempt immediate connection recovery on temporary client drops.",
                    checked = autoReconnect,
                    activeColor = activeColor,
                    onCheckedChange = { viewModel.setAutoReconnect(it) }
                )

                Spacer(modifier = Modifier.height(12.dp))
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(PolishedBorder.copy(alpha = 0.4f)))
                Spacer(modifier = Modifier.height(12.dp))

                // Auto Zip
                SecuritySwitchRow(
                    title = "Speed-Boost Auto-Zip Batch Elements",
                    description = "Unify multiple file elements in a single zip context to minimize handshakes.",
                    checked = enableAutoZip,
                    activeColor = activeColor,
                    onCheckedChange = { viewModel.setEnableAutoZip(it) }
                )

                Spacer(modifier = Modifier.height(12.dp))
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(PolishedBorder.copy(alpha = 0.4f)))
                Spacer(modifier = Modifier.height(12.dp))

                // AeroShare Fast Mode
                val fastModeEnabled by viewModel.fastModeEnabled.collectAsStateWithLifecycle()
                SecuritySwitchRow(
                    title = "AeroShare Fast Mode",
                    description = "Break down payloads into parallel chunks and transfer over dynamic concurrent sockets simultaneously.",
                    checked = fastModeEnabled,
                    activeColor = activeColor,
                    onCheckedChange = { viewModel.setFastModeEnabled(it) }
                )
            }
        }

        // Target Speed Threshold segment
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateSurface),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, PolishedBorder, RoundedCornerShape(24.dp))
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "Goal Speed Alert Threshold",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = WhiteText
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Warns inside the chart workspace if active beam falls behind targeted throughput.",
                    fontSize = 11.sp,
                    color = MutedText
                )
                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(50, 100, 150).forEach { limit ->
                        val isChosen = speedThreshold == limit
                        val limitColor = if (isChosen) activeColor else SlateSurface
                        val textColor = if (isChosen) Color.White else WhiteText
                        val borderCol = if (isChosen) activeColor else PolishedBorder

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(limitColor)
                                .border(1.dp, borderCol, RoundedCornerShape(12.dp))
                                .clickable { viewModel.setSpeedAlertThreshold(limit) }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$limit MB/s",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = textColor
                            )
                        }
                    }
                }
            }
        }

        // System Permissions & Access Card
        val cameraPermissionLauncher = rememberLauncherForActivityResult(
            contract = androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
        ) { granted ->
            isCameraGranted = granted
        }

        val notificationPermissionLauncher = rememberLauncherForActivityResult(
            contract = androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
        ) { granted ->
            isNotificationGranted = granted
        }

        val openSettings = {
            try {
                val intent = android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = android.net.Uri.fromParts("package", context.packageName, null)
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(context, "Unable to open app settings screen.", Toast.LENGTH_SHORT).show()
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = SlateSurface),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, PolishedBorder, RoundedCornerShape(24.dp))
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "System Permissions & Access",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = WhiteText
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Review device access credentials requested by AeroShare and understand why they are required.",
                    fontSize = 11.sp,
                    color = MutedText
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Item 1: Camera
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(activeColor.copy(alpha = 0.12f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Camera,
                            contentDescription = "Camera Permission Indicator",
                            tint = activeColor,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "Camera Device",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = WhiteText
                            )

                            // Status Pill
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (isCameraGranted) Color(0xFF006874).copy(0.12f) else Color(0xFFBA1A1A).copy(0.12f),
                                        RoundedCornerShape(6.dp)
                                    )
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (isCameraGranted) "GRANTED" else "DENIED",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isCameraGranted) Color(0xFF00F0FF) else Color(0xFFFFB4AB),
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = "Used to scan pairing QR codes on sender or receiver screen to instantly exchange cryptographic session handshake parameters.",
                            fontSize = 11.sp,
                            color = MutedText,
                            lineHeight = 15.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = {
                                if (!isCameraGranted) {
                                    cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
                                } else {
                                    Toast.makeText(context, "Camera permission already granted!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isCameraGranted) SlateBg else activeColor.copy(0.15f)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .height(32.dp)
                                .border(
                                    1.dp,
                                    if (isCameraGranted) PolishedBorder else activeColor.copy(0.4f),
                                    RoundedCornerShape(10.dp)
                                ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                        ) {
                            Text(
                                text = if (isCameraGranted) "Access Allowed" else "Request Camera Access",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isCameraGranted) MutedText else WhiteText
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(PolishedBorder.copy(alpha = 0.4f)))
                Spacer(modifier = Modifier.height(14.dp))

                // Item 2: Notifications
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(activeColor.copy(alpha = 0.12f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Notifications Permission Indicator",
                            tint = activeColor,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "Push Notifications",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = WhiteText
                            )

                            // Status Pill
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (isNotificationGranted) Color(0xFF006874).copy(0.12f) else Color(0xFFBA1A1A).copy(0.12f),
                                        RoundedCornerShape(6.dp)
                                    )
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (isNotificationGranted) "GRANTED" else "DENIED",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isNotificationGranted) Color(0xFF00F0FF) else Color(0xFFFFB4AB),
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = "Used to display transfer speed, file streaming progress bars, and alerts when receiving/sending files while the app behaves in background state.",
                            fontSize = 11.sp,
                            color = MutedText,
                            lineHeight = 15.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = {
                                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                                    if (!isNotificationGranted) {
                                        notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                                    } else {
                                        Toast.makeText(context, "Notification permission already granted!", Toast.LENGTH_SHORT).show()
                                    }
                                } else {
                                    Toast.makeText(context, "Notification permissions are automatically allowed on this Android version.", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isNotificationGranted) SlateBg else activeColor.copy(0.15f)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .height(32.dp)
                                .border(
                                    1.dp,
                                    if (isNotificationGranted) PolishedBorder else activeColor.copy(0.4f),
                                    RoundedCornerShape(10.dp)
                                ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                        ) {
                            Text(
                                text = if (isNotificationGranted) "Access Allowed" else "Request Notification Access",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isNotificationGranted) MutedText else WhiteText
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(PolishedBorder.copy(alpha = 0.4f)))
                Spacer(modifier = Modifier.height(16.dp))

                // Footer manual open configuration
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Having system permissions issues?",
                        fontSize = 11.sp,
                        color = MutedText
                    )

                    Button(
                        onClick = openSettings,
                        colors = ButtonDefaults.buttonColors(containerColor = SlateBg),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .border(1.dp, PolishedBorder, RoundedCornerShape(10.dp)),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "System Settings Config Details Icon Button",
                            tint = WhiteText,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Open App Settings",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = WhiteText
                        )
                    }
                }
            }
        }

        // Custom Styling Cards
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateSurface),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, PolishedBorder, RoundedCornerShape(24.dp))
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "Visual Accent Styling",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = WhiteText
                )
                Spacer(modifier = Modifier.height(10.dp))

                listOf("Majesty Purple", "Tech Emerald", "Stealth Onyx").forEach { name ->
                    val isChosen = themeColorName == name
                    val dotColor = when (name) {
                        "Tech Emerald" -> Color(0xFF006874)
                        "Stealth Onyx" -> Color(0xFF111827)
                        else -> Color(0xFF6750A4)
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { viewModel.setAppThemeColorName(name) }
                            .padding(vertical = 8.dp, horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .background(dotColor, CircleShape)
                                .border(1.dp, Color.White, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = name,
                            fontSize = 12.sp,
                            fontWeight = if (isChosen) FontWeight.Bold else FontWeight.Normal,
                            color = if (isChosen) dotColor else WhiteText,
                            modifier = Modifier.weight(1f)
                        )
                        if (isChosen) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Selected Theme",
                                tint = dotColor,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        // Secure Transfer Analytics metrics segment
        SecureTransferAnalytics(
            history = historyLogs,
            activeColor = activeColor,
            viewModel = viewModel
        )

        // Encrypted Transaction Ledger list
        TransferHistoryLogsViewer(
            history = historyLogs,
            activeColor = activeColor,
            viewModel = viewModel
        )

        // Data Cleanup Card
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateSurface),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, PolishedBorder, RoundedCornerShape(24.dp))
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = "Data Management",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = WhiteText
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Purge local transaction logs and transfer events indices.",
                    fontSize = 11.sp,
                    color = MutedText
                )
                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { showWipeConfirm = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFDE8E8)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .border(1.dp, SecureRed.copy(0.3f), RoundedCornerShape(12.dp)),
                    enabled = historyLogs.isNotEmpty()
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Trash Icon",
                        tint = SecureRed,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (historyLogs.isEmpty()) "No History to Clear" else "Wipe All Transfer History (${historyLogs.size} Events)",
                        color = SecureRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    if (showWipeConfirm) {
        AlertDialog(
            onDismissRequest = { showWipeConfirm = false },
            title = {
                Text(text = "Are you absolutely sure?", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Text(text = "This will wipe all transferred files records in the history database. The physical files themselves will not be affected.", fontSize = 13.sp)
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearAllLogs()
                        showWipeConfirm = false
                    }
                ) {
                    Text("Clear All", color = SecureRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showWipeConfirm = false }
                ) {
                    Text("Cancel", color = MutedText)
                }
            }
        )
    }
}

@Composable
fun SecureConnectionIndicator(
    fingerprint: String?,
    encryptionStrength: String,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "secure_pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1250, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "secure_alpha"
    )

    Card(
        colors = CardDefaults.cardColors(containerColor = SlateSurfaceVariant),
        shape = RoundedCornerShape(20.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, TechEmerald.copy(alpha = 0.35f), RoundedCornerShape(20.dp))
            .testTag("secure_connection_indicator")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(TechEmerald.copy(alpha = 0.12f * alpha), CircleShape)
                    .border(1.dp, TechEmerald.copy(alpha = 0.3f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.EnhancedEncryption,
                    contentDescription = "Verified Handshake Strong Lock",
                    tint = TechEmerald,
                    modifier = Modifier.size(24.dp)
                )
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "SECURE E2EE LINK",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = TechEmerald,
                        letterSpacing = 0.5.sp
                    )
                    Box(
                        modifier = Modifier
                            .background(TechEmerald.copy(0.12f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 5.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = encryptionStrength,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = TechEmerald
                        )
                    }
                }
                Text(
                    text = "End-to-end symmetric session keys established.",
                    fontSize = 11.sp,
                    color = WhiteText,
                    fontWeight = FontWeight.Bold
                )
                if (!fingerprint.isNullOrEmpty()) {
                    Text(
                        text = "Handshake Verify Code: $fingerprint",
                        fontSize = 10.sp,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = TechEmerald,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun SecureTransferAnalytics(
    history: List<TransferEvent>,
    activeColor: Color,
    viewModel: TransferViewModel,
    modifier: Modifier = Modifier
) {
    val completedTransfers = remember(history) { history.filter { it.status == "COMPLETED" } }
    
    // Calculate stats
    val totalVolume = remember(completedTransfers) { completedTransfers.sumOf { it.fileSize } }
    val maxSpeed = remember(completedTransfers) { if (completedTransfers.isEmpty()) 0.0 else completedTransfers.maxOf { it.speedMBs } }
    val avgSpeed = remember(completedTransfers) { if (completedTransfers.isEmpty()) 0.0 else completedTransfers.map { it.speedMBs }.average() }
    val secureHandshakes = remember(history) { history.size }

    Card(
        colors = CardDefaults.cardColors(containerColor = SlateSurface),
        shape = RoundedCornerShape(24.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, PolishedBorder, RoundedCornerShape(24.dp))
            .testTag("transfer_analytics_card")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                text = "Secure Transfer Metrics",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = WhiteText
            )
            Text(
                text = "Encrypted transaction metrics aggregated from local DB logs.",
                fontSize = 11.sp,
                color = MutedText,
                modifier = Modifier.padding(top = 2.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Stat columns in a row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Stat 1: Beamed volume
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(activeColor.copy(alpha = 0.08f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudQueue,
                            contentDescription = "Data volume icon",
                            tint = activeColor,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Data Beamed",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = MutedText
                    )
                    Text(
                        text = viewModel.formatBytes(totalVolume),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = WhiteText,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                // Divider
                Box(
                    modifier = Modifier
                        .height(55.dp)
                        .width(1.dp)
                        .background(PolishedBorder.copy(alpha = 0.4f))
                        .align(Alignment.CenterVertically)
                )

                // Stat 2: Max Speed
                Column(
                    modifier = Modifier.weight(1.2f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(TechEmerald.copy(alpha = 0.08f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.TrendingUp,
                            contentDescription = "Peak throughput icon",
                            tint = TechEmerald,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Peak Throughput",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = MutedText
                    )
                    Text(
                        text = String.format("%.2f MB/s", maxSpeed),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = WhiteText,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                // Divider
                Box(
                    modifier = Modifier
                        .height(55.dp)
                        .width(1.dp)
                        .background(PolishedBorder.copy(alpha = 0.4f))
                        .align(Alignment.CenterVertically)
                )

                // Stat 3: Sessions
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(LaserOrange.copy(alpha = 0.08f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "Crypto handshakes count icon",
                            tint = LaserOrange,
                            modifier = Modifier.size(17.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Secure Beams",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = MutedText
                    )
                    Text(
                        text = "$secureHandshakes log(s)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = WhiteText,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }

            if (completedTransfers.isNotEmpty()) {
                Spacer(modifier = Modifier.height(14.dp))
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(PolishedBorder.copy(alpha = 0.3f)))
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.OfflineBolt,
                        contentDescription = "Analytics spark",
                        tint = TechEmerald,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = String.format("AeroShare Avg Speed: %.2f MB/s", avgSpeed),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TechEmerald
                    )
                }
            }
        }
    }
}

@Composable
fun TransferHistoryLogsViewer(
    history: List<TransferEvent>,
    activeColor: Color,
    viewModel: TransferViewModel,
    modifier: Modifier = Modifier
) {
    var showAllLogs by remember { mutableStateOf(false) }
    var expandedEventId by remember { mutableStateOf<Int?>(null) }

    val formatEpochTime: (Long) -> String = { epoch ->
        try {
            val sdf = java.text.SimpleDateFormat("MMM dd, HH:mm", java.util.Locale.getDefault())
            sdf.format(java.util.Date(epoch))
        } catch (e: Exception) {
            "Recent"
        }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = SlateSurface),
        shape = RoundedCornerShape(24.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, PolishedBorder, RoundedCornerShape(24.dp))
            .testTag("transfer_history_card")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Encrypted Transaction Ledger",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = WhiteText
                    )
                    Text(
                        text = "${history.size} session events cached locally.",
                        fontSize = 11.sp,
                        color = MutedText
                    )
                }

                if (history.size > 4) {
                    TextButton(
                        onClick = { showAllLogs = !showAllLogs },
                        colors = ButtonDefaults.textButtonColors(contentColor = activeColor)
                    ) {
                        Text(
                            text = if (showAllLogs) "Show Less" else "View All",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (history.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .background(activeColor.copy(alpha = 0.08f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "Empty History",
                            tint = activeColor.copy(alpha = 0.5f),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Text(
                        text = "No transfer logs cataloged.",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = WhiteText,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "When you beam or receive files over direct Wi-Fi endpoints, secure verification entries will populate here.",
                        fontSize = 10.sp,
                        color = MutedText,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 16.dp),
                        lineHeight = 14.sp
                    )
                }
            } else {
                val displayedList = if (showAllLogs) history else history.take(4)
                
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    displayedList.forEach { event ->
                        val isExpanded = expandedEventId == event.id
                        
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(SlateSurfaceVariant.copy(alpha = 0.4f))
                                .border(1.dp, PolishedBorder.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                                .clickable {
                                    expandedEventId = if (isExpanded) null else event.id
                                }
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                val directionColor = if (event.isSender) activeColor else TechEmerald
                                val directionIcon = if (event.isSender) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward
                                val directionLabel = if (event.isSender) "Sent" else "Received"

                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(directionColor.copy(alpha = 0.1f), CircleShape)
                                        .border(1.dp, directionColor.copy(alpha = 0.2f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = directionIcon,
                                        contentDescription = directionLabel,
                                        tint = directionColor,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    Text(
                                        text = event.fileName,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = WhiteText,
                                        maxLines = 1,
                                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                    )
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = viewModel.formatBytes(event.fileSize),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MutedText
                                        )
                                        Text(
                                            text = "•",
                                            fontSize = 10.sp,
                                            color = MutedText
                                        )
                                        Text(
                                            text = formatEpochTime(event.timestamp),
                                            fontSize = 10.sp,
                                            color = MutedText
                                        )
                                    }
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    if (event.status == "COMPLETED") {
                                        Text(
                                            text = String.format("%.1f MB/s", event.speedMBs),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = TechEmerald
                                        )
                                    } else {
                                        Text(
                                            text = "Failed",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = SecureRed
                                        )
                                    }

                                    IconButton(
                                        onClick = { viewModel.deleteLog(event) },
                                        modifier = Modifier
                                            .size(32.dp)
                                            .testTag("delete_log_${event.id}")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.DeleteOutline,
                                            contentDescription = "Delete Single Log Record",
                                            tint = MutedText.copy(alpha = 0.5f),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }

                            AnimatedVisibility(
                                visible = isExpanded,
                                enter = expandVertically() + fadeIn(),
                                exit = shrinkVertically() + fadeOut()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(1.dp)
                                            .background(PolishedBorder.copy(alpha = 0.2f))
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Cryptographic Strength:",
                                            fontSize = 10.sp,
                                            color = MutedText,
                                            fontWeight = FontWeight.Medium
                                        )
                                        Box(
                                            modifier = Modifier
                                                .background(TechEmerald.copy(0.08f), RoundedCornerShape(4.dp))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "AES-GCM (Enveloped)",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = TechEmerald
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Direct Peer Endpoint:",
                                            fontSize = 10.sp,
                                            color = MutedText,
                                            fontWeight = FontWeight.Medium
                                        )
                                        Text(
                                            text = event.peerIp,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = WhiteText,
                                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Integrity Validation:",
                                            fontSize = 10.sp,
                                            color = MutedText,
                                            fontWeight = FontWeight.Medium
                                        )
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = "Success tick",
                                                tint = TechEmerald,
                                                modifier = Modifier.size(10.dp)
                                            )
                                            Text(
                                                text = "Verified Block Hash",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = TechEmerald
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==================== RECEIVER DIALOGS ====================

@Composable
fun ReceivePortDialog(
    isActive: Boolean,
    pairingCode: String?,
    onDismiss: () -> Unit,
    onToggle: (Boolean) -> Unit,
    activeColor: Color
) {
    val context = LocalContext.current
    val clipboardManager = remember { context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SlateSurface),
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .border(1.dp, PolishedBorder, RoundedCornerShape(28.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "RECEIVING PORT",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isActive) TechEmerald else MutedText,
                        letterSpacing = 1.sp
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = MutedText)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (isActive) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .background(TechEmerald, CircleShape)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.SignalWifiOff,
                                contentDescription = "Offline Port",
                                tint = MutedText,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Text(
                            text = if (isActive) "Active Beam Beacon" else "Port Offline",
                            fontSize = 13.sp,
                            color = WhiteText,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Switch(
                        checked = isActive,
                        onCheckedChange = { onToggle(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = activeColor,
                            uncheckedThumbColor = MutedText,
                            uncheckedTrackColor = SlateSurfaceVariant
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (isActive && pairingCode != null) {
                    Text(
                        text = pairingCode,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = activeColor,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Box(
                        modifier = Modifier
                            .size(180.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White)
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        QrCodeView(
                            pairingCode = pairingCode,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Scan QR or input pairing code on sender device to start transmission.",
                        fontSize = 12.sp,
                        color = MutedText,
                        textAlign = TextAlign.Center,
                        lineHeight = 16.sp
                    )
                    
                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = {
                            val clipData = android.content.ClipData.newPlainText("PairingCode", pairingCode)
                            clipboardManager.setPrimaryClip(clipData)
                            Toast.makeText(context, "Pairing code copied!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SlateBg),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .border(1.dp, PolishedBorder, RoundedCornerShape(12.dp))
                    ) {
                        Icon(Icons.Outlined.ContentCopy, contentDescription = "Copy", tint = WhiteText, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Copy Info", color = WhiteText, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                } else {
                    Text(
                        text = "Aero Receiving Port is currently offline. Activate it to generate secure temporary credentials and a QR code for incoming transfers.",
                        fontSize = 13.sp,
                        color = WhiteText,
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}

@Composable
fun WifiDirectConsoleCard(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val p2pEnabled by WifiDirectManager.p2pEnabled.collectAsStateWithLifecycle()
    val discoveredP2pPeers by WifiDirectManager.discoveredPeers.collectAsStateWithLifecycle()
    val connectionState by WifiDirectManager.connectionState.collectAsStateWithLifecycle()
    val statusMessage by WifiDirectManager.statusMessage.collectAsStateWithLifecycle()

    Card(
        colors = CardDefaults.cardColors(containerColor = SlateSurface),
        shape = RoundedCornerShape(24.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, PolishedBorder, RoundedCornerShape(24.dp))
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Wifi,
                        contentDescription = "Wi-Fi Direct Status Indicator",
                        tint = when (connectionState) {
                            is WifiDirectManager.ConnectionState.Connected -> NeonCyan
                            is WifiDirectManager.ConnectionState.Discovering -> Color(0xFF6750A4)
                            else -> MutedText
                        },
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "WI-FI DIRECT DISCOVERY",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF6750A4),
                        letterSpacing = 1.sp
                    )
                }

                // State Pill Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            when (connectionState) {
                                is WifiDirectManager.ConnectionState.Connected -> NeonCyan.copy(alpha = 0.12f)
                                is WifiDirectManager.ConnectionState.Discovering -> Color(0xFF6750A4).copy(alpha = 0.12f)
                                is WifiDirectManager.ConnectionState.Connecting -> Color.Yellow.copy(alpha = 0.12f)
                                else -> SlateBg
                            }
                        )
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = when (connectionState) {
                            is WifiDirectManager.ConnectionState.Connected -> "LINKED"
                            is WifiDirectManager.ConnectionState.Discovering -> "SCANNING"
                            is WifiDirectManager.ConnectionState.Connecting -> "LINKING..."
                            else -> if (p2pEnabled) "READY" else "OFFLINE"
                        },
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (connectionState) {
                            is WifiDirectManager.ConnectionState.Connected -> NeonCyan
                            is WifiDirectManager.ConnectionState.Discovering -> Color(0xFFD0BCFF)
                            is WifiDirectManager.ConnectionState.Connecting -> Color.Yellow
                            else -> MutedText
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Establish direct peer-to-peer links without local Wi-Fi router networks. Once linked, automatic mDNS receiver polling and QR scanner streaming operate gauge-free.",
                fontSize = 11.sp,
                color = MutedText,
                lineHeight = 15.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Connection actions
            when (val state = connectionState) {
                is WifiDirectManager.ConnectionState.Connected -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(SlateBg)
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = if (state.isGroupOwner) "Group Owner (Host)" else "Connected Peer Client",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = WhiteText
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "P2P IP: ${state.groupOwnerAddress}",
                                fontSize = 10.sp,
                                color = NeonCyan
                            )
                        }

                        Button(
                            onClick = { WifiDirectManager.disconnect() },
                            colors = ButtonDefaults.buttonColors(containerColor = SecureRed.copy(0.12f)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .border(1.dp, SecureRed.copy(0.3f), RoundedCornerShape(10.dp))
                                .height(32.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp)
                        ) {
                            Text("Disconnect", color = SecureRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                else -> {
                    // Start Discovery trigger
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { WifiDirectManager.startDiscovery() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6750A4)),
                            shape = RoundedCornerShape(12.dp),
                            enabled = state !is WifiDirectManager.ConnectionState.Connecting,
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Sensors,
                                    contentDescription = "Discover Devices",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = if (state is WifiDirectManager.ConnectionState.Discovering) "Searching Peer Devices..." else "Scan Nearby Off-Grid Peers",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }

                        if (state is WifiDirectManager.ConnectionState.Discovering || state is WifiDirectManager.ConnectionState.Connecting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                strokeWidth = 2.dp,
                                color = Color(0xFF6750A4)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Status: $statusMessage",
                fontSize = 10.sp,
                color = MutedText,
                fontStyle = FontStyle.Italic
            )

            // Discover list
            if (discoveredP2pPeers.isNotEmpty() && connectionState !is WifiDirectManager.ConnectionState.Connected) {
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "DISCOVERED PEER HARDWARE (${discoveredP2pPeers.size})",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MutedText,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    discoveredP2pPeers.forEach { p2pDevice ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(SlateBg)
                                .border(1.dp, PolishedBorder, RoundedCornerShape(12.dp))
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(Color(0xFF6750A4).copy(0.12f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Smartphone,
                                        contentDescription = "Handset",
                                        tint = Color(0xFFD0BCFF),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        text = p2pDevice.deviceName.ifBlank { "Aero Device" },
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = WhiteText
                                    )
                                    Text(
                                        text = "Address: ${p2pDevice.deviceAddress}",
                                        fontSize = 9.sp,
                                        color = MutedText
                                    )
                                }
                            }

                            Button(
                                onClick = { WifiDirectManager.connectToDevice(p2pDevice) },
                                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(28.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                            ) {
                                Text("Link Device", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}
