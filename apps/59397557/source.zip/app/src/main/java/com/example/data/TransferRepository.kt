package com.example.data

import kotlinx.coroutines.flow.Flow

class TransferRepository(private val transferDao: TransferDao) {
    val allTransfers: Flow<List<TransferEvent>> = transferDao.getAllTransfers()

    suspend fun insert(event: TransferEvent) {
        transferDao.insertTransfer(event)
    }

    suspend fun clear() {
        transferDao.clearHistory()
    }

    suspend fun delete(event: TransferEvent) {
        transferDao.deleteTransfer(event)
    }
}
