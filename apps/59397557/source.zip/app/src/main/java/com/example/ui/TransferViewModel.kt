package com.example.ui

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.crypto.CryptoManager
import com.example.data.TransferDatabase
import com.example.data.TransferEvent
import com.example.data.TransferRepository
import com.example.network.NetworkManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import com.example.network.MdnsDiscoveryManager
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

data class ChosenFile(
    val uri: Uri,
    val name: String,
    val size: Long
)

class TransferViewModel(
    private val repository: TransferRepository
) : ViewModel() {

    private val TAG = "TransferViewModel"

    // Observed reactive logs from the local database
    val transferHistory: StateFlow<List<TransferEvent>> = repository.allTransfers
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val sessionState: StateFlow<NetworkManager.SessionState> = NetworkManager.transferState
    val activeSessionFingerprint: StateFlow<String?> = NetworkManager.activeSessionFingerprint

    // Observed reactive from mDNS Discovery
    val discoveredPeers = MdnsDiscoveryManager.discoveredPeers

    // Batch transfer queue
    private val _chosenFiles = MutableStateFlow<List<ChosenFile>>(emptyList())
    val chosenFiles = _chosenFiles.asStateFlow()

    // Track chosen file properties (kept for backwards compatibility)
    private val _chosenFileUri = MutableStateFlow<Uri?>(null)
    val chosenFileUri = _chosenFileUri.asStateFlow()

    private val _chosenFileName = MutableStateFlow("")
    val chosenFileName = _chosenFileName.asStateFlow()

    private val _chosenFileSize = MutableStateFlow(0L)
    val chosenFileSize = _chosenFileSize.asStateFlow()

    // Setting for automatic reconnection attempts
    private val _autoReconnect = MutableStateFlow(true)
    val autoReconnect = _autoReconnect.asStateFlow()

    fun setAutoReconnect(enabled: Boolean) {
        _autoReconnect.value = enabled
    }

    // Setting for automatic zipping of multiple files
    private val _enableAutoZip = MutableStateFlow(false)
    val enableAutoZip = _enableAutoZip.asStateFlow()

    fun setEnableAutoZip(enabled: Boolean) {
        _enableAutoZip.value = enabled
    }

    // Setting for AeroShare Fast Mode (Multi-part parallel transmission)
    private val _fastModeEnabled = MutableStateFlow(false)
    val fastModeEnabled = _fastModeEnabled.asStateFlow()

    fun setFastModeEnabled(enabled: Boolean) {
        _fastModeEnabled.value = enabled
    }

    // Setting for simultaneous share/receive mode (allow port to share/receive at the same time)
    private val _simultaneousModeEnabled = MutableStateFlow(false)
    val simultaneousModeEnabled = _simultaneousModeEnabled.asStateFlow()

    fun setSimultaneousModeEnabled(enabled: Boolean, context: Context? = null) {
        _simultaneousModeEnabled.value = enabled
        if (enabled && context != null) {
            hostSession(context)
        }
    }

    // Security Tab Preferences
    private val _encryptionStrength = MutableStateFlow("AES-256")
    val encryptionStrength = _encryptionStrength.asStateFlow()

    fun setEncryptionStrength(strength: String) {
        _encryptionStrength.value = strength
    }

    private val _enforceTls13 = MutableStateFlow(true)
    val enforceTls13 = _enforceTls13.asStateFlow()

    fun setEnforceTls13(enabled: Boolean) {
        _enforceTls13.value = enabled
    }

    private val _strictFileIntegrity = MutableStateFlow(true)
    val strictFileIntegrity = _strictFileIntegrity.asStateFlow()

    fun setStrictFileIntegrity(enabled: Boolean) {
        _strictFileIntegrity.value = enabled
    }

    private val _requirePairingCode = MutableStateFlow(true)
    val requirePairingCode = _requirePairingCode.asStateFlow()

    fun setRequirePairingCode(enabled: Boolean) {
        _requirePairingCode.value = enabled
    }

    // Settings Tab Preferences
    private val _speedAlertThreshold = MutableStateFlow(100)
    val speedAlertThreshold = _speedAlertThreshold.asStateFlow()

    fun setSpeedAlertThreshold(threshold: Int) {
        _speedAlertThreshold.value = threshold
    }

    private val _appThemeColorName = MutableStateFlow("Majesty Purple")
    val appThemeColorName = _appThemeColorName.asStateFlow()

    fun setAppThemeColorName(themeName: String) {
        _appThemeColorName.value = themeName
    }

    // Tracks transfer speed history points
    private val _transferSpeedHistory = MutableStateFlow<List<Double>>(emptyList())
    val transferSpeedHistory = _transferSpeedHistory.asStateFlow()

    private var activeSessionKey: javax.crypto.SecretKey? = null

    init {
        // Monitor transfers to write to Room upon successful completion and reactively start/stop mDNS discovery
        viewModelScope.launch {
            sessionState.collect { state ->
                // Manage notifications for offline/progress working
                when (state) {
                    is NetworkManager.SessionState.Transferring -> {
                        com.example.notification.NotificationHelper.showProgressNotification(
                            fileName = state.fileName,
                            progress = state.progress
                        )
                    }
                    is NetworkManager.SessionState.Completed,
                    is NetworkManager.SessionState.Failed,
                    is NetworkManager.SessionState.Idle -> {
                        com.example.notification.NotificationHelper.clearProgressNotification()
                    }
                    else -> {}
                }

                // Manage mDNS Discovery & Advertising based on the transmission state
                when (state) {
                    is NetworkManager.SessionState.Listening -> {
                        MdnsDiscoveryManager.startAdvertising(state.pairingCode)
                        MdnsDiscoveryManager.stopDiscovery()
                    }
                    is NetworkManager.SessionState.Idle -> {
                        MdnsDiscoveryManager.stopAdvertising()
                        MdnsDiscoveryManager.startDiscovery()
                    }
                    else -> {
                        MdnsDiscoveryManager.stopAdvertising()
                        MdnsDiscoveryManager.stopDiscovery()
                    }
                }

                // Manage Speed Analytics history tracking
                if (state is NetworkManager.SessionState.Idle || state is NetworkManager.SessionState.Listening || state is NetworkManager.SessionState.Connected) {
                    _transferSpeedHistory.value = emptyList()
                } else if (state is NetworkManager.SessionState.Transferring) {
                    val currentList = _transferSpeedHistory.value.toMutableList()
                    if (currentList.isEmpty() || currentList.last() != state.speedMBs) {
                        currentList.add(state.speedMBs)
                        if (currentList.size > 50) {
                            currentList.removeAt(0)
                        }
                        _transferSpeedHistory.value = currentList
                    }
                }

                if (state is NetworkManager.SessionState.Completed) {
                    val isSender = _chosenFileUri.value != null
                    // Write event to database
                    val peer = if (isSender) state.fileName else "Secure Peer"
                    val event = TransferEvent(
                        fileName = state.fileName,
                        fileSize = state.fileSize,
                        isSender = isSender,
                        speedMBs = state.speedMBs,
                        status = "COMPLETED",
                        peerIp = peer
                    )
                    repository.insert(event)

                    // Issue local background notification
                    val isLarge = state.fileSize >= 5 * 1024 * 1024L
                    val prefixLabel = if (isLarge) "Large File" else "Secure File"
                    com.example.notification.NotificationHelper.showNotification(
                        title = "$prefixLabel Beamed Successfully!",
                        message = "File: \"${state.fileName}\" (${formatBytes(state.fileSize)}) completed successfully."
                    )
                } else if (state is NetworkManager.SessionState.Failed) {
                    val isSender = _chosenFileUri.value != null
                    val name = _chosenFileName.value.ifEmpty() { "Secure Transfer" }
                    val event = TransferEvent(
                        fileName = name,
                        fileSize = _chosenFileSize.value,
                        isSender = isSender,
                        speedMBs = 0.0,
                        status = "FAILED",
                        peerIp = "Peer Connection"
                    )
                    repository.insert(event)

                    // Issue local background notification for transfer failure/interruption
                    com.example.notification.NotificationHelper.showNotification(
                        title = "Secure Transfer Interrupted",
                        message = "Transfer failed: ${state.reason}",
                        isError = true
                    )
                }
            }
        }
    }

    /**
     * Resolves selected file properties (Uri, name, size) from the resolver columns.
     */
    fun selectFile(context: Context, uri: Uri) {
        val resolver = context.contentResolver
        var name = "UnknownFile"
        var size = 0L

        try {
            resolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex != -1) name = cursor.getString(nameIndex)
                    if (sizeIndex != -1) size = cursor.getLong(sizeIndex)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to inspect selected database properties", e)
        }

        val fileItem = ChosenFile(uri, name, size)
        _chosenFiles.value = _chosenFiles.value + fileItem

        _chosenFileUri.value = uri
        _chosenFileName.value = name
        _chosenFileSize.value = size
    }

    /**
     * Resolves multiple selected file properties (Uris, names, sizes) and appends to queue.
     */
    fun selectMultipleFiles(context: Context, uris: List<Uri>) {
        val resolver = context.contentResolver
        val newFiles = uris.map { uri ->
            var name = "UnknownFile"
            var size = 0L
            try {
                resolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (cursor.moveToFirst()) {
                        if (nameIndex != -1) name = cursor.getString(nameIndex)
                        if (sizeIndex != -1) size = cursor.getLong(sizeIndex)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to inspect selected database properties", e)
            }
            ChosenFile(uri, name, size)
        }

        val updatedList = _chosenFiles.value + newFiles
        _chosenFiles.value = updatedList

        if (updatedList.isNotEmpty()) {
            val first = updatedList.first()
            _chosenFileUri.value = first.uri
            _chosenFileName.value = first.name
            _chosenFileSize.value = first.size
        }
    }

    /**
     * Clears selected file fields.
     */
    fun clearChosenFile() {
        _chosenFileUri.value = null
        _chosenFileName.value = ""
        _chosenFileSize.value = 0L
        _chosenFiles.value = emptyList()
    }

    /**
     * Removes an individual chosen file from the queue by index.
     */
    fun removeChosenFile(index: Int) {
        val currentList = _chosenFiles.value.toMutableList()
        if (index in currentList.indices) {
            currentList.removeAt(index)
            _chosenFiles.value = currentList

            // Sync legacy properties
            if (currentList.isNotEmpty()) {
                val first = currentList.first()
                _chosenFileUri.value = first.uri
                _chosenFileName.value = first.name
                _chosenFileSize.value = first.size
            } else {
                _chosenFileUri.value = null
                _chosenFileName.value = ""
                _chosenFileSize.value = 0L
            }
        }
    }

    /**
     * Moves an item in the queue up (decrease index) to prioritize it.
     */
    fun moveChosenFileUp(index: Int) {
        val currentList = _chosenFiles.value.toMutableList()
        if (index > 0 && index in currentList.indices) {
            val element = currentList.removeAt(index)
            currentList.add(index - 1, element)
            _chosenFiles.value = currentList
            
            // Sync legacy properties
            val first = currentList.first()
            _chosenFileUri.value = first.uri
            _chosenFileName.value = first.name
            _chosenFileSize.value = first.size
        }
    }

    /**
     * Moves an item in the queue down (increase index) to deprioritize it.
     */
    fun moveChosenFileDown(index: Int) {
        val currentList = _chosenFiles.value.toMutableList()
        if (index < currentList.size - 1 && index in currentList.indices) {
            val element = currentList.removeAt(index)
            currentList.add(index + 1, element)
            _chosenFiles.value = currentList
            
            // Sync legacy properties
            val first = currentList.first()
            _chosenFileUri.value = first.uri
            _chosenFileName.value = first.name
            _chosenFileSize.value = first.size
        }
    }

    /**
     * Automatically zips multiple files in background to bypass sequential transfer overhead.
     */
    fun zipSelectedFiles(context: Context, files: List<ChosenFile>): File? {
        if (files.isEmpty()) return null
        return try {
            val cacheDir = context.cacheDir
            if (!cacheDir.exists()) cacheDir.mkdirs()
            val zipFile = File(cacheDir, "AeroShare_Archive_${System.currentTimeMillis()}.zip")
            java.util.zip.ZipOutputStream(java.io.FileOutputStream(zipFile)).use { zos ->
                val buffer = ByteArray(32 * 1024)
                for (file in files) {
                    context.contentResolver.openInputStream(file.uri)?.use { inputStream ->
                        zos.putNextEntry(java.util.zip.ZipEntry(file.name))
                        var bytesRead: Int
                        while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                            zos.write(buffer, 0, bytesRead)
                        }
                        zos.closeEntry()
                    }
                }
            }
            zipFile
        } catch (e: Exception) {
            Log.e(TAG, "Failed manual zipping flow for batch elements", e)
            null
        }
    }

    /**
     * Set up E2E cryptography parameters and begin listening for client connections.
     */
    fun hostSession(context: Context) {
        viewModelScope.launch {
            val key = CryptoManager.generateAESKey()
            activeSessionKey = key
            NetworkManager.startReceiverServer(context, key, _autoReconnect.value, _simultaneousModeEnabled.value)
        }
    }

    /**
     * Submits all files in the selection queue sequentially.
     */
    fun sendSession(context: Context, pairingCode: String) {
        val filesToTransfer = _chosenFiles.value
        if (filesToTransfer.isEmpty()) {
            val legacyUri = _chosenFileUri.value ?: return
            val legacyName = _chosenFileName.value
            val legacySize = _chosenFileSize.value
            _chosenFiles.value = listOf(ChosenFile(legacyUri, legacyName, legacySize))
        }

        val finalFiles = _chosenFiles.value
        viewModelScope.launch {
            if (_enableAutoZip.value && finalFiles.size > 1) {
                Log.d(TAG, "Auto-Zip compression enabled. Zipping ${finalFiles.size} selected items...")
                val zipFile = zipSelectedFiles(context, finalFiles)
                if (zipFile != null && zipFile.exists()) {
                    val zipUri = Uri.fromFile(zipFile)
                    val zipName = zipFile.name
                    val zipSize = zipFile.length()
                    Log.d(TAG, "Zip compression successful! Sending unified archive: $zipName ($zipSize bytes)")
                    NetworkManager.startSenderClient(context, pairingCode, zipUri, zipName, zipSize, _autoReconnect.value, _fastModeEnabled.value, _simultaneousModeEnabled.value)
                } else {
                    Log.w(TAG, "Auto-zip failed or generated empty outcome. Falling back to default sequential batch transfer.")
                    performSequentialSend(context, pairingCode, finalFiles)
                }
            } else {
                performSequentialSend(context, pairingCode, finalFiles)
            }
            clearChosenFile()
        }
    }

    private suspend fun performSequentialSend(context: Context, pairingCode: String, files: List<ChosenFile>) {
        for ((index, file) in files.withIndex()) {
            Log.d(TAG, "Batch send: starting file ${index + 1}/${files.size}: ${file.name}")
            NetworkManager.startSenderClient(context, pairingCode, file.uri, file.name, file.size, _autoReconnect.value, _fastModeEnabled.value, _simultaneousModeEnabled.value)

            val state = NetworkManager.transferState.value
            if (state is NetworkManager.SessionState.Failed) {
                Log.w(TAG, "Batch send interrupted due to failure at file: ${file.name}")
                break
            }
            // Delay to allow the receiver state machine room to transition and restart listening
            kotlinx.coroutines.delay(1000)
        }
    }

    /**
     * Shuts down any current connections.
     */
    fun cancelSession() {
        NetworkManager.stopAllSessions()
        clearChosenFile()
    }

    /**
     * Wipes SQLite transferred logs history.
     */
    fun clearAllLogs() {
        viewModelScope.launch {
            repository.clear()
        }
    }

    /**
     * Deletes a specific transfer log element.
     */
    fun deleteLog(event: TransferEvent) {
        viewModelScope.launch {
            repository.delete(event)
        }
    }

    /**
     * Nicely format bytes dynamically.
     */
    fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
        return String.format(
            "%.2f %s",
            bytes / Math.pow(1024.0, digitGroups.toDouble()),
            units[digitGroups]
        )
    }

    /**
     * Factory instance provider class helper.
     */
    class Factory(private val context: Context) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(TransferViewModel::class.java)) {
                val database = TransferDatabase.getDatabase(context)
                val repository = TransferRepository(database.transferDao())
                @Suppress("UNCHECKED_CAST")
                return TransferViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
