package com.example.network

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.crypto.CryptoManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer
import javax.crypto.SecretKey

object NetworkManager {
    private const val TAG = "NetworkManager"
    const val DEFAULT_PORT = 9988

    // Represents the live state of a transfer session
    sealed class SessionState {
        object Idle : SessionState()
        data class Listening(val ip: String, val port: Int, val pairingCode: String) : SessionState()
        data class Connected(val peerIp: String) : SessionState()
        data class Transferring(
            val fileName: String,
            val fileSize: Long,
            val bytesTransferred: Long,
            val progress: Float, // 0.0 to 1.0
            val speedMBs: Double, // Realtime megabytes per second
            val isSending: Boolean
        ) : SessionState()
        data class Completed(
            val fileName: String, 
            val fileSize: Long, 
            val speedMBs: Double,
            val localPath: String? = null
        ) : SessionState()
        data class Failed(val reason: String) : SessionState()
    }

    val transferState = MutableStateFlow<SessionState>(SessionState.Idle)
    val activeSessionFingerprint = MutableStateFlow<String?>(null)

    // Keep active sockets and servers reference for cancellation / cleanup
    private var activeServerSocket: ServerSocket? = null
    private var activeClientSocket: Socket? = null

    /**
     * Resolves the primary local wireless IPv4 address.
     */
    fun getLocalIpAddress(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                // Skip inactive / loopback / VPN tunnels
                if (!networkInterface.isUp || networkInterface.isLoopback || networkInterface.name.contains("tun")) continue
                val addresses = networkInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (address is Inet4Address && !address.isLoopbackAddress) {
                        return address.hostAddress ?: "127.0.0.1"
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting IP", e)
        }
        return "127.0.0.1"
    }

    /**
     * Converts IP, Port, and key into a formatted pairing credential string: "IP|PORT|AESKEY_BASE64"
     */
    fun createPairingCode(ip: String, port: Int, key: SecretKey): String {
        val base64Key = CryptoManager.keyToBase64(key)
        return "$ip|$port|$base64Key"
    }

    /**
     * Parses a pairing credential string back into its constituent properties.
     */
    fun parsePairingCode(code: String): Triple<String, Int, SecretKey>? {
        return try {
            val parts = code.trim().split("|")
            if (parts.size == 3) {
                val ip = parts[0]
                val port = parts[1].toInt()
                val key = CryptoManager.base64ToKey(parts[2])
                Triple(ip, port, key)
            } else {
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed parsing credentials", e)
            null
        }
    }

    /**
     * Generates a visual, cryptographically secure 12-char SHA-256 derived safety number fingerprint
     * for mutual device handshake verification.
     */
    fun computeFingerprint(key: SecretKey): String {
        return try {
            val encodedBytes = key.encoded
            val md = java.security.MessageDigest.getInstance("SHA-256")
            val hash = md.digest(encodedBytes)
            val sb = StringBuilder()
            for (i in 0 until minOf(hash.size, 6)) {
                sb.append(String.format("%02X", hash[i]))
            }
            val rawHex = sb.toString()
            if (rawHex.length >= 12) {
                "${rawHex.substring(0, 4)}-${rawHex.substring(4, 8)}-${rawHex.substring(8, 12)}"
            } else {
                rawHex
            }
        } catch (e: Exception) {
            "AERO-AES-KEY"
        }
    }

    /**
     * Shuts down any current connections or server instances.
     */
    fun stopAllSessions() {
        activeSessionFingerprint.value = null
        try {
            activeServerSocket?.close()
            activeServerSocket = null
        } catch (_: Exception) {}

        try {
            activeClientSocket?.close()
            activeClientSocket = null
        } catch (_: Exception) {}

        transferState.value = SessionState.Idle
    }

    /**
     * Closes current outbound client socket only, retaining the receiving server state.
     */
    fun stopClientSessionOnly() {
        try {
            activeClientSocket?.close()
            activeClientSocket = null
        } catch (_: Exception) {}
    }

    /**
     * Determines optimal segment breakdowns based on file payload size.
     */
    fun getNumParts(fileSize: Long): Int {
        return when {
            fileSize < 2 * 1024 * 1024 -> 1 // < 2MB: 1 segment (avoid thread initialization overhead)
            fileSize < 10 * 1024 * 1024 -> 2 // 2MB to 10MB: 2 segments
            else -> 4 // > 10MB: 4 segment threads
        }
    }

    /**
     * Reads exactly [length] bytes from [inputStream] into [buffer].
     * Returns the total number of bytes read, which will equal [length] unless EOF is reached.
     */
    private fun readFully(inputStream: java.io.InputStream, buffer: ByteArray, length: Int): Int {
        var totalRead = 0
        while (totalRead < length) {
            val read = inputStream.read(buffer, totalRead, length - totalRead)
            if (read == -1) break
            totalRead += read
        }
        return totalRead
    }

    /**
     * Starts listening for direct secure socket transfers as the connection receiver.
     */
    suspend fun startReceiverServer(
        context: Context,
        key: SecretKey,
        autoReconnect: Boolean = true,
        allowSimultaneous: Boolean = false
    ) = withContext(Dispatchers.IO) {
        if (allowSimultaneous) {
            try {
                activeServerSocket?.close()
                activeServerSocket = null
            } catch (_: Exception) {}
        } else {
            stopAllSessions()
        }
        
        val ip = getLocalIpAddress()
        val port = DEFAULT_PORT
        val server = try {
            ServerSocket(port)
        } catch (e: Exception) {
            Log.e(TAG, "Error starting ServerSocket", e)
            transferState.value = SessionState.Failed("Could not open port $port")
            return@withContext
        }
        
        activeServerSocket = server
        val pairingCode = createPairingCode(ip, port, key)
        activeSessionFingerprint.value = computeFingerprint(key)
        transferState.value = SessionState.Listening(ip, port, pairingCode)

        while (activeServerSocket != null) {
            var attempts = 0
            val maxAttempts = if (autoReconnect) 3 else 1
            var success = false

            while (attempts < maxAttempts && !success && activeServerSocket != null) {
                attempts++
                var clientSocket: Socket? = null
                try {
                    if (attempts > 1) {
                        transferState.value = SessionState.Failed("Connection interrupted. Reconnecting (attempt $attempts/$maxAttempts)...")
                        Log.d(TAG, "Receiver: waiting for reconnection attempt $attempts...")
                    }
                    clientSocket = server.accept()
                    activeClientSocket = clientSocket
                    
                    // Optimize socket for raw speed
                    clientSocket.tcpNoDelay = true
                    clientSocket.receiveBufferSize = 512 * 1024 // 512KB Buffer
                    
                    val peerIp = clientSocket.inetAddress.hostAddress ?: "Unknown Peer"
                    transferState.value = SessionState.Connected(peerIp)

                    val input = BufferedInputStream(clientSocket.inputStream)
                    
                    // 1. Session handshake / salt
                    val salt = ByteArray(8)
                    var bytesRead = input.read(salt)
                    if (bytesRead != 8) {
                        throw Exception("Handshake failed: Invalid salt packet")
                    }

                    // 2. Read Metadata Packet
                    // Reads exact packet length
                    val metaLenBuffer = ByteArray(4)
                    if (readFully(input, metaLenBuffer, 4) != 4) throw Exception("Metadata length read error")
                    val metaLen = ByteBuffer.wrap(metaLenBuffer).int
                    if (metaLen <= 0 || metaLen > 1024 * 1024) throw Exception("Invalid metadata packet size: $metaLen")
                    
                    val encryptedMetaBytes = ByteArray(metaLen)
                    var readAccumulator = 0
                    while (readAccumulator < metaLen) {
                        val chunkBytesRead = input.read(encryptedMetaBytes, readAccumulator, metaLen - readAccumulator)
                        if (chunkBytesRead == -1) throw Exception("EOF while reading metadata")
                        readAccumulator += chunkBytesRead
                    }
                    
                    // Decrypt string
                    val decryptedMetaText = CryptoManager.decryptText(String(encryptedMetaBytes, Charsets.UTF_8), key)
                    val metaParts = decryptedMetaText.split("|") // Format: "filename|size" or "filename|size|FAST"
                    if (metaParts.size < 2) throw Exception("Invalid metadata components")
                    val fileName = metaParts[0]
                    val fileSize = metaParts[1].toLong()
                    val isFastModeHandshake = metaParts.size >= 3 && metaParts[2] == "FAST"

                    // Resolve unique target files inside Downloads folder (or cache fallback)
                    val downloadDir = context.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
                    if (!downloadDir.exists()) downloadDir.mkdirs()
                    
                    var targetFile = File(downloadDir, fileName)
                    // Handle name collisions simply
                    if (targetFile.exists() && attempts == 1) {
                        val nameWithoutExt = targetFile.nameWithoutExtension
                        val ext = targetFile.extension
                        targetFile = File(downloadDir, "${nameWithoutExt}_${System.currentTimeMillis()}.$ext")
                    }

                    val startTime = System.currentTimeMillis()

                    if (isFastModeHandshake) {
                        // ==== FAST MODE MULTI-THREAD PIPELINE ====
                        val numParts = getNumParts(fileSize)
                        Log.d(TAG, "Fast Mode Handshake matched. Receiving file: $fileName via $numParts parallel sockets...")

                        val recvThreads = mutableListOf<Thread>()
                        val recvErrors = java.util.concurrent.CopyOnWriteArrayList<Throwable>()
                        val totalTransferredBytes = java.util.concurrent.atomic.AtomicLong(0)
                        
                        var speedMBs = 0.0

                        for (i in 0 until numParts) {
                            val threadIndex = i
                            val thread = Thread {
                                var subServer: ServerSocket? = null
                                var subClient: Socket? = null
                                try {
                                    val partPort = port + 1 + threadIndex
                                    subServer = ServerSocket(partPort)
                                    subServer.soTimeout = 12000 // 12 seconds connection timeout
                                    subClient = subServer.accept()
                                    subClient.tcpNoDelay = true
                                    subClient.receiveBufferSize = 512 * 1024

                                    val subIn = BufferedInputStream(subClient.inputStream)

                                    // Handshake salt Verification
                                    val subSalt = ByteArray(8)
                                    if (subIn.read(subSalt) != 8) {
                                        throw Exception("Failed fragment salt validation")
                                    }

                                    val partFile = File(downloadDir, "temp_part_${threadIndex}_$fileName")
                                    partFile.outputStream().use { fos ->
                                        val subIntBuffer = ByteArray(4)
                                        var subChunkIdx = 0
                                        
                                        val startOffset = threadIndex * (fileSize / numParts)
                                        val sliceLength = if (threadIndex == numParts - 1) fileSize - startOffset else (fileSize / numParts)
                                        var subTransferred = 0L

                                        while (subTransferred < sliceLength) {
                                            val cr = readFully(subIn, subIntBuffer, 4)
                                            if (cr != 4) {
                                                if (subTransferred == sliceLength) break
                                                throw Exception("Unexpected socket EOF reading packet size")
                                            }
                                            val encSize = ByteBuffer.wrap(subIntBuffer).int
                                            if (encSize <= 0 || encSize > 256 * 1024) {
                                                throw Exception("Fragment protocol size error ($encSize)")
                                            }

                                            val encBlock = ByteArray(encSize)
                                            var blockReadAcc = 0
                                            while (blockReadAcc < encSize) {
                                                val r = subIn.read(encBlock, blockReadAcc, encSize - blockReadAcc)
                                                if (r == -1) throw Exception("EOF in fragment block stream")
                                                blockReadAcc += r
                                            }

                                            val rIv = CryptoManager.generateChunkIV(subSalt, subChunkIdx)
                                            val decBytes = CryptoManager.decryptChunk(encBlock, key, rIv)
                                            fos.write(decBytes)

                                            subTransferred += decBytes.size
                                            subChunkIdx++

                                            val overall = totalTransferredBytes.addAndGet(decBytes.size.toLong())

                                            // Dynamic Speed update
                                            val now = System.currentTimeMillis()
                                            val delta = now - startTime
                                            if (delta >= 400 || overall == fileSize) {
                                                synchronized(this@NetworkManager) {
                                                    val deltaSec = (System.currentTimeMillis() - startTime) / 1000.0
                                                    speedMBs = if (deltaSec > 0) {
                                                        (overall.toDouble() / (1024.0 * 1024.0)) / deltaSec
                                                    } else 0.0

                                                    transferState.value = SessionState.Transferring(
                                                        fileName = fileName,
                                                        fileSize = fileSize,
                                                        bytesTransferred = overall,
                                                        progress = overall.toFloat() / fileSize.toFloat(),
                                                        speedMBs = speedMBs,
                                                        isSending = false
                                                    )
                                                }
                                            }
                                        }
                                        fos.flush()
                                    }
                                } catch (t: Throwable) {
                                    Log.e(TAG, "Fast Mode Receiver thread $threadIndex failed", t)
                                    recvErrors.add(t)
                                } finally {
                                    try { subClient?.close() } catch (_: Exception) {}
                                    try { subServer?.close() } catch (_: Exception) {}
                                }
                            }
                            recvThreads.add(thread)
                        }

                        recvThreads.forEach { it.start() }
                        recvThreads.forEach { it.join() }

                        if (recvErrors.isNotEmpty()) {
                            throw Exception("Parallel receiver pipeline failure: ${recvErrors.first().message}")
                        }

                        // Combine Fragment Parts Carefully without changing anything
                        Log.d(TAG, "Combining fragments carefully into final destination: ${targetFile.absolutePath}")
                        targetFile.outputStream().use { fos ->
                            for (i in 0 until numParts) {
                                val partFile = File(downloadDir, "temp_part_${i}_$fileName")
                                if (!partFile.exists()) {
                                    throw Exception("Missing downloaded piece: part $i")
                                }
                                partFile.inputStream().use { fis ->
                                    fis.copyTo(fos)
                                }
                                partFile.delete() // Clean up temp slice
                            }
                        }

                        val totalSeconds = (System.currentTimeMillis() - startTime) / 1000.0
                        val overallSpeed = if (totalSeconds > 0) {
                            (fileSize.toDouble() / (1024.0 * 1024.0)) / totalSeconds
                        } else 0.0

                        transferState.value = SessionState.Completed(
                            fileName = fileName,
                            fileSize = fileSize,
                            speedMBs = overallSpeed,
                            localPath = targetFile.absolutePath
                        )
                        success = true

                    } else {
                        // ==== LEGACY SINGLE-THREAD TRANSFERS FLOW ====
                        Log.d(TAG, "Receiving file $fileName ($fileSize bytes) over standard channel")
                        val outputStream = targetFile.outputStream()
                        
                        var bytesTransferred = 0L
                        var chunkIndex = 0
                        val intBuffer = ByteArray(4)

                        var speedLastUpdate = startTime
                        var bytesSinceLastUpdate = 0L
                        var speedMBs = 0.0

                        while (bytesTransferred < fileSize) {
                            val metaBytesRead = readFully(input, intBuffer, 4)
                            if (metaBytesRead != 4) {
                                if (bytesTransferred == fileSize) {
                                    break
                                }
                                throw Exception("Unexpected connection drop reading block size")
                            }
                            
                            val encryptedChunkSize = ByteBuffer.wrap(intBuffer).int
                            if (encryptedChunkSize <= 0 || encryptedChunkSize > 256 * 1024) {
                                throw Exception("Protocol error: corrupted block size ($encryptedChunkSize)")
                            }

                            val encryptedBlock = ByteArray(encryptedChunkSize)
                            var blockReadAccumulator = 0
                            while (blockReadAccumulator < encryptedChunkSize) {
                                val cr = input.read(encryptedBlock, blockReadAccumulator, encryptedChunkSize - blockReadAccumulator)
                                if (cr == -1) throw Exception("EOF reached unexpectedly within active chunk block")
                                blockReadAccumulator += cr
                            }

                            val chunkIv = CryptoManager.generateChunkIV(salt, chunkIndex)
                            val decryptedChunkBytes = CryptoManager.decryptChunk(encryptedBlock, key, chunkIv)
                            
                            outputStream.write(decryptedChunkBytes)
                            
                            bytesTransferred += decryptedChunkBytes.size
                            bytesSinceLastUpdate += decryptedChunkBytes.size
                            chunkIndex++

                            val now = System.currentTimeMillis()
                            val delta = now - speedLastUpdate
                            if (delta >= 400 || bytesTransferred == fileSize) {
                                speedMBs = if (delta > 0) {
                                    (bytesSinceLastUpdate.toDouble() / (1024.0 * 1024.0)) / (delta.toDouble() / 1000.0)
                                } else 0.0
                                
                                speedLastUpdate = now
                                bytesSinceLastUpdate = 0L
                                
                                transferState.value = SessionState.Transferring(
                                    fileName = fileName,
                                    fileSize = fileSize,
                                    bytesTransferred = bytesTransferred,
                                    progress = bytesTransferred.toFloat() / fileSize.toFloat(),
                                    speedMBs = speedMBs,
                                    isSending = false
                                )
                            }
                        }

                        outputStream.flush()
                        outputStream.close()
                        
                        val totalSeconds = (System.currentTimeMillis() - startTime) / 1000.0
                        val overallSpeed = if (totalSeconds > 0) {
                            (fileSize.toDouble() / (1024.0 * 1024.0)) / totalSeconds
                        } else 0.0

                        transferState.value = SessionState.Completed(
                            fileName = fileName,
                            fileSize = fileSize,
                            speedMBs = overallSpeed,
                            localPath = targetFile.absolutePath
                        )
                        success = true
                    }

                } catch (e: Exception) {
                    Log.e(TAG, "Error receiving file", e)
                    if (attempts >= maxAttempts) {
                        transferState.value = SessionState.Failed(e.message ?: "Transfer aborted.")
                    } else {
                        transferState.value = SessionState.Failed("Connection interrupted. Reconnecting (attempt $attempts/$maxAttempts)...")
                        kotlinx.coroutines.delay(1500)
                    }
                } finally {
                    try { clientSocket?.close() } catch (_: Exception) {}
                    activeClientSocket = null
                }
            }

            if (success) {
                // Transfer was successful! Delay and check if we are still active to reset state to Listening for subsequent files in batch
                kotlinx.coroutines.delay(1500)
                if (activeServerSocket != null) {
                    transferState.value = SessionState.Listening(ip, port, pairingCode)
                }
            } else {
                break
            }
        }

        try { server.close() } catch (_: Exception) {}
        activeServerSocket = null
    }

    /**
     * Connects to a secure receiver endpoint and uploads selected file data.
     */
    suspend fun startSenderClient(
        context: Context,
        pairingCode: String,
        fileUri: Uri,
        fileName: String,
        fileSize: Long,
        autoReconnect: Boolean = true,
        fastMode: Boolean = false,
        allowSimultaneous: Boolean = false
    ) = withContext(Dispatchers.IO) {
        if (allowSimultaneous) {
            stopClientSessionOnly()
        } else {
            stopAllSessions()
        }
        
        var attempts = 0
        val maxAttempts = if (autoReconnect) 3 else 1
        var success = false

        while (attempts < maxAttempts && !success) {
            attempts++
            if (attempts > 1) {
                Log.d(TAG, "Sender: Reconnection attempt $attempts of $maxAttempts...")
                kotlinx.coroutines.delay(1500)
            }

            try { activeClientSocket?.close() } catch (_: Exception) {}
            activeClientSocket = null

            var socket: Socket? = null
            try {
                val parsed = parsePairingCode(pairingCode)
                if (parsed == null) {
                    transferState.value = SessionState.Failed("Invalid pairing code format")
                    return@withContext
                }
                
                val (ip, port, key) = parsed
                activeSessionFingerprint.value = computeFingerprint(key)
                transferState.value = SessionState.Connected(ip)

                // Establish Connection
                socket = Socket(ip, port)
                activeClientSocket = socket
                
                // Optimize socket configurations
                socket.tcpNoDelay = true
                socket.sendBufferSize = 512 * 1024 // 512KB Buffer

                val out = BufferedOutputStream(socket.getOutputStream())
                
                // 1. Send Handshake prefix salt (8 random bytes)
                val sessionSalt = ByteArray(8)
                CryptoManager.secureRandom.nextBytes(sessionSalt)
                out.write(sessionSalt)
                out.flush()

                // 2. Prepare encrypted Metadata String
                val numParts = getNumParts(fileSize)
                val useFastMode = fastMode && numParts > 1
                val metadataText = if (useFastMode) {
                    "$fileName|$fileSize|FAST"
                } else {
                    "$fileName|$fileSize"
                }
                val encryptedMetaBase64 = CryptoManager.encryptText(metadataText, key)
                val metaBytes = encryptedMetaBase64.toByteArray(Charsets.UTF_8)
                
                // Send Metadata Size + Data
                val sizeBuffer = ByteBuffer.allocate(4).putInt(metaBytes.size).array()
                out.write(sizeBuffer)
                out.write(metaBytes)
                out.flush()

                Log.d(TAG, "Connected. Sending file $fileName ($fileSize bytes) with useFastMode=$useFastMode")

                val startTime = System.currentTimeMillis()

                if (useFastMode) {
                    // ==== FAST MODE MULTI-THREAD PIPELINE SENDER ====
                    Log.d(TAG, "Starting Fast Mode Sender. Sending file in $numParts parallel elements...")
                    val partSize = fileSize / numParts
                    val sendThreads = mutableListOf<Thread>()
                    val sendErrors = java.util.concurrent.CopyOnWriteArrayList<Throwable>()
                    val totalTransferredBytes = java.util.concurrent.atomic.AtomicLong(0)
                    
                    var speedMBs = 0.0

                    // Give receiver 500ms to open up their server sockets
                    kotlinx.coroutines.delay(500)

                    for (i in 0 until numParts) {
                        val threadIndex = i
                        val thread = Thread {
                            var subSocket: Socket? = null
                            try {
                                val startOffset = threadIndex * partSize
                                val sliceLength = if (threadIndex == numParts - 1) fileSize - startOffset else partSize
                                val partPort = port + 1 + threadIndex
                                
                                // Direct connect with retry overhead
                                var error: Exception? = null
                                for (retry in 1..8) {
                                    try {
                                        subSocket = Socket(ip, partPort)
                                        break
                                    } catch (e: Exception) {
                                        error = e
                                        Thread.sleep((150 + retry * 50).toLong())
                                    }
                                }
                                if (subSocket == null) {
                                    throw Exception("Helper thread $threadIndex could not connect on port $partPort: ${error?.message}")
                                }

                                subSocket.tcpNoDelay = true
                                subSocket.sendBufferSize = 512 * 1024

                                val subOut = BufferedOutputStream(subSocket.getOutputStream())

                                // Send part handshake salt (fully random unique salt per threaded segment)
                                val threadSalt = ByteArray(8)
                                CryptoManager.secureRandom.nextBytes(threadSalt)
                                subOut.write(threadSalt)
                                subOut.flush()

                                val resolver = context.contentResolver
                                resolver.openInputStream(fileUri)?.use { subIn ->
                                    val bufferedSubIn = BufferedInputStream(subIn)
                                    
                                    // Skip to target starting offset
                                    var totalSkipped = 0L
                                    val skipBuffer = ByteArray(8192)
                                    while (totalSkipped < startOffset) {
                                        val remain = startOffset - totalSkipped
                                        val skipped = bufferedSubIn.skip(remain)
                                        if (skipped > 0) {
                                            totalSkipped += skipped
                                        } else {
                                            val toSkip = minOf(remain, skipBuffer.size.toLong())
                                            val rs = bufferedSubIn.read(skipBuffer, 0, toSkip.toInt())
                                            if (rs == -1) break
                                            totalSkipped += rs
                                        }
                                    }

                                    // Stream blocks
                                    val streamBuffer = ByteArray(16 * 1024)
                                    var bytesSentInThread = 0L
                                    var subChunkIdx = 0

                                    while (bytesSentInThread < sliceLength) {
                                        val toRead = minOf(streamBuffer.size.toLong(), sliceLength - bytesSentInThread).toInt()
                                        val read = bufferedSubIn.read(streamBuffer, 0, toRead)
                                        if (read == -1) break

                                        val pieceBytes = if (read < streamBuffer.size) {
                                            val slice = ByteArray(read)
                                            System.arraycopy(streamBuffer, 0, slice, 0, read)
                                            slice
                                        } else streamBuffer

                                        val chunkIv = CryptoManager.generateChunkIV(threadSalt, subChunkIdx)
                                        val encrypted = CryptoManager.encryptChunk(pieceBytes, key, chunkIv)

                                        val lengthHeader = ByteBuffer.allocate(4).putInt(encrypted.size).array()
                                        subOut.write(lengthHeader)
                                        subOut.write(encrypted)

                                        bytesSentInThread += read
                                        subChunkIdx++

                                        val overall = totalTransferredBytes.addAndGet(read.toLong())

                                        // Speed calculations
                                        val now = System.currentTimeMillis()
                                        val delta = now - startTime
                                        if (delta >= 400 || overall == fileSize) {
                                            synchronized(this@NetworkManager) {
                                                val deltaSec = (System.currentTimeMillis() - startTime) / 1000.0
                                                speedMBs = if (deltaSec > 0) {
                                                    (overall.toDouble() / (1024.0 * 1024.0)) / deltaSec
                                                } else 0.0

                                                transferState.value = SessionState.Transferring(
                                                    fileName = fileName,
                                                    fileSize = fileSize,
                                                    bytesTransferred = overall,
                                                    progress = overall.toFloat() / fileSize.toFloat(),
                                                    speedMBs = speedMBs,
                                                    isSending = true
                                                )
                                            }
                                        }
                                    }
                                    subOut.flush()
                                } ?: throw Exception("Failure reading file Uri slice input stream")
                            } catch (t: Throwable) {
                                Log.e(TAG, "Fast Mode Sender thread $threadIndex failed", t)
                                sendErrors.add(t)
                            } finally {
                                try { subSocket?.close() } catch (_: Exception) {}
                            }
                        }
                        sendThreads.add(thread)
                    }

                    sendThreads.forEach { it.start() }
                    sendThreads.forEach { it.join() }

                    if (sendErrors.isNotEmpty()) {
                        throw Exception("Parallel upload pipeline failures: ${sendErrors.first().message}")
                    }

                    val totalSeconds = (System.currentTimeMillis() - startTime) / 1000.0
                    val overallSpeed = if (totalSeconds > 0) {
                        (fileSize.toDouble() / (1024.0 * 1024.0)) / totalSeconds
                    } else 0.0

                    transferState.value = SessionState.Completed(
                        fileName = fileName,
                        fileSize = fileSize,
                        speedMBs = overallSpeed,
                        localPath = null
                    )
                    success = true

                } else {
                    // ==== LEGACY SINGLE-THREAD TRANSFERS FLOW ====
                    val resolver = context.contentResolver
                    val inputStream = resolver.openInputStream(fileUri) ?: throw Exception("Could not open file source stream")
                    val bufferedInput = BufferedInputStream(inputStream)

                    val buffer = ByteArray(16 * 1024) // 16KB raw reading window
                    var rawRead: Int
                    
                    var bytesTransferred = 0L
                    var chunkIndex = 0

                    var speedLastUpdate = startTime
                    var bytesSinceLastUpdate = 0L
                    var speedMBs = 0.0

                    while (bytesTransferred < fileSize) {
                        rawRead = bufferedInput.read(buffer)
                        if (rawRead == -1) break
                        
                        // Read piece
                        val rawPiece = if (rawRead < buffer.size) {
                            val slice = ByteArray(rawRead)
                            System.arraycopy(buffer, 0, slice, 0, rawRead)
                            slice
                        } else buffer

                        // Encrypt piece with specific IV
                        val chunkIv = CryptoManager.generateChunkIV(sessionSalt, chunkIndex)
                        val encryptedPieceBytes = CryptoManager.encryptChunk(rawPiece, key, chunkIv)

                        // Write size prefix (4 bytes) + ciphertext bytes
                        val pieceHeader = ByteBuffer.allocate(4).putInt(encryptedPieceBytes.size).array()
                        out.write(pieceHeader)
                        out.write(encryptedPieceBytes)
                        
                        bytesTransferred += rawRead
                        bytesSinceLastUpdate += rawRead
                        chunkIndex++

                        // Update speed stats
                        val now = System.currentTimeMillis()
                        val delta = now - speedLastUpdate
                        if (delta >= 400 || bytesTransferred == fileSize) {
                            speedMBs = if (delta > 0) {
                                (bytesSinceLastUpdate.toDouble() / (1024.0 * 1024.0)) / (delta.toDouble() / 1000.0)
                            } else 0.0
                            
                            speedLastUpdate = now
                            bytesSinceLastUpdate = 0L
                            
                            transferState.value = SessionState.Transferring(
                                fileName = fileName,
                                fileSize = fileSize,
                                bytesTransferred = bytesTransferred,
                                progress = bytesTransferred.toFloat() / fileSize.toFloat(),
                                speedMBs = speedMBs,
                                isSending = true
                            )
                        }
                    }

                    out.flush()
                    bufferedInput.close()
                    inputStream.close()
                    
                    val totalSeconds = (System.currentTimeMillis() - startTime) / 1000.0
                    val overallSpeed = if (totalSeconds > 0) {
                        (fileSize.toDouble() / (1024.0 * 1024.0)) / totalSeconds
                    } else 0.0

                    transferState.value = SessionState.Completed(
                        fileName = fileName,
                        fileSize = fileSize,
                        speedMBs = overallSpeed,
                        localPath = null
                    )
                    success = true
                }

            } catch (e: Exception) {
                Log.e(TAG, "Error sending file", e)
                if (attempts >= maxAttempts) {
                    transferState.value = SessionState.Failed(e.message ?: "Transfer aborted.")
                } else {
                    transferState.value = SessionState.Failed("Connection interrupted. Reconnecting (attempt $attempts/$maxAttempts)...")
                }
            } finally {
                try { socket?.close() } catch (_: Exception) {}
                activeClientSocket = null
            }
        }
    }
}
