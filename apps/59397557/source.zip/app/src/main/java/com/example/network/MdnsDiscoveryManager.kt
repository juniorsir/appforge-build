package com.example.network

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

object MdnsDiscoveryManager {
    private const val TAG = "MdnsDiscovery"
    private const val SERVICE_TYPE = "_aeroshare._tcp"

    private var nsdManager: NsdManager? = null
    private var registrationListener: NsdManager.RegistrationListener? = null
    private var discoveryListener: NsdManager.DiscoveryListener? = null

    // Represents a discovered nearby AeroShare peer
    data class DiscoveredPeer(
        val serviceName: String,
        val deviceName: String,
        val ipAddress: String,
        val pairingCode: String
    )

    private val _discoveredPeers = MutableStateFlow<List<DiscoveredPeer>>(emptyList())
    val discoveredPeers = _discoveredPeers.asStateFlow()

    private var registeredServiceName: String? = null

    // Sequential resolver queue to avoid rate limits ("already active" errors)
    private var isResolving = false
    private val resolveQueue = mutableListOf<NsdServiceInfo>()

    /**
     * Initializes the manager with context.
     */
    fun init(context: Context) {
        if (nsdManager == null) {
            nsdManager = context.applicationContext.getSystemService(Context.NSD_SERVICE) as NsdManager
        }
    }

    /**
     * Starts advertising the receiver service beacon natively over mDNS.
     */
    fun startAdvertising(pairingCode: String) {
        val manager = nsdManager ?: return
        stopAdvertising() // Clean up any active registration

        // Sanitize device model to conform to standard mDNS format
        val deviceModel = Build.MODEL.replace(" ", "_").replace("[^a-zA-Z0-9_]".toRegex(), "").take(15)
        val uniqueId = (1000..9999).random()
        val serviceNameStr = "Aero_${deviceModel}_$uniqueId"

        val serviceInfo = NsdServiceInfo().apply {
            serviceName = serviceNameStr
            serviceType = SERVICE_TYPE
            port = NetworkManager.DEFAULT_PORT
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                setAttribute("pairingCode", pairingCode)
                setAttribute("deviceName", Build.MODEL)
            }
        }

        registrationListener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(info: NsdServiceInfo) {
                Log.d(TAG, "Service registered mDNS successfully: ${info.serviceName}")
                registeredServiceName = info.serviceName
            }

            override fun onRegistrationFailed(info: NsdServiceInfo, errorCode: Int) {
                Log.e(TAG, "mDNS Service registration failed code: $errorCode")
            }

            override fun onServiceUnregistered(info: NsdServiceInfo) {
                Log.d(TAG, "mDNS Service unregistered: ${info.serviceName}")
            }

            override fun onUnregistrationFailed(info: NsdServiceInfo, errorCode: Int) {
                Log.e(TAG, "mDNS Service unregistration failed code: $errorCode")
            }
        }

        try {
            manager.registerService(serviceInfo, NsdManager.PROTOCOL_DNS_SD, registrationListener)
        } catch (e: Exception) {
            Log.e(TAG, "Exception starting mDNS registration", e)
        }
    }

    /**
     * Stops active mDNS service advertising.
     */
    fun stopAdvertising() {
        val manager = nsdManager ?: return
        val listener = registrationListener ?: return
        try {
            manager.unregisterService(listener)
        } catch (e: Exception) {
            Log.e(TAG, "Exception unregistering mDNS service", e)
        } finally {
            registrationListener = null
            registeredServiceName = null
        }
    }

    /**
     * Commences background network discovery for other AeroShare instances.
     */
    fun startDiscovery() {
        val manager = nsdManager ?: return
        stopDiscovery() // Clean up any active discovery first
        
        synchronized(resolveQueue) {
            resolveQueue.clear()
        }
        isResolving = false
        _discoveredPeers.value = emptyList()

        discoveryListener = object : NsdManager.DiscoveryListener {
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                Log.e(TAG, "Discovery start failed code: $errorCode")
                try {
                    manager.stopServiceDiscovery(this)
                } catch (_: Exception) {}
            }

            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {
                Log.e(TAG, "Discovery stop failed code: $errorCode")
            }

            override fun onDiscoveryStarted(serviceType: String) {
                Log.d(TAG, "mDNS Discovery started successfully: $serviceType")
            }

            override fun onDiscoveryStopped(serviceType: String) {
                Log.d(TAG, "mDNS Discovery stopped")
                _discoveredPeers.value = emptyList()
            }

            override fun onServiceFound(info: NsdServiceInfo) {
                Log.d(TAG, "mDNS Service found: ${info.serviceName}")
                
                // Skip resolving our own receiver instance
                if (info.serviceName == registeredServiceName) return
                
                // Verify the service matches our expected type
                if (info.serviceType.contains("aeroshare")) {
                    queueResolve(info)
                }
            }

            override fun onServiceLost(info: NsdServiceInfo) {
                Log.d(TAG, "mDNS Service lost: ${info.serviceName}")
                removePeerByName(info.serviceName)
            }
        }

        try {
            manager.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, discoveryListener)
        } catch (e: Exception) {
            Log.e(TAG, "Exception during discovery start", e)
        }
    }

    /**
     * Terminate active background service discovery.
     */
    fun stopDiscovery() {
        val manager = nsdManager ?: return
        val listener = discoveryListener ?: return
        try {
            manager.stopServiceDiscovery(listener)
        } catch (e: Exception) {
            Log.e(TAG, "Exception stopping discovery", e)
        } finally {
            discoveryListener = null
            synchronized(resolveQueue) {
                resolveQueue.clear()
            }
            isResolving = false
        }
    }

    private fun queueResolve(info: NsdServiceInfo) {
        synchronized(resolveQueue) {
            if (resolveQueue.none { it.serviceName == info.serviceName }) {
                resolveQueue.add(info)
            }
        }
        resolveNext()
    }

    private fun resolveNext() {
        val manager = nsdManager ?: return
        synchronized(resolveQueue) {
            if (isResolving || resolveQueue.isEmpty()) return
            isResolving = true
            val next = resolveQueue.removeAt(0)
            
            try {
                manager.resolveService(next, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                        Log.e(TAG, "Resolve failed for ${serviceInfo.serviceName}: $errorCode")
                        synchronized(resolveQueue) {
                            isResolving = false
                        }
                        resolveNext() // Carry on resolving subsequent entries
                    }

                    override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                        Log.d(TAG, "Service successfully resolved: ${serviceInfo.serviceName}")
                        
                        val pairingCodeBytes = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            serviceInfo.attributes["pairingCode"]
                        } else null
                        
                        val deviceNameBytes = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            serviceInfo.attributes["deviceName"]
                        } else null

                        val pairingCode = pairingCodeBytes?.let { String(it) }
                        val deviceName = deviceNameBytes?.let { String(it) } ?: serviceInfo.serviceName
                        val ipAddress = serviceInfo.host?.hostAddress

                        if (pairingCode != null && ipAddress != null) {
                            val peer = DiscoveredPeer(
                                serviceName = serviceInfo.serviceName,
                                deviceName = deviceName,
                                ipAddress = ipAddress,
                                pairingCode = pairingCode
                            )
                            addOrUpdatePeer(peer)
                        }

                        synchronized(resolveQueue) {
                            isResolving = false
                        }
                        resolveNext()
                    }
                })
            } catch (e: Exception) {
                Log.e(TAG, "Exception resolving service", e)
                isResolving = false
                resolveNext()
            }
        }
    }

    private fun addOrUpdatePeer(peer: DiscoveredPeer) {
        val currentList = _discoveredPeers.value.toMutableList()
        val index = currentList.indexOfFirst { it.serviceName == peer.serviceName }
        if (index >= 0) {
            currentList[index] = peer
        } else {
            currentList.add(peer)
        }
        _discoveredPeers.value = currentList
    }

    private fun removePeerByName(serviceName: String) {
        val currentList = _discoveredPeers.value.filter { it.serviceName != serviceName }
        _discoveredPeers.value = currentList
    }
}
