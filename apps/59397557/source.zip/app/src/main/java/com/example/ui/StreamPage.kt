package com.example.ui

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.network.QrCodeScannerView
import com.example.network.QrCodeView
import com.example.network.StreamManager
import com.example.ui.theme.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StreamPage(
    viewModel: TransferViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val coroutineScope = rememberCoroutineScope()

    val chosenFiles by viewModel.chosenFiles.collectAsStateWithLifecycle()
    val themeColorName by viewModel.appThemeColorName.collectAsStateWithLifecycle()
    val streamState by StreamManager.streamState.collectAsStateWithLifecycle()
    val activeProgressLine by StreamManager.streamingProgress.collectAsStateWithLifecycle()

    val activeColor = when (themeColorName) {
        "Tech Emerald" -> Color(0xFF006874)
        "Stealth Onyx" -> Color(0xFF111827)
        else -> Color(0xFF6750A4)
    }

    var streamTabRole by remember { mutableStateOf(0) } // 0 = Host (Sender), 1 = Connect (Receiver)
    var inputStreamingCode by remember { mutableStateOf("") }
    var cameraPermissionGranted by remember {
        mutableStateOf(
            androidx.core.content.ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.CAMERA
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        )
    }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        cameraPermissionGranted = isGranted
        if (!isGranted) {
            Toast.makeText(context, "Camera access required to scan stream QR codes.", Toast.LENGTH_SHORT).show()
        }
    }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            viewModel.selectMultipleFiles(context, uris)
        }
    }

    var showCameraScanner by remember { mutableStateOf(false) }

    // Media and Text preview Modal States
    var previewFileUrlAndBytes by remember { mutableStateOf<ByteArray?>(null) }
    var previewFileName by remember { mutableStateOf("") }
    var previewFileType by remember { mutableStateOf("") } // "text", "image", "other"
    var isFetchingOnDemand by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.Start
    ) {
        // Mode Selector Tab Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(SlateSurfaceVariant)
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (streamTabRole == 0) SlateSurface else Color.Transparent)
                    .clickable { streamTabRole = 0 }
                    .testTag("stream_tab_host"),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudQueue,
                        contentDescription = "Host Stream Mode",
                        tint = if (streamTabRole == 0) activeColor else MutedText,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Host Stream Server",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (streamTabRole == 0) activeColor else MutedText
                    )
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (streamTabRole == 1) SlateSurface else Color.Transparent)
                    .clickable { streamTabRole = 1 }
                    .testTag("stream_tab_connect"),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Launch,
                        contentDescription = "Connect to Stream",
                        tint = if (streamTabRole == 1) activeColor else MutedText,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Connect to Stream",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (streamTabRole == 1) activeColor else MutedText
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        when (streamTabRole) {
            0 -> {
                // SENDER / STREAM HOST ROLE
                when (val state = streamState) {
                    is StreamManager.StreamState.Hosting -> {
                        // SERVER SENDER SCREEN ACTIVE
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SlateSurface),
                            shape = RoundedCornerShape(24.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, PolishedBorder, RoundedCornerShape(24.dp))
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .background(TechEmerald.copy(alpha = 0.12f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CellTower,
                                        contentDescription = "Streaming Active Indicator",
                                        tint = TechEmerald,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Text(
                                    text = "On-Demand Stream Active",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = WhiteText
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                Text(
                                    text = "Sharing ${state.filesCount} file(s) without transferring them. Connected clients can view and play files in real-time.",
                                    fontSize = 11.sp,
                                    color = MutedText,
                                    lineHeight = 15.sp,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )

                                Spacer(modifier = Modifier.height(20.dp))

                                // QR Code Display
                                Box(
                                    modifier = Modifier
                                        .size(200.dp)
                                        .border(2.dp, PolishedBorder, RoundedCornerShape(16.dp))
                                        .background(Color.White)
                                        .padding(12.dp)
                                ) {
                                    QrCodeView(
                                        pairingCode = state.pairingCode,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                // Pairing Credential Box
                                Surface(
                                    color = SlateSurfaceVariant,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 14.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "STREAM HANDSHAKE PORT",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MutedText
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = state.pairingCode,
                                                fontSize = 11.sp,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.SemiBold,
                                                color = WhiteText,
                                                maxLines = 1,
                                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                            )
                                        }

                                        IconButton(
                                            onClick = {
                                                clipboardManager.setText(
                                                    androidx.compose.ui.text.AnnotatedString(
                                                        state.pairingCode
                                                    )
                                                )
                                                Toast.makeText(context, "Streaming port copied!", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Outlined.ContentCopy,
                                                contentDescription = "Copy Streaming pairing credentials",
                                                tint = activeColor,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(20.dp))

                                // Stop Broadcasting Button
                                Button(
                                    onClick = { StreamManager.stopStreamSession() },
                                    colors = ButtonDefaults.buttonColors(containerColor = SecureRed.copy(0.12f)),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(1.dp, SecureRed.copy(0.4f), RoundedCornerShape(14.dp))
                                        .height(44.dp)
                                        .testTag("stop_stream_server_button")
                                ) {
                                    Text(
                                        text = "Deactivate Stream Broker",
                                        color = SecureRed,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                    is StreamManager.StreamState.Error -> {
                        // Error Card
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SlateSurface),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, PolishedBorder, RoundedCornerShape(20.dp))
                        ) {
                            Column(modifier = Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = "Streaming error",
                                    tint = SecureRed,
                                    modifier = Modifier.size(32.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(state.message, color = WhiteText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                Spacer(modifier = Modifier.height(14.dp))
                                Button(
                                    onClick = { StreamManager.stopStreamSession() },
                                    colors = ButtonDefaults.buttonColors(containerColor = activeColor),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("Reset Session", color = Color.White)
                                }
                            }
                        }
                    }
                    StreamManager.StreamState.Idle -> {
                        if (chosenFiles.isEmpty()) {
                            // EMPTY STATE SELECT FILES FIRST
                            Card(
                                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                                shape = RoundedCornerShape(20.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, PolishedBorder, RoundedCornerShape(20.dp))
                            ) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.CloudOff,
                                        contentDescription = "No Stream Files",
                                        tint = MutedText,
                                        modifier = Modifier.size(44.dp)
                                    )
                                    Spacer(modifier = Modifier.height(14.dp))
                                    Text(
                                        text = "No Files Chosen to Stream",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = WhiteText
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Securely serve files and folder structures to nearby clients. They can list, preview, and read your items instantly on-demand without writing files on their device storage.",
                                        fontSize = 11.sp,
                                        color = MutedText,
                                        lineHeight = 15.sp,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(20.dp))

                                    Button(
                                        onClick = { filePicker.launch("*/*") },
                                        colors = ButtonDefaults.buttonColors(containerColor = activeColor),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(44.dp)
                                            .testTag("select_files_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Add,
                                            contentDescription = "Select Files",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Select Files to Stream",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                }
                            }
                        } else {
                            // SHOW FILES OFFERED LIST BEFORE STARTING
                            Card(
                                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                                shape = RoundedCornerShape(24.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, PolishedBorder, RoundedCornerShape(24.dp))
                            ) {
                                Column(modifier = Modifier.padding(18.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "Streaming Payloads Ready",
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = WhiteText
                                            )
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = "You will share ${chosenFiles.size} virtual items.",
                                                fontSize = 11.sp,
                                                color = MutedText
                                            )
                                        }

                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            TextButton(
                                                onClick = { filePicker.launch("*/*") },
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Add,
                                                    contentDescription = "Add Files",
                                                    tint = activeColor,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = "Add",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = activeColor
                                                )
                                            }

                                            TextButton(
                                                onClick = { viewModel.clearChosenFile() },
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.DeleteSweep,
                                                    contentDescription = "Clear All Files",
                                                    tint = SecureRed,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = "Clear",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = SecureRed
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    // Mini scroll list of selected payloads
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .heightIn(max = 180.dp)
                                            .verticalScroll(rememberScrollState()),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        chosenFiles.forEachIndexed { index, file ->
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .background(
                                                        SlateSurfaceVariant,
                                                        RoundedCornerShape(10.dp)
                                                    )
                                                    .padding(10.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                                            ) {
                                                val (icon, tint) = getFileIconAndColor(file.name)
                                                Icon(
                                                    imageVector = icon,
                                                    contentDescription = "File Type Icon",
                                                    tint = tint,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = file.name,
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = WhiteText,
                                                        maxLines = 1,
                                                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                                    )
                                                    Text(
                                                        text = viewModel.formatBytes(file.size),
                                                        fontSize = 9.sp,
                                                        color = MutedText
                                                    )
                                                }

                                                IconButton(
                                                    onClick = { viewModel.removeChosenFile(index) },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Delete,
                                                        contentDescription = "Remove file",
                                                        tint = SecureRed.copy(alpha = 0.8f),
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(18.dp))

                                    Button(
                                        onClick = { StreamManager.hostStreamSession(context, chosenFiles) },
                                        colors = ButtonDefaults.buttonColors(containerColor = activeColor),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(44.dp)
                                            .testTag("host_stream_active_button"),
                                        shape = RoundedCornerShape(14.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CellTower,
                                            contentDescription = "Host Stream Icon",
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Activate Stream Services",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = Color.White
                                        )
                                    }
                                }
                            }
                        }
                    }
                    is StreamManager.StreamState.Loading -> {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SlateSurface),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, PolishedBorder, RoundedCornerShape(20.dp))
                        ) {
                            Column(
                                modifier = Modifier.padding(32.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                CircularProgressIndicator(
                                    color = activeColor,
                                    modifier = Modifier.size(36.dp),
                                    strokeWidth = 3.dp
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = state.message,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = WhiteText
                                )
                            }
                        }
                    }
                    else -> {}
                }
            }

            1 -> {
                // RECEIVER / CLIENT CONSOLE ROLE
                when (val state = streamState) {
                    is StreamManager.StreamState.ClientConnected -> {
                        // CLIENT VIEW SECURE VIRTUAL STREAM DIRECTORY
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            // Connected Header Info Details
                            Card(
                                colors = CardDefaults.cardColors(containerColor = TechEmerald.copy(0.08f)),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, TechEmerald.copy(0.3f), RoundedCornerShape(16.dp))
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            text = "Securely Connected",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TechEmerald
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "Host IP: ${state.hostIp} | ${state.files.size} Available Elements",
                                            fontSize = 11.sp,
                                            color = MutedText
                                        )
                                    }

                                    IconButton(
                                        onClick = { StreamManager.stopStreamSession() },
                                        modifier = Modifier
                                            .size(32.dp)
                                            .background(
                                                SecureRed.copy(0.12f),
                                                CircleShape
                                            )
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Disconnect Stream Client",
                                            tint = SecureRed,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }

                            // Show current downloading progress or on-demand loading
                            if (isFetchingOnDemand || activeProgressLine != null) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = SlateSurfaceVariant),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        CircularProgressIndicator(
                                            color = activeColor,
                                            modifier = Modifier.size(20.dp),
                                            strokeWidth = 2.dp
                                        )
                                        Text(
                                            text = activeProgressLine ?: "Streaming from host on demand...",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = WhiteText
                                        )
                                    }
                                }
                            }

                            // Files elements listings
                            Text(
                                text = "Streamable Directories & Handsets",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MutedText
                            )

                            if (state.files.isEmpty()) {
                                Text(
                                    text = "No files currently served by host in this session segment.",
                                    fontSize = 11.sp,
                                    color = MutedText,
                                    modifier = Modifier.padding(8.dp)
                                )
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    state.files.forEach { file ->
                                        Card(
                                            colors = CardDefaults.cardColors(containerColor = SlateSurface),
                                            shape = RoundedCornerShape(14.dp),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .border(
                                                    1.dp,
                                                    PolishedBorder.copy(alpha = 0.5f),
                                                    RoundedCornerShape(14.dp)
                                                )
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                ) {
                                                    val (icon, tint) = getFileIconAndColor(file.name)
                                                    Box(
                                                        modifier = Modifier
                                                            .size(36.dp)
                                                            .background(tint.copy(0.12f), CircleShape),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Icon(
                                                            imageVector = icon,
                                                            contentDescription = "Stream Item Icon",
                                                            tint = tint,
                                                            modifier = Modifier.size(18.dp)
                                                        )
                                                    }

                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(
                                                            text = file.name,
                                                            fontSize = 12.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = WhiteText,
                                                            maxLines = 1,
                                                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                                        )
                                                        Text(
                                                            text = viewModel.formatBytes(file.size),
                                                            fontSize = 10.sp,
                                                            color = MutedText
                                                        )
                                                    }
                                                }

                                                Spacer(modifier = Modifier.height(10.dp))

                                                // Streaming action buttons based on extension
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    val ext = file.name.substringAfterLast(".", "").lowercase()
                                                    val isText = ext in listOf("txt", "log", "json", "xml", "kt", "kts", "java", "py", "html", "css", "md", "csv")
                                                    val isImage = ext in listOf("jpg", "jpeg", "png", "webp", "gif", "bmp")

                                                    if (isText) {
                                                        Button(
                                                            onClick = {
                                                                if (isFetchingOnDemand) return@Button
                                                                isFetchingOnDemand = true
                                                                coroutineScope.launch {
                                                                    val res = StreamManager.streamFileOnDemand(file.index) {}
                                                                    if (res != null) {
                                                                        previewFileUrlAndBytes = res
                                                                        previewFileName = file.name
                                                                        previewFileType = "text"
                                                                    } else {
                                                                        Toast.makeText(context, "Stream failure fetching text content", Toast.LENGTH_SHORT).show()
                                                                    }
                                                                    isFetchingOnDemand = false
                                                                }
                                                            },
                                                            colors = ButtonDefaults.buttonColors(containerColor = SlateSurfaceVariant),
                                                            shape = RoundedCornerShape(8.dp),
                                                            modifier = Modifier.weight(1f).height(30.dp),
                                                            contentPadding = PaddingValues(0.dp)
                                                        ) {
                                                            Icon(Icons.Default.ReadMore, contentDescription = "Stream text", tint = activeColor, modifier = Modifier.size(12.dp))
                                                            Spacer(modifier = Modifier.width(4.dp))
                                                            Text("Read Text", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = activeColor)
                                                        }
                                                    }

                                                    if (isImage) {
                                                        Button(
                                                            onClick = {
                                                                if (isFetchingOnDemand) return@Button
                                                                isFetchingOnDemand = true
                                                                coroutineScope.launch {
                                                                    val res = StreamManager.streamFileOnDemand(file.index) {}
                                                                    if (res != null) {
                                                                        previewFileUrlAndBytes = res
                                                                        previewFileName = file.name
                                                                        previewFileType = "image"
                                                                    } else {
                                                                        Toast.makeText(context, "Stream failure fetching image content", Toast.LENGTH_SHORT).show()
                                                                    }
                                                                    isFetchingOnDemand = false
                                                                }
                                                            },
                                                            colors = ButtonDefaults.buttonColors(containerColor = SlateSurfaceVariant),
                                                            shape = RoundedCornerShape(8.dp),
                                                            modifier = Modifier.weight(1f).height(30.dp),
                                                            contentPadding = PaddingValues(0.dp)
                                                        ) {
                                                            Icon(Icons.Default.Visibility, contentDescription = "Raw Stream preview image", tint = activeColor, modifier = Modifier.size(12.dp))
                                                            Spacer(modifier = Modifier.width(4.dp))
                                                            Text("Raw Preview", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = activeColor)
                                                        }
                                                    }

                                                    // Standard Download Button (always available)
                                                    Button(
                                                        onClick = {
                                                            if (isFetchingOnDemand) return@Button
                                                            isFetchingOnDemand = true
                                                            coroutineScope.launch {
                                                                val res = StreamManager.streamFileOnDemand(file.index) {}
                                                                if (res != null) {
                                                                    val downloadDest = getUniqueDownloadFile(file.name)
                                                                    withContext(Dispatchers.IO) {
                                                                        downloadDest.writeBytes(res)
                                                                    }
                                                                    Toast.makeText(context, "Stream downloaded: ${downloadDest.name}", Toast.LENGTH_LONG).show()
                                                                    com.example.notification.NotificationHelper.showNotification(
                                                                        title = "Stream Saved Successfully",
                                                                        message = "File: ${downloadDest.name} has been saved."
                                                                    )
                                                                } else {
                                                                    Toast.makeText(context, "Download stream failed", Toast.LENGTH_SHORT).show()
                                                                    com.example.notification.NotificationHelper.showNotification(
                                                                        title = "Stream Flow Interrupted",
                                                                        message = "Streaming ${file.name} failed to complete on-demand.",
                                                                        isError = true
                                                                    )
                                                                }
                                                                isFetchingOnDemand = false
                                                            }
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = activeColor.copy(0.1f)),
                                                        shape = RoundedCornerShape(8.dp),
                                                        modifier = Modifier.weight(1f).height(30.dp),
                                                        contentPadding = PaddingValues(0.dp)
                                                    ) {
                                                        Icon(Icons.Default.Download, contentDescription = "Download fully", tint = activeColor, modifier = Modifier.size(12.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("Get File", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = activeColor)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    is StreamManager.StreamState.Loading -> {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SlateSurface),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, PolishedBorder, RoundedCornerShape(20.dp))
                        ) {
                            Column(
                                modifier = Modifier.padding(32.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                CircularProgressIndicator(
                                    color = activeColor,
                                    modifier = Modifier.size(36.dp),
                                    strokeWidth = 3.dp
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = state.message,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = WhiteText
                                )
                            }
                        }
                    }
                    is StreamManager.StreamState.Error -> {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SlateSurface),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, PolishedBorder, RoundedCornerShape(20.dp))
                        ) {
                            Column(modifier = Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = "Streaming error",
                                    tint = SecureRed,
                                    modifier = Modifier.size(32.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(state.message, color = WhiteText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                Spacer(modifier = Modifier.height(14.dp))
                                Button(
                                    onClick = { StreamManager.stopStreamSession() },
                                    colors = ButtonDefaults.buttonColors(containerColor = activeColor),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("Dismiss", color = Color.White)
                                }
                            }
                        }
                    }
                    StreamManager.StreamState.Idle -> {
                        // DETAILED CONNECT ENTRY SCREEN
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SlateSurface),
                            shape = RoundedCornerShape(24.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, PolishedBorder, RoundedCornerShape(24.dp))
                        ) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .background(activeColor.copy(0.12f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.WifiTethering,
                                        contentDescription = "Stream Connection Area",
                                        tint = activeColor,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Text(
                                    text = "Bridge Stream Handshake",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = WhiteText
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                Text(
                                    text = "Enter raw stream credentials or execute a scan on the host QR to begin reading local catalogs securely.",
                                    fontSize = 11.sp,
                                    color = MutedText,
                                    lineHeight = 15.sp
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                OutlinedTextField(
                                    value = inputStreamingCode,
                                    onValueChange = { inputStreamingCode = it },
                                    label = { Text("Stream Handshake Key", fontSize = 12.sp) },
                                    placeholder = { Text("AEROSHARE_STREAM|ip|port|key...", fontSize = 11.sp) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("stream_pairing_input"),
                                    singleLine = true,
                                    shape = RoundedCornerShape(12.dp),
                                    keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Done),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = activeColor,
                                        unfocusedBorderColor = PolishedBorder
                                    )
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                // Credentials Utility Row
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            val clipText = clipboardManager.getText()?.text
                                            if (!clipText.isNullOrBlank()) {
                                                inputStreamingCode = clipText
                                                Toast.makeText(context, "Handshake code pasted!", Toast.LENGTH_SHORT).show()
                                            } else {
                                                Toast.makeText(context, "Clipboard is empty", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = SlateSurfaceVariant),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f).height(38.dp),
                                        contentPadding = PaddingValues(0.dp)
                                    ) {
                                        Icon(Icons.Default.ContentPaste, contentDescription = "Paste Code", tint = WhiteText, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Paste", color = WhiteText, fontSize = 11.sp)
                                    }

                                    Button(
                                        onClick = {
                                            if (cameraPermissionGranted) {
                                                showCameraScanner = true
                                            } else {
                                                launcher.launch(android.Manifest.permission.CAMERA)
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = SlateSurfaceVariant),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f).height(38.dp),
                                        contentPadding = PaddingValues(0.dp)
                                    ) {
                                        Icon(Icons.Default.QrCodeScanner, contentDescription = "Scan Stream QR Code", tint = WhiteText, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Scan QR", color = WhiteText, fontSize = 11.sp)
                                    }
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                Button(
                                    onClick = {
                                        if (inputStreamingCode.isBlank()) {
                                            Toast.makeText(context, "Please provide valid streaming pairing credentials.", Toast.LENGTH_SHORT).show()
                                        } else {
                                            StreamManager.connectToStreamHost(inputStreamingCode.trim())
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = activeColor),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(44.dp)
                                        .testTag("stream_connect_submit_button")
                                ) {
                                    Icon(Icons.Default.Link, contentDescription = "Link Stream", tint = Color.White, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Verify & Connect", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                                }
                            }
                        }
                    }
                    else -> {}
                }
            }
        }
    }

    // Camera Scan overlay modal
    if (showCameraScanner) {
        Dialog(
            onDismissRequest = { showCameraScanner = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
            ) {
                QrCodeScannerView(
                    onCodeScanned = { code ->
                        inputStreamingCode = code
                        showCameraScanner = false
                        Toast.makeText(context, "Stream QR Scanned successfully!", Toast.LENGTH_SHORT).show()
                    },
                    onClose = { showCameraScanner = false }
                )
            }
        }
    }

    // Media and Text view preview Dialogs
    previewFileUrlAndBytes?.let { bytes ->
        Dialog(
            onDismissRequest = {
                previewFileUrlAndBytes = null
                previewFileName = ""
                previewFileType = ""
            },
            properties = DialogProperties(dismissOnBackPress = true, dismissOnClickOutside = false)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .fillMaxHeight(0.85f)
                    .border(1.dp, PolishedBorder, RoundedCornerShape(20.dp))
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Header Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "On-Demand Resource Stream",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MutedText
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = previewFileName,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = WhiteText,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                            )
                        }

                        IconButton(
                            onClick = {
                                previewFileUrlAndBytes = null
                                previewFileName = ""
                                previewFileType = ""
                            }
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close Preview Dialog", tint = WhiteText)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .background(SlateBg)
                            .padding(14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (previewFileType == "text") {
                            // Text contents view
                            val textContent = remember(bytes) { String(bytes, Charsets.UTF_8) }
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(SlateSurfaceVariant, RoundedCornerShape(8.dp))
                                    .verticalScroll(rememberScrollState())
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = textContent,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = WhiteText,
                                    lineHeight = 16.sp
                                )
                            }
                        } else if (previewFileType == "image") {
                            // Image content view
                            val bitmap = remember(bytes) {
                                try {
                                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                } catch (e: Exception) {
                                    null
                                }
                            }
                            if (bitmap != null) {
                                Image(
                                    bitmap = bitmap.asImageBitmap(),
                                    contentDescription = "Decrypted raw stream preview metadata image",
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(RoundedCornerShape(8.dp)),
                                    contentScale = ContentScale.Fit
                                )
                            } else {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.BrokenImage, contentDescription = "Broken Image", tint = SecureRed, modifier = Modifier.size(44.dp))
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text("Failed to compile image bytes", color = MutedText, fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    // Action elements at bottom
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                clipboardManager.setText(
                                    androidx.compose.ui.text.AnnotatedString(
                                        if (previewFileType == "text") String(bytes, Charsets.UTF_8) else previewFileName
                                    )
                                )
                                Toast.makeText(context, if (previewFileType == "text") "Transcribed text copied!" else "File name copied!", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SlateSurfaceVariant),
                            modifier = Modifier.weight(1f).height(40.dp),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy Content", tint = WhiteText, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Copy Content", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = WhiteText)
                        }

                        Button(
                            onClick = {
                                val dlFile = getUniqueDownloadFile(previewFileName)
                                try {
                                    dlFile.writeBytes(bytes)
                                    Toast.makeText(context, "Saved stream content to Downloads folder!", Toast.LENGTH_LONG).show()
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Failed to download preview: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = activeColor),
                            modifier = Modifier.weight(1f).height(40.dp),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Download, contentDescription = "Download Resource", tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Download File", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

/**
 * Checks and resolves unique unused download filename inside Android Downloads folder
 */
fun getUniqueDownloadFile(fileName: String): File {
    val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
    if (!downloadsDir.exists()) downloadsDir.mkdirs()
    var target = File(downloadsDir, fileName)
    if (!target.exists()) return target

    val nameWithoutExt = fileName.substringBeforeLast(".")
    val ext = fileName.substringAfterLast(".", "")
    val extSuffix = if (ext.isNotEmpty()) ".$ext" else ""
    var counter = 1
    while (target.exists()) {
        target = File(downloadsDir, "$nameWithoutExt($counter)$extSuffix")
        counter++
    }
    return target
}

/**
 * Self contained duplicate helper of layout icons and types configuration
 */
private fun getFileIconAndColor(fileName: String): Pair<ImageVector, Color> {
    val ext = fileName.substringAfterLast(".", "").lowercase()
    return when (ext) {
        "pdf" -> Icons.Default.PictureAsPdf to Color(0xFFE53935)
        "png", "jpg", "jpeg", "gif", "webp", "bmp", "svg" -> Icons.Default.Image to Color(0xFF1E88E5)
        "mp4", "mkv", "avi", "mov", "flv", "webm", "3gp" -> Icons.Default.VideoFile to Color(0xFF8E24AA)
        "mp3", "wav", "ogg", "flac", "m4a", "aac" -> Icons.Default.AudioFile to Color(0xFF00ACC1)
        "txt", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "rtf", "md" -> Icons.Default.Description to Color(0xFF43A047)
        "zip", "rar", "7z", "tar", "gz" -> Icons.Default.FolderZip to Color(0xFFFDD835)
        "js", "ts", "html", "css", "json", "xml", "kt", "kts", "java", "py", "cpp", "c", "sh" -> Icons.Default.Code to Color(0xFFF4511E)
        else -> Icons.Default.InsertDriveFile to Color(0xFF9E9E9E)
    }
}
