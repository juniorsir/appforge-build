package com.example.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object NotificationHelper {
    private const val CHANNEL_ID = "aeroshare_transfer_channel"
    private const val CHANNEL_NAME = "AeroShare Transfers"
    private const val NOTIFICATION_ID = 4001
    private const val PROGRESS_NOTIFICATION_ID = 4002

    private var appContext: Context? = null
    var isAppInForeground: Boolean = false
    private var lastProgressUpdateTime: Long = 0

    fun init(context: Context) {
        val appCtx = context.applicationContext
        appContext = appCtx

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Secure peer-to-peer file transfer status alerts"
            }
            val channelProgress = NotificationChannel(
                CHANNEL_ID + "_progress",
                CHANNEL_NAME + " Progress",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "File transfer progress"
            }
            val manager = appCtx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
            manager.createNotificationChannel(channelProgress)
            Log.d("NotificationHelper", "Notification channel created: $CHANNEL_ID")
        }
    }

    fun showProgressNotification(fileName: String, progress: Float) {
        val ctx = appContext ?: return
        
        // Always show or keep progress updating even in background, but we can rate limit
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastProgressUpdateTime < 500 && progress < 1.0f) {
            return
        }
        lastProgressUpdateTime = currentTime

        try {
            val progressInt = (progress * 100).toInt()
            val text = "Transferring: $fileName ($progressInt%)"
            
            val builder = NotificationCompat.Builder(ctx, CHANNEL_ID + "_progress")
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("File Transfer in Progress")
                .setContentText(text)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setProgress(100, progressInt, false)

            val manager = NotificationManagerCompat.from(ctx)

            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
                androidx.core.content.ContextCompat.checkSelfPermission(
                    ctx,
                    android.Manifest.permission.POST_NOTIFICATIONS
                ) == android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                manager.notify(PROGRESS_NOTIFICATION_ID, builder.build())
            }
        } catch (e: Exception) {
            Log.e("NotificationHelper", "Error posting progress notification", e)
        }
    }

    fun clearProgressNotification() {
        val ctx = appContext ?: return
        try {
            val manager = NotificationManagerCompat.from(ctx)
            manager.cancel(PROGRESS_NOTIFICATION_ID)
        } catch (e: Exception) {
            Log.e("NotificationHelper", "Error clearing progress", e)
        }
    }

    fun showNotification(title: String, message: String, isError: Boolean = false) {
        val ctx = appContext ?: return
        
        // Only deliver alerts when the app is in the background
        if (isAppInForeground) {
            Log.d("NotificationHelper", "App is in foreground. Skipping alert delivery: $title - $message")
            return
        }

        try {
            val builder = NotificationCompat.Builder(ctx, CHANNEL_ID)
                .setSmallIcon(if (isError) android.R.drawable.stat_notify_error else android.R.drawable.stat_sys_download_done)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)

            val manager = NotificationManagerCompat.from(ctx)

            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
                androidx.core.content.ContextCompat.checkSelfPermission(
                    ctx,
                    android.Manifest.permission.POST_NOTIFICATIONS
                ) == android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                val notifyId = System.currentTimeMillis().toInt()
                manager.notify(notifyId, builder.build())
                Log.d("NotificationHelper", "Notification posted: $title with id: $notifyId")
            } else {
                Log.w("NotificationHelper", "Notification skipped: Permission not granted")
            }
        } catch (e: Exception) {
            Log.e("NotificationHelper", "Error posting notification", e)
        }
    }
}
