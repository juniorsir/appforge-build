package com.example.network

import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import java.util.Hashtable
import com.google.zxing.EncodeHintType

object QrCodeGenerator {
    /**
     * Generates a 2D boolean array representing the QR code matrix for a string.
     */
    fun generateQrMatrix(content: String, size: Int = 40): Array<BooleanArray>? {
        return try {
            val writer = QRCodeWriter()
            val hints = Hashtable<EncodeHintType, Any>().apply {
                put(EncodeHintType.MARGIN, 1) // Minimize margin for tight grids
            }
            val bitMatrix = writer.encode(content, BarcodeFormat.QR_CODE, size, size, hints)
            val matrix = Array(bitMatrix.height) { y ->
                BooleanArray(bitMatrix.width) { x ->
                    bitMatrix.get(x, y)
                }
            }
            matrix
        } catch (e: Exception) {
            null
        }
    }
}
