package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TransferDao {
    @Query("SELECT * FROM transfer_events ORDER BY timestamp DESC")
    fun getAllTransfers(): Flow<List<TransferEvent>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransfer(event: TransferEvent)

    @Query("DELETE FROM transfer_events")
    suspend fun clearHistory()

    @Delete
    suspend fun deleteTransfer(event: TransferEvent)
}
